"""Launcher do Carry (como os launchers de jogo): arte do seu main, novidades da versao, status do cliente do LoL,
seu elo e o botao JOGAR (abre o cliente da Riot e liga o overlay)."""
import html
import json
import os
import subprocess
import time

e = lambda x: html.escape("" if x is None else str(x))
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TIER_PT = {"IRON": "Ferro", "BRONZE": "Bronze", "SILVER": "Prata", "GOLD": "Ouro", "PLATINUM": "Platina", "EMERALD": "Esmeralda",
           "DIAMOND": "Diamante", "MASTER": "Mestre", "GRANDMASTER": "Grão-Mestre", "CHALLENGER": "Desafiante"}


# ---------------- cliente da Riot ----------------
def _riot_client():
    """Caminho do RiotClientServices.exe (o instalador da Riot grava em ProgramData)."""
    cands = []
    try:
        with open(r"C:\ProgramData\Riot Games\RiotClientInstalls.json", encoding="utf-8") as fh:
            d = json.load(fh)
        cands += [d.get(k) for k in ("rc_live", "rc_default", "rc_beta") if d.get(k)]
    except Exception:
        pass
    cands += [r"C:\Riot Games\Riot Client\RiotClientServices.exe", r"D:\Riot Games\Riot Client\RiotClientServices.exe"]
    return next((c for c in cands if c and os.path.exists(c)), None)


def client_state():
    """('fechado' | 'aberto' | 'fila' | 'selecao' | 'partida', texto)."""
    try:
        from . import lcu
        ph = lcu.LCU.discover().gameflow_phase()
    except Exception:
        ph = None
    if ph is None:
        return "fechado", "Fechado"
    if ph in ("InProgress", "GameStart", "Reconnect"):
        return "partida", "Em partida"
    if ph == "ChampSelect":
        return "selecao", "Seleção de campeões"
    if ph in ("Matchmaking", "ReadyCheck", "Lobby"):
        return "fila", "Na fila" if ph != "Lobby" else "No saguão"
    return "aberto", "Aberto"


def abrir_lol():
    """Abre o League of Legends pelo cliente da Riot (o mesmo atalho do Windows). Nao digita nada nem faz login."""
    st, _ = client_state()
    if st != "fechado":
        return True, "O League of Legends já está aberto."
    exe = _riot_client()
    if not exe:
        return False, "Não achei o cliente da Riot neste PC. Abra o League of Legends pelo atalho de sempre."
    try:
        subprocess.Popen([exe, "--launch-product=league_of_legends", "--launch-patchline=live"],
                         creationflags=0x08000000 if os.name == "nt" else 0)
        return True, "Abrindo o League of Legends…"
    except Exception as ex:
        return False, f"Não deu para abrir o LoL ({type(ex).__name__})."


# ---------------- pagina ----------------
def _novidades():
    try:
        with open(os.path.join(RAIZ, "NOVIDADES.json"), encoding="utf-8") as fh:
            d = json.load(fh)
        return d.get("versao"), [n for n in d.get("notas") or [] if n]
    except Exception:
        return None, []


def _slides(ctx):
    v, notas = _novidades()
    out = []
    if notas:
        out.append({"tag": "Novidades", "sub": f"Versão {v}", "title": "O que mudou no Carry",
                    "text": notas[0], "more": notas[1:6], "img": ctx.get("art")})
    if ctx.get("missao"):
        out.append({"tag": "Missão de hoje", "sub": ctx.get("missao_sub") or "", "title": ctx["missao"],
                    "text": ctx.get("missao_txt") or "", "more": [], "img": ctx.get("art2") or ctx.get("art"), "href": "/habitos"})
    if ctx.get("falta") is not None:
        out.append({"tag": "Caminho", "sub": f"rumo ao {ctx.get('alvo') or 'Mestre'}", "title": f"Faltam {ctx['falta']} PDL",
                    "text": "O que encurta é ganhar mais, não jogar mais. Veja o ritmo e o que mais pesa nos seus jogos.",
                    "more": [], "img": ctx.get("art3") or ctx.get("art"), "href": "/"})
    return out


def page_html(ctx, mark_svg, msg=None):
    slides = _slides(ctx)
    tier = ctx.get("tier")
    elo = (f"{TIER_PT.get(tier, tier)} {ctx.get('division') or ''}".strip() + f" · {ctx.get('lp') or 0} PDL") if tier else "Sem elo"
    cst, ctxt = ctx.get("client", ("fechado", "Fechado"))
    ov = ctx.get("overlay")
    upd = ctx.get("update")
    sl_html = ""
    for i, s in enumerate(slides):
        more = "".join(f"<li>{e(x)}</li>" for x in s.get("more") or [])
        sl_html += (f"<article class='sl' data-i='{i}'{'' if i == 0 else ' hidden'}>"
                    f"<div class='th' style=\"background-image:url('{e(s.get('img') or '')}')\"></div>"
                    f"<div class='tx'><p class='tg'><b>{e(s['tag'])}</b><i></i><span>{e(s['sub'])}</span></p>"
                    f"<h3>{e(s['title'])}</h3><p class='ds'>{e(s['text'])}</p>"
                    + (f"<details><summary>Ver tudo</summary><ul>{more}</ul></details>" if more else
                       (f"<a class='rd' href='{e(s['href'])}'>Abrir <span aria-hidden='true'>↗</span></a>" if s.get("href") else ""))
                    + "</div></article>")
    n = max(1, len(slides))
    dots = "".join(f"<i{' class=on' if i == 0 else ''}></i>" for i in range(n))
    status = ("<span class='dot up'></span><div><b>Atualização pronta</b><small>versão " + e(upd) + " · <a href='/'>atualizar no app</a></small></div>") if upd else \
        ("<span class='dot'></span><div><b>Pronto</b><small>" + e(ctx.get("sync") or "Dados em dia") + "</small></div>")
    return f"""<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Carry · Launcher</title><style>
@font-face{{font-family:'BC';src:url(/static/fonts/barlow-condensed-latin-800-normal.woff2) format('woff2');font-weight:800}}
@font-face{{font-family:'BC';src:url(/static/fonts/barlow-condensed-latin-700-normal.woff2) format('woff2');font-weight:700}}
@font-face{{font-family:'BC';src:url(/static/fonts/barlow-condensed-latin-600-normal.woff2) format('woff2');font-weight:600}}
@font-face{{font-family:'CP';src:url(/static/fonts/chakra-petch-latin-600-normal.woff2) format('woff2');font-weight:600}}
@font-face{{font-family:'CP';src:url(/static/fonts/chakra-petch-latin-700-normal.woff2) format('woff2');font-weight:700}}
@font-face{{font-family:'BL';src:url(/static/fonts/barlow-latin-400-normal.woff2) format('woff2');font-weight:400}}
@font-face{{font-family:'BL';src:url(/static/fonts/barlow-latin-600-normal.woff2) format('woff2');font-weight:600}}
:root{{--bg:#07070B;--bar:#0B0B11;--line:#1F2030;--line2:#2C2D40;--ink:#F2EEF6;--mute:#8F8AA0;--red:#E0263A;--red2:#B3121F;--gold:#D9B45A;--ok:#6FCB98;
--h:'BC','Bahnschrift','Arial Narrow',sans-serif;--t:'CP','Bahnschrift',monospace;--b:'BL','Segoe UI',sans-serif;color-scheme:dark}}
*{{box-sizing:border-box}}[hidden]{{display:none!important}}html,body{{height:100%;margin:0}}
body{{background:var(--bg);color:var(--ink);font:400 14px/1.45 var(--b);display:grid;grid-template-rows:64px 1fr 108px;overflow:hidden;-webkit-font-smoothing:antialiased}}
a{{color:inherit}}
/* topo */
.top{{display:flex;align-items:stretch;border-bottom:1px solid var(--line);background:var(--bar)}}
.brand{{display:flex;align-items:center;gap:10px;padding:0 26px;text-decoration:none}}
.brand b{{font:800 25px/1 var(--h);letter-spacing:.03em}}
.brand small{{display:block;font:600 8.5px var(--t);letter-spacing:.24em;color:var(--mute);margin-top:2px}}
.tabs{{display:flex;align-items:stretch;border-left:1px solid var(--line);padding-left:10px}}
.tabs a{{display:flex;align-items:center;padding:0 16px;font:700 12px var(--t);letter-spacing:.16em;text-transform:uppercase;color:var(--mute);text-decoration:none;position:relative}}
.tabs a[aria-current]{{color:var(--ink)}}.tabs a[aria-current]::after{{content:'';position:absolute;left:16px;right:16px;bottom:16px;height:2px;background:var(--red)}}
.tabs a:hover{{color:var(--ink)}}
.tr{{margin-left:auto;display:flex}}
.tr>*{{display:flex;align-items:center;gap:8px;padding:0 22px;border-left:1px solid var(--line);font:700 11.5px var(--t);letter-spacing:.14em;text-transform:uppercase;color:var(--mute);text-decoration:none}}
.tr a:hover{{color:var(--ink)}}
/* palco */
.hero{{position:relative;overflow:hidden;min-height:0}}
.art{{position:absolute;inset:0;background:center 22%/cover no-repeat;opacity:.95}}
.art::after{{content:'';position:absolute;inset:0;background:linear-gradient(90deg,var(--bg) 18%,rgba(7,7,11,.82) 38%,rgba(7,7,11,.18) 70%,rgba(7,7,11,.55)),linear-gradient(0deg,var(--bg) 0,rgba(7,7,11,0) 38%)}}
.stripe{{position:absolute;right:16%;top:-20%;width:150px;height:150%;background:linear-gradient(180deg,rgba(224,38,58,.0),rgba(224,38,58,.55) 45%,rgba(224,38,58,.15));transform:rotate(32deg);mix-blend-mode:screen}}
.stripe.b{{right:8%;width:46px;opacity:.6}}
.ghost{{position:absolute;right:4%;top:6%;width:min(36vw,460px);opacity:.07}}
.in{{position:relative;height:100%;display:grid;grid-template-rows:auto 1fr auto;padding:44px 48px 26px;max-width:1500px}}
.eb{{display:flex;align-items:center;gap:14px;font:700 11.5px var(--t);letter-spacing:.22em;text-transform:uppercase;color:#CFCADA}}
.eb i{{width:34px;height:1px;background:var(--red)}}
.wm{{align-self:center;display:flex;align-items:center;gap:0;margin:-6px 0 0 -8px}}
.wm svg{{width:clamp(90px,min(15vw,22vh),210px);height:auto;filter:drop-shadow(0 8px 30px rgba(224,38,58,.35));margin-right:-6px}}
.wm h1{{margin:0;font:800 clamp(90px,min(15.5vw,25vh),236px)/.8 var(--h);letter-spacing:.005em;text-transform:uppercase}}
.tl{{margin:14px 0 0 6px;font:800 clamp(26px,2.6vw,38px)/1 var(--h);letter-spacing:.02em;text-transform:uppercase}}
.tl span{{color:var(--red)}}
/* novidades */
.news{{border-top:1px solid var(--line2);padding-top:16px;display:grid;grid-template-columns:1fr auto;gap:10px 30px;align-items:end;max-width:1180px}}
.news>p{{grid-column:1/-1;margin:0;font:700 11px var(--t);letter-spacing:.22em;color:var(--mute);text-transform:uppercase}}
.sl{{display:grid;grid-template-columns:168px 1fr;gap:22px;align-items:start;min-width:0}}
.th{{height:96px;background:center/cover #15151F;border:1px solid var(--line2)}}
.tx{{min-width:0}}
.tg{{margin:0;display:flex;align-items:center;gap:10px;font:700 11px var(--t);letter-spacing:.14em;text-transform:uppercase}}
.tg b{{color:var(--red)}}.tg i{{width:20px;height:1px;background:var(--line2)}}.tg span{{color:var(--mute)}}
.tx h3{{margin:5px 0 2px;font:700 26px/1.05 var(--h);text-transform:uppercase;letter-spacing:.01em}}
.ds{{margin:0;color:#BDB8CA;max-width:72ch;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}}
details{{margin-top:6px}}summary,.rd{{cursor:pointer;font:700 11.5px var(--t);letter-spacing:.14em;text-transform:uppercase;color:var(--ink);text-decoration:none;list-style:none}}
summary::after{{content:' ↗';color:var(--red)}}.rd span{{color:var(--red)}}
details ul{{margin:8px 0 0;padding-left:18px;color:#BDB8CA;max-height:120px;overflow:auto}}
.nav{{display:grid;gap:12px;justify-items:end}}
.cnt{{font:700 12px var(--t);letter-spacing:.1em;color:var(--mute)}}.cnt b{{color:var(--ink)}}
.dots{{display:flex;gap:6px}}.dots i{{width:28px;height:2px;background:var(--line2)}}.dots i.on{{background:var(--red)}}
.arr{{display:flex;gap:8px}}.arr button{{width:46px;height:42px;background:rgba(7,7,11,.6);border:1px solid var(--line2);color:var(--ink);font:600 18px var(--b);cursor:pointer}}
.arr button:hover{{border-color:var(--ink)}}
/* barra de baixo */
.bot{{display:grid;grid-template-columns:minmax(220px,1.1fr) minmax(220px,1.3fr) minmax(220px,1.3fr) auto auto minmax(250px,1fr);border-top:1px solid var(--line);background:var(--bar)}}
.bot>*{{display:flex;align-items:center;gap:14px;padding:0 26px;border-right:1px solid var(--line);min-width:0}}
.bot b{{display:block;font:700 15px var(--t);letter-spacing:.06em;text-transform:uppercase}}
.bot small{{display:block;color:var(--mute);font:500 11.5px var(--b);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}
.bot small.k{{font:700 9.5px var(--t);letter-spacing:.16em;text-transform:uppercase}}
.dot{{width:10px;height:10px;border-radius:50%;background:var(--ok);box-shadow:0 0 0 4px rgba(111,203,152,.16);flex:none}}
.dot.up{{background:var(--gold);box-shadow:0 0 0 4px rgba(217,180,90,.16)}}
.dot.off{{background:#5A5868;box-shadow:none}}
.chip{{margin-left:auto;font:700 10px var(--t);letter-spacing:.14em;border:1px solid #4C6A3E;color:#B6E39A;padding:3px 7px}}
.chip.off{{border-color:var(--line2);color:var(--mute)}}
.ic{{width:74px;justify-content:center;padding:0;text-decoration:none;color:var(--mute)}}.ic:hover{{color:var(--ink)}}
.ic svg{{width:22px;height:22px}}.ic.on{{color:var(--ok)}}
.play{{border:0;padding:0}}
.play form{{width:100%;height:100%;margin:0}}
.play button{{width:100%;height:100%;border:0;background:var(--red);color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:space-between;padding:0 30px;text-align:left;transition:background .15s}}
.play button:hover{{background:#F23447}}.play button:active{{background:var(--red2)}}
.play small{{color:rgba(255,255,255,.75)!important;font:700 9.5px var(--t)!important;letter-spacing:.16em;text-transform:uppercase}}
.play b{{font:800 32px/1 var(--h)!important;letter-spacing:.03em}}
.play svg{{width:26px;height:26px}}
.msg{{position:absolute;right:48px;top:28px;background:rgba(7,7,11,.85);border:1px solid var(--line2);border-left:3px solid var(--red);padding:10px 14px;font:600 13px var(--b);z-index:3}}
:focus-visible{{outline:2px solid var(--gold);outline-offset:2px}}
@media (max-height:760px){{.in{{padding-top:26px}}.th{{height:76px}}.sl{{grid-template-columns:130px 1fr}}}}
@media (max-width:1180px){{.bot{{grid-template-columns:1fr 1fr 1fr auto minmax(210px,1fr)}}.bot .elo{{display:none}}}}
@media (prefers-reduced-motion:no-preference){{.wm,.tl,.eb{{animation:up .7s cubic-bezier(.2,.7,.2,1) both}}.tl{{animation-delay:.08s}}.wm svg{{animation:spin 1.2s cubic-bezier(.2,.7,.2,1) both}}
@keyframes up{{from{{opacity:0;transform:translateY(14px)}}}}@keyframes spin{{from{{transform:rotate(-120deg) scale(.6);opacity:0}}}}}}
</style></head><body>
<header class="top">
  <a class="brand" href="/launcher">{mark_svg(38, 'lt')}<span><b>CARRY</b><small>COACH DE LOL</small></span></a>
  <div class="tr"><a href="/reportar">Status e ajuda <span aria-hidden="true">↗</span></a><span>PT-BR</span><span>Versão {e(ctx.get('versao') or '')}</span></div>
</header>
<main class="hero">
  <div class="art" style="background-image:url('{e(ctx.get('art') or '')}')"></div>
  <div class="stripe"></div><div class="stripe b"></div>
  <div class="ghost" aria-hidden="true">{mark_svg(460, 'lg')}</div>
  {f"<div class='msg' role='status'>{e(msg)}</div>" if msg else ""}
  <div class="in">
    <p class="eb">Carry<i></i>Coach de League of Legends<i></i>{e(ctx.get('who') or '')}</p>
    <div>
      <div class="wm">{mark_svg(200, 'wm')}<h1>Carry</h1></div>
      <p class="tl">Quem treina, <span>carrega.</span></p>
    </div>
    <section class="news" aria-label="Últimas do Carry">
      <p>Últimas do Carry</p>
      <div class="slides">{sl_html or "<p class='ds'>Sem novidades.</p>"}</div>
      <div class="nav"><span class="cnt"><b id="ci">01</b> / {n:02d}</span><div class="dots">{dots}</div>
        <div class="arr"><button type="button" id="pv" aria-label="Anterior">←</button><button type="button" id="nx" aria-label="Próximo">→</button></div></div>
    </section>
  </div>
</main>
<footer class="bot">
  <div>{status}</div>
  <div><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true" style="color:var(--mute);flex:none"><path d="M4 18a8 8 0 1 1 16 0"/><path d="M12 18l4-6"/></svg>
    <div style="min-width:0"><small class="k">Cliente do LoL</small><b>{e(ctxt)}</b></div>
    <span class="chip{'' if cst == 'partida' else ' off'}">{'AO VIVO' if cst == 'partida' else ('ABERTO' if cst != 'fechado' else 'FECHADO')}</span></div>
  <div class="elo"><span class="dot{'' if tier else ' off'}" style="background:var(--gold);box-shadow:0 0 0 4px rgba(217,180,90,.14)"></span>
    <div style="min-width:0"><small class="k">Solo/Duo</small><b>{e(elo)}</b><small>{e(ctx.get('hoje') or '')}</small></div></div>
  <a class="ic{' on' if ov else ''}" href="/overlay" title="{'Overlay ligado' if ov else 'Overlay desligado'}: editar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="13" rx="1"/><path d="M8 21h8M12 17v4"/></svg></a>
  <a class="ic" href="/conta" title="Conta e ajustes"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/></svg></a>
  <div class="play"><form method="post" action="/launcher/jogar"><button type="submit">
    <span><small>{'Partida em andamento' if cst == 'partida' else 'League of Legends + overlay'}</small><b>{'ACOMPANHAR' if cst == 'partida' else 'JOGAR'}</b></span>
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M7 4.5v15a1 1 0 0 0 1.5.86l12-7.5a1 1 0 0 0 0-1.72l-12-7.5A1 1 0 0 0 7 4.5z"/></svg></button></form></div>
</footer>
<script>(function(){{var S=document.querySelectorAll('.sl'),D=document.querySelectorAll('.dots i'),c=document.getElementById('ci'),k=0,t;
function go(n){{if(!S.length)return;k=(n+S.length)%S.length;S.forEach(function(s,i){{s.hidden=i!==k}});D.forEach(function(d,i){{d.className=i===k?'on':''}});c.textContent=('0'+(k+1)).slice(-2)}}
function auto(){{clearInterval(t);t=setInterval(function(){{go(k+1)}},9000)}}
document.getElementById('nx').onclick=function(){{go(k+1);auto()}};document.getElementById('pv').onclick=function(){{go(k-1);auto()}};auto();
setTimeout(function(){{if(!document.querySelector('details[open]'))location.reload()}},30000)}})();</script>
</body></html>"""
