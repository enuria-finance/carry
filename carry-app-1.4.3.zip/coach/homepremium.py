"""Inicio no visual premium: topo com o seu main (troca pelo pool), trilha do elo, numeros com tendencia,
ultimas partidas que abrem (curva de ouro e mortes de verdade), missao do dia e confrontos do campeao.
Tudo calculado das suas partidas e das amostras do app; nada inventado."""
import html
import json
from collections import Counter

from . import champview, icons, premium, ranks, statsui

e = lambda x: html.escape("" if x is None else str(x))
TIERS = statsui.TIERS
TIER_PT = statsui.TIER_PT
DIVS = ["IV", "III", "II", "I"]


def _wr(gs):
    return round(100 * sum(1 for g in gs if g["win"]) / len(gs)) if gs else 0


def _avg(xs):
    xs = [x for x in xs if x is not None]
    return sum(xs) / len(xs) if xs else None


def insight(champ, gs):
    n = len(gs)
    head = f"{n} partida{'s' if n != 1 else ''} de {e(champ)}, {_wr(gs)}% de vitória."
    a = [g for g in gs if g.get("deaths_before_10") is not None and g["deaths_before_10"] <= 1]
    b = [g for g in gs if g.get("deaths_before_10") is not None and g["deaths_before_10"] >= 2]
    if len(a) >= 3 and len(b) >= 3 and _wr(a) - _wr(b) >= 8:
        return (f"{head} Quando você morre no máximo uma vez antes dos 10 minutos, vence <b>{_wr(a)}%</b>. "
                f"Com duas mortes ou mais, <b>{_wr(b)}%</b>.")
    a = [g for g in gs if g.get("golddiff15") is not None and g["golddiff15"] >= 0]
    b = [g for g in gs if g.get("golddiff15") is not None and g["golddiff15"] < 0]
    if len(a) >= 3 and len(b) >= 3 and _wr(a) - _wr(b) >= 8:
        return f"{head} Chegando aos 15 minutos com mais ouro que o oponente, vence <b>{_wr(a)}%</b>. Atrás no ouro, <b>{_wr(b)}%</b>."
    a = [g for g in gs if g.get("csdiff10") is not None and g["csdiff10"] >= 0]
    b = [g for g in gs if g.get("csdiff10") is not None and g["csdiff10"] < 0]
    if len(a) >= 3 and len(b) >= 3 and _wr(a) - _wr(b) >= 8:
        return f"{head} Com o CS empatado ou na frente aos 10 minutos, vence <b>{_wr(a)}%</b>. Atrás no CS, <b>{_wr(b)}%</b>."
    k = sum(g["kills"] + g["assists"] for g in gs) / max(1, sum(g["deaths"] for g in gs))
    cs = _avg([g.get("cs_per_min") for g in gs])
    return f"{head} KDA de <b>{k:.2f}</b>" + (f" e <b>{cs:.1f}</b> de CS por minuto." if cs else ".")


# ---------------------------------------------------------------- pecas
def _spark(vals, w=110, h=30):
    vals = [v for v in vals if v is not None]
    if len(vals) < 3:
        return ""
    mn, mx = min(vals), max(vals)
    r = (mx - mn) or 1
    pts = [(i / (len(vals) - 1) * w, h - 3 - (v - mn) / r * (h - 6)) for i, v in enumerate(vals)]
    p = " ".join(f"{x:.1f},{y:.1f}" for x, y in pts)
    return f"<svg viewBox='0 0 {w} {h}' class='hp-sp' aria-hidden='true'><polyline points='{p}'/><circle cx='{pts[-1][0]:.1f}' cy='{pts[-1][1]:.1f}' r='2.6'/></svg>"


def _rolling(games, key, k=5):
    seq = list(reversed(games[:20]))
    out = []
    for i in range(len(seq)):
        win = seq[max(0, i - k + 1):i + 1]
        if key == "win":
            out.append(sum(1 for g in win if g["win"]) / len(win))
        elif key == "kda":
            out.append(sum(g["kills"] + g["assists"] for g in win) / max(1, sum(g["deaths"] for g in win)))
        else:
            out.append(_avg([g.get(key) for g in win]))
    return out


def nums(games):
    a, b = games[:20], games[20:40]
    if not a:
        return ""

    def kda(gs):
        return sum(g["kills"] + g["assists"] for g in gs) / max(1, sum(g["deaths"] for g in gs)) if gs else None
    items = []
    wa, wb = _wr(a), (_wr(b) if b else None)
    items.append((f"{wa}%", f"de vitória nos últimos {len(a)}", None if wb is None else (wa - wb, "pp", True), _spark(_rolling(games, "win"))))
    ka, kb = kda(a), kda(b)
    items.append((f"{ka:.2f}", "KDA médio", None if kb is None else (ka - kb, "", True), _spark(_rolling(games, "kda"))))
    ca, cb = _avg([g.get("cs_per_min") for g in a]), _avg([g.get("cs_per_min") for g in b])
    if ca is not None:
        items.append((f"{ca:.1f}", "CS por minuto", None if cb is None else (ca - cb, "", True), _spark(_rolling(games, "cs_per_min"))))
    da, db_ = _avg([g.get("deaths_before_10") for g in a]), _avg([g.get("deaths_before_10") for g in b])
    if da is not None:
        items.append((f"{da:.1f}", "mortes antes dos 10 min", None if db_ is None else (da - db_, "", False), _spark(_rolling(games, "deaths_before_10"))))
    out = ""
    for big, lab, d, sp in items:
        sub = ""
        if d is not None:
            v, unit, up_good = d
            if abs(v) < 0.05:
                sub = "<small>igual aos anteriores</small>"
            else:
                good = (v > 0) == up_good
                word = "subiu" if v > 0 else "caiu"
                amt = f"{abs(v):.0f} pontos" if unit == "pp" else f"{abs(v):.2f}".rstrip("0").rstrip(".")
                sub = f"<small class='{'up' if good else 'dn'}'>{word} {amt} em relação aos {len(b)} anteriores</small>"
        out += f"<div class='hp-num'><div class='hp-num-t'><b>{big}</b>{sp}</div><span>{e(lab)}</span>{sub}</div>"
    return f"<div class='hp-nums'>{out}</div>"


def climb(link, hist):
    if not link or not link["tier"]:
        return ""
    tier, div, lp = link["tier"].upper(), link["division"] or "", link["lp"] or 0
    if tier not in TIERS:
        return ""
    head = f"<strong>{e(TIER_PT[tier])}{' ' + e(div) if tier not in ('MASTER', 'GRANDMASTER', 'CHALLENGER') else ''}</strong><span>{lp} PDL</span>"
    lpbox = ""
    d = ranks.delta_days(hist, 14) if hist else None
    if d is not None and len(hist) >= 2:
        cut = hist[-1]["at_ms"] - 14 * 86400000
        pts = [h["v"] for h in hist if h["at_ms"] >= cut] or [h["v"] for h in hist[-8:]]
        W, H = 220, 46
        if len(pts) >= 2:
            mn, mx = min(pts), max(pts)
            r = (mx - mn) or 1
            pp = " ".join(f"{i / (len(pts) - 1) * W:.1f},{H - 4 - (v - mn) / r * (H - 8):.1f}" for i, v in enumerate(pts))
            svg = f"<svg viewBox='0 0 {W} {H}' class='hp-lpc' aria-hidden='true'><polygon points='0,{H} {pp} {W},{H}' class='a'/><polyline points='{pp}' class='l'/></svg>"
        else:
            svg = ""
        lpbox = f"<div class='hp-lpbox'><div><b class='{'up' if d >= 0 else 'dn'}'>{'+' if d >= 0 else '−'}{abs(d)} PDL</b><small>nos últimos 14 dias</small></div>{svg}</div>"
    if tier in ("MASTER", "GRANDMASTER", "CHALLENGER"):
        return f"<div class='hp-climb'><div class='hp-climb-h'>{head}{lpbox}</div></div>"
    nxt = TIERS[TIERS.index(tier) + 1]
    di = DIVS.index(div) if div in DIVS else 0
    pos = (di + min(100, lp) / 100) / 4 * 100
    short = lambda t: TIER_PT[t][0]
    ticks = "".join(f"<span class='hp-tick{' done' if i <= di else ''}' style='left:{i * 25}%'><i></i>{short(tier)}{4 - i}</span>" for i in range(4))
    nxt_lab = f"{short(nxt)}4" if nxt != "MASTER" else "Mestre"
    ticks += f"<span class='hp-tick goal' style='left:100%'><i></i>{nxt_lab}</span>"
    goal_name = f"{TIER_PT[nxt]} IV" if nxt != "MASTER" else "Mestre"
    falta = f"faltam {100 - lp} PDL para {goal_name}" if di == 3 else f"faltam {100 - lp} PDL para a próxima divisão"
    return (f"<div class='hp-climb'><div class='hp-climb-h'>{head}{lpbox}</div><div class='hp-track'><span class='hp-fill' style='width:{pos:.1f}%'></span>{ticks}"
            f"<span class='hp-me' style='left:{pos:.1f}%'><span>{e(falta)}</span></span></div></div>")


def _gold_svg(con, mid, pid, opp_pid, w=520, h=110):
    me = dict(con.execute("SELECT minute, gold FROM frames WHERE match_id=? AND participant_id=?", (mid, pid)).fetchall())
    op = dict(con.execute("SELECT minute, gold FROM frames WHERE match_id=? AND participant_id=?", (mid, opp_pid)).fetchall()) if opp_pid else {}
    mins = sorted(m for m in me if m in op)
    if len(mins) < 4:
        return None, None
    pts = [me[m] - op[m] for m in mins]
    deaths = [int(t // 60000) for (t,) in con.execute("SELECT t_ms FROM deaths WHERE match_id=? AND victim_id=? ORDER BY t_ms", (mid, pid))]
    n = mins[-1] or 1
    mx = max(1200, max(abs(p) for p in pts))
    X = lambda m: m / n * w
    Y = lambda v: h / 2 - v / mx * (h / 2 - 8)
    line = " ".join(f"{X(m):.1f},{Y(v):.1f}" for m, v in zip(mins, pts))
    up = f"M{X(mins[0]):.1f},{h / 2} " + " ".join(f"L{X(m):.1f},{min(Y(v), h / 2):.1f}" for m, v in zip(mins, pts)) + f" L{X(mins[-1]):.1f},{h / 2} Z"
    dn = f"M{X(mins[0]):.1f},{h / 2} " + " ".join(f"L{X(m):.1f},{max(Y(v), h / 2):.1f}" for m, v in zip(mins, pts)) + f" L{X(mins[-1]):.1f},{h / 2} Z"
    dm = "".join(f"<g transform='translate({X(min(m, n)):.1f},{h - 6})'><path d='M-4,-4 L4,4 M4,-4 L-4,4' class='dx'/></g>"
                 f"<text x='{X(min(m, n)):.1f}' y='{h + 12}' class='dt'>{m}'</text>" for m in deaths)
    ticks = "".join(f"<text x='{X(m):.1f}' y='{h + 26}' class='tt'>{m} min</text>" for m in range(0, n + 1, 10))
    svg = (f"<svg viewBox='-4 0 {w + 8} {h + 30}' class='hp-gold' role='img' aria-label='Diferença de ouro contra o oponente, minuto a minuto'>"
           f"<line x1='0' x2='{w}' y1='{h / 2}' y2='{h / 2}' class='zero'/><path d='{up}' class='gu'/><path d='{dn}' class='gd'/>"
           f"<polyline points='{line}' class='gl'/>{dm}{ticks}</svg>")
    g15 = me.get(15, None)
    o15 = op.get(15, None)
    return svg, (g15 - o15 if g15 is not None and o15 is not None else None)


def vhero(link, R, main, sent, arts, btns, lpbox, gs_main):
    """Topo do Inicio no visual novo: elo grande, escada ate a meta e a arte da skin travada."""
    tier = (link["tier"] or "").upper() if link else ""
    div, lp = (link["division"] or "") if link else "", (link["lp"] or 0) if link else 0
    apex = tier in ("MASTER", "GRANDMASTER", "CHALLENGER")
    name = f"{TIER_PT.get(tier, tier.title())}{'' if apex or not div else ' ' + div}" if tier else "Sem elo"
    ladder = ""
    if tier in TIERS and not apex:
        di = DIVS.index(div) if div in DIVS else 0
        nxt = TIERS[TIERS.index(tier) + 1]
        seg = ""
        for i in range(4):
            fill = 100 if i < di else (min(100, lp) if i == di else 0)
            seg += f"<div class='vh-sg'><span class='tr'><i style='width:{fill}%'></i></span><small>{e(TIER_PT[tier][0])}{4 - i}</small></div>"
        goal = "Mestre" if nxt == "MASTER" else f"{TIER_PT[nxt]} IV"
        ladder = f"<div class='vh-ladder' role='img' aria-label='{e(name)} com {lp} PDL'>{seg}<div class='vh-goal'>{e(goal)}</div></div>"
    big, stats = "", ""
    if R:
        alvo = TIER_PT.get(R["target"], R["target"])
        ritmo = R["real"] if R["real"] is not None else R["lp14"]
        jm = int(R["falta"] / R["lp_main"] + 0.999) if R.get("lp_main") and R["lp_main"] > 0.3 else None
        big = f"Faltam <b>{R['falta']}</b> PDL para o {e(alvo)}."
        if jm and R.get("main") and jm <= 150:
            big += f" Só de {e(R['main'])}, no seu ritmo, são umas <b>{jm}</b> partidas."
        # quantas partidas com cada % de vitoria (uns +21 por vitoria e -19 por derrota): mais util que um ritmo baixo
        por = lambda w: int(R["falta"] / (21 * w - 19 * (1 - w)) + 0.999)
        big += (f"<br><span class='vh-wr'>Com 55% de vitória: <b>{por(.55)}</b> partidas · 60%: <b>{por(.60)}</b> · 65%: <b>{por(.65)}</b></span>")
        f1 = lambda v: f"{v:+.1f}".replace(".", ",").replace("-", "−")
        if ritmo is not None:
            stats += f"<div><small>Ritmo em 2 semanas</small><b class='{'up' if ritmo >= 0 else 'dn'}'>{f1(ritmo)}</b><span>PDL por partida</span></div>"
        if R.get("lp_main") is not None and R.get("main"):
            stats += f"<div><small>Só de {e(R['main'])}</small><b class='{'up' if R['lp_main'] >= 0 else 'dn'}'>{f1(R['lp_main'])}</b><span>PDL por partida</span></div>"
    if gs_main:
        stats += f"<div><small>{e(main)}</small><b>{_wr(gs_main)}%</b><span>{len(gs_main)} jogos</span></div>"
    kick = f"{e(main)} · seu main" if main else ""
    return (f"<section class='vh hp-hero'>{arts}<div class='vh-in'><div class='vh-k'>{kick}</div>"
            f"<div class='vh-rank'><span class='vh-tier'>{e(name)}</span>{'' if not tier else f'<span class=vh-lp>{lp} PDL</span>'}</div>{ladder}"
            + (f"<p class='vh-big'>{big}</p>" if big else "") + f"<div class='vh-stats'>{stats}{lpbox}</div>"
            f"<p class='vh-sub'><b id='hpn'>{e(main)}</b> <span id='hps'>{sent}</span></p></div>"
            + (f"<div class='hp-pool vh-pool' role='group' aria-label='Seu pool'>{btns}</div>" if btns else "") + "</section>")


def _lpbox(hist):
    d = ranks.delta_days(hist, 14) if hist else None
    if d is None or len(hist) < 2:
        return ""
    cut = hist[-1]["at_ms"] - 14 * 86400000
    pts = [h["v"] for h in hist if h["at_ms"] >= cut] or [h["v"] for h in hist[-8:]]
    W, H = 160, 40
    svg = ""
    if len(pts) >= 2:
        mn, mx = min(pts), max(pts)
        r = (mx - mn) or 1
        pp = " ".join(f"{i / (len(pts) - 1) * W:.1f},{H - 4 - (v - mn) / r * (H - 8):.1f}" for i, v in enumerate(pts))
        svg = f"<svg viewBox='0 0 {W} {H}' class='hp-lpc' aria-hidden='true'><polygon points='0,{H} {pp} {W},{H}' class='a'/><polyline points='{pp}' class='l'/></svg>"
    return f"<div class='vh-lpb'><small>Últimos 14 dias</small><b class='{'up' if d >= 0 else 'dn'}'>{'+' if d >= 0 else '−'}{abs(d)}</b><span>PDL</span>{svg}</div>"


def _note(g):
    bits = []
    d10 = g.get("deaths_before_10")
    if d10:
        bits.append(f"{d10} morte{'s' if d10 > 1 else ''} antes dos 10 minutos.")
    elif d10 == 0:
        bits.append("Nenhuma morte antes dos 10 minutos.")
    gd = g.get("golddiff15")
    if gd is not None and g.get("opp_champion"):
        bits.append(f"Chegou aos 15 com {abs(gd)} de ouro {'a mais' if gd >= 0 else 'a menos'} que {e(g['opp_champion'])}.")
    if g.get("cs_per_min"):
        bits.append(f"{g['cs_per_min']:.1f} de CS por minuto.")
    if g.get("kp") is not None:
        bits.append(f"Participou de {round(100 * g['kp'])}% dos abates do time.")
    return " ".join(bits[:3])


def game_rows(con, games, dd, limit=5, ids_prefix="hg"):
    try:
        ver, items = dd.version(), dd.items()
    except Exception:
        ver, items = None, {}
    try:
        from . import pages4
        lpg = pages4.lp_per_game(con, games[0]["puuid"]) if games else {}
    except Exception:
        lpg = {}
    out = ""
    for i, g in enumerate(games[:limit]):
        mid = g["match_id"]
        ex = con.execute("SELECT items FROM participant_extra WHERE match_id=? AND participant_id=?", (mid, g["participant_id"])).fetchone()
        its = (json.loads(ex["items"] or "[]") + [0] * 6)[:6] if ex else [0] * 6
        kda = "perfeito" if g["deaths"] == 0 else f"{(g['kills'] + g['assists']) / g['deaths']:.1f} KDA"
        svg, g15 = _gold_svg(con, mid, g["participant_id"], g.get("opp_id"))
        when = statsui.ago(g["started_ms"])
        mins = (g["duration_s"] or 0) // 60
        chart = (f"<p class='gx-t'>Ouro contra {e(g.get('opp_champion') or 'o oponente')}"
                 + (f" <b class='{'pos' if g15 >= 0 else 'neg'}'>{'+' if g15 >= 0 else '−'}{abs(g15)} aos 15</b>" if g15 is not None else "") + f"</p>{svg}"
                 if svg else "<p class='gx-t'>Esta partida não tem a linha do tempo minuto a minuto.</p>")
        try:
            from . import postmore
            sc_ = postmore.score(g)["total"]
            gr_, gc_ = postmore.grade(sc_)
            chip = f" <i class='gchip {gc_}' title='Nota da partida'>{sc_}</i>" if sc_ is not None else ""
        except Exception:
            chip = ""
        out += (f"<li class='hg {'w' if g['win'] else 'l'}' data-c='{e(g['champion'])}'><button type='button' class='hg-row' aria-expanded='false' aria-controls='{ids_prefix}{i}'>"
                f"<span class='hg-r'><b>{'Vitória' if g['win'] else 'Derrota'}{chip}</b><span>{e(when)} · {mins} min de jogo"
                + (f" · {pages4.lp_badge(lpg[mid])} PDL{'' if lpg[mid][1] else ' (estimado)'}" if mid in lpg else "") + "</span></span>"
                f"<span class='hg-c'>{icons.champ(g['champion'], 44)}<span><b>{e(g['champion'])}</b><span>contra {e(g.get('opp_champion') or '?')}</span></span></span>"
                f"<span class='hg-k'><b>{g['kills']}<em>/</em><s>{g['deaths']}</s><em>/</em>{g['assists']}</b><span>{kda}</span></span>"
                f"<span class='hg-i'>{''.join(statsui.item_img(ver, x, items, 30) for x in its)}</span>"
                f"<span class='hg-cs'>{g['cs']}<span>CS</span></span><span class='chev' aria-hidden='true'></span></button>"
                f"<div class='hg-x' id='{ids_prefix}{i}' hidden><div class='gx-in'><div>{chart}</div>"
                f"<div class='gx-side'><p>{_note(g)}</p><a href='/partida/{e(mid)}'>Ver pós-jogo</a><a href='/revisao/{e(mid)}' class='alt'>Revisar lance a lance</a></div></div></div></li>")
    return out


def _cnt(lst):
    return "".join(f"<li><a href='/campeao/{e(icons.champ_id(n))}'>{icons.champ(n, 30)}<b>{e(n)}</b><span class='bar'><i style='width:{min(100, max(4, (p - 45) * 7)):.0f}%'></i></span>"
                   f"<em>{p:.1f}%</em><small>{c} jogos</small></a></li>" for n, p, c in lst)


def matchups(ddir, champ, pos):
    mu = [(o, n, w) for o, n, w in champview.matchup_stats(ddir, champ, pos) if n >= 20]     # amostra do topo: 3 jogos era ruido
    sv = lambda n, w: (w + 10) / (n + 20)
    vs = sorted([(o, 100 * (n - w) / n, n, sv(n, w)) for o, n, w in mu], key=lambda x: x[3])
    ok = sorted([(o, 100 * w / n, n, sv(n, w)) for o, n, w in mu], key=lambda x: -x[3])
    return (_cnt([x[:3] for x in vs if x[3] < 0.49][:5]), _cnt([x[:3] for x in ok if x[3] > 0.51][:5]))


def mission_box(mst):
    if not mst:
        return ""
    m = mst["mission"]
    checks = mst["checks"]
    pips = "".join(f"<i class='{'on' if c['ok'] else 'no' if c['value'] is not None else ''}'></i>" for c in checks)
    pips += "".join("<i></i>" for _ in range(max(0, 3 - len(checks))))
    met = sum(1 for c in checks if c["ok"])
    status = {"done": "Missão de hoje cumprida.", "failed": "Ainda dá para virar o dia.", "pending": "Missão de hoje."}[m["status"]]
    line = f"{met} de {len(checks)} partidas de hoje cumpriram" if checks else "Nenhuma partida hoje ainda"
    why = ""
    if mst.get("why"):
        hi, lo, _ = mst["why"]
        why = f" Nos seus jogos com {e(hi['label'].lower())} você vence {hi['wr']}%; com {e(lo['label'].lower())}, {lo['wr']}%."
    streak = f"{mst['streak']} dia{'s' if mst['streak'] != 1 else ''} seguido{'s' if mst['streak'] != 1 else ''}, recorde {mst['best']}"
    return (f"<section class='hp-mission'><p class='t'>{e(m['text'])}</p><p>{status} Vale em pelo menos metade das partidas do dia.{why}</p>"
            f"<div class='pips'>{pips}</div><small>{e(line)}. Sequência: {e(streak)}.</small></section>")


def _panel(title, sub, body, action="", cls=""):
    """Bloco padrao da tela: titulo, uma linha explicando e o conteudo dentro de uma moldura."""
    return (f"<section class='hpn {cls}'><header class='hpn-h'><div><h3>{title}</h3>" + (f"<small>{sub}</small>" if sub else "") + "</div>"
            f"{action}</header>{body}</section>")


def build(con, games, all_games, link, hist, mst, dd, ddir, diag_html="", more_html="", cam=None):
    """games: posicao principal (para o pool); all_games: todas as posicoes (para numeros e partidas)."""
    by = {}
    for g in all_games:
        by.setdefault(g["champion"], []).append(g)
    main = (link["main_champ"] if link and link["main_champ"] in by else None) or (max(by, key=lambda c: len(by[c])) if by else None)
    pool = [main] + [c for c, _ in sorted(by.items(), key=lambda kv: -len(kv[1])) if c != main][:2] if main else []
    data, arts, btns = {}, "", ""
    for c in pool:
        gs = by[c]
        pos = Counter(g.get("position") for g in gs if g.get("position")).most_common(1)
        vs, ok = matchups(ddir, c, pos[0][0] if pos else "MIDDLE")
        col = premium.accent(c)
        r, g_, b = int(col[1:3], 16), int(col[3:5], 16), int(col[5:7], 16)
        data[c] = {"ac": col, "acs": f"rgba({r},{g_},{b},.14)", "acm": f"rgba({r},{g_},{b},.35)", "sent": insight(c, gs), "vs": vs, "ok": ok}
        arts += f"<div class='hp-art{' on' if c == main else ''}' data-c='{e(c)}' style=\"background-image:url('{e(icons.splash(c))}')\"></div>"
        btns += (f"<button type='button' aria-pressed='{'true' if c == main else 'false'}' data-c='{e(c)}'>{icons.champ(c, 44)}<b>{e(c)}</b>"
                 f"<small>{len(gs)} jogos, {_wr(gs)}% de vitória</small></button>")
    if not main:
        return ""
    d0 = data[main]
    hero = vhero(link, cam, main, d0['sent'], arts, btns if len(pool) > 1 else '', _lpbox(hist), by.get(main, []))
    last5 = all_games[:5]
    w5 = sum(1 for g in last5 if g["win"])
    worst = next((g for g in last5 if not g["win"] and (g.get("deaths_before_10") or 0) >= 2), None)
    lead = f"Ganhou {w5} das últimas {len(last5)}."
    if worst:
        lead += f" A derrota de {e(worst['champion'])} contra {e(worst.get('opp_champion') or '?')} teve {worst['deaths_before_10']} mortes antes dos 10 minutos."
    lead += " Clique numa partida para ver o ouro contra o oponente e onde você morreu."
    filt = ("<div class='seg' id='hpf' role='group' aria-label='Filtrar partidas'><button type='button' aria-pressed='true' data-f='all'>Todas</button>"
            "<button type='button' aria-pressed='false' data-f='w'>Vitórias</button><button type='button' aria-pressed='false' data-f='l'>Derrotas</button>"
            f"<button type='button' aria-pressed='false' data-f='c' id='hpc'>Só {e(main)}</button></div>")
    p_games = _panel("Últimas partidas", lead, filt + f"<ol class='hp-games'>{game_rows(con, all_games, dd, 8)}</ol>",
                     "<a class='hpn-a' href='/partidas'>Ver todas</a>")
    cnt_empty = "<li class='empty-li'>Ainda sem confrontos suficientes. Baixe a amostra do topo na página do campeão.</li>"
    p_cnt = _panel(f"<span id='hpct'>Confrontos de {e(main)}</span>", "Pelas amostras do app, na posição em que você joga com ele. Troque o campeão lá em cima.",
                   "<div class='hpn-2'><div><b class='hpn-k bad'>Quem vence ele</b>"
                   f"<ul class='hp-list' id='hpvs'>{d0['vs'] or cnt_empty}</ul></div><div><b class='hpn-k good'>Contra quem ele vai bem</b>"
                   f"<ul class='hp-list' id='hpok'>{d0['ok'] or cnt_empty}</ul></div></div>",
                   f"<a class='hpn-a' id='hpcl' href='/campeao/{e(icons.champ_id(main))}'>Abrir a página de {e(main)}</a>")
    p_nums = _panel("Seus números", f"Últimas {min(20, len(all_games))} partidas, comparadas com as 20 anteriores.", nums(all_games), "", "hpn-nums")
    p_miss = _panel("Missão de hoje", "Um foco por dia, escolhido pelo que mais pesa nos seus jogos.", mission_box(mst) or "<p class='n'>Sem missão hoje.</p>",
                    "<a class='hpn-a' href='/habitos'>Hábitos</a>", "hpn-miss")
    preview = _panel("Últimos jogos", lead.split(" Clique")[0], f"<ol class='hp-games'>{game_rows(con, all_games, dd, 3, 'hgp')}</ol>",
                     "<button type='button' class='hpn-a' data-go='partidas'>Ver mais</button>")
    p_diag = _panel("O que mais pesa", "Do diagnóstico: o que separa as suas vitórias das derrotas.", diag_html,
                    "<a class='hpn-a' href='/diagnostico'>Diagnóstico</a>") if diag_html else ""
    p_games = p_games.replace("<ol class='hp-games'>", "<ol class='hp-games' id='hp-all'>", 1)
    resumo = (p_nums + f"<div class='hpn-row'>{p_miss}{p_games}</div>" + p_diag + p_cnt + (more_html or ""))
    nav, panels = "", resumo
    js = ("<script>(function(){var P=" + json.dumps(data, ensure_ascii=False).replace("</", "<\\/") + ",cur=" + json.dumps(main) + ",gf='all',EMPTY=" + json.dumps(cnt_empty) + ";"
          """function seg(id,fn){var g=document.getElementById(id);if(!g)return;g.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;
g.querySelectorAll('button').forEach(function(x){x.setAttribute('aria-pressed',x===b)});fn(b)})}
function games(){document.querySelectorAll('#hp-all .hg').forEach(function(g){g.hidden=!(gf==='all'||(gf==='w'&&g.classList.contains('w'))||(gf==='l'&&g.classList.contains('l'))||(gf==='c'&&g.dataset.c===cur))})}
seg('hpf',function(b){gf=b.dataset.f;games()});
var T=document.querySelector('.hp-tabs');function tab(k,focus){var b=document.getElementById('tab-'+k);if(!b)return;
T.querySelectorAll('[role=tab]').forEach(function(x){var on=x===b;x.setAttribute('aria-selected',on);x.tabIndex=on?0:-1;document.getElementById(x.getAttribute('aria-controls')).hidden=!on});
if(focus)b.focus();try{localStorage.setItem('hp-tab',k)}catch(_){}if(history.replaceState)history.replaceState(null,'','#'+k)}
if(T){T.addEventListener('click',function(e){var b=e.target.closest('[role=tab]');if(b)tab(b.dataset.t)});
T.addEventListener('keydown',function(e){var l=[].slice.call(T.querySelectorAll('[role=tab]')),i=l.indexOf(document.activeElement);if(i<0)return;
var d={ArrowRight:1,ArrowLeft:-1}[e.key];if(!d)return;e.preventDefault();tab(l[(i+d+l.length)%l.length].dataset.t,true)});
document.addEventListener('click',function(e){var g=e.target.closest('[data-go]');if(g){tab(g.dataset.go);T.scrollIntoView({behavior:'smooth',block:'start'})}});
var st=(location.hash||'').slice(1);if(!st){try{st=localStorage.getItem('hp-tab')}catch(_){}}if(st)tab(st)}
var pool=document.querySelector('.hp-pool');if(pool)pool.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;var c=b.dataset.c,d=P[c];cur=c;
pool.querySelectorAll('button').forEach(function(x){x.setAttribute('aria-pressed',x===b)});var r=document.documentElement.style;r.setProperty('--ac',d.ac);r.setProperty('--acs',d.acs);r.setProperty('--acm',d.acm);
document.getElementById('hpn').textContent=c;document.getElementById('hps').innerHTML=d.sent;document.querySelectorAll('.hp-art').forEach(function(a){a.classList.toggle('on',a.dataset.c===c)});
document.getElementById('hpct').textContent='Confrontos de '+c;document.getElementById('hpc').textContent='Só '+c;var l=document.getElementById('hpcl');l.textContent='Abrir a página de '+c;l.href='/campeao/'+encodeURIComponent(c);
document.getElementById('hpvs').innerHTML=d.vs||EMPTY;document.getElementById('hpok').innerHTML=d.ok||EMPTY;games()});
document.addEventListener('click',function(e){var r=e.target.closest('.hg-row');if(!r)return;var x=document.getElementById(r.getAttribute('aria-controls')),o=r.getAttribute('aria-expanded')==='true';r.setAttribute('aria-expanded',!o);x.hidden=o});
})();</script>""")
    last = all_games[0]["match_id"] if all_games else None
    quick = [("/jogo", "Partida ao vivo", "seleção, plano e overlay"), (f"/partida/{last}" if last else "/partidas", "Último pós-jogo", "o que pesou na última partida"),
             ("/coach", "Perguntar ao Coach IA", "tire dúvidas sobre o seu jogo"), ("/diagnostico", "Diagnóstico", "o que mais te custa vitórias")]
    qh = "<nav class='hp-quick' aria-label='Atalhos'>" + "".join(
        f"<a href='{e(h)}'>{icons.nav_icon(h if not h.startswith('/partida/') else '/partidas')}<span><b>{e(t)}</b><small>{e(d)}</small></span></a>" for h, t, d in quick) + "</nav>"
    return hero + qh + nav + panels + js


CSS = """
/* ===== inicio premium ===== */
.hp-quick{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:16px 0 0}
.hp-quick a{position:relative;display:flex;align-items:center;gap:14px;padding:14px 16px;border-radius:14px;background:var(--raised);border:1px solid var(--line);text-decoration:none;color:var(--bone);transition:border-color .15s,transform .15s}
.hp-quick a:hover{border-color:rgba(200,170,110,.5);transform:translateY(-1px)}
.hp-quick .ni{flex:none;width:38px;height:38px;padding:9px;border-radius:10px;background:rgba(200,170,110,.1);color:#c8aa6e;border:1px solid rgba(200,170,110,.25)}
.hp-quick b{display:block;font:600 14.5px var(--body)}.hp-quick small{display:block;color:var(--steel);font-size:12.5px}
@media (max-width:1100px){.hp-quick{grid-template-columns:repeat(2,1fr)}}
.hp-hero{position:relative;margin:0;padding:44px 44px 30px;overflow:hidden;isolation:isolate;border-radius:18px;border:1px solid rgba(200,170,110,.22)}
.hp-hero::after{content:'';position:absolute;left:24px;right:24px;top:-1px;height:1px;background:linear-gradient(90deg,transparent,#c8aa6e,transparent)}
.hp-art{position:absolute;inset:0;z-index:-2;background-size:cover;background-position:70% 18%;opacity:0;transform:scale(1.04);transition:opacity .8s ease,transform 6s ease}
.hp-art.on{opacity:1;transform:none}
.hp-hero::before{content:'';position:absolute;inset:0;z-index:-1;background:linear-gradient(90deg,var(--night) 22%,rgba(18,20,27,.55) 52%,rgba(18,20,27,.12) 82%),linear-gradient(0deg,var(--night) 3%,transparent 45%),radial-gradient(60% 90% at 78% 30%,var(--acs),transparent 70%)}
.hp-g{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:end;gap:40px}
.hp-name{font:900 clamp(84px,10vw,168px)/.8 var(--d) !important;letter-spacing:-.02em;margin:0;color:var(--bone)}
.hp-name::after{content:'';display:block;width:72px;height:6px;background:var(--ac);margin:26px 0 0 6px;transition:background .6s}
.hp-sub{max-width:48ch;margin:22px 0 0;color:#c9c3b8;font-size:18px;line-height:1.5;min-height:3em}.hp-sub b{color:var(--bone);font-weight:600}
.hp-pool{display:flex;flex-direction:column;gap:6px;padding-bottom:6px}
.hp-pool button{display:grid !important;grid-template-columns:44px auto;gap:2px 12px;align-items:center;text-align:left;background:rgba(18,20,27,.6) !important;backdrop-filter:blur(8px);
border:1px solid var(--line) !important;border-radius:14px !important;padding:8px 18px 8px 8px !important;transition:border-color .2s}
.hp-pool button .cic,.hp-pool button .ph{grid-row:1/3;border-radius:50%}.hp-pool button b{font-weight:600}.hp-pool button small{color:var(--steel);font-size:12.5px;font-weight:400}
.hp-pool button:hover{border-color:#3a4152 !important}.hp-pool button[aria-pressed=true]{border-color:var(--ac) !important;background:rgba(18,20,27,.85) !important}
.hp-climb{margin-top:40px;max-width:1040px}
.hp-climb-h{display:flex;align-items:flex-end;gap:16px}.hp-climb-h strong{font:700 44px/1 var(--d);color:var(--emerald)}.hp-climb-h>span{color:var(--steel);padding-bottom:4px}
.hp-lpbox{margin-left:auto;display:flex;align-items:flex-end;gap:12px;text-align:right}.hp-lpbox b{display:block;font:700 22px/1 var(--d)}.hp-lpbox b.up{color:var(--emerald)}.hp-lpbox b.dn{color:var(--loss)}
.hp-lpbox small{color:var(--steel);font-size:12.5px}.hp-lpc{width:220px;height:46px}.hp-lpc .a{fill:rgba(61,190,139,.12)}.hp-lpc .l{fill:none;stroke:var(--emerald);stroke-width:2;stroke-linejoin:round}
.hp-track{position:relative;height:56px;margin-top:46px}
.hp-track::before{content:'';position:absolute;left:0;right:0;top:12px;height:2px;background:var(--line)}
.hp-fill{position:absolute;left:0;top:11px;height:4px;background:linear-gradient(90deg,#1f6b51,var(--emerald));border-radius:2px;transform-origin:left;animation:hpgrow 1.4s .3s cubic-bezier(.2,.8,.2,1) both}
@keyframes hpgrow{from{transform:scaleX(0)}}
.hp-tick{position:absolute;top:0;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;gap:10px;font:600 13px var(--body);color:var(--steel)}
.hp-tick:first-of-type{transform:none;align-items:flex-start}.hp-tick.goal{transform:translateX(-100%);align-items:flex-end;color:var(--bone)}
.hp-tick i{width:2px;height:26px;background:var(--line)}.hp-tick.done i{background:var(--emerald)}.hp-tick.goal i{background:var(--bone)}
.hp-me{position:absolute;top:2px;transform:translateX(-50%);width:22px;height:22px;border-radius:50%;background:var(--night);border:3px solid var(--emerald);box-shadow:0 0 0 6px rgba(61,190,139,.15);animation:hppop .5s 1.5s both}
.hp-me span{position:absolute;bottom:30px;left:50%;transform:translateX(-50%);white-space:nowrap;font:600 13px var(--body);color:var(--bone)}
@keyframes hppop{from{transform:translateX(-50%) scale(0)}}
.hp-nums{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));margin:16px 0 0;border-top:1px solid var(--line);border-bottom:1px solid var(--line)}
.hp-num{padding:22px 32px;border-left:1px solid var(--line)}.hp-num:first-child{border-left:0;padding-left:0}
.hp-num-t{display:flex;align-items:flex-end;justify-content:space-between;gap:12px}
.hp-num b{display:block;font:700 54px/1 var(--d)}.hp-num>span{color:var(--steel);font-size:14px}.hp-num small{display:block;margin-top:2px;font-size:13px;color:var(--steel)}
.hp-num small.up{color:var(--win)}.hp-num small.dn{color:var(--loss)}
.hp-sp{width:110px;height:30px;flex:none}.hp-sp polyline{fill:none;stroke:var(--steel);stroke-width:1.6;stroke-linejoin:round;opacity:.7}.hp-sp circle{fill:var(--bone)}
.hp-body{display:grid;grid-template-columns:minmax(0,1fr) 340px;gap:36px;padding-top:40px}
.hp-body h2{margin-top:0}.hp-lead{margin:0 0 20px;color:var(--steel);max-width:70ch}
.hp-body .seg{margin-bottom:10px;flex-wrap:wrap}
ol.hp-games{list-style:none;margin:0;padding:0}
.hg{border-bottom:1px solid var(--line);position:relative}.hg[hidden]{display:none}
.hg::before{content:'';position:absolute;left:0;top:16px;height:44px;width:3px;border-radius:2px}.hg.w::before{background:var(--win)}.hg.l::before{background:var(--loss)}
button.hg-row{all:unset !important;box-sizing:border-box !important;cursor:pointer !important;width:100% !important;display:grid !important;grid-template-columns:100px minmax(140px,1fr) 92px auto 46px 14px !important;align-items:center !important;gap:12px !important;padding:16px 4px 16px 18px !important}
button.hg-row:hover{background:linear-gradient(90deg,rgba(255,255,255,.025),transparent) !important}button.hg-row:focus-visible{outline:2px solid var(--ac) !important;outline-offset:-2px}
.hg-r b,.hg-c b{display:block;font-weight:600}.hg.w .hg-r b{color:var(--win)}.hg.l .hg-r b{color:var(--loss)}.hg-r span,.hg-c span span{color:var(--steel);font-size:13px}
.hg-c{display:flex;align-items:center;gap:12px}.hg-c .cic,.hg-c .ph{border-radius:50%}.hg-c>span:last-child{display:block;min-width:0}
.hg-k b{display:block;font:700 26px/1 var(--d)}.hg-k em{font-style:normal;color:#4a5164;margin:0 3px}.hg-k s{text-decoration:none;color:var(--loss)}.hg-k>span{color:var(--steel);font-size:13px}
.hg-i{display:flex;gap:3px}.hg-i .sx{border-radius:6px;width:28px;height:28px}
@media (max-width:1380px){.hg-i{display:none}}
.hg-cs{font:700 22px/1 var(--d);text-align:right}.hg-cs span{display:block;font:500 12px var(--body);color:var(--steel)}
.chev{width:10px;height:10px;border-right:2px solid var(--steel);border-bottom:2px solid var(--steel);transform:rotate(45deg) translate(-2px,-2px);transition:transform .25s}
.hg-row[aria-expanded=true] .chev{transform:rotate(-135deg)}
.gx-in{display:grid;grid-template-columns:minmax(0,1fr) 240px;gap:32px;padding:4px 18px 24px;animation:hpopen .3s ease both}
@keyframes hpopen{from{opacity:0;transform:translateY(-6px)}}
.gx-t{margin:0 0 6px;color:var(--steel);font-size:14px}.gx-t b{font:700 20px var(--d);margin-left:6px}.pos{color:var(--win)}.neg{color:var(--loss)}
.hp-gold{width:100%;height:auto;display:block}.hp-gold .zero{stroke:#3a4152;stroke-dasharray:3 4}.hp-gold .gu{fill:rgba(127,178,229,.16)}.hp-gold .gd{fill:rgba(196,106,120,.18)}
.hp-gold .gl{fill:none;stroke:var(--bone);stroke-width:1.8;stroke-linejoin:round}.hp-gold .dx{stroke:var(--loss);stroke-width:2;stroke-linecap:round}
.hp-gold .dt{fill:var(--loss);font:600 10px var(--body);text-anchor:middle}.hp-gold .tt{fill:var(--steel);font:500 10.5px var(--body)}
.gx-side p{margin:0 0 16px;color:#d6d0c5;line-height:1.55}
.gx-side a{display:block;text-align:center;text-decoration:none;font:600 14px var(--body);padding:10px 0;border-radius:10px;background:var(--bone);color:var(--night);margin-bottom:8px}
.gx-side a.alt{background:none;color:var(--bone);border:1px solid var(--line)}.gx-side a.alt:hover{border-color:var(--steel)}
.hp-more{display:inline-block;margin-top:14px;color:var(--steel);font-size:14px;text-decoration:none;border-bottom:1px solid var(--line)}.hp-more:hover{color:var(--bone)}
.hp-body aside>section+section{margin-top:44px}
.hp-mission{padding:22px 22px 20px;border-radius:14px;background:var(--raised);position:relative;overflow:hidden;border:1px solid rgba(200,170,110,.18)}
.hp-mission::after{content:'';position:absolute;right:-30px;top:-30px;width:130px;height:130px;border-radius:50%;border:18px solid var(--acs);transition:border-color .6s}
.hp-mission p.t{font:700 28px/1.05 var(--d);margin:0 0 10px;max-width:15ch;position:relative}.hp-mission p{margin:0;color:#c9c3b8;font-size:14px;max-width:36ch;position:relative}
.hp-mission .pips{display:flex;gap:6px;margin-top:18px}.hp-mission .pips i{flex:1;height:6px;border-radius:3px;background:var(--line)}
.hp-mission .pips i.on{background:var(--ac)}.hp-mission .pips i.no{background:#4a3038}
.hp-mission small{display:block;margin-top:8px;color:var(--steel);font-size:13px}
ul.hp-list{list-style:none;margin:0;padding:0}ul.hp-list[hidden]{display:none}
ul.hp-list a{display:grid;grid-template-columns:30px 1fr 60px;grid-template-areas:'p n v' 'p b s';column-gap:12px;row-gap:6px;align-items:center;padding:12px 0;border-bottom:1px solid var(--line);text-decoration:none;color:inherit}
ul.hp-list a:hover b{color:#fff}ul.hp-list .cic,ul.hp-list .ph{grid-area:p;border-radius:50%}ul.hp-list b{grid-area:n;font-weight:600}
ul.hp-list em{grid-area:v;font:700 20px/1 var(--d);font-style:normal;text-align:right}
ul.hp-list .bar{grid-area:b;height:3px;background:var(--line);border-radius:2px}ul.hp-list .bar i{display:block;height:100%;background:var(--bone);border-radius:2px}
ul.hp-list small{grid-area:s;text-align:right;color:var(--steel);font-size:12px}.empty-li{padding:12px 0;color:var(--steel);font-size:14px}
.hp-rest{margin-top:70px}
/* abas e blocos */
.hp-tabs{position:sticky;top:0;z-index:6;display:flex;gap:4px;margin:26px 0 18px;padding:6px;border-radius:14px;background:rgba(18,20,27,.86);backdrop-filter:blur(10px);border:1px solid var(--line)}
.hp-tabs button{all:unset !important;box-sizing:border-box !important;cursor:pointer !important;flex:1 !important;text-align:center !important;padding:11px 14px !important;border-radius:10px !important;
font:600 14.5px var(--body) !important;color:var(--steel) !important;transition:background .2s,color .2s !important;position:relative !important}
.hp-tabs button:hover{color:var(--bone) !important;background:rgba(255,255,255,.03) !important}
.hp-tabs button[aria-selected=true]{color:var(--bone) !important;background:var(--raised) !important;box-shadow:inset 0 0 0 1px rgba(200,170,110,.35) !important}
.hp-tabs button[aria-selected=true]::after{content:'' !important;display:block !important;position:absolute;left:30%;right:30%;bottom:4px;height:2px;border-radius:2px;background:var(--ac)}
.hp-tabs button:focus-visible{outline:2px solid var(--ac) !important;outline-offset:2px !important}
.hp-tp[hidden]{display:none}
.hp-tabs button .tbx{display:block;font:500 11.5px var(--body);color:var(--steel);margin-top:2px;letter-spacing:0}
.hp-tabs button[aria-selected=true] .tbx{color:#c8aa6e}.hp-tp{animation:fxin .35s cubic-bezier(.2,.8,.2,1) both}
.hp-tp>*+*{margin-top:18px}
.hpn{position:relative;background:var(--raised);border:1px solid var(--line);border-radius:16px;padding:22px 24px}
.hpn::after{content:'';position:absolute;left:22px;right:22px;top:-1px;height:1px;background:linear-gradient(90deg,transparent,rgba(200,170,110,.7),transparent)}
.hpn-h{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:16px}
.hpn-h h3{display:flex;align-items:center;gap:10px;margin:0;font:700 24px/1.1 var(--d);color:var(--bone);letter-spacing:.005em}
.hpn-h h3::before{content:'';width:7px;height:7px;transform:rotate(45deg);background:#c8aa6e;flex:none}
.hpn-h small{display:block;margin-top:4px;color:var(--steel);font-size:13.5px;max-width:70ch}
.hpn-a,button.hpn-a{all:unset !important;cursor:pointer !important;flex:none !important;font:600 13.5px var(--body) !important;color:var(--bone) !important;padding:7px 12px !important;
border:1px solid var(--line) !important;border-radius:999px !important;white-space:nowrap !important;transition:border-color .2s !important}
.hpn-a:hover,button.hpn-a:hover{border-color:#c8aa6e !important}
.hpn-row{display:grid;grid-template-columns:minmax(300px,380px) minmax(0,1fr);gap:18px;align-items:stretch}
.hpn-row>.hpn{margin:0}
.hpn-nums .hp-nums{margin:0;border:0}.hpn-nums .hp-num:first-child{padding-left:0}
.hpn-miss .hp-mission{border:0;background:none;padding:0;overflow:visible}.hpn-miss .hp-mission::after{display:none}.hpn-miss .hp-mission p.t{font-size:30px}
.hpn .seg{margin-bottom:6px}
.hpn-2{display:grid;grid-template-columns:1fr 1fr;gap:28px}
.td-row{display:flex;gap:6px;flex-wrap:wrap;margin:4px 0 8px}.td-d{width:22px;height:22px;border-radius:6px;background:#261C1B;border:1px solid var(--rule)}.td-d.w{background:#6BBF8A;border-color:#6BBF8A}.td-d.l{background:#D9534F;border-color:#D9534F}
.td-m{font:700 15px var(--head);color:#EEE6DB;margin:0 0 6px}.td-m.loss{color:#E8817C}.td-m.win{color:#8FD4A8}.td-m.gold{color:var(--gold)}
.td-f{gap:8px;align-items:center;margin-top:8px}.td-f label{font-size:13px;color:var(--mute)}.td-f select{width:auto}
.hpn-k{display:block;font:600 13px var(--body);margin-bottom:4px}.hpn-k.bad{color:var(--loss)}.hpn-k.good{color:var(--win)}
.hpn .dcards{margin:0}
.hpn .radar{overflow:visible;display:block;margin:0 auto;max-width:100%;padding:0 40px;box-sizing:border-box}
.hpn-gap{gap:18px !important}.hpn-gap>.hpn{margin:0}
@media (max-width:1100px){.hpn-row,.hpn-2{grid-template-columns:1fr}.hp-tabs{overflow-x:auto}.hp-tabs button{flex:none !important}}
@media (max-width:1100px){.hp-hero{padding:34px 22px 24px}.hp-body{grid-template-columns:1fr}.hp-g{grid-template-columns:1fr}.hp-pool{flex-direction:row;flex-wrap:wrap}
button.hg-row{grid-template-columns:110px 1fr 90px 50px 16px !important}.hg-i{display:none}.hp-nums{grid-template-columns:repeat(2,1fr)}.hp-num:nth-child(3){border-left:0;padding-left:0}
.hp-num:nth-child(n+3){border-top:1px solid var(--line)}.gx-in{grid-template-columns:1fr}.hp-lpbox{display:none}}
@media (max-width:640px){.hp-num{padding:18px 12px}.hp-sp{display:none}button.hg-row{grid-template-columns:1fr auto 16px !important;gap:10px !important}.hg-r,.hg-cs{display:none}
.hp-me span{left:auto;right:-60px;transform:none}}
"""
