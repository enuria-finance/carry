"""Como jogar CONTRA um campeao especifico (nao por classe): dicas oficiais da Riot (Data Dragon, "enemytips")
e, se existir, o guia por IA do campeao ("contra"). So cai na dica geral da classe quando nao ha nada do campeao.

tips_vs("Sylas") -> ["...", "..."]   (texto em portugues, ja limpo)
"""
import os

_MEM = {}


def _ddir():
    try:
        from .web import CTX
        return CTX.get("ddir") or ""
    except Exception:
        return ""


def _clean(t):
    from .ddragon import clean
    t = clean(t or "").strip()
    return t if not t or t.endswith((".", "!", "?")) else t + "."


def tips_vs(cid, n=2, ddir=None, tags=None):
    """Ate n dicas para enfrentar o campeao cid (id do Data Dragon, ex.: 'MonkeyKing')."""
    if not cid:
        return []
    key = (cid, n)
    if key in _MEM:
        return _MEM[key]
    ddir = ddir if ddir is not None else _ddir()
    out = []
    if ddir:          # 1) guia do campeao por IA (feito com o kit atual), quando ja existe
        try:
            from . import guides, icons
            g = guides.get(ddir, cid, icons.version() or "") or {}
            for t in (g.get("contra") or []):
                t = _clean(t.replace("[P]", "").replace("[Q]", "(Q)").replace("[W]", "(W)").replace("[E]", "(E)").replace("[R]", "(R)"))
                if t and t not in out:
                    out.append(t)
        except Exception:
            pass
    if len(out) < n:  # 2) dicas oficiais da Riot para enfrentar o campeao
        try:
            from .ddragon import DataDragon
            c = DataDragon(cache_dir=os.path.join(ddir, "cache") if ddir else "cache").champion(cid)
            out += [_clean(t) for t in (c.get("enemytips") or []) if t and _clean(t) not in out]
            tags = tags or c.get("tags") or []
        except Exception:
            pass
    specific = bool(out)
    if not out:
        from .gameview import CLASS_TIPS
        out = [next((CLASS_TIPS[t] for t in (tags or []) if t in CLASS_TIPS), "")]
        out = [t for t in out if t]
    out = out[:n]
    if specific:            # a dica geral da classe nao fica guardada: a do campeao pode chegar depois
        _MEM[key] = out
    return out


def tip_vs(cid, ddir=None, tags=None):
    t = tips_vs(cid, 1, ddir, tags)
    return t[0] if t else ""
