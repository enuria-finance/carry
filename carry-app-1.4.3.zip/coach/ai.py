"""Um lugar so para chamar a IA: Anthropic (Claude, pago por uso) ou Google Gemini (tem plano gratis, sem cartao).

As chaves ficam em Administracao. Quem chama recebe a resposta no formato da Anthropic ({"content": [{"type": "text", ...}]}),
entao o resto do app nao precisa saber qual servico respondeu. Uma chave do Gemini circula no app como "gemini:<chave>".
"""
import json
import os
import time
import urllib.error
import urllib.request

ANTHROPIC = "https://api.anthropic.com/v1/messages"
GEMINI = "https://generativelanguage.googleapis.com/v1beta"
GEMINI_FALLBACK = "gemini-2.5-flash"
_MODEL = {"name": None, "at": 0.0}
_MODELS = {"list": None, "at": 0.0}


def pick(c):
    """(chave, modelo) conforme o que esta configurado. Com as duas chaves, vale a escolha de Administracao (padrao: Gemini, que e gratis)."""
    ak = (c.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY") or "").strip()
    gk = (c.get("gemini_api_key") or os.environ.get("GEMINI_API_KEY") or "").strip()
    prov = c.get("ai_provider") or ""
    from . import coachbot
    if gk and (prov == "gemini" or not ak or prov != "anthropic"):
        return "gemini:" + gk, None
    return ak, c.get("anthropic_model") or coachbot.DEFAULT_MODEL


def is_gemini(key):
    return bool(key) and key.startswith("gemini:")


def _gemini_flash_list(gk):
    """Modelos Flash da conta (com e sem 'lite'), do mais novo para o mais velho. Guarda por 6 horas."""
    if _MODELS["list"] is not None and time.time() - _MODELS["at"] < 6 * 3600:
        return _MODELS["list"]
    out = []
    try:
        import re
        with urllib.request.urlopen(f"{GEMINI}/models?key={gk}&pageSize=200", timeout=15) as r:
            data = json.loads(r.read().decode("utf-8"))
        for m in data.get("models") or []:
            nm = (m.get("name") or "").split("/")[-1]
            low = nm.lower()
            if "generateContent" not in (m.get("supportedGenerationMethods") or []) or "flash" not in low:
                continue
            if any(x in low for x in ("image", "tts", "audio", "live", "embedding", "8b", "exp", "thinking")):
                continue
            v = re.findall(r"(\d+(?:\.\d+)?)", low)
            out.append(((float(v[0]) if v else 0), "preview" not in low, nm))
    except Exception:
        out = []
    _MODELS.update(list=[n for *_, n in sorted(out, reverse=True)], at=time.time())
    return _MODELS["list"]


def _gemini_model(gk):
    """Escolhe o melhor modelo Flash disponivel na conta (a lista muda com o tempo). Guarda por 6 horas."""
    if _MODEL["name"] and time.time() - _MODEL["at"] < 6 * 3600:
        return _MODEL["name"]
    best = None
    try:
        with urllib.request.urlopen(f"{GEMINI}/models?key={gk}&pageSize=200", timeout=15) as r:
            data = json.loads(r.read().decode("utf-8"))
        cands = []
        for m in data.get("models") or []:
            nm = (m.get("name") or "").split("/")[-1]
            if "generateContent" not in (m.get("supportedGenerationMethods") or []):
                continue
            low = nm.lower()
            if "flash" not in low or any(x in low for x in ("lite", "image", "tts", "audio", "live", "embedding", "8b", "exp")):
                continue
            import re
            v = re.findall(r"(\d+(?:\.\d+)?)", low)
            ver = float(v[0]) if v else 0
            cands.append((("preview" not in low), ver, nm))
        if cands:
            best = sorted(cands, reverse=True)[0][2]
    except Exception:
        best = None
    _MODEL.update(name=best or GEMINI_FALLBACK, at=time.time())
    return _MODEL["name"]


def _text_of(content):
    if isinstance(content, str):
        return content
    out = []
    for b in content or []:
        if isinstance(b, dict):
            if b.get("type") == "text":
                out.append(b.get("text", ""))
            elif b.get("type") == "tool_result":
                out.append(str(b.get("content", "")))
    return "\n".join(out)


def post(key, body, timeout=90):
    """body no formato da Anthropic (model, max_tokens, system, messages). Devolve a resposta no formato da Anthropic."""
    lite = bool(body.pop("_lite", False)) if isinstance(body, dict) else False
    if is_gemini(key):
        gk = key[len("gemini:"):]
        model = _gemini_model(gk)
        contents = [{"role": "model" if m["role"] == "assistant" else "user", "parts": [{"text": _text_of(m["content"])}]}
                    for m in body.get("messages") or []]
        g = {"contents": contents, "generationConfig": {"maxOutputTokens": max(1024, int(body.get("max_tokens") or 1024) * 2), "temperature": 0.6}}
        if body.get("system"):
            g["systemInstruction"] = {"parts": [{"text": body["system"]}]}
        try:
            res = gemini_call(gk, g, timeout, lite=lite)
        except urllib.error.HTTPError as ex:
            detail = ex.read().decode("utf-8", "replace")[:300]
            if ex.code == 429:
                raise RuntimeError("O limite grátis do Gemini acabou por agora (por minuto ou por dia). Tente mais tarde.")
            if ex.code in (400, 403) and ("API key" in detail or "API_KEY" in detail or "PERMISSION" in detail):
                raise RuntimeError("A chave do Gemini foi recusada. Confira a chave em Administração (aistudio.google.com).")
            if ex.code == 404:
                _MODEL.update(name=None, at=0)
            if ex.code >= 500:
                raise RuntimeError("O Gemini está sobrecarregado agora. Tente de novo em alguns segundos.")
            raise RuntimeError(f"O Gemini respondeu com erro {ex.code}: {detail}")
        except (TimeoutError, OSError) as ex:
            if not isinstance(ex, urllib.error.URLError):
                raise RuntimeError("O Gemini demorou demais para responder. Tente de novo.")
            raise RuntimeError(f"Sem conexão com o Gemini: {ex.reason}")
        parts = (((res.get("candidates") or [{}])[0].get("content") or {}).get("parts")) or []
        text = "".join(p.get("text", "") for p in parts if not p.get("thought"))
        if not text:
            why = (res.get("promptFeedback") or {}).get("blockReason") or ((res.get("candidates") or [{}])[0].get("finishReason"))
            raise RuntimeError(f"O Gemini não devolveu texto ({why or 'sem motivo'}). Tente de novo.")
        return {"content": [{"type": "text", "text": text}], "stop_reason": "end_turn"}
    req = urllib.request.Request(ANTHROPIC, data=json.dumps(body).encode("utf-8"), method="POST", headers={
        "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError):
        gk = _gemini_key_saved()
        if gk:              # Claude sem credito, chave recusada ou fora do ar: o Gemini (gratis) responde no lugar
            body["_lite"] = lite
            return post("gemini:" + gk, body, timeout)
        raise


def gemini_call(gk, payload, timeout=90, lite=False):
    """generateContent com reserva: se o modelo estiver sobrecarregado (5xx), sem cota (429) ou nao existir (404),
    tenta os outros Flash da conta. lite=True comeca pelos 'flash-lite' (respondem mais rapido e tem mais cota gratis)."""
    first = _gemini_model(gk)
    avail = _gemini_flash_list(gk)
    lites = [m for m in avail if "lite" in m.lower()]
    fulls = [m for m in avail if "lite" not in m.lower()]
    order = (lites + [first] + fulls) if lite else ([first] + fulls + lites)
    order += [m for m in (GEMINI_FALLBACK, "gemini-2.5-flash-lite") if m not in order]
    models = []
    for m in order:
        if m and m not in models:
            models.append(m)
    models = models[:5]
    data = json.dumps(payload).encode("utf-8")
    last = None
    for i, model in enumerate(models):
        req = urllib.request.Request(f"{GEMINI}/models/{model}:generateContent?key={gk}", data=data,
                                     method="POST", headers={"content-type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=timeout if i == 0 else min(timeout, 25)) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as ex:
            if ex.code < 500 and ex.code not in (404, 429):
                raise
            if last is None or getattr(last, "code", 0) != 429:     # guarda o 429 (o motivo mais util para mostrar)
                last = ex
        except urllib.error.URLError as ex:
            if not isinstance(getattr(ex, "reason", None), TimeoutError):
                raise
            last = last or TimeoutError("timeout")
        except TimeoutError as ex:
            last = last or ex
    raise last


def _gemini_key_saved():
    try:
        from . import config as _cfg
        from .web import CTX
        c = _cfg.Config(os.path.join(CTX.get("ddir") or ".", "coach.sqlite")).load()
        return (c.get("gemini_api_key") or os.environ.get("GEMINI_API_KEY") or "").strip()
    except Exception:
        return (os.environ.get("GEMINI_API_KEY") or "").strip()
