"""Detalhes da partida falados na hora certa (tudo do placar do proprio jogo: runas, feiticos, itens, farm e abates).

- Carregamento: runa principal e feiticos do oponente de rota (e do par da rota de baixo) com o que isso muda na troca.
- Item inicial do oponente (Selo Sombrio, Escudo de Doran, Lagrima...): o plano dele na rota.
- Farm aos 5/10/15/20 min contra o oponente de rota.
- Item que muda a sua jogada (Zhonya, Anjo, Mercurio, Escudo da Banshee...): o que fazer diferente.
- Primeiro item lendario do oponente e o seu: pico de forca.
- Jungler deles apareceu em outra rota: janela para jogar agressivo (ou para invadir, se voce e jungler).
- Recompensa: inimigo com 3+ abates sem morrer, e voce valendo recompensa.
- Morrendo sempre para o mesmo: mude o plano.
- Assassino: alvo do combo (o carregador mais fragil e sem item de defesa).
- Caranguejos aos 3:30 (meio e selva).

Uma fala nova a cada ~18 s no maximo (prioridade pela ordem acima). Chaves det_* (o overlay fala uma vez cada).
"""
import os

_ST = {}
GAP = 18

LANE_PT = {"TOP": "topo", "JUNGLE": "selva", "MIDDLE": "meio", "BOTTOM": "rota de baixo", "UTILITY": "rota de baixo"}
LANE_NO = {"TOP": "no topo", "MIDDLE": "no meio", "BOTTOM": "na rota de baixo", "UTILITY": "na rota de baixo"}
SIDE = {"TOP": "cima", "MIDDLE": "meio", "BOTTOM": "baixo", "UTILITY": "baixo"}

KEYSTONE = {
    8112: "trocas curtas e explosivas: depois que ele acertar o combo, recue e não fique trocando",
    8128: "fica mais forte a cada abate: não entregue abate cedo",
    9923: "três ataques muito rápidos de uma vez: não deixe ele encostar em você",
    8005: "o terceiro ataque seguido aumenta o dano: corte a troca antes disso",
    8008: "fica mais forte quanto mais longa a luta: troque curto",
    8021: "troca de longe e se cura: puna quando ele chegar perto pra farmar",
    8010: "ganha força em luta longa: troque curto e saia",
    8437: "ganha toda troca curta: não fique parado na frente dele",
    8439: "fica resistente depois de prender você: não troque logo depois do controle dele",
    8214: "vai cutucar o tempo todo: mantenha a vida alta",
    8229: "vai cutucar de longe: ande de lado para desviar",
    8230: "foge e persegue fácil: gank nele precisa de controle de grupo",
    8351: "deixa lento forte: cuidado com o all-in junto do jungler",
    8369: "ganha ouro trocando: não deixe ele acertar primeiro",
    8465: "protege o atirador dele: foque quem não está com o escudo",
}
SUMM = {
    "ignite": "tem Incendiar: vai buscar abate, cuidado abaixo de metade da vida",
    "teleport": "tem Teleporte: pode aparecer em outra rota, avise quando ele sumir",
    "exhaust": "tem Exaustão: o seu all-in perde força",
    "barrier": "tem Barreira: o combo precisa de mais dano",
    "cleanse": "tem Purificar: pode limpar o seu controle",
    "ghost": "tem Fantasma: corre muito para perseguir ou fugir",
    "heal": "tem Curar",
}
RAW = {"SummonerDot": "ignite", "SummonerBoost": "cleanse", "SummonerHaste": "ghost", "SummonerFlash": "flash", "SummonerExhaust": "exhaust",
       "SummonerHeal": "heal", "SummonerBarrier": "barrier", "SummonerTeleport": "teleport", "SummonerSmite": "smite"}
PT = {"incendiar": "ignite", "exaust": "exhaust", "curar": "heal", "barreira": "barrier", "purificar": "cleanse",
      "fantasma": "ghost", "teleporte": "teleport", "golpear": "smite", "flash": "flash"}

START = {
    1082: "começou com Selo Sombrio: confia na rota e quer abate, não morra pra ele",
    1054: "começou com Escudo de Doran: vai jogar seguro e se curar, foque no farm e na prioridade de rota",
    2033: "começou com Poção Corrompida: vai trocar muito com sustentação",
    3070: "começou com Lágrima: é fraco no começo, puna nos níveis 1 a 3",
    1083: "começou com Ceifador: vai farmar passivo, puna com trocas",
    1056: "começou com Anel de Doran: vai cutucar e farmar de longe",
}
# itens que mudam a sua jogada contra ele
ANSWER = {
    3157: ("fica intocável por alguns segundos", "espere ele usar a Zhonya antes de usar o seu combo"),
    2420: ("pode ficar intocável uma vez", "espere ele usar a Ampulheta antes do seu combo"),
    3026: ("revive depois de morrer", "guarde dano para a segunda vida"),
    3140: ("pode limpar o controle", "use o controle depois que ele gastar o item"),
    3139: ("pode limpar o controle", "use o controle depois que ele gastar o item"),
    3102: ("bloqueia a primeira habilidade", "quebre o escudo com uma habilidade fraca antes do combo"),
    3814: ("bloqueia a primeira habilidade", "quebre o escudo com uma habilidade fraca antes do combo"),
    3053: ("ganha um escudo grande quando apanha", "não gaste tudo no começo da luta"),
    3156: ("ganha escudo contra dano mágico", "a troca curta rende menos agora"),
    3075: ("devolve dano e corta cura", "evite trocas longas de ataque básico"),
    3143: ("deixa ataques lentos e reduz crítico", "procure outro alvo na luta"),
    3047: ("reduz dano de ataques básicos", "troque com habilidades, não com ataques básicos"),
    3111: ("reduz o tempo de controle", "o seu controle dura menos nele"),
    4401: ("reduz dano mágico em luta longa", "troque curto e explosivo"),
    2504: ("ganha escudo contra dano mágico", "a troca curta rende menos agora"),
    3091: ("reduz dano mágico e acerta forte", "não troque ataque com ele"),
    3065: ("se cura muito mais", "compre corte de cura"),
}
ASSASSIN_ANSWER = {3157, 2420, 3026, 3140, 3139, 3102, 3814}
DEF_ITEMS = set(ANSWER)


def _gk(live_data):
    return "|".join(sorted((p.get("championName") or "") for p in live_data.get("allPlayers") or []))


def _summ(p):
    out = []
    for slot in ("summonerSpellOne", "summonerSpellTwo"):
        sp = (p.get("summonerSpells") or {}).get(slot) or {}
        raw = sp.get("rawDisplayName") or ""
        k = next((v for r, v in RAW.items() if r.lower() in raw.lower()), None)
        if not k:
            low = (sp.get("displayName") or "").lower()
            k = next((v for r, v in PT.items() if r in low), None)
        if k:
            out.append(k)
    return out


def _ids(p):
    return [int(it.get("itemID") or 0) for it in p.get("items") or []]


def _legendary(p, items):
    """Itens completos e caros (lendarios), sem botas e consumiveis."""
    out = []
    for i in _ids(p):
        info = (items or {}).get(str(i)) or {}
        g = (info.get("gold") or {}).get("total") or 0
        tags = info.get("tags") or []
        if g >= 2200 and "Boots" not in tags and "Consumable" not in tags and not info.get("into"):
            out.append(i)
    return out


def _iname(i, items):
    return ((items or {}).get(str(i)) or {}).get("name") or "um item de defesa"


def _champs(ddir):
    try:
        from .ddragon import DataDragon
        return DataDragon(cache_dir=os.path.join(ddir, "cache") if ddir else "cache").champions()
    except Exception:
        return {}


# ultimates perigosas: um aviso quando o inimigo chega no nivel 6 (conhecimento do campeao, nao acompanha recarga)
ULT_PERIGO = {
    "Rengar": "O Rengar chegou no 6: a ultimate deixa ele invisível e ele pula em quem estiver sozinho. Fique perto do time, sentinela de controle e Lente ajudam a achar ele.",
    "KhaZix": "O Kha'Zix chegou no 6: ele fica invisível e caça quem está isolado. Não ande sozinho pela selva.",
    "Evelynn": "A Evelynn chegou no 6: ela já ganka invisível desde o começo e agora finaliza de longe com a ultimate. Sentinela de controle no rio.",
    "TwistedFate": "O Twisted Fate chegou no 6: a ultimate mostra todo mundo e ele se teleporta. Quando ele sumir da rota, recue.",
    "Pantheon": "O Pantheon chegou no 6: ele cai do céu em qualquer rota. Quando ele sumir, jogue perto da torre.",
    "Shen": "O Shen chegou no 6: ele protege um aliado de qualquer lugar do mapa. Conte com ele na luta.",
    "Nocturne": "O Nocturne chegou no 6: a ultimate apaga a visão de todos e ele voa em alguém. Quando escurecer, fique perto do time.",
    "Karthus": "O Karthus chegou no 6: a ultimate acerta todo mundo no mapa. Com pouca vida, volte para a base.",
    "Ashe": "A Ashe chegou no 6: a flecha atordoa de longe e abre gank. Desvie para o lado quando ela atirar.",
    "Jinx": "A Jinx chegou no 6: o foguete finaliza de qualquer distância. Com pouca vida, volte.",
    "Draven": "O Draven chegou no 6: os machados finalizam de longe. Com pouca vida, volte.",
    "Galio": "O Galio chegou no 6: ele pula na luta de outra rota. Conte com ele antes de lutar.",
    "Ezreal": "O Ezreal chegou no 6: a ultimate acerta de qualquer distância. Com pouca vida, volte.",
    "Senna": "A Senna chegou no 6: a ultimate atravessa o mapa. Com pouca vida, volte.",
    "Soraka": "A Soraka chegou no 6: ela cura o time inteiro de qualquer lugar. Termine o abate antes de ela usar.",
    "Malphite": "O Malphite chegou no 6: a ultimate derruba todo mundo junto. Não fiquem amontoados.",
    "Amumu": "O Amumu chegou no 6: a ultimate prende todo mundo em volta dele. Separe do time quando ele vier.",
    "Leona": "A Leona chegou no 6: a ultimate atordoa no centro. Cuidado com a rota de baixo depois do 6.",
    "Zed": "O Zed chegou no 6: a ultimate marca e mata alvo sozinho. Guarde Zhonya ou o Flash para ela.",
    "Fizz": "O Fizz chegou no 6: o tubarão derruba e dá muito dano. Quando o peixe grudar, saia do círculo.",
    "Kayn": "O Kayn chegou no 6: ele entra no seu corpo e fica intocável. Fique perto da torre quando ele sumir.",
    "Kalista": "A Kalista chegou no 6: ela puxa o suporte e joga ele em cima do time.",
    "Vi": "A Vi chegou no 6: a ultimate prende o alvo e ninguém consegue impedir. Quem carrega o time, fique atrás.",
    "Warwick": "O Warwick chegou no 6: ele salta e prende. Com pouca vida, ele te acha.",
    "Briar": "A Briar chegou no 6: ela atravessa o mapa até um campeão. Cuidado com pouca vida.",
    "Hecarim": "O Hecarim chegou no 6: a ultimate assusta o time inteiro. Não fiquem amontoados.",
    "Sion": "O Sion chegou no 6: ele vem correndo de longe e derruba. Saia da frente dele.",
    "Qiyana": "A Qiyana chegou no 6: a ultimate atordoa perto de paredes. Lute longe das paredes.",
}


def candidates(live_data, me, foes, pos, gt, items, ddir=None, st=None):
    """Todas as falas possiveis agora, da mais importante para a menos: [(chave, texto, texto_curto)]."""
    from . import live, liveview
    out = []
    add = lambda k, t, v=None: out.append(("det_" + k, t, v))
    pos = (pos or "").upper()
    me_name = live._name(me)
    alive = not me.get("isDead")
    ev = (live_data.get("events") or {}).get("Events") or []
    allp = live_data.get("allPlayers") or []
    by_name = {live._name(p): p for p in allp}
    lp = next((p for p in foes if pos and pos != "JUNGLE" and (p.get("position") or "").upper() == pos), None)
    if pos == "JUNGLE":
        lp = next((p for p in foes if (p.get("position") or "").upper() == "JUNGLE"), None)
    ejg = next((p for p in foes if (p.get("position") or "").upper() == "JUNGLE"), None)
    pair = None
    if pos in ("BOTTOM", "UTILITY"):
        other = "UTILITY" if pos == "BOTTOM" else "BOTTOM"
        pair = next((p for p in foes if (p.get("position") or "").upper() == other), None)
    champs = _champs(ddir)
    my_cid = liveview.champ_id(me)
    my_info = champs.get(my_cid) or {}
    i_am_assassin = "Assassin" in (my_info.get("tags") or [])
    i_am_ap = (my_info.get("info") or {}).get("magic", 0) > (my_info.get("info") or {}).get("attack", 0)

    # 1) carregamento: runa e feiticos do oponente (e do par da rota de baixo)
    if gt < 150:
        for p in [x for x in (lp, pair) if x]:
            nm = p.get("championName")
            ks = ((p.get("runes") or {}).get("keystone") or {})
            kid = int(ks.get("id") or 0)
            sp = _summ(p)
            bits = []
            if kid in KEYSTONE:
                tip_ = KEYSTONE[kid]
                bits.append(f"{nm} com {ks.get('displayName') or 'essa runa'}. {tip_[0].upper() + tip_[1:]}")
            extra = [SUMM[s] for s in sp if s in SUMM]
            if "flash" not in sp and sp and pos != "JUNGLE":
                extra.insert(0, "está sem Flash nessa partida, puna com all-in")
            if extra:
                bits.append(("Ele " if bits else f"{nm} ") + extra[0])
            if bits:
                add(f"ks_{nm}", ". ".join(bits) + ".")

    # 2) item inicial do oponente
    if lp and 15 <= gt < 180 and pos != "JUNGLE":
        hit = next((i for i in _ids(lp) if i in START), None)
        if hit:
            add(f"start_{lp.get('championName')}", f"{lp.get('championName')} {START[hit]}.")

    # 3) caranguejos (meio e selva)
    if pos in ("MIDDLE", "JUNGLE") and 190 <= gt < 205:
        add("scuttle", "Caranguejos nascem em 3 minutos e meio: se a sua onda estiver empurrada, vá para o rio com o seu jungler."
            if pos == "MIDDLE" else "Caranguejos em 3 minutos e meio: veja de que lado o jungler deles começou e dispute o caranguejo do lado oposto.")

    # 4) farm contra o oponente aos 5/10/15/20 min (suporte e caçador nao: nao e o trabalho deles)
    if lp and pos not in ("UTILITY", "JUNGLE"):
        for m in (5, 10, 15, 20):
            if m * 60 <= gt < m * 60 + 25:
                a = int((me.get("scores") or {}).get("creepScore") or 0)
                b = int((lp.get("scores") or {}).get("creepScore") or 0)
                d = a - b
                nm = lp.get("championName")
                if d <= -10:
                    tip = "farme perto da torre e não troque sem motivo" if m <= 10 else "pegue as ondas do lado antes de ir para luta"
                    add(f"cs_{m}", f"{m} minutos: você tem {a} de farm e {nm} tem {b}. Está {-d} atrás: {tip}.",
                        f"{m} minutos: {-d} de farm atrás do {nm}.")
                elif d >= 15:
                    add(f"cs_{m}", f"{m} minutos: {a} de farm contra {b} do {nm}. {d} na frente: use para rodar ou pegar placa.",
                        f"{m} minutos: {d} de farm na frente do {nm}.")
                else:
                    add(f"cs_{m}", f"{m} minutos: {a} de farm, {nm} tem {b}.", None)

    # 5) item que muda a sua jogada
    for p in foes:
        relevant = p is lp or p is pair or (i_am_assassin and (p.get("position") or "").upper() in ("MIDDLE", "BOTTOM", "UTILITY"))
        nm = p.get("championName")
        for i in _ids(p):
            if i not in ANSWER:
                continue
            if i == 3047 and i_am_ap or i in (3111,) and p is not lp:
                continue
            if i in (3156, 4401, 2504, 3091) and not i_am_ap:
                continue
            if not relevant and not (i_am_assassin and i in ASSASSIN_ANSWER):
                continue
            what, do = ANSWER[i]
            add(f"ans_{nm}_{i}", f"{nm} comprou {_iname(i, items)}: {what}. {do[0].upper() + do[1:]}.",
                f"{nm} tem {_iname(i, items)}: {do}.")

    # 6) primeiro item lendario: pico de forca
    if lp and gt < 1500:
        le, me_le = _legendary(lp, items), _legendary(me, items)
        nm = lp.get("championName")
        if le and len(le) > len(me_le):
            add(f"spike_{nm}_{len(le)}", f"{nm} fechou {_iname(le[-1], items)} e está com mais item que você: evite troca até fechar o seu.",
                f"{nm} fechou item: evite troca até fechar o seu.")
        if me_le and len(me_le) > len(le):
            add(f"myspike_{len(me_le)}", f"Você fechou {_iname(me_le[-1], items)} e está com mais item que {nm}: é o seu pico, procure troca.",
                "Você fechou item: é o seu pico, procure troca.")

    # 7) jungler deles apareceu em outra rota
    if ejg and gt < 1200 and alive:
        jn = live._name(ejg)
        for x in ev:
            if x.get("EventName") != "ChampionKill" or gt - (x.get("EventTime") or 0) > 15:
                continue
            if jn not in [x.get("KillerName")] + list(x.get("Assisters") or []) and x.get("VictimName") != jn:
                continue
            v = by_name.get(x.get("VictimName")) or {}
            if v is me:
                continue
            lane = (v.get("position") or "").upper()
            if lane not in SIDE:
                continue
            nm = ejg.get("championName")
            if pos == "JUNGLE":
                far = {"cima": "baixo", "baixo": "cima"}.get(SIDE[lane])
                t = (f"{nm} apareceu {LANE_NO[lane]}: o lado de {far} da selva está livre, invada ou pegue o objetivo de {far}."
                     if far else f"{nm} apareceu no meio: os dois lados estão longe dele por alguns segundos.")
            elif SIDE.get(pos) == SIDE[lane] or (pos == "MIDDLE" and lane == "MIDDLE"):
                continue
            else:
                t = f"{nm} apareceu {LANE_NO[lane]}: está longe de você. Jogue agressivo pelos próximos 30 segundos."
            add(f"jgseen_{int(x.get('EventTime') or 0)}", t)
            break

    # 8) recompensa (3+ abates sem morrer)
    streak = {}
    for x in ev:
        if x.get("EventName") != "ChampionKill":
            continue
        streak[x.get("VictimName")] = 0
        k = x.get("KillerName")
        streak[k] = streak.get(k, 0) + 1
    for p in foes:
        n = streak.get(live._name(p), 0)
        if n >= 3:
            add(f"bounty_{p.get('championName')}_{n}", f"{p.get('championName')} está com {n} abates sem morrer e vale recompensa: "
                "não lute sozinho com ele. Em luta de time, ele é o alvo.", f"{p.get('championName')} vale recompensa: não lute sozinho com ele.")
    n_me = streak.get(me_name, 0)
    if n_me >= 3:
        add(f"bounty_me_{n_me}", f"Você está com {n_me} abates sem morrer e vale recompensa: não arrisque sem visão.",
            "Você vale recompensa: não arrisque sem visão.")

    # 9) morrendo sempre para o mesmo
    killers = {}
    for x in ev:
        if x.get("EventName") == "ChampionKill" and x.get("VictimName") == me_name:
            kp = by_name.get(x.get("KillerName"))
            if kp and kp.get("team") != me.get("team"):
                killers[kp.get("championName")] = killers.get(kp.get("championName"), 0) + 1
    for nm, n in killers.items():
        if n >= 2:
            if ejg and nm == ejg.get("championName") and pos != "JUNGLE":
                t = f"Você já morreu {n} vezes para {nm}, o jungler deles: coloque sentinela no rio antes de avançar."
            else:
                t = f"Você já morreu {n} vezes para {nm}: mude o plano contra ele, jogue com o time e não sozinho."
            add(f"deaths_{nm}_{n}", t)

    # 9b) atras no meio do jogo: o plano certo (em vez de entrar na luta do time e morrer)
    if 840 <= gt < 2100 and alive:
        from .macrocues import _val
        mine_v = sum(_val(p, items) for p in live_data.get("allPlayers") or [] if p.get("team") == me.get("team"))
        foe_v = sum(_val(p, items) for p in foes)
        lane_d = (_val(me, items) - _val(lp, items)) if lp else 0
        behind = foe_v - mine_v >= 3000 or lane_d <= -1200
        if behind:
            slot = int(gt // 240)
            if i_am_assassin:
                add(f"behind_{slot}", "Vocês estão atrás no ouro. Assassino atrás não ganha luta cinco contra cinco: pressione uma onda do lado com visão, "
                    "espere o carregador deles ficar fora de posição e só entre na luta com um alvo certo para a ult.",
                    "Atrás no ouro: pressione o lado e só entre com alvo certo.")
            elif pos == "UTILITY":
                add(f"behind_{slot}", "Vocês estão atrás no ouro. Não force luta: coloque visão perto das torres do seu lado, fique com quem carrega "
                    "e espere eles errarem para lutar.", "Atrás no ouro: visão segura e proteja quem carrega.")
            else:
                add(f"behind_{slot}", "Vocês estão atrás no ouro. Não force luta: pegue as ondas do lado seguro, defenda perto das torres "
                    "e espere eles errarem para lutar.", "Atrás no ouro: farme seguro e espere eles errarem.")

    # 10) assassino: alvo do combo
    if i_am_assassin and int(me.get("level") or 1) >= 6 and gt < 2100:
        slot = 0 if gt < 600 else int(gt // 300)
        best, best_s, avoid = None, -1e9, []
        for p in foes:
            info = champs.get(liveview.champ_id(p)) or {}
            if "Tank" in (info.get("tags") or []) or p.get("isDead"):
                continue
            ids = set(_ids(p))
            sc = p.get("scores") or {}
            s = 2 * int(sc.get("kills") or 0) + len(_legendary(p, items)) * 2 - int(sc.get("deaths") or 0)
            if (p.get("position") or "").upper() in ("BOTTOM", "MIDDLE"):
                s += 3
            if ids & ASSASSIN_ANSWER:
                avoid.append((p.get("championName"), _iname(next(iter(ids & ASSASSIN_ANSWER)), items)))
                s -= 6
            if s > best_s:
                best, best_s = p, s
        if best:
            sc = best.get("scores") or {}
            t = f"Alvo do seu combo: {best.get('championName')} ({sc.get('kills', 0)}/{sc.get('deaths', 0)}/{sc.get('assists', 0)})"
            t += ", sem item de defesa." if not set(_ids(best)) & ASSASSIN_ANSWER else "."
            if avoid and avoid[0][0] != best.get("championName"):
                t += f" Evite {avoid[0][0]}: tem {avoid[0][1]}."
            add(f"target_{slot}", t, f"Alvo do seu combo: {best.get('championName')}.")
    # 13) oponente de rota comprou na base: ele esta voltando
    if lp and alive and 150 <= gt < 900 and pos != "JUNGLE" and st is not None:
        v_lp = sum(((items or {}).get(str(i)) or {}).get("gold", {}).get("total", 0) for i in _ids(lp))
        old_v = st.get("lp_val")
        st["lp_val"] = v_lp
        if old_v is not None and v_lp >= old_v + 300 and not lp.get("isDead"):
            novo = [i for i in _ids(lp) if i not in st.get("lp_ids", [])]
            nm_i = _iname(novo[-1], items) if novo else "itens"
            add(f"lpback_{int(gt)}", f"{lp.get('championName')} comprou {nm_i} na base: ele volta para a rota em uns 25 segundos. "
                "Aproveite para empurrar a onda ou voltar você também.", f"{lp.get('championName')} voltou para a base: empurre ou volte também.")
        st["lp_ids"] = _ids(lp)

    # 14) melhoria da ultimate (11 e 16)
    if lp and pos != "JUNGLE":
        for L in (11, 16):
            if int(lp.get("level") or 1) >= L > int(me.get("level") or 1):
                add(f"ult{L}_{lp.get('championName')}", f"{lp.get('championName')} chegou no {L} antes de você: a ultimate dele ficou mais forte. Evite a luta até empatar.")

    # 15) botas certas contra a composicao
    if 1001 in _ids(me) and alive and 420 <= gt < 1200 and pos != "BOTTOM":
        ap = sum(1 for p in foes if (champs.get(liveview.champ_id(p)) or {}).get("info", {}).get("magic", 0) >= 7)
        ad = sum(1 for p in foes if "Marksman" in (champs.get(liveview.champ_id(p)) or {}).get("tags", []) or
                 (champs.get(liveview.champ_id(p)) or {}).get("info", {}).get("attack", 0) >= 8)
        if ap >= 3:
            add("botas", f"O time deles tem {ap} campeões de dano mágico: na próxima volta, Botas de Mercúrio, que também diminuem o controle.",
                "Próximas botas: Mercúrio.")
        elif ad >= 3:
            add("botas", f"O time deles tem {ad} campeões de ataque físico: na próxima volta, Botas Galvanizadas de Aço.", "Próximas botas: Galvanizadas.")

    # 12) onda de canhao: a melhor hora de voltar para a base sem perder farm
    if pos in ("TOP", "MIDDLE", "BOTTOM") and alive and 180 <= gt < 840:
        t0 = next((x.get("EventTime") for x in ev if x.get("EventName") == "MinionsSpawning"), None)
        gold_ = int(((live_data.get("activePlayer") or {}).get("currentGold")) or 0)
        if t0 is not None and gold_ >= 1100:
            i = int((gt - t0) // 30) + 1                 # onda que nasceu por ultimo
            spawn = t0 + 30 * (i - 1)
            if i % 3 == 0 and gt - spawn <= 6 and gt - (st or {}).get("canhao", -999) >= 180:
                if st is not None:
                    st["canhao"] = gt
                add(f"canhao_{i}", f"A onda de canhão acabou de nascer e você tem {gold_} de ouro: empurre essa onda e volte para a base. "
                    "É a volta que perde menos farm.", "Onda de canhão: empurre e volte para a base.")

    # 11) cuidados de rotina: sentinela de controle, lente, elixir, morto no fim, ouro parado
    st = st if st is not None else {}
    ids = _ids(me)
    gold = int(((live_data.get("activePlayer") or {}).get("currentGold")) or 0)
    val = sum(((items or {}).get(str(i)) or {}).get("gold", {}).get("total", 0) for i in ids)
    if "val" not in st:
        st["val"] = val
    from . import visao
    cw_ok = not visao.needs(me, gt)                  # no inventario ou ativa no mapa
    if val > st["val"] + 300 and gt > 360:          # voltou e comprou
        st["backs"] = st.get("backs", 0) + 1
        if 2055 in ids or cw_ok:
            st["no_cw"] = 0
        else:
            st["no_cw"] = st.get("no_cw", 0) + 1
    st["val"] = max(val, st.get("val", 0))
    if st.get("no_cw", 0) in (2, 4) and gt < 2100 and pos != "UTILITY" and not cw_ok:
        add(f"cw_{st['backs']}", "Duas voltas seguidas sem Sentinela de Controle. Na próxima, compre uma e coloque no rio do seu lado.",
            "Duas voltas sem Sentinela de Controle: compre na próxima.")
    if 3340 in ids and int(me.get("level") or 1) >= 9 and pos in ("MIDDLE", "TOP", "JUNGLE") and gt < 1800:
        add("lente", "Nível 9 e você ainda está com o Totem: troque para a Lente de Varredura na próxima volta. "
            "Ela tira as sentinelas do caminho do jungler e dos seus abates.", "Troque o amuleto para a Lente de Varredura.")
    legend = len(_legendary(me, items))
    if gt >= 1800 and alive and legend >= 5 and gold >= 600 and not any(i in ids for i in (2138, 2139, 2140)):
        add(f"elixir_{int(gt // 300)}", f"Você tem {gold} de ouro sobrando e a build quase completa: compre um Elixir antes da próxima luta de objetivo.",
            "Ouro sobrando: compre Elixir antes do objetivo.")
    if me.get("isDead") and gt >= 1800 and float(me.get("respawnTimer") or 0) >= 30:
        r = int(float(me.get("respawnTimer") or 0))
        d = int((me.get("scores") or {}).get("deaths") or 0)
        add(f"mortofim_{d}", f"Você volta em {r} segundos. Sem você, o time não deve lutar nem disputar objetivo: defendam perto das torres até você nascer.",
            f"Você volta em {r}: time defende, sem luta.")
    if alive and gold >= 2000:
        st.setdefault("rich_since", gt)
        if gt - st["rich_since"] >= 120:
            add(f"rico_{int(st['rich_since'])}", f"Você está vivo com {gold} de ouro há mais de 2 minutos: empurre a onda e volte para gastar. Ouro na bolsa não luta.",
                f"{gold} de ouro parado: volte para gastar.")
    else:
        st.pop("rich_since", None)

    # sentinela antes do primeiro gank (2:45): quem esta em rota
    if pos in ("TOP", "MIDDLE", "BOTTOM", "UTILITY") and 155 <= gt < 190:
        add("ward245", "Dois minutos e quarenta e cinco: coloque o amuleto no rio do lado da sua rota agora. É quando chega o primeiro gank.",
            "2:45: sentinela no rio.")
    # 4 contra 5: aliado morto por muito tempo com objetivo chegando
    try:
        ally_dead = [p for p in (live_data.get("allPlayers") or []) if p.get("team") == me.get("team") and p is not me
                     and p.get("isDead") and float(p.get("respawnTimer") or 0) >= 20]
        foe_dead = [p for p in foes if p.get("isDead") and float(p.get("respawnTimer") or 0) >= 10]
        if gt >= 600 and len(ally_dead) - len(foe_dead) >= 1 and alive:
            nm_ = ", ".join(p.get("championName") for p in ally_dead[:2])
            add(f"menos_{int(gt // 45)}", f"Vocês estão com {5 - len(ally_dead)} contra {5 - len(foe_dead)} ({nm_} morto): não dispute objetivo nem entre em luta "
                f"até ele nascer.", f"{5 - len(ally_dead)} contra {5 - len(foe_dead)}: não lute agora.")
    except Exception:
        pass
    # fim da fase de rotas: hora de agrupar
    try:
        tw = [x for x in ev if x.get("EventName") == "TurretKilled"]
        if 840 <= gt < 1200 and len(tw) >= 3:
            add("agrupar", "A fase de rotas acabou: várias torres já caíram. Agora o time joga junto: "
                + ("vá com o time para o próximo objetivo com visão." if pos in ("UTILITY", "JUNGLE") else
                   "empurre a sua onda e vá para o lado do próximo objetivo."), "Fim da fase de rotas: joguem juntos.")
    except Exception:
        pass
    # inibidor seu renascendo (5 min depois de cair)
    try:
        my_t = me.get("team")
        for x in ev:
            if x.get("EventName") != "InhibKilled":
                continue
            killer = by_name.get(x.get("KillerName"))
            if killer and killer.get("team") != my_t:
                volta = (x.get("EventTime") or 0) + 300
                if volta - 20 <= gt < volta:
                    add(f"inibvolta_{int(volta)}", "O seu inibidor volta em 20 segundos: as supertropas param. Segure só mais um pouco.",
                        "Seu inibidor volta em 20 s.")
    except Exception:
        pass
    # ouro para item depois de uma luta (ideia 32)
    try:
        recent = [x for x in ev if x.get("EventName") == "ChampionKill" and gt - (x.get("EventTime") or 0) <= 8
                  and (x.get("KillerName") == me_name or me_name in (x.get("Assisters") or []))]
        if alive and recent and gold >= 1300 and gt >= 360:
            add(f"ouroluta_{int(gt // 60)}", f"Luta boa e você tem {gold} de ouro: se a onda deixar, volte agora para comprar. O item ganha a próxima luta.",
                "Luta ganha: volte para comprar.")
    except Exception:
        pass
    # tipo da alma do dragao (ideia 38): o terceiro dragao da partida mostra o elemento da alma
    try:
        drs = [x for x in ev if x.get("EventName") == "DragonKill" and (x.get("DragonType") or "").lower() not in ("elder", "")]
        if len(drs) == 3:
            tp = (drs[2].get("DragonType") or "").lower()
            ALMA = {"fire": ("do Infernal", "dano extra em explosão"), "earth": ("da Montanha", "escudo forte"), "water": ("do Oceano", "cura fora de luta"),
                    "air": ("das Nuvens", "velocidade depois da ultimate"), "hextech": ("Hextec", "lentidão em cadeia"), "chemtech": ("Quimtec", "resistência quando com pouca vida")}
            if tp in ALMA and gt - (drs[2].get("EventTime") or 0) <= 60:
                add(f"alma_{tp}", f"A alma desta partida é a {ALMA[tp][0]} ({ALMA[tp][1]}). Quem chegar a 4 dragões leva: conte os dragões de cada time.")
    except Exception:
        pass
    # ultimate perigosa no time deles: um aviso no nivel 6 de cada um
    for p in foes:
        cid_ = liveview.champ_id(p)
        if cid_ in ULT_PERIGO and int(p.get("level") or 1) >= 6 and cid_ != my_cid:
            add(f"ult6_{cid_}", ULT_PERIGO[cid_])
    # dica de especialista do confronto (ex.: Fizz saindo para roamar, Xerath com ultimate)
    try:
        if lp:
            from . import especialista
            for k_, t_ in especialista.jogo(my_cid, liveview.champ_id(lp), gt, lp.get("level")):
                add(f"esp_{k_}", t_)
    except Exception:
        pass
    return out


def cues(live_data, me, foes, pos, gt, items, ddir=None):
    """Escolhe no maximo uma fala nova por vez (intervalo GAP) e repete as recentes por 60 s (o overlay fala uma vez)."""
    st = _ST.setdefault(_gk(live_data), {"done": {}, "last": -1e9})
    if len(_ST) > 4:
        for k in list(_ST)[:-4]:
            _ST.pop(k, None)
    try:
        cands = candidates(live_data, me, foes, pos, gt, items, ddir, st)
    except Exception:
        cands = []
    if gt - st["last"] >= GAP:
        for k, t, v in cands:
            if k not in st["done"]:
                st["done"][k] = (gt, t, v)
                st["last"] = gt
                break
    out = []
    for k, (at, t, v) in st["done"].items():
        if gt - at < 60:
            out.append({"k": k, "t": t, **({"v": v} if v else {})})
    return out
