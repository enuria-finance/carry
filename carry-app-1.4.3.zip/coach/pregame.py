"""Antes da partida: aquecimento, sequencia ruim, limite do dia, plano ao trancar, melhor do pool contra o oponente,
ban pela composicao e ajuste de build pela composicao inimiga.

Tudo vem do SEU historico (dado), das partidas dos melhores guardadas pelo app (dado) e das classes do Data Dragon
(regra geral / hipotese). Nada le o jogo: so o cliente (fila e selecao) e o banco local.
"""
import time

from . import draft, habits, report

DEFAULT_LIMIT = 5

# campeoes com muita cura propria (regra geral: anticura rende contra eles)
HEALERS = {"Aatrox", "Vladimir", "Soraka", "Sylas", "Warwick", "DrMundo", "Yuumi", "Swain", "Briar", "Olaf", "Illaoi",
           "Fiddlesticks", "Nidalee", "Sona", "Seraphine", "Volibear", "Udyr", "Trundle", "Gwen", "Maokai", "Zac", "Nami",
           "Milio", "Belveth", "Viego", "Kayn", "Samira", "Yorick", "Renekton", "Darius", "Mordekaiser", "Senna"}

# itens por funcao (o app confere se o item existe na versao atual antes de sugerir)
ANTIHEAL = {"AD": [3123, 3033, 6609], "AP": [3916, 3165, 3011], "TANK": [3076, 3075], "SUP": [3011, 3916]}
# escudos fortes: Presa da Serpente (6695) corta escudo para quem causa dano fisico
SHIELDERS = {"Lulu", "Karma", "Janna", "Yasuo", "Yone", "Sett", "Seraphine", "Lux", "Renata", "Ivern", "Orianna", "Rakan",
             "Riven", "Shen", "Sion", "Diana", "Mordekaiser", "Nautilus", "Skarner", "Taric", "Galio", "Garen", "Annie",
             "Sona", "Milio", "Viktor", "TahmKench", "Urgot", "Rumble", "Poppy", "KSante", "Camille", "Kalista", "Lissandra"}
# controle pesado (atordoar, prender, puxar): Passos de Mercurio; atirador: Bandana/Cimitarra de Mercurio; suporte: Mikael
HARD_CC = {"Leona", "Nautilus", "Amumu", "Malphite", "Sejuani", "Lissandra", "Morgana", "Ashe", "Lux", "Thresh", "Blitzcrank",
           "Rell", "Maokai", "Zac", "Annie", "Veigar", "Vi", "Warwick", "Skarner", "Rammus", "Alistar", "Taric", "TwistedFate",
           "Sion", "Galio", "Ornn", "JarvanIV", "Neeko", "Seraphine", "Zyra", "Xerath", "Pyke", "Rakan", "Braum", "Poppy",
           "Cassiopeia", "Fiddlesticks", "Nami", "Sona", "Gragas", "Jax", "Pantheon", "Renekton", "Ryze", "Swain", "Lillia"}
AD_ASSASSINS = {"Zed", "Talon", "Qiyana", "Khazix", "Rengar", "Naafiri", "Pyke", "Kayn", "Nocturne", "Yone", "Yasuo"}
AP_BURST = {"Fizz", "Leblanc", "Evelynn", "Kassadin", "Akali", "Diana", "Ekko", "Katarina", "Syndra", "Veigar", "Annie",
            "Ahri", "Lux", "Elise", "Sylas", "Vex", "Zoe", "Brand", "Hwei", "Aurora"}
SERPENT, ZHONYA, BANSHEE, MAW, MERC_BOOTS, QSS, MERCURIAL, MIKAEL, GA = 6695, 3157, 3102, 3156, 3111, 3140, 3139, 3222, 3026
STEELCAPS, SEEKER = 3047, 2420
AD_ASSASSINS |= {"Akshan", "Shaco", "Briar", "Kled", "Pantheon", "Talon"}
PEN = {"AD": [3036, 6694, 3071], "AP": [3135, 4010]}


def _day_start_ms(now=None):
    lt = time.localtime(now or time.time())
    return int(time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 0, 0, 0, 0, 0, -1)) * 1000)


def today(con, puuid, limit=None):
    """Partidas de hoje, vitorias, sequencia atual e o que fazer com o limite do dia."""
    limit = int(limit or DEFAULT_LIMIT)
    res = habits.all_results(con, puuid, 40)
    try:          # o cliente sabe das partidas na hora, mesmo com a chave da Riot vencida
        from . import lcu
        cl = lcu.LCU.discover().recent_results(20)
        if cl and (not res or cl[0]["started_ms"] > (res[0]["started_ms"] or 0) + 60000):
            res = cl
    except Exception:
        pass
    t0 = _day_start_ms()
    day = [r for r in res if (r["started_ms"] or 0) >= t0]
    w = sum(1 for r in day if r["win"])
    streak_l = streak_w = 0
    for r in res:
        if r["win"]:
            if streak_l:
                break
            streak_w += 1
        else:
            if streak_w:
                break
            streak_l += 1
    n = len(day)
    if n >= limit and streak_l >= 2:
        verdict, msg = "stop", f"Limite do dia alcançado ({n} de {limit}) e {streak_l} derrotas seguidas: melhor parar por hoje."
    elif n >= limit and streak_w:
        verdict, msg = "go", f"Limite do dia alcançado ({n} de {limit}), mas você está ganhando: pode seguir enquanto estiver bem."
    elif n >= limit:
        verdict, msg = "warn", f"Limite do dia alcançado ({n} de {limit}). Se a próxima for derrota, pare."
    elif streak_l >= 2:          # combinado com o usuario: duas derrotas seguidas, parou por hoje
        verdict, msg = "stop", (f"{streak_l} derrotas seguidas. Combinado: parou por hoje. "
                                "Agora o jogo é contra o tilt, não contra o time inimigo. O PDL volta amanhã, com a cabeça fria.")
    else:
        verdict, msg = "ok", f"{n} de {limit} partidas hoje."
    return {"n": n, "w": w, "l": n - w, "limit": limit, "streak_l": streak_l, "streak_w": streak_w,
            "verdict": verdict, "msg": msg, "last": res[0] if res else None}


def last_focus(con, puuid):
    """Uma frase sobre o que mais pesou na ultima partida (analise da IA, se tiver; senao os numeros)."""
    try:
        res = habits.all_results(con, puuid, 1)
        if not res:
            return None
        mid = res[0]["match_id"]
        try:
            from . import analysis
            a = analysis.get(con, mid)
            if a and a.get("focus"):
                return a["focus"]
        except Exception:
            pass
        g = next((x for x in report.my_games(con, puuid, "") if x["match_id"] == mid), None)
        if not g:
            return None
        if (g.get("deaths_before_10") or 0) >= 2:
            return f"na última você morreu {g['deaths_before_10']} vezes antes dos 10 minutos"
        if g.get("csdiff10") is not None and g["csdiff10"] <= -15:
            return f"na última você terminou os 10 minutos com {abs(g['csdiff10'])} de farm a menos que o oponente"
        if g.get("deaths", 0) >= 8:
            return f"na última você morreu {g['deaths']} vezes"
        return "na última partida " + ("você venceu: repita o que funcionou" if g.get("win") else "o jogo escapou: jogue o começo com mais calma")
    except Exception:
        return None


def lobby_cues(con, puuid, limit=None):
    """Na fila (lobby): aquecimento, sequencia ruim e limite do dia. Chaves mudam por dia e por partida."""
    al = []
    add = lambda k, t, v=None: al.append({"k": k, "t": t, **({"v": v} if v else {})})
    st = today(con, puuid, limit)
    tag = time.strftime("%Y%m%d") + f"_{st['n']}"
    parts = []
    try:
        from . import missions
        m = missions.ensure_today(con, report.my_games(con, puuid, ""))
        if m and m.get("mission"):
            t_ = m['mission']['text']
            parts.append(f"foco de hoje: {t_[:1].lower() + t_[1:]}")
    except Exception:
        pass
    lf = last_focus(con, puuid)
    if lf:
        parts.append(lf)
    if parts:
        add(f"lobby_warm_{tag}", "Aquecimento · " + " · ".join(parts), "Aquecimento. " + ". ".join(p[0].upper() + p[1:] for p in parts) + ".")
    try:                          # horario em que voce perde mais (pelo seu historico)
        hr = time.localtime().tm_hour
        if hr >= 23 or hr < 5:
            res_ = habits.all_results(con, puuid, 400)
            late = [r for r in res_ if r.get("started_ms") and (time.localtime(r["started_ms"] / 1000).tm_hour >= 23
                                                                 or time.localtime(r["started_ms"] / 1000).tm_hour < 5)]
            if len(late) >= 15:
                lw = round(100 * sum(1 for r in late if r["win"]) / len(late))
                if lw <= 46:
                    add(f"lobby_late_{time.strftime('%Y%m%d')}", f"Depois das 23h você tem {lw}% de vitórias em {len(late)} partidas. "
                        "Nesse horário o seu jogo cai: melhor parar e voltar amanhã.", f"Depois das 23h você tem {lw}%. Melhor parar por hoje.")
    except Exception:
        pass
    try:                          # caminho ate a meta (uma vez por dia)
        from . import accounts, caminho
        lk = None
        try:
            from .web import CTX
            lk = CTX.get("link")
        except Exception:
            lk = None
        ln = caminho.lobby_line(caminho.build(con, puuid, lk)) if lk else None
        if ln:
            add(f"lobby_meta_{time.strftime('%Y%m%d')}", ln)
    except Exception:
        pass
    try:                          # treino do dia: o maior buraco contra os melhores com o seu campeao
        from . import evolucao
        dt = evolucao.drill_text(evolucao.gaps(con, puuid))
        if dt:
            add(f"lobby_treino_{time.strftime('%Y%m%d')}", dt)
    except Exception:
        pass
    try:                          # cansaco (ordem da partida no dia) e queda de rendimento
        from . import evolucao2
        gs_ = report.my_games(con, puuid, "")
        fw = evolucao2.fatigue_warn(gs_, st["n"])
        if fw:
            add(f"lobby_cansaco_{tag}", fw)
        sw = evolucao2.slump_warn(gs_)
        if sw:
            add(f"lobby_queda_{gs_[0]['match_id'] if gs_ else ''}", sw)
    except Exception:
        pass
    try:                          # pausa de 3 minutos depois de uma derrota
        last = st.get("last") or {}
        if last and not last.get("win") and last.get("started_ms"):
            fim = last["started_ms"] + int(last.get("duration_s") or 0) * 1000
            falta = 180 - (time.time() * 1000 - fim) / 1000
            if 0 < falta <= 180 and last.get("duration_s"):
                add(f"lobby_pausa_{last.get('match_id') or fim}", f"Derrota. Pausa de 3 minutos antes da próxima: levante, beba água e volte. "
                    f"Faltam {int(falta // 60)}:{int(falta % 60):02d}.", "Derrota. Três minutos de pausa antes da próxima.")
    except Exception:
        pass
    try:                          # derrota sem revisao: 10 minutos antes da proxima
        last = st.get("last") or {}
        mid = last.get("match_id")
        if mid and not last.get("win"):
            gid_ = str(mid).split("_")[-1]
            done = con.execute("SELECT COUNT(*) FROM review_answers WHERE match_id=? OR match_id LIKE ?", (mid, "%_" + gid_)).fetchone()[0]
            try:                  # revisao pela IA (abrir a revisao ja gera a analise) tambem conta
                done += con.execute("SELECT COUNT(*) FROM match_ai WHERE match_id=? OR match_id LIKE ?", (mid, "%_" + gid_)).fetchone()[0]
            except Exception:
                pass
            if not done:
                add(f"lobby_rev_{mid}", "A última partida foi derrota e ainda não foi revisada. Antes da próxima: 10 minutos na revisão das mortes, "
                    "no Pós-jogo, em Revisão das mortes pela IA.", "A última foi derrota e não foi revisada. Dez minutos de revisão antes da próxima.")
    except Exception:
        pass
    if st["verdict"] in ("stop", "pause", "warn", "go"):
        add(f"lobby_lim_{tag}_{st['verdict']}", st["msg"])
    elif st["n"]:
        add(f"lobby_lim_{tag}", f"Hoje: {st['w']} vitórias e {st['l']} derrotas ({st['n']} de {st['limit']}).")
    return al


_CB = {}


def comp_bans(con, snap, champs, position, limit=3):
    """Ban pela composicao: quem vai bem entre os melhores e ainda pune o que o seu time esta montando (hipotese)."""
    taken = draft._taken(snap) if snap else set()
    mine = draft.comp(snap, champs)[0] if snap else {"n": 0, "names": []}
    squishy = sum(1 for nm in mine.get("names", []) if not set((champs.get(nm) or {}).get("tags", [])) & {"Tank", "Fighter"})
    ck = (draft._db_key(con), position or "")
    hit = _CB.get(ck) if ck[0] else None
    if hit and time.time() - hit[0] < 900:
        rows = hit[1]
    else:
        rows = [tuple(r) for r in con.execute(
            """SELECT p.champion, COUNT(*) n, SUM(p.win) w FROM participants p JOIN match_source s USING (match_id)
               WHERE s.source='top' AND (?='' OR p.position=?) GROUP BY p.champion HAVING n >= 8""",
            (position or "", position or "")).fetchall()]
        if ck[0]:
            _CB[ck] = (time.time(), rows)
    out = []
    for nm, n, w in rows:
        if nm in taken:
            continue
        tags = set((champs.get(nm) or {}).get("tags", []))
        sw = draft.smooth(w or 0, n)
        why = [f"{round(100 * (w or 0) / n)}% de vitória em {n} partidas dos melhores"]
        score = sw
        if squishy >= 3 and "Assassin" in tags:
            score += 0.03
            why.append(f"seu time tem {squishy} campeões frágeis")
        if mine.get("n", 0) >= 3 and mine.get("front", 0) == 0 and tags & {"Fighter", "Tank"}:
            score += 0.02
            why.append("seu time não tem linha de frente para segurar ele")
        if score < 0.52:
            continue
        out.append({"champion": nm, "score": score, "n": n, "w": w or 0, "why": why})
    out.sort(key=lambda x: -x["score"])
    return out[:limit]


def _first_ok_all(ids, items):
    for i in ids:
        it = (items or {}).get(str(i)) or {}
        if it and (it.get("gold") or {}).get("purchasable", True) is not False and (it.get("maps") or {}).get("11", True):
            return i, it.get("name", str(i))
    return None


# Itens de situacao so para quem de fato usa (pedido: Lucian recebia Presa da Serpente, que e item de letalidade).
# Regra de classe, usada quando a amostra dos melhores com o campeao e pequena.
LETHALITY = {"Zed", "Talon", "Qiyana", "Pyke", "Khazix", "Rengar", "Naafiri", "Kayn", "Shaco", "Nocturne", "Pantheon", "Graves",
             "Kindred", "Elise", "Evelynn", "Akshan", "Varus", "Caitlyn", "Draven", "Jhin", "Aphelios", "MissFortune", "Senna",
             "Yone", "Riven", "Renekton", "Jayce", "Kled", "Quinn", "Vayne", "Tryndamere", "Ambessa", "Briar"}
CLASS_OK = {
    SERPENT: lambda c, t: c in LETHALITY or "Assassin" in t[:1],
    MAW: lambda c, t: "Marksman" not in t[:1],
    3071: lambda c, t: "Fighter" in t or "Tank" in t,                 # Cutelo Negro
    6694: lambda c, t: "Marksman" not in t[:1] or c in LETHALITY,      # Lembranças de Serylda
    3036: lambda c, t: "Marksman" in t or "Fighter" in t,              # Lembranças do Lorde Dominik
    3033: lambda c, t: "Marksman" in t,                                # Lembrete Mortal
    6609: lambda c, t: "Marksman" not in t[:1],                        # Quimiopunk
    3139: lambda c, t: "Marksman" in t,                                # Cimitarra Mercurial
}
_USE = {}


def item_usage(con, champ):
    """(partidas, {item: fracao}) dos itens finais dos melhores com o campeao (qualquer rota)."""
    if not con or not champ:
        return 0, {}
    hit = _USE.get(champ)
    if hit and time.time() - hit[0] < 1800:
        return hit[1], hit[2]
    import json as _j
    from collections import Counter as _C
    cnt, n = _C(), 0
    try:
        for (its,) in con.execute("""SELECT x.items FROM participants p JOIN participant_extra x USING (match_id, participant_id)
                                     JOIN match_source s USING (match_id) WHERE s.source='top' AND p.champion=?""", (champ,)):
            n += 1
            for i in set(_j.loads(its or "[]")):
                if i:
                    cnt[int(i)] += 1
    except Exception:
        pass
    share = {i: k / n for i, k in cnt.items()} if n else {}
    _USE[champ] = (time.time(), n, share)
    return n, share


def item_fits(con, champs, mine, item_id, role=None, items=None):
    """O item faz sentido para o seu campeao NA ROTA? (itemfit: regras fixas, amostra dos melhores na rota, classe)."""
    from . import itemfit, profile
    if items is None:
        try:
            import os
            from .ddragon import DataDragon
            items = DataDragon(cache_dir=os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "cache")).items()
        except Exception:
            items = {}
    return itemfit.fits(con, champs, items, mine, role or profile.position(), item_id)


def comp_adjust(enemy_names, champs, my_dtype, items, defensive=None, role=None, mine=None, con=None, laner=None):
    """[(item_id, nome, motivo, tag)] pela composicao inimiga. my_dtype: 'AD', 'AP' ou 'TANK'. role: rota (muda o item).
    mine/con: o seu campeao e o banco; com eles, so entra item que os melhores com o seu campeao de fato compram."""
    from . import itemfit, profile
    if role not in itemfit.ROLES:
        role = profile.resolve_pos(role, mine)
    # todo item passa pelo filtro do campeao NA ROTA (antes Zhonya e botas de armadura passavam direto: atirador recebia bota de armadura)
    _first_ok = lambda ids, items_: _first_ok_all([i for i in ids if itemfit.fits(con, champs, items_, mine, role, i)], items_)
    out = []
    lane_ad_assa = bool(laner and laner in AD_ASSASSINS)
    names = [n for n in enemy_names if n]
    if not names:
        return out
    prof = {"AP": 0, "AD": 0, "MIX": 0, "front": 0}
    for nm in names:
        c = champs.get(nm) or {}
        prof[draft.damage_type(c.get("info"), c.get("tags", []))] += 1
        prof["front"] += 1 if set(c.get("tags", [])) & {"Tank", "Fighter"} else 0
    heal = [nm for nm in names if nm in HEALERS]
    if len(heal) >= 2 or (heal and len(names) <= 3):
        hit = _first_ok(ANTIHEAL["SUP"] if role == "UTILITY" and my_dtype != "TANK" else ANTIHEAL.get(my_dtype, ANTIHEAL["AD"]), items)
        if hit:
            out.append((hit[0], hit[1], f"anticura: {', '.join(heal[:3])} se curam muito", "regra"))
    if prof["front"] >= 3 and role != "UTILITY" and my_dtype != "TANK":          # tanque nao compra perfuracao
        pen_ids = PEN.get(my_dtype if my_dtype in PEN else "AD", PEN["AD"])
        if lane_ad_assa or prof["AD"] >= 3:
            pen_ids = [i for i in pen_ids if i != 4010]      # sem Botas do Feiticeiro: as botas vao ser de armadura
        hit = _first_ok(pen_ids, items)
        if hit:
            out.append((hit[0], hit[1], f"perfuração: {prof['front']} campeões de linha de frente", "regra"))
    shields = [nm for nm in names if nm in SHIELDERS]
    if shields and my_dtype == "AD" and (len(shields) >= 2 or set(shields) & {"Lulu", "Karma", "Janna", "Yasuo", "Seraphine", "Renata", "Sett"}):
        hit = _first_ok([SERPENT], items)
        if hit:
            out.append((hit[0], hit[1], f"corta escudo: {', '.join(shields[:3])} {'dão' if len(shields) > 1 else 'dá'} escudo", "regra"))
    cc = [nm for nm in names if nm in HARD_CC]
    if len(cc) >= 3:
        ids = [MIKAEL] if role == "UTILITY" else ([QSS, MERCURIAL] if role == "BOTTOM" else ([] if (lane_ad_assa or prof["AD"] >= 3) else [MERC_BOOTS]))
        hit = _first_ok(ids, items)
        if hit:
            out.append((hit[0], hit[1], f"muito controle: {', '.join(cc[:3])} prendem/atordoam", "regra"))
    assa = [nm for nm in names if nm in AD_ASSASSINS]
    if assa and my_dtype == "AP" and role != "UTILITY":
        hit = _first_ok([ZHONYA], items)
        if hit:
            quem = laner if lane_ad_assa else ", ".join(assa[:2])
            out.append((hit[0], hit[1], (f"{quem} na sua rota: Zhonya no 1º ou 2º item, fica intocável no combo dele" if lane_ad_assa
                                         else f"contra {quem}: fica intocável no combo dele"), "regra", 0 if lane_ad_assa else 3))
    # botas: armadura contra assassino AD na rota ou time de dano fisico; Mercurio contra muito controle e dano magico
    if role != "UTILITY" and (lane_ad_assa or prof["AD"] >= 3):
        hit = _first_ok([STEELCAPS], items)
        if hit:
            out.append((hit[0], hit[1], (f"botas de armadura contra {laner}" if lane_ad_assa else f"botas de armadura: {prof['AD']} campeões de dano físico"),
                        "regra", 1 if lane_ad_assa else 4))
    burst = [nm for nm in names if nm in AP_BURST]
    if len(burst) >= 2 and role != "UTILITY":
        hit = _first_ok([BANSHEE] if my_dtype == "AP" else ([MAW] if my_dtype == "AD" and role != "BOTTOM" else []), items)
        if hit:
            out.append((hit[0], hit[1], f"explosão mágica: {', '.join(burst[:3])}", "regra"))
    if defensive:
        defensive = {k: v for k, v in defensive.items() if v and itemfit.fits(con, champs, items, mine, role, v["id"])}
        if prof["AP"] >= 3 and defensive.get("AP"):
            d = defensive["AP"]
            out.append((d["id"], d["name"], f"resistência mágica: {prof['AP']} campeões de dano mágico", "regra"))
        if prof["AD"] >= 3 and defensive.get("AD"):
            d = defensive["AD"]
            out.append((d["id"], d["name"], f"armadura: {prof['AD']} campeões de dano físico", "regra"))
    # prioridade: sobrevivencia contra quem te mata na rota primeiro; perfuracao por ultimo
    PRI = {ZHONYA: 3, STEELCAPS: 4, MERC_BOOTS: 4, QSS: 4, MERCURIAL: 4, BANSHEE: 5, MAW: 5, MIKAEL: 5, SERPENT: 6}
    pen_all = {i for v in PEN.values() for i in v}
    def pri(x):
        if len(x) > 4:
            return x[4]
        return 9 if x[0] in pen_all else PRI.get(x[0], 7)
    out.sort(key=pri)
    return [x[:4] for x in out]


def my_dtype(champs, champ):
    c = champs.get(champ) or {}
    tags = c.get("tags", [])
    if "Tank" in tags[:1]:
        return "TANK"
    dt = draft.damage_type(c.get("info"), tags)
    return "AP" if dt == "AP" else "AD"


def plan_parts(con, games, snap, champs, position, roles, items=None):
    """Plano em partes, para a tela: [(tipo, titulo, texto, fala)]."""
    from . import gameview
    me = (snap or {}).get("me") or {}
    mine = me.get("champion")
    if not mine:
        return []
    dn = lambda nm: (champs.get(nm) or {}).get("name") or nm
    enemy, _ = draft.enemy_laner(snap, position, roles)
    out = []
    mg = [g for g in games if g["champion"] == mine]
    if enemy:
        vs = [g for g in mg if (g.get("opp_champion") or "") == enemy]
        etags = (champs.get(enemy) or {}).get("tags", [])
        from . import champtips
        tip_ = champtips.tip_vs(enemy, tags=etags)
        w = sum(1 for g in vs if g["win"])
        rec = f"você venceu {w} de {len(vs)} com {dn(mine)}" if vs else "primeira vez nesse duelo"
        out.append(("duelo", f"Duelo contra {dn(enemy)}", f"{rec[0].upper() + rec[1:]}. {tip_}".strip(), f"Contra {dn(enemy)}, {rec}. {tip_}"))
    foes = [p["champion"] for p in (snap or {}).get("enemy_team", []) if p.get("champion")]
    assassins = [nm for nm in foes if "Assassin" in (champs.get(nm) or {}).get("tags", [])]
    if assassins:
        nms = " e ".join(dn(x) for x in assassins[:2])
        pl = len(assassins[:2]) > 1
        out.append(("perigo", "Perigo", f"{nms} ({'assassinos' if pl else 'assassino'}) {'procuram' if pl else 'procura'} abates a partir do nível 6. "
                    "Ande com visão e guarde o feitiço de fuga.", f"Perigo: {nms}, cuidado depois do nível 6."))
    elif foes:
        nf = sum(1 for nm in foes if set((champs.get(nm) or {}).get("tags", [])) & {"Tank", "Fighter"})
        if nf >= 3:
            out.append(("perigo", "Perigo", f"{nf} campeões de linha de frente no inimigo: lute depois do seu item principal.",
                        "O inimigo tem muita linha de frente. Lute depois do seu item principal."))
    if mg:
        d10 = [g["deaths_before_10"] for g in mg if g.get("deaths_before_10") is not None]
        if d10:
            avg = sum(d10) / len(d10)
            if avg >= 1:
                out.append(("fraco", "Seu ponto fraco", f"Com {dn(mine)} você morre em média {avg:.1f} vez antes dos 10 minutos. Jogue seguro até o nível 6.",
                            f"Com {dn(mine)} você morre {avg:.1f} vezes antes dos 10 minutos. Segure o começo."))
    pk = _spike(con, mine, position, items)
    if pk:
        out.append(("pico", "Seu pico de força", f"{pk[0].upper() + pk[1:]}: é a hora de forçar troca e luta.", f"Seu pico: {pk}."))
    return out


def plan_text(con, puuid, games, snap, champs, position, roles, items=None):
    """Plano curto ao trancar: duelo, perigo e pico. Devolve (texto, fala)."""
    parts = plan_parts(con, games, snap, champs, position, roles, items)
    if not parts:
        return None
    return " ".join(f"{t}: {x}" for _, t, x, _ in parts), "Plano da partida. " + " ".join(f for _, _, _, f in parts)


_SPIKE = {}


def _spike(con, champ, position, items):
    """'nível 6 e Gume da Noite (por volta dos 13 min)' pelo primeiro item dos melhores."""
    key = (champ, position)
    if key in _SPIKE and time.time() - _SPIKE[key][0] < 1800:
        return _SPIKE[key][1]
    txt = None
    try:
        from . import builds
        rows = builds.top_rows(con, champ, position)[:40]
        if len(rows) >= builds.MIN_ROWS and items:
            st = builds.item_stats(con, rows, items)
            first = (builds.clean_build(st, items, champ, position)["order"] or [None])[0]
            nm = (items.get(str(first)) or {}).get("name") if first else None
            if nm:
                mm = st.get("first_item_min")
                txt = f"nível 6 e {nm}" + (f" (por volta dos {mm:.0f} min)" if mm else "")
    except Exception:
        txt = None
    if txt:
        _SPIKE[key] = (time.time(), txt)
    return txt or "nível 6 e o primeiro item completo"
