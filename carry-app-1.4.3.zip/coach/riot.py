"""Cliente minimo da API da Riot (so biblioteca padrao).

Respeita os limites da chave de desenvolvimento (20 req/1s e 100 req/2min)
e repete a chamada quando a Riot responde 429 (limite) ou erro temporario.
"""
import json
import time
import urllib.error
import urllib.parse
import urllib.request
import threading
from collections import deque

# BR usa o cluster "americas" para account-v1 e match-v5.
CLUSTER = "americas"
USER_AGENT = "lol-coach/0.1 (app pessoal de estudo)"
PLATFORM_HOST = "br1.api.riotgames.com"  # padrao: league, summoner e mastery usam a plataforma
# plataforma -> (nome, cluster das partidas)
REGIONS = {
    "br1": ("Brasil", "americas"), "na1": ("América do Norte", "americas"), "la1": ("LAN", "americas"), "la2": ("LAS", "americas"),
    "euw1": ("Europa Oeste", "europe"), "eun1": ("Europa Nórdica e Leste", "europe"), "tr1": ("Turquia", "europe"), "ru": ("Rússia", "europe"),
    "kr": ("Coreia", "asia"), "jp1": ("Japão", "asia"),
    "oc1": ("Oceania", "sea"), "ph2": ("Filipinas", "sea"), "sg2": ("Singapura", "sea"), "th2": ("Tailândia", "sea"),
    "tw2": ("Taiwan", "sea"), "vn2": ("Vietnã", "sea"),
}
LIMITS = ((20, 1.0), (100, 120.0))  # (requisicoes, janela em segundos)
# O limite e da CHAVE, nao do cliente: todos os clientes com a mesma chave dividem a mesma fila.
_SHARED = {}
_SHARED_LOCK = threading.Lock()


def _stamps_for(key):
    with _SHARED_LOCK:
        return _SHARED.setdefault(key, (deque(), threading.Lock()))


class RiotError(Exception):
    pass


class RiotClient:
    def __init__(self, api_key, cluster=CLUSTER, sleep=time.sleep, now=time.monotonic, region="br1", max_wait=None):
        if not api_key:
            raise RiotError("Falta a chave da Riot (variavel RIOT_API_KEY).")
        self.api_key = api_key
        if region in REGIONS and cluster == CLUSTER and region != "br1":
            cluster = REGIONS[region][1]
        self.cluster = cluster
        self.platform_host = f"{region if region in REGIONS else 'br1'}.api.riotgames.com"
        self._sleep = sleep
        self.max_wait = max_wait  # telas: nao espera a fila da chave mais que isso
        self._now = now
        if now is time.monotonic:
            self._stamps, self._slock = _stamps_for(api_key)
        else:  # testes com relogio falso
            self._stamps, self._slock = deque(), threading.Lock()

    # -- controle de taxa -------------------------------------------------
    def _throttle(self):
        while True:
            with self._slock:
                wait = self._try_take()
            if wait <= 0:
                return
            if self.max_wait is not None and wait > self.max_wait:
                raise RiotError("O app está ocupado buscando partidas agora. Tente de novo em 1 ou 2 minutos.")
            self._sleep(wait)

    def _try_take(self):
        now = self._now()
        while self._stamps and now - self._stamps[0] > LIMITS[-1][1]:
            self._stamps.popleft()
        wait = 0.0
        for count, window in LIMITS:
            recent = [t for t in self._stamps if now - t < window]
            if len(recent) >= count:
                wait = max(wait, window - (now - recent[0]) + 0.05)
        if wait <= 0:
            self._stamps.append(now)
        return wait

    # -- HTTP -------------------------------------------------------------
    def _get(self, path, params=None, retries=4, host=None):
        url = f"https://{host or (self.cluster + '.api.riotgames.com')}{path}"
        if params:
            url += "?" + urllib.parse.urlencode(params)
        for attempt in range(retries + 1):
            self._throttle()
            req = urllib.request.Request(url, headers={"X-Riot-Token": self.api_key, "User-Agent": USER_AGENT})
            try:
                with urllib.request.urlopen(req, timeout=30) as resp:
                    return json.loads(resp.read().decode("utf-8"))
            except urllib.error.HTTPError as e:
                if e.code == 429:
                    self._sleep(float(e.headers.get("Retry-After", "5")) + 0.5)
                    continue
                if e.code in (500, 502, 503, 504) and attempt < retries:
                    self._sleep(2 ** attempt)
                    continue
                if e.code in (401, 403):
                    try:
                        body = e.read().decode("utf-8", "replace")[:200]
                    except Exception:
                        body = ""
                    if "1010" in body:
                        raise RiotError("A Riot bloqueou o pedido (error code 1010, bloqueio de User-Agent), não é a chave.")
                    import re as _re
                    msg = (_re.search(r'"message"\s*:\s*"([^"]+)"', body) or [None, ""])[1]
                    raise RiotError(
                        f"A Riot recusou a chave (código {e.code}{': ' + msg if msg else ''}). A chave de desenvolvimento dura só 24 horas: "
                        "gere outra em developer.riotgames.com e cole em Administração."
                    )
                if e.code == 404:
                    return None
                raise RiotError(f"Erro {e.code} em {path}")
            except urllib.error.URLError as e:
                if attempt < retries:
                    self._sleep(2 ** attempt)
                    continue
                raise RiotError(f"Sem conexão com a Riot: {e.reason}")
        raise RiotError(f"Muitas tentativas falharam em {path}")

    # -- endpoints --------------------------------------------------------
    def puuid_by_riot_id(self, game_name, tag_line):
        data = self._get(
            "/riot/account/v1/accounts/by-riot-id/"
            f"{urllib.parse.quote(game_name)}/{urllib.parse.quote(tag_line)}"
        )
        if not data:
            raise RiotError(f"Conta {game_name}#{tag_line} não encontrada.")
        return data["puuid"]

    def match_ids(self, puuid, count=100, start=0, queue=420, start_time=None):
        """queue 420 = ranqueada solo/duo. start_time em segundos (epoch) limita ao periodo."""
        params = {"start": start, "count": count}
        if start_time:
            params["startTime"] = int(start_time)
        if queue:
            params["queue"] = queue
        return self._get(f"/lol/match/v5/matches/by-puuid/{puuid}/ids", params) or []

    def match(self, match_id):
        return self._get(f"/lol/match/v5/matches/{match_id}")

    def timeline(self, match_id):
        return self._get(f"/lol/match/v5/matches/{match_id}/timeline")

    # -- amostra dos melhores jogadores ------------------------------------
    def league_entries(self, tier):
        """tier: challenger, grandmaster ou master (solo/duo do BR)."""
        data = self._get(f"/lol/league/v4/{tier}leagues/by-queue/RANKED_SOLO_5x5",
                         host=self.platform_host)
        return (data or {}).get("entries", [])

    def puuid_by_summoner(self, summoner_id):
        data = self._get(f"/lol/summoner/v4/summoners/{summoner_id}", host=self.platform_host)
        return (data or {}).get("puuid")

    def mastery_all(self, puuid):
        return self._get("/lol/champion-mastery/v4/champion-masteries/by-puuid/" + str(puuid), host=self.platform_host)

    def mastery(self, puuid, champion_id):
        return self._get("/lol/champion-mastery/v4/champion-masteries/by-puuid/"
                         f"{puuid}/by-champion/{champion_id}", host=self.platform_host)

    # -- conta do jogador (perfil) -----------------------------------------
    def account_by_puuid(self, puuid):
        return self._get(f"/riot/account/v1/accounts/by-puuid/{puuid}")

    def summoner_by_puuid(self, puuid):
        """Nivel e icone de perfil (o icone prova que a conta e de quem diz ser)."""
        return self._get(f"/lol/summoner/v4/summoners/by-puuid/{puuid}", host=self.platform_host)

    def league_by_puuid(self, puuid):
        """Elo atual (fila solo/duo e flex)."""
        return self._get(f"/lol/league/v4/entries/by-puuid/{puuid}", host=self.platform_host) or []


def quick_test(key, region="br1"):
    """Testa a chave direto, sem esperar a fila das outras buscas. Devolve (ok, codigo, mensagem_da_riot)."""
    import re as _re
    host = f"{region if region in REGIONS else 'br1'}.api.riotgames.com"
    req = urllib.request.Request(f"https://{host}/lol/status/v4/platform-data", headers={"X-Riot-Token": key, "User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=12) as r:
            return True, r.status, ""
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode("utf-8", "replace")[:300]
        except Exception:
            body = ""
        msg = (_re.search(r'"message"\s*:\s*"([^"]+)"', body) or [None, ""])[1]
        return False, e.code, msg
    except Exception as e:
        return False, 0, f"sem conexão com a Riot ({type(e).__name__})"
