"""Counters reais pela amostra do alto elo que o app guarda (partidas oficiais da Riot): quem vence quem NA MESMA ROTA.

Winrate suavizado (puxa para 50% quando ha poucos jogos), sempre com o numero de jogos. Sem amostra suficiente, nao fala.
"""
import time

PRIOR = 20          # jogos "imaginarios" a 50% (evita 3 jogos virarem 100%)
MIN_N = 25         # 12 jogos era ruido: sugeria pick bizarro contra o oponente
_MEM = {}


def _q(con, sql, args):
    key = (id(con), sql, args)
    hit = _MEM.get(key)
    if hit and time.time() - hit[0] < 1800:
        return hit[1]
    try:
        rows = con.execute(sql, args).fetchall()
    except Exception:
        rows = []
    _MEM[key] = (time.time(), rows)
    if len(_MEM) > 300:
        for k in list(_MEM)[:100]:
            _MEM.pop(k, None)
    return rows


def smooth(w, n):
    return (w + PRIOR * 0.5) / (n + PRIOR) if n >= 0 else 0.5


def vs_enemy(con, enemy, position):
    """{campeao: (jogos, vitorias)} de quem jogou contra `enemy` na mesma rota (amostra do topo)."""
    rows = _q(con, """SELECT a.champion, COUNT(*), SUM(a.win) FROM participants b
                      JOIN participants a ON a.match_id=b.match_id AND a.team_id<>b.team_id AND a.position=b.position
                      JOIN match_source s ON s.match_id=b.match_id
                      WHERE b.champion=? AND b.position=? AND s.source='top' GROUP BY a.champion""", (enemy, position))
    return {r[0]: (int(r[1] or 0), int(r[2] or 0)) for r in rows}


def counters_of(con, enemy, position, limit=3, min_n=MIN_N):
    """Os campeoes que mais vencem `enemy` nessa rota: [(campeao, wr%, jogos)]."""
    d = vs_enemy(con, enemy, position)
    best = [(c, smooth(w, n), n, w) for c, (n, w) in d.items() if n >= min_n]
    best.sort(key=lambda x: -x[1])
    return [(c, round(100 * w / n), n) for c, s, n, w in best[:limit] if s > 0.505]


def matchup(con, mine, enemy, position):
    """(jogos, winrate% do `mine` contra `enemy`) ou None se a amostra e pequena."""
    n, w = vs_enemy(con, enemy, position).get(mine, (0, 0))
    if n < MIN_N:
        return None
    return n, round(100 * w / n)


def verdict(wr):
    if wr >= 53:
        return "vantagem"
    if wr <= 47:
        return "desvantagem"
    return "equilibrado"
