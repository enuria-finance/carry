"""Tela "Ao vivo": dicas durante a partida com a API OFICIAL do proprio jogo (Live Client Data).

A Riot publica essa API (https://127.0.0.1:2999) justamente para apps de terceiros.
O app usa SO o que o seu jogo ja mostra na tela (placar, itens, niveis, eventos);
nao rastreia nada oculto do inimigo e nao automatiza nenhuma acao no jogo.
Cada dica vem marcada como dado, regra geral ou hipotese.
Nao testado contra uma partida real: quem confirma e o seu PC.
"""
import json
import ssl
import urllib.request

from .tags import DADO, REGRA, HIPOTESE, tip

URL = "https://127.0.0.1:2999/liveclientdata/allgamedata"


_CTX = None


def _port_open(timeout=0.25):
    """O jogo esta aberto? No Windows, conectar numa porta fechada demora ~2 s; assim falha em 0,25 s."""
    import socket
    try:
        with socket.create_connection(("127.0.0.1", 2999), timeout=timeout):
            return True
    except OSError:
        return False


def fetch(opener=None):
    """Dados da partida em andamento, ou None se nao ha partida/jogo fechado."""
    global _CTX
    try:
        if opener is None:
            if not _port_open():
                return None
            if _CTX is None:
                ctx = ssl.create_default_context()
                ctx.check_hostname = False          # certificado do proprio jogo, so em 127.0.0.1
                ctx.verify_mode = ssl.CERT_NONE
                _CTX = ctx
            opener = lambda req: urllib.request.urlopen(req, timeout=2, context=_CTX)
        with opener(urllib.request.Request(URL)) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return None


def _name(p):
    return p.get("riotIdGameName") or p.get("summonerName") or ""


def _find_me(data):
    ap = data.get("activePlayer") or {}
    keys = {k for k in (ap.get("riotIdGameName"), ap.get("summonerName"),
                        (ap.get("riotId") or "").split("#")[0]) if k}
    for p in data.get("allPlayers") or []:
        if _name(p) in keys or (p.get("summonerName") or "").split("#")[0] in keys:
            return p
    return None


def _value(p):
    return sum((i.get("price") or 0) * (i.get("count") or 1) for i in p.get("items") or [])


def _mmss(sec):
    sec = int(sec)
    return f"{sec // 60}:{sec % 60:02d}"


def advice(data, next_items=None, my_cs_avg=None):
    """Lista de dicas. next_items = {'order': [ids], 'n': amostra, 'items': dados do Data Dragon}."""
    players = data.get("allPlayers") or []
    me = _find_me(data)
    t = (data.get("gameData") or {}).get("gameTime") or 0
    out = []
    if not me:
        return [tip(HIPOTESE, "Não consegui identificar você na partida (talvez modo espectador ou treino).")]
    mine = [p for p in players if p.get("team") == me.get("team")]
    foes = [p for p in players if p.get("team") != me.get("team")]
    ap = data.get("activePlayer") or {}

    # 1) proximo item (amostra dos melhores) x ouro atual
    if next_items and next_items.get("order"):
        owned = {i.get("itemID") for i in me.get("items") or []}
        items = next_items.get("items") or {}
        nxt = next((i for i in next_items["order"] if i not in owned), None)
        if nxt:
            it = items.get(str(nxt)) or {}
            cost = (it.get("gold") or {}).get("total")
            gold = int(ap.get("currentGold") or 0)
            extra = ""
            if cost:
                extra = (f" Custa {cost}; você tem {gold}" +
                         (": já dá para comprar." if gold >= cost else f": faltam {cost - gold}."))
            out.append(tip(DADO, f"Próximo item mais comum entre os melhores: {it.get('name', nxt)}.{extra}",
                           next_items.get("n")))

    # 2) duelo de rota (mesma posicao)
    pos = me.get("position")
    opp = next((p for p in foes if pos and p.get("position") == pos), None)
    if opp:
        dl = (me.get("level") or 0) - (opp.get("level") or 0)
        txt = (f"Seu oponente de rota ({opp.get('championName')}) está no nível {opp.get('level')}; "
               f"você, no {me.get('level')}")
        txt += " (vantagem sua)." if dl > 0 else (" (desvantagem)." if dl < 0 else " (igual).")
        out.append(tip(DADO, txt))

    # 3) valor de itens por time (estimativa)
    v_me, v_foe = sum(_value(p) for p in mine), sum(_value(p) for p in foes)
    if v_me or v_foe:
        d = v_me - v_foe
        out.append(tip(HIPOTESE, f"Valor dos itens comprados: seu time {v_me}, inimigo {v_foe} "
                                 f"({'+' if d >= 0 else ''}{d}). Estimativa: ignora ouro guardado e componentes."))

    # 4) inimigos mortos agora
    dead = [(p.get("championName"), p.get("respawnTimer")) for p in foes if p.get("isDead")]
    if dead:
        out.append(tip(DADO, "Inimigos mortos agora: " +
                       ", ".join(f"{n} (volta em {int(r or 0)}s)" for n, r in dead) + "."))

    # 5) seu CS/min
    sc = me.get("scores") or {}
    if t >= 300 and sc.get("creepScore") is not None:
        cpm = sc["creepScore"] / (t / 60)
        txt = f"Seu CS/min agora: {cpm:.1f}."
        if my_cs_avg:
            txt += f" Sua média nos jogos sincronizados: {my_cs_avg[0]:.1f}."
            out.append(tip(DADO, txt, my_cs_avg[1]))
        else:
            out.append(tip(DADO, txt))

    # 6) objetivos (eventos do proprio jogo)
    names = {"DragonKill": "dragão", "BaronKill": "barão", "HeraldKill": "arauto"}
    last = {}
    for ev in (data.get("events") or {}).get("Events") or []:
        if ev.get("EventName") in names:
            last[ev["EventName"]] = ev
    team_of = {_name(p): p.get("team") for p in players}
    for k, ev in last.items():
        who = "seu time" if team_of.get(ev.get("KillerName")) == me.get("team") else "o time inimigo"
        age = t - (ev.get("EventTime") or 0)
        out.append(tip(DADO, f"Último {names[k]}: {who}, aos {_mmss(ev.get('EventTime') or 0)} (há {_mmss(max(age, 0))})."))
        if age <= 60 and who == "o time inimigo" and not me.get("isDead"):
            out.append(tip(REGRA, f"O inimigo acabou de fazer o {names[k]}: o time dele costuma estar recolhendo ou "
                                  "se reposicionando; pense em empurrar a rota e pegar torre em vez de seguir atrás."))

    # 7) suas mortes
    if sc.get("deaths", 0) >= 3 and sc["deaths"] > (sc.get("kills", 0) + sc.get("assists", 0)):
        out.append(tip(REGRA, f"Você tem {sc['deaths']} mortes, mais que abates+assistências: jogue mais seguro, "
                              "farme perto da torre e só lute com visão do jungler até fechar o próximo item."))
    return out


def team_values(data):
    """Valor dos itens por jogador e por time (estimativa; ouro guardado nao aparece)."""
    players = data.get("allPlayers") or []
    me = _find_me(data)
    mine = [(p.get("championName"), _value(p)) for p in players if me and p.get("team") == me.get("team")]
    foes = [(p.get("championName"), _value(p)) for p in players if me and p.get("team") != me.get("team")]
    return mine, foes


PHASE_TIPS = [
    ("Início", 0, 14 * 60, [
        "Farme com segurança e guarde habilidades defensivas para quando o oponente tiver as dele fora.",
        "Empurre a onda antes de recolher e compre o item principal quando der ouro."]),
    ("Meio", 14 * 60, 28 * 60, [
        "Junte o time para objetivos só com visão por perto; sem visão, não entre no escuro.",
        "Depois de uma luta ganha, use a vantagem: torre ou objetivo antes do inimigo renascer."]),
    ("Fim", 28 * 60, 10 ** 9, [
        "Uma morte pode decidir o jogo: espere o time antes de entrar em objetivos grandes.",
        "Barão ou ancião só com o time vivo e visão ao redor."]),
]


# dicas por rota (a de cima, PHASE_TIPS, era de quem farma: errado para suporte e caçador)
ROLE_TIPS = {
    "UTILITY": [
        ["Não farme: deixe os minions para o atirador e use o Atlas Mundial com ataques no campeão inimigo para carregar as moedas.",
         "Sentinela no rio e na entrada da selva antes dos 3 minutos; quando o caçador inimigo aparecer do outro lado, a rota é sua.",
         "Ande para o meio ou para a selva quando a onda estiver segura: um roam no tempo certo vale mais que ficar parado na rota."],
        ["Vá com o caçador colocar sentinelas antes de cada objetivo e limpar as do inimigo com a Lente.",
         "Fique perto de quem carrega o time nas lutas e guarde a habilidade de controle para quem pular nele."],
        ["Visão perto do Barão e do Dragão Ancião 1 minuto antes de nascerem; nunca entre no escuro sozinho.",
         "Sua vida vale muito: proteja o atirador e espere o inimigo gastar as habilidades antes de entrar."]],
    "JUNGLE": [
        ["Limpe a selva no caminho que termina perto da rota que dá para gankar no nível 3 ou 4.",
         "Antes de gankar, olhe se a rota tem controle de grupo e se o inimigo está sem Flash."],
        ["Chegue nos objetivos 1 minuto antes com visão e com a sua rota mais forte junto.",
         "Acompanhe o caçador inimigo: se ele apareceu de um lado, invada ou faça objetivo do outro."],
        ["Barão e Ancião: guarde o Golpear e só disputa com o time perto.",
         "Não morra sozinho na selva: sem você não tem objetivo."]],
}


def tips_for(pos):
    """[[dicas do inicio], [meio], [fim]] para a rota da pessoa."""
    return ROLE_TIPS.get((pos or "").upper()) or [t[3] for t in PHASE_TIPS]


def phase_now(t):
    for i, (name, a, b, tips) in enumerate(PHASE_TIPS):
        if a <= t < b:
            return i
    return 0


def win_condition(data, tags_by_name):
    """Condicao de vitoria simples (hipotese): usa so as classes do Data Dragon."""
    me = _find_me(data)
    if not me or not tags_by_name:
        return None
    allies = [p.get("championName") for p in data.get("allPlayers") or [] if p.get("team") == me.get("team")]
    tanks = [a for a in allies if "Tank" in tags_by_name.get(a, [])]
    if tanks:
        return tip(HIPOTESE, f"Seu time tem tanque ({', '.join(tanks)}): junte o time e deixe ele abrir a luta, "
                             "focando quem causa dano no time inimigo.")
    return tip(HIPOTESE, "Nenhum tanque no seu time (classes do Data Dragon): lutas 5v5 de frente tendem a ser difíceis; "
                         "prefira pegar alvos soltos e pressionar rotas.")


def lane_advantage(data):
    """[(posicao, seu campeao, campeao inimigo, diferenca de valor de itens, e_voce)] por rota."""
    me = _find_me(data)
    if not me:
        return []
    players = data.get("allPlayers") or []
    out = []
    for pos in ("TOP", "JUNGLE", "MIDDLE", "BOTTOM", "UTILITY"):
        a = next((p for p in players if p.get("team") == me.get("team") and p.get("position") == pos), None)
        b = next((p for p in players if p.get("team") != me.get("team") and p.get("position") == pos), None)
        if a and b:
            out.append((pos, a.get("championName"), b.get("championName"), _value(a) - _value(b), a is me))
    return out
