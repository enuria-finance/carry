"""Dicionario 'por requisicao': cada thread do servidor ve o seu (varios usuarios ao mesmo tempo, sem misturar)."""
import threading


class LocalDict:
    def __init__(self, **defaults):
        self._defaults = defaults
        self._tl = threading.local()

    def _d(self):
        d = getattr(self._tl, "d", None)
        if d is None:
            d = self._tl.d = dict(self._defaults)
        return d

    def reset(self):
        self._tl.d = dict(self._defaults)

    def __getitem__(self, k):
        return self._d()[k]

    def __setitem__(self, k, v):
        self._d()[k] = v

    def __contains__(self, k):
        return k in self._d()

    def get(self, k, default=None):
        return self._d().get(k, default)

    def update(self, *a, **kw):
        self._d().update(*a, **kw)
