"""O SEU erro que mais custa PDL (das suas ultimas partidas) vira aviso de voz na hora em que ele costuma acontecer.

A revisao pos-jogo encontra o padrao (postmore.common_mistakes); aqui ele entra na partida seguinte:
- no comeco: qual e o erro, quanto ele custa e o combinado de hoje;
- no momento de risco: aos 3 min se voce morre para o jungler, com vantagem se voce morre na frente, etc.
Chaves erro_* (o overlay fala uma vez cada).
"""
import time

_CACHE = {}
_ST = {}


def top_mistake(con, puuid, position=None):
    """O erro com mais impacto nas ultimas 20 partidas (na sua posicao). Guardado por 30 min."""
    key = (puuid, position or "")
    hit = _CACHE.get(key)
    if hit and time.time() - hit[0] < 1800:
        return hit[1]
    from . import postmore, report
    try:
        games = report.my_games(con, puuid, position or "")[:20]
        ms = postmore.common_mistakes(con, puuid, games) if len(games) >= 8 else []
        top = ms[0] if ms and ms[0].get("impact", 0) > 0 else None
    except Exception:
        top = None
    _CACHE[key] = (time.time(), top)
    return top


def _gk(live_data):
    return "|".join(sorted((p.get("championName") or "") for p in live_data.get("allPlayers") or []))


def cues(con, puuid, live_data, me, foes, pos, gt, items=None):
    m = top_mistake(con, puuid, pos)
    if not m:
        return []
    al = []
    add = lambda k, t, v=None: al.append({"k": "erro_" + k, "t": t, **({"v": v} if v else {})})
    st = _ST.setdefault(_gk(live_data), {})
    if len(_ST) > 4:
        for k in list(_ST)[:-4]:
            _ST.pop(k, None)
    k = m["k"]
    if k == "cs" and (pos or "").upper() in ("UTILITY", "JUNGLE"):
        return []          # farm nao e o trabalho do suporte nem do caçador
    sc = me.get("scores") or {}
    deaths = int(sc.get("deaths") or 0)
    lp = next((p for p in foes if pos and pos != "JUNGLE" and (p.get("position") or "").upper() == pos), None)

    # comeco: o erro, quanto custa e o combinado
    if 25 <= gt < 90:
        cost = (f" Quando acontece você ganha {m['wr_with']}%, quando não acontece {m['wr_without']}%."
                if m.get("wr_with") is not None and m.get("wr_without") is not None else "")
        add("intro", f"O seu erro que mais custa PDL nas últimas {m['n']} partidas: {m['title'].lower()}.{cost} Hoje: {m['fix']}",
            f"Seu erro que mais custa: {m['title'].lower()}. Hoje o foco é esse.")

    if k == "d10":
        for mm in (5, 8):
            if mm * 60 <= gt < mm * 60 + 20 and deaths == 0:
                add(f"d10_{mm}", f"{mm} minutos e zero mortes. Faltam {10 - mm} minutos: segue jogando seguro.")
        if deaths >= 1 and gt < 600 and not st.get("d10_dead"):
            st["d10_dead"] = gt
        if st.get("d10_dead") and gt - st["d10_dead"] < 40:
            add("d10_morreu", "Morreu antes dos 10, o seu erro principal. Agora, nada de troca até voltar com item.")
    elif k == "jg":
        for at, txt in ((165, "Quase 3 minutos: é aqui que o jungler deles costuma te pegar. Jogue para trás até saber onde ele está."),
                        (390, "6 minutos e meio: hora do segundo gank. Sentinela no rio antes de trocar.")):
            if at <= gt < at + 20 and pos != "JUNGLE":
                add(f"jg_{at}", txt)
    elif k == "ahead" and lp and gt < 1500:
        from .macrocues import _val
        d = _val(me, items) - _val(lp, items)
        if d >= 700:
            add(f"ahead_{int(gt // 300)}", f"Você está {d} de ouro na frente. É exatamente quando você costuma morrer: "
                "transforme em torre ou objetivo, não procure mais abate.", "Na frente: converta em torre, não procure mais abate.")
    elif k == "deep":
        if 840 <= gt < 860:
            add("deep_14", "Daqui para frente é do outro lado do rio que você costuma morrer. Só entre na selva deles com visão e sabendo onde estão os inimigos.")
    elif k == "many":
        if deaths >= 2 and not st.get("many2"):
            st["many2"] = gt
        if st.get("many2") and gt - st["many2"] < 40:
            add("many_2", "Segunda morte. O seu padrão é morrer muito: jogue seguro até o próximo item ou objetivo.")
    elif k == "vis":
        for at in (360, 720, 1080):
            if at <= gt < at + 20:
                add(f"vis_{at}", "Lembrete do seu erro principal, a visão: na próxima volta, compre Sentinela de Controle e use o amuleto no rio.")
    elif k == "cs" and lp:
        if 420 <= gt < 440:
            a = int(sc.get("creepScore") or 0)
            b = int((lp.get("scores") or {}).get("creepScore") or 0)
            add("cs_7", f"7 minutos: {a} de farm contra {b}. O farm é o seu erro principal: não deixe a onda morrer na torre enquanto troca.")
    return al
