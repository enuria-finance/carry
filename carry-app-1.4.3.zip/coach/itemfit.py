"""Filtro unico de item: ele faz sentido para ESTE campeao NESTA rota?

Pedido do usuario: "identifique primeiro a rota, depois sugira itens". Toda sugestao de item do app (build, botas,
item pela composicao, conjunto de itens no cliente, overlay) passa por aqui, sempre com campeao + rota.

Ordem das regras:
1. Regras fixas de rota: item de suporte (linha do Atlas Mundial) so no suporte; filhote da selva so na selva.
2. Tipo de dano: item de dano fisico em mago (e o contrario) nunca.
3. Amostra dos melhores com o campeao NA ROTA (20+ partidas): o item precisa aparecer em pelo menos 3% delas.
   Botas: conta a familia (as botas de nivel 3 viram as de nivel 2).
4. Sem amostra: regra de classe (ex.: atirador nao recebe Botas Galvanizadas de Aco nem Presa da Serpente).
"""
import json
import time
from collections import Counter

MIN_ROWS = 20
MIN_SHARE = 0.03
ROLES = ("TOP", "JUNGLE", "MIDDLE", "BOTTOM", "UTILITY")

STEELCAPS, MERC_BOOTS, SORC_BOOTS, BERSERK = 3047, 3111, 3020, 3006
ZHONYA, BANSHEE, MAW, SERPENT, QSS, MERCURIAL, MIKAEL = 3157, 3102, 3156, 6695, 3140, 3139, 3222

LETHALITY = {"Zed", "Talon", "Qiyana", "Pyke", "Khazix", "Rengar", "Naafiri", "Kayn", "Shaco", "Nocturne", "Pantheon", "Graves",
             "Kindred", "Elise", "Evelynn", "Akshan", "Varus", "Caitlyn", "Draven", "Jhin", "Aphelios", "MissFortune", "Senna",
             "Yone", "Riven", "Renekton", "Jayce", "Kled", "Quinn", "Vayne", "Tryndamere", "Ambessa", "Briar"}


def _t(champs, c):
    return list(((champs or {}).get(c) or {}).get("tags") or [])


def _info(champs, c):
    return ((champs or {}).get(c) or {}).get("info") or {}


def is_ap(champs, c):
    t, inf = _t(champs, c), _info(champs, c)
    return "Marksman" not in t and (inf.get("magic") or 0) > (inf.get("attack") or 0)


def is_marksman(champs, c):
    return "Marksman" in _t(champs, c)[:1]


# Regra de classe quando a amostra dos melhores e pequena. (champs, campeao, rota) -> bool
CLASS_OK = {
    STEELCAPS: lambda ch, c, r: not is_marksman(ch, c) and r != "UTILITY" or "Tank" in _t(ch, c),
    MERC_BOOTS: lambda ch, c, r: True,
    SORC_BOOTS: lambda ch, c, r: is_ap(ch, c),
    BERSERK: lambda ch, c, r: is_marksman(ch, c) or c in {"Yasuo", "Yone", "Jax", "MasterYi", "Belveth", "Kayle", "Kindred", "Nilah"},
    ZHONYA: lambda ch, c, r: is_ap(ch, c) and r != "UTILITY",
    BANSHEE: lambda ch, c, r: is_ap(ch, c) and r != "UTILITY",
    MAW: lambda ch, c, r: not is_ap(ch, c) and not is_marksman(ch, c),
    SERPENT: lambda ch, c, r: "Assassin" in _t(ch, c)[:1] or (c in LETHALITY and not is_marksman(ch, c)),   # atirador so com amostra
    QSS: lambda ch, c, r: not is_ap(ch, c),
    MERCURIAL: lambda ch, c, r: is_marksman(ch, c),
    MIKAEL: lambda ch, c, r: r == "UTILITY",
    3071: lambda ch, c, r: bool({"Fighter", "Tank"} & set(_t(ch, c))) and not is_ap(ch, c),     # Cutelo Negro
    6694: lambda ch, c, r: not is_marksman(ch, c) or c in LETHALITY,                           # Rancor de Serylda
    3036: lambda ch, c, r: is_marksman(ch, c) or "Fighter" in _t(ch, c),                       # Lembrancas do Lorde Dominik
    3033: lambda ch, c, r: is_marksman(ch, c),                                                 # Lembrete Mortal
    3123: lambda ch, c, r: not is_ap(ch, c),                                                   # Chamado do Carrasco
    6609: lambda ch, c, r: not is_marksman(ch, c) and not is_ap(ch, c),                        # Quimiopunk
    3916: lambda ch, c, r: is_ap(ch, c) or r == "UTILITY",                                     # Orbe do Oblivio
    3165: lambda ch, c, r: is_ap(ch, c),                                                       # Morellonomicon
    3076: lambda ch, c, r: "Tank" in _t(ch, c) or ("Fighter" in _t(ch, c) and r in ("TOP", "JUNGLE")),
    3075: lambda ch, c, r: "Tank" in _t(ch, c) or ("Fighter" in _t(ch, c) and r in ("TOP", "JUNGLE")),
    3135: lambda ch, c, r: is_ap(ch, c),
}


def is_support_item(it):
    tags = set((it or {}).get("tags") or [])
    return {"GoldPer", "Vision", "Lane"} <= tags


def is_jungle_item(it):
    tags = set((it or {}).get("tags") or [])
    return "Jungle" in tags and not tags & {"Consumable", "Trinket", "Lane"}


def base_id(items_data, item_id):
    """Botas de nivel 3 contam como as de nivel 2 de onde vieram (ex.: Mobilizacao Blindada -> Botas Galvanizadas)."""
    it = (items_data or {}).get(str(item_id)) or {}
    if "Boots" in (it.get("tags") or []):
        for f in it.get("from") or []:
            fi = (items_data or {}).get(str(f)) or {}
            if "Boots" in (fi.get("tags") or []) and (fi.get("gold") or {}).get("total", 0) >= 900:
                return int(f)
    return int(item_id)


def family(items_data, item_id):
    """O item, o que ele vira e de onde vem (para saber se voce ja tem 'esse item' em outra forma)."""
    out, todo = set(), [str(item_id)]
    while todo:
        k = todo.pop()
        if k in out:
            continue
        out.add(k)
        it = (items_data or {}).get(k) or {}
        todo += [str(x) for x in it.get("into") or []]
    it = (items_data or {}).get(str(item_id)) or {}
    out |= {str(x) for x in it.get("from") or [] if ((items_data or {}).get(str(x)) or {}).get("gold", {}).get("total", 0) >= 700}
    return {int(x) for x in out if str(x).isdigit()}


def is_boots(items_data, item_id):
    return "Boots" in (((items_data or {}).get(str(item_id)) or {}).get("tags") or [])


_U = {}


def usage(con, champ, role, items_data=None):
    """(partidas, {item_base: fracao}) dos itens no fim da partida dos melhores com o campeao NA ROTA."""
    if not con or not champ or role not in ROLES:
        return 0, {}
    key = (id(con), champ, role)
    hit = _U.get(key)
    if hit and time.time() - hit[0] < 1800:
        return hit[1], hit[2]
    n, cnt = 0, Counter()
    try:
        from . import builds
        for r in builds.top_rows(con, champ, role):
            n += 1
            for i in {base_id(items_data, i) for i in json.loads(r.get("items") or "[]") if i}:
                cnt[i] += 1
    except Exception:
        n, cnt = 0, Counter()
    share = {i: k / n for i, k in cnt.items()} if n else {}
    if len(_U) > 200:
        _U.clear()
    _U[key] = (time.time(), n, share)
    return n, share


def hard_ok(champs, items_data, champ, role, item_id):
    """Regras que valem sempre, com ou sem amostra."""
    it = (items_data or {}).get(str(item_id))
    if not it:
        return False
    if is_support_item(it) and role != "UTILITY":
        return False
    if is_jungle_item(it) and role != "JUNGLE":
        return False
    if champ:
        from . import builds
        if not builds.sane_item(items_data, (champs or {}).get(champ), item_id):
            return False
    return True


def fits(con, champs, items_data, champ, role, item_id, min_share=MIN_SHARE):
    """O item faz sentido para o campeao na rota? (regras fixas + amostra dos melhores na rota; sem amostra, classe)."""
    if not hard_ok(champs, items_data, champ, role, item_id):
        return False
    if not champ:
        return True
    n, share = usage(con, champ, role, items_data)
    bid = base_id(items_data, item_id)
    if n >= MIN_ROWS:
        ids = {bid}
        if not is_boots(items_data, item_id):        # componente (ex.: Chamado do Carrasco): vale o que ele vira
            ids |= {i for i in family(items_data, item_id) if not ((items_data or {}).get(str(i)) or {}).get("into")}
        return sum(share.get(i, 0) for i in ids) >= min_share
    rule = CLASS_OK.get(bid)
    return bool(rule(champs, champ, role)) if rule else True


def clean_seq(champs, items_data, champ, role, ids, finals=None, n=0):
    """Tira de uma build (ja vinda da amostra) o que quebra as regras fixas. Item de tipo de dano 'errado' fica se 20%+
    da amostra fecha ele (ex.: campeao hibrido)."""
    fin = dict(finals or [])
    out = []
    for i in ids:
        if i in out:
            continue
        it = (items_data or {}).get(str(i))
        if not it:
            continue
        if (is_support_item(it) and role != "UTILITY") or (is_jungle_item(it) and role != "JUNGLE"):
            continue
        if not hard_ok(champs, items_data, champ, role, i) and fin.get(i, 0) < 0.2 * max(1, n):
            continue
        out.append(i)
    return out
