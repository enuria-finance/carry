"""Caminho ate a meta (Mestre para quem esta no Esmeralda/Diamante; senao o proximo elo): quanto PDL falta, o ritmo de
verdade das ultimas 2 semanas (PDL ganho por partida, pelo historico de elo que o app guarda) e quantas partidas faltam
nesse ritmo. Mostra tambem o ritmo com o main, para a pessoa ver quanto o resto do pool custa."""
import html
import time

from . import ranks

e = lambda x: html.escape("" if x is None else str(x))


def target(tier):
    t = (tier or "").upper()
    if t not in ranks.TIERS:
        return None
    i = ranks.TIERS.index(t)
    if i >= 7:
        return None
    if t in ("EMERALD", "DIAMOND"):
        return "MASTER"
    return ranks.TIERS[i + 1]


def build(con, puuid, link):
    if not link or not link["tier"]:
        return None
    tg = target(link["tier"])
    if not tg:
        return None
    now = ranks.ladder(link["tier"], link["division"], link["lp"])
    goal = ranks.ladder(tg, "IV", 0)
    falta = goal - now
    # ritmo real: PDL por partida nas ultimas 2 semanas (historico de elo)
    hist = ranks.history(con)
    cut = int(time.time() * 1000) - 14 * 86400000
    h2 = [h for h in hist if h["at_ms"] >= cut]
    real = None
    if len(h2) >= 2:
        g = ((h2[-1]["wins"] or 0) + (h2[-1]["losses"] or 0)) - ((h2[0]["wins"] or 0) + (h2[0]["losses"] or 0))
        if g >= 5:
            real = (h2[-1]["v"] - h2[0]["v"]) / g
    # ritmo pelo winrate (aprox. +20/-20 por partida), geral e so com o main
    from . import report
    gs = [g for g in report.my_games(con, puuid, "") if (g.get("started_ms") or 0) >= cut]
    allg = report.my_games(con, puuid, "")[:100]
    cnt = {}
    for g in allg:
        cnt[g["champion"]] = cnt.get(g["champion"], 0) + 1
    main = max(cnt, key=cnt.get) if cnt else None
    wr = lambda xs: sum(1 for x in xs if x["win"]) / len(xs) if xs else None
    w_all, w_main = wr(gs), wr([g for g in report.my_games(con, puuid, "")[:60] if g["champion"] == main])
    est = lambda w: (2 * w - 1) * 20 if w is not None else None
    return {"tier": link["tier"], "div": link["division"], "lp": link["lp"], "target": tg, "falta": falta,
            "real": real, "n14": len(gs), "wr14": w_all, "main": main, "wr_main": w_main, "lp_main": est(w_main), "lp14": est(w_all)}


def _jogos(falta, ritmo):
    if ritmo is None or ritmo <= 0.3:
        return None
    return int(falta / ritmo + 0.999)


def html_card(R):
    if not R:
        return ""
    alvo = ranks.TIER_PT.get(R["target"], R["target"])
    ritmo = R["real"] if R["real"] is not None else R["lp14"]
    j = _jogos(R["falta"], ritmo)
    jm = _jogos(R["falta"], R["lp_main"])
    linhas = [f"<p>Faltam <b>{R['falta']} PDL</b> para o {e(alvo)}.</p>"]
    if ritmo is not None:
        fonte = "pelo seu histórico de elo" if R["real"] is not None else "estimado pelo seu winrate"
        linhas.append(f"<p>Seu ritmo nas últimas 2 semanas: <b>{f"{ritmo:+.1f}".replace(".", ",")} PDL por partida</b> ({fonte}, {R['n14']} partidas).</p>")
        linhas.append(f"<p>Nesse ritmo: <b>{j} partidas</b>.</p>" if j and j <= 150 else
                      "<p>Nesse ritmo a subida é lenta: o que encurta o caminho é o % de vitória.</p>" if j else
                      "<p class='loss'>Nesse ritmo você não sobe: o PDL está parado ou caindo.</p>")
    por = lambda w: int(R["falta"] / (21 * w - 19 * (1 - w)) + 0.999)
    linhas.append(f"<p>Com 55% de vitória: <b>{por(.55)} partidas</b> · 60%: <b>{por(.60)}</b> · 65%: <b>{por(.65)}</b>.</p>")
    if R["main"] and R["lp_main"] is not None and R["wr_main"] is not None:
        linhas.append(f"<p>Só com {e(R['main'])} ({round(100 * R['wr_main'])}% nas últimas partidas): <b>{f"{R['lp_main']:+.1f}".replace(".", ",")} PDL por partida</b>"
                      + (f", umas <b>{jm} partidas</b>." if jm and jm <= 150 else ".") + "</p>")
    pct = max(0, min(100, 100 - R["falta"] / 4))       # barra: os ultimos 400 PDL ate a meta
    return ("<div class='card' style='margin-bottom:14px'><b class='gl'>Caminho até o " + e(alvo) + "</b>"
            f"<div style='height:10px;border-radius:6px;background:#241B1A;margin:8px 0 10px'><div style='height:10px;border-radius:6px;width:{pct:.0f}%;"
            "background:linear-gradient(90deg,#D7263D,#E9C46A)'></div></div>" + "".join(linhas) + "</div>")


def lobby_line(R):
    if not R:
        return None
    alvo = ranks.TIER_PT.get(R["target"], R["target"])
    ritmo = R["real"] if R["real"] is not None else R["lp14"]
    j = _jogos(R["falta"], ritmo)
    j60 = int(R["falta"] / (21 * .6 - 19 * .4) + 0.999)
    if j and j <= 150:
        return f"Faltam {R['falta']} PDL para o {alvo}: no seu ritmo, umas {j} partidas."
    if j:
        return f"Faltam {R['falta']} PDL para o {alvo}. Com 60% de vitória, são umas {j60} partidas: o que encurta é ganhar mais, não jogar mais."
    return f"Faltam {R['falta']} PDL para o {alvo}. Nas últimas 2 semanas o PDL não subiu: hoje, só com o seu main."
