"""Overlay no jogo: janela pequena, transparente e sempre por cima do LoL (so biblioteca padrao: tkinter + ctypes).

- Nao injeta nada no jogo e nao le memoria: e uma janela comum do Windows por cima, como a do Discord.
  Por isso o LoL precisa estar no modo de tela "Sem bordas" (em tela cheia exclusiva nenhuma janela fica por cima).
- Os cliques passam direto para o jogo. Ctrl+Shift+O mostra/esconde. Ctrl+Shift+M solta/prende para arrastar.
- Le os dados do proprio app (http://127.0.0.1:PORTA/api/overlay) com um codigo secreto gerado a cada abertura.
- So aparece durante a partida; some sozinho fora dela.
"""
import json
import os
import secrets
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request

TOKEN = secrets.token_urlsafe(24)
STATE = {"proc": None, "owner": None, "demo_until": 0.0, "say": None}
LOG_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "overlay.log")


def log(msg):
    """Diario curto do overlay (para descobrir por que a voz nao saiu, por exemplo). So acrescenta uma linha (rapido);
    de vez em quando corta o arquivo para as ultimas 3000 linhas."""
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as fh:
            fh.write(time.strftime("%d/%m %H:%M:%S ") + str(msg)[:300] + "\n")
        if os.path.getsize(LOG_PATH) > 600_000:
            old = open(LOG_PATH, encoding="utf-8").read().splitlines()[-3000:]
            with open(LOG_PATH, "w", encoding="utf-8") as fh:
                fh.write("\n".join(old) + "\n")
    except Exception:
        pass


VIVO_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "cache", "overlay_vivo.txt")


def heartbeat(info=""):
    """Sinal de vida do overlay (o app reinicia o overlay se ele travar)."""
    try:
        os.makedirs(os.path.dirname(VIVO_PATH), exist_ok=True)
        with open(VIVO_PATH, "w") as fh:
            fh.write(f"{time.time():.0f} {info}")
    except Exception:
        pass


def log_tail(n=6):
    try:
        return open(LOG_PATH, encoding="utf-8").read().splitlines()[-n:]
    except Exception:
        return []
CFG_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "overlay.json")

# O que o overlay mostra e como (editado na pagina "Editar overlay"; o overlay le de novo a cada 2 s)
DEFAULT_UI = {"plan": 1, "lanes": 1, "p_plan": 1, "item": 1, "gold": 1, "after": 1, "note": 1, "cdstrip": 1, "toasts": 1,
              "mm_obj": 1, "mm_camps": 1, "mm_jungle": 1,
              "a_obj": 1, "a_gold": 1, "a_lane": 1, "a_lvl6": 1, "a_edead": 1, "a_mission": 1,
              "a_select": 1, "a_map": 1, "a_mapnudge": 0, "a_enemyitem": 1, "a_farm": 1, "a_habit": 1,
              "ptt": "none", "ptt_mode": "hold", "quiet_fight": 1, "voz_essencial": 1, "mic": -1, "ebar": 1, "fx3": None, "fy3": None, "layout_v": 3,
              "balao": 1, "fx4": None, "fy4": None, "runas_auto": 1, "a_mytips": 1, "a_mmlook": 1, "a_det": 1, "auto_aceitar": 0,
              "a_cd": 1, "a_threat": 1, "a_self": 1, "a_timers": 1, "a_events": 1, "a_matchup": 1, "a_role": 1, "a_jgvis": 1, "p_cd": 1, "p_tm": 1,
              "scale": 100, "opacity": 86, "toast_secs": 7, "luta_vol": 100, "bub_size": 100, "bub_font": 100, "perfil": None, "mm_text": 100, "accent": "main", "fx": None, "fy": None,
              "mm_side": "right", "mm_size": 26,
              "panel": 1, "p_cs": 1, "p_lane": 1, "p_gold": 1, "p_team": 1, "p_obj": 1, "fx2": None, "fy2": None}
ALERT_KIND = (("obj_", "a_obj"), ("gold_", "a_gold"), ("lane_dead_", "a_lane"), ("lane6", "a_lvl6"), ("me6", "a_lvl6"),
              ("edead_", "a_edead"), ("mission_", "a_mission"), ("sel_", "a_select"), ("selx_", "a_select"), ("map_", "a_map"), ("nudge_", "a_mapnudge"),
              ("eitem_", "a_enemyitem"), ("farm_", "a_farm"), ("habit_", "a_habit"), ("cd_", "a_cd"), ("threat_", "a_threat"),
              ("self_", "a_self"), ("buff_", "a_timers"), ("inhib_", "a_timers"), ("ev_", "a_events"), ("mu_", "a_matchup"), ("lobby_", "a_select"), ("post_", "a_self"), ("jg_", "a_role"), ("sup_", "a_role"), ("top_", "a_role"), ("mid_", "a_role"), ("adc_", "a_role"), ("mytip_", "a_mytips"), ("mmlook_", "a_mmlook"), ("det_", "a_det"), ("erro_", "a_det"), ("ficha_", "a_det"), ("fichax_", "a_det"))


# botao para falar com o coach (lido com GetAsyncKeyState: o clique continua indo para o jogo normalmente)
PTT_VK = {"none": 0, "mouse3": 0x04, "mouse4": 0x05, "mouse5": 0x06, "f8": 0x77, "f9": 0x78, "f10": 0x79}
PTT_NAMES = [("none", "Só o atalho"), ("mouse3", "Botão do meio (mouse 3)"), ("mouse4", "Mouse 4 (lateral)"), ("mouse5", "Mouse 5 (lateral)"),
             ("f8", "F8"), ("f9", "F9"), ("f10", "F10")]


def load_cfg():
    try:
        with open(CFG_PATH, encoding="utf-8") as fh:
            d = json.load(fh)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def save_cfg(**kw):
    d = load_cfg()
    d.update(kw)
    tmp = CFG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(d, fh)
    for _ in range(25):          # OneDrive pode travar o arquivo por instantes
        try:
            os.replace(tmp, CFG_PATH)
            break
        except PermissionError:
            time.sleep(0.2)


CLEAN = {"plan": 0, "lanes": 0, "p_plan": 0, "item": 1, "gold": 1, "after": 0, "note": 0, "cdstrip": 1, "toasts": 1,
         "panel": 0, "ebar": 1}
FULL = {"plan": 1, "lanes": 1, "p_plan": 1, "item": 1, "gold": 1, "after": 1, "note": 1, "cdstrip": 1, "toasts": 1,
        "panel": 1, "ebar": 1}


def ui_settings():
    u = dict(DEFAULT_UI)
    cfg_ = load_cfg()
    got = cfg_.get("ui") or {}
    if got and int(got.get("layout_v") or 0) < 2:     # uma vez: passa para o modo limpo (o que a gente olha de verdade)
        got = dict(got, **CLEAN, layout_v=3)
        try:
            save_cfg(ui=got)
        except Exception:
            pass
    elif got and int(got.get("layout_v") or 0) < 3:   # o proximo item volta para o modo limpo
        got = dict(got, item=1, gold=1, layout_v=3)
        try:
            save_cfg(ui=got)
        except Exception:
            pass
    for k, v in got.items():
        if k in u:
            u[k] = v
    u["ebar"] = 0          # barra de Flash/ult dos inimigos removida (regra da Riot): marcar so por voz, so feiticos
    return u


def clean_ui(form):
    """Valida o que veio da pagina (cada valor dentro do limite; o resto fica no padrao)."""
    u = dict(DEFAULT_UI)
    for k, v in DEFAULT_UI.items():
        if v in (0, 1) and k not in ("fx", "fy"):
            u[k] = 1 if form.get(k) in ("1", 1, True, "on") else 0
    lim = {"scale": (70, 170), "opacity": (40, 100), "toast_secs": (3, 15), "mm_text": (70, 170), "mm_size": (12, 45),
           "luta_vol": (20, 100), "bub_size": (70, 170), "bub_font": (70, 170)}
    u["mm_side"] = "left" if form.get("mm_side") == "left" else "right"
    u["ptt"] = form.get("ptt") if form.get("ptt") in PTT_VK else "none"
    u["ptt_mode"] = "toggle" if form.get("ptt_mode") == "toggle" else "hold"
    for k, (lo, hi) in lim.items():
        try:
            u[k] = max(lo, min(hi, int(float(form.get(k)))))
        except (TypeError, ValueError):
            pass
    try:
        u["mic"] = max(-1, min(15, int(form.get("mic"))))
    except (TypeError, ValueError):
        u["mic"] = -1
    u["accent"] = form.get("accent") if form.get("accent") in ("main", "game", "gold", "green", "blue") else "main"
    u["layout_v"] = 3
    for k in ("fx", "fy", "fx2", "fy2", "fx3", "fy3", "fx4", "fy4"):
        try:
            u[k] = round(max(0.0, min(0.98, float(form.get(k)))), 4)
        except (TypeError, ValueError):
            u[k] = None
    return u


# ---------------- fila da voz: prioridade, sem repetir, audio gerado antes da vez ----------------
URGENT = ("voltou.", "volta em 30", "volta em 1 minuto", "apareceu no mapa", "Todo o seu time", "nasce em", "Cuidado", "Perigo", "gank", "sumiu")
LOW = ("voltando à vida", "Você completou", "Olhe o minimapa", "minutos:", "de farm", "sem sentinela", "Missão")


def speak_priority(txt):
    if any(w in txt for w in URGENT):
        return 3, 10        # (prioridade, segundos ate ficar velho)
    if any(w in txt for w in LOW):
        return 0, 14
    return 1, 20


# ---------------- modo "só o necessário" (padrão): corta a falação no jogo ----------------
# Sempre fala: Flash/ult marcados voltando, vantagem/desvantagem numérica, Barão/Ancião/inibidor/alma,
# objetivo chegando (uma vez), caçador inimigo perto de você. O resto só de vez em quando, com intervalo.
VOZ_SEMPRE = ("scout_", "luta_", "morte_", "det_", "erro_", "ficha_", "start_", "lane6", "me6", "spell", "mytip_", "esc_", "jgback_", "agg_", "jg_gank_", "jgtempo_", "jg_best_", "nitem_", "sit_", "macro_x_", "jgvis_", "mmlook_", "jgwin_", "macro_mid_numbad", "macro_mid_num_", "macro_mid_baron", "macro_mid_elder", "macro_mid_inhib",
              "macro_mid_soul", "macro_window_", "edead_", "macro_obj_", "obj_", "buff_", "jgvis_perto")
VOZ_NUNCA = ("selx_", "fichax_", "eitem_", "farm_", "nudge_", "mission_", "self_", "cd_", "map_", "nv_", "habit_", "mu_threat_",
             "mu_tip0_", "mu_death_", "mu_safe_", "mu_item_", "sup_vis_", "sup_cw_", "gold_", "ev_", "threat_", "adc_",
             "jg_worst_", "macro_mid_even", "wave_ward", "wave_lv2")
VOZ_FAMILIA = (("macro_mid_ahead", "ouro", 300), ("macro_mid_behind", "ouro", 300), ("macro_mid_gold", "ouro", 300),
               ("macro_ahead_", "ouro", 300), ("macro_behind_", "ouro", 300), ("macro_group_", "ritmo", 240),
               ("macro_farm_", "ritmo", 240), ("macro_idle_", "ritmo", 240), ("macro_recall_", "volta", 240),
               ("wave_", "onda", 240), ("lane_dead_", "rota", 180), ("macro_mid_fed_", None, 99999))
VOZ_GAP = 45          # segundos de silencio entre falas que nao sao essenciais


VOZ_VIVA = ("macro_window_", "macro_mid_", "macro_x_", "edead_", "lane_dead_", "macro_recall_", "macro_group_", "macro_idle_", "macro_farm_")
VOZ_MORTO_OK = ("scout_", "luta_", "morte_", "ficha_", "det_", "erro_intro", "spell", "macro_obj_", "obj_", "buff_", "mytip_", "nitem_", "sit_")


def voice_short(k, t):
    """Versao curta e sem numeros que mudam (fica no cache e sai na hora)."""
    import re as _re
    m = _re.match(r"Vocês estão com (\d) a menos", t)
    if m:
        return f"{m.group(1)} a menos. Recue, não lute."
    m = _re.match(r"(\d) inimigos mortos por \d+ segundos: peguem (.+?) agora", t)
    if m:
        return f"{m.group(1)} inimigos mortos: peguem {m.group(2)} agora."
    if k == "jgtempo_3":
        return t.split(" já está")[0] + " nível 3: pode gankar agora. Jogue perto da torre."
    if k == "jgtempo_4":
        return "O jungler deles terminou a primeira volta: pode estar descendo pro seu lado."
    if k.startswith("jg_best_"):
        m = _re.match(r"Rota com vantagem para gankar: (.+?) \(", t)
        if m:
            return f"Bom gank no {m.group(1)}."
    if k == "lane6":
        return t.split(" já tem")[0] + " tem ult e você não: jogue para trás."
    if k == "me6":
        return "Você tem ult e ele não: hora de trocar pesado."
    if k.startswith("macro_mid_baronus"):
        return "Vocês têm Barão: empurrem uma rota juntos."
    if k.startswith("macro_mid_baronthem"):
        return "Eles têm Barão: defenda nas torres."
    if k.startswith("macro_mid_elderus"):
        return "Vocês têm Ancião: forcem a luta."
    if k.startswith("macro_mid_elderthem"):
        return "Eles têm Ancião: recuem."
    m = _re.match(r"(.+?) morto por \d+s", t)
    if m and k.startswith("lane_dead_"):
        return f"{m.group(1)} morto: empurre e ajude o time."
    m = _re.match(r"Vocês estão ([\d.]+) mil (atrás|na frente)", t)
    if m:
        return "Time atrás em ouro: jogue seguro." if m.group(2) == "atrás" else "Time na frente em ouro: forcem objetivo."
    m = _re.match(r"Você está \d+ de ouro atrás de (.+?) em itens", t)
    if m:
        return f"Atrás do {m.group(1)} em itens: não troque, farme."
    m = _re.match(r"Você tem \d+ de ouro em itens a mais que (.+?):", t)
    if m:
        return f"Na frente do {m.group(1)}: force troca."
    return None


def voz_essencial(k, st, now=None, dead=False):
    """True se o aviso de chave k deve ser falado no modo 'só o necessário'. st guarda o estado entre chamadas."""
    now = now or time.time()
    if dead and not k.startswith(VOZ_MORTO_OK):       # morto: nada de "empurre", "recue", "peguem"
        return False
    if k.startswith(("obj_", "macro_obj_")):          # objetivo: uma fala por objetivo (a de 1 minuto ou a contagem)
        nm = k.split("obj_", 1)[1].split("_")[0]
        fam = "obj_" + {"dragao": "drag", "barao": "baron", "larvas": "grubs", "arauto": "herald"}.get(nm, nm)
        fams = st.setdefault("fam", {})
        if fam in fams and now - fams[fam] < 120:
            return False
        st["fam"][fam] = now
        st["last"] = now
        return True
    if k.startswith(VOZ_SEMPRE):
        st["last"] = now
        return True
    if k.startswith(VOZ_NUNCA):
        return False
    fam, cd = k, 180
    for pre, f, c in VOZ_FAMILIA:
        if k.startswith(pre):
            fam, cd = (f or k), c
            break
    fams = st.setdefault("fam", {})
    if (fam in fams and now - fams[fam] < cd) or now - st.get("last", -1e9) < VOZ_GAP:
        return False
    fams[fam] = now
    st["last"] = now
    return True


_LANE_PATH = {          # rotas no minimapa (0 a 1; 0,0 = canto de cima a esquerda; base azul embaixo a esquerda)
    "TOP": [(0.08, 0.82), (0.08, 0.08), (0.82, 0.08)],
    "MIDDLE": [(0.15, 0.85), (0.85, 0.15)],
    "BOTTOM": [(0.18, 0.92), (0.92, 0.92), (0.92, 0.18)],
}
_LANE_PATH["UTILITY"] = _LANE_PATH["BOTTOM"]


def _dist_seg(p, a, b):
    (px, py), (ax, ay), (bx, by) = p, a, b
    dx, dy = bx - ax, by - ay
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / ((dx * dx + dy * dy) or 1)))
    return ((px - ax - t * dx) ** 2 + (py - ay - t * dy) ** 2) ** 0.5


def jg_near(pos, nx, ny, where_=""):
    """True se o caçador inimigo está perto da SUA rota (pela posição no minimapa). Selva: só quando ele invade a sua selva."""
    pos = (pos or "").upper()
    if pos == "JUNGLE":
        return "na sua selva" in where_
    path = _LANE_PATH.get(pos)
    if not path:
        return False
    d = min(_dist_seg((nx, ny), path[i], path[i + 1]) for i in range(len(path) - 1))
    return d <= 0.13


class SpeakQueue:
    """Substitui a fila simples: urgente fura a fila, frase repetida em 2,5 min nao entra, e o audio da proxima
    frase ja e gerado enquanto a atual toca (era isso que atrasava a voz)."""

    def __init__(self, fetch, max_items=6):
        import concurrent.futures
        self.items = []
        self.cv = threading.Condition()
        self.pool = concurrent.futures.ThreadPoolExecutor(max_workers=3)
        self.fetch = fetch
        self.recent = {}
        self.max = max_items

    def put(self, item):
        if not isinstance(item, dict):
            item = {"t": item}
        item = dict(item)
        now = time.time()
        item.setdefault("made", now)
        txt = item["t"]
        special = txt.startswith(("Coach", "Teste", "Resumo"))
        if item.get("at") is None and not special and not item.get("force"):
            if now - self.recent.get(txt, 0) < 150:
                return
            self.recent[txt] = now
            if len(self.recent) > 300:
                self.recent = {k: v for k, v in self.recent.items() if now - v < 150}
        pri, ttl = (5, 120) if special else speak_priority(txt)
        if item.get("live"):
            ttl = min(ttl, 10)
        item["pri"], item["ttl"] = pri, ttl
        if item.get("at") is None:
            item["fut"] = self.pool.submit(self.fetch, txt)
        with self.cv:
            self.items.append(item)
            if len(self.items) > self.max:            # cheio: sai o menos importante e mais velho
                worst = min(self.items, key=lambda x: (x["pri"], -x["made"]))
                self.items.remove(worst)
            self.cv.notify()

    def get(self):
        with self.cv:
            while not self.items:
                self.cv.wait()
            best = max(self.items, key=lambda x: (x["pri"], -x["made"]))
            self.items.remove(best)
            return best

    def qsize(self):
        return len(self.items)

    def clear(self):
        with self.cv:
            self.items.clear()


def alert_on(ui, key):
    if key.startswith("demo"):
        return True
    for pre, opt in ALERT_KIND:
        if key.startswith(pre):
            return bool(ui.get(opt, 1))
    return True


DEMO_TIPS = ["Dragão nasce em 60s", "Ouro suficiente para Lâmina Fantasma de Youmuu", "Ahri morta por 22s: a rota está livre",
             "Ahri já tem a ultimate (nível 6)", "3 inimigos mortos, o primeiro volta em 18s"]


def demo_data(items):
    """Partida de mentira para ajustar o overlay fora do jogo (botao "Mostrar no jogo agora")."""
    left = max(0, int(STATE["demo_until"] - time.time()))
    nm = lambda i, d: ((items or {}).get(str(i)) or {}).get("name") or d
    k = int(time.time() // 8)
    return {"in_game": True, "demo": True, "clock": "4:00", "champion": "Prévia", "ver": None,
            "next": {"id": 3142, "name": nm(3142, "Lâmina Fantasma de Youmuu"), "cost": 2700, "gold": 1850, "pct": 69},
            "after": [6694, 3814], "cdl": "Ahri: Q 7s · W 9s · E 14s · R 130s",
            "plan": {"title": "Pressione a rota lateral antes de disputar objetivos", "phase": "Meio do jogo",
                     "tips": ["Empurre a onda lateral antes de ir para o próximo objetivo.", "Recue quando Lee Sin sumir do mapa.",
                              "Sem Teleporte, aproxime-se do time mais cedo."]},
            "lanes": {"total": 1200, "roles": [{"pos": "TOP", "lb": "TOP", "v": 350, "me": False}, {"pos": "JUNGLE", "lb": "JG", "v": -200, "me": False},
                                               {"pos": "MIDDLE", "lb": "MID", "v": 0, "me": True}, {"pos": "BOTTOM", "lb": "ADC", "v": 700, "me": False},
                                               {"pos": "UTILITY", "lb": "SUP", "v": 350, "me": False}]}, "note": {"kind": "obj", "text": f"Prévia do overlay: some em {left}s"},
            "timers": {"t": 240, "dragon": 300, "baron": 1200, "dk": False, "bk": False},
            "alerts": [{"k": f"demo_{k}", "t": DEMO_TIPS[k % len(DEMO_TIPS)]}],
            "panel": {"head": "4:00 · Prévia · nível 4", "cs": "31 de farm · 7.8/min (sua média 6.9)", "cs_ok": True,
                      "lane": "Ahri nível 4 · mesmo nível", "lane_k": 0, "gold": "você 1.3k · Ahri 1.1k", "gold_k": 1,
                      "team": "+0.8k em itens · abates 3 x 1", "team_k": 1, "obj": "Dragão 1:00 · Barão 16:00",
                      "cd": "Ahri: Q 7s · W 9s · E 14s", "tm": "Inibidor deles 3:20"}}


# ---- lado do servidor --------------------------------------------------------
def running():
    p = STATE["proc"]
    return bool(p and p.poll() is None)


def stop():
    p = STATE["proc"]
    if p and p.poll() is None:
        try:
            p.terminate()
        except Exception:
            pass


def launch(owner_uid, port):
    """Abre a janela do overlay (processo separado, sem console)."""
    if running():
        return True
    STATE["owner"] = owner_uid
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    exe = sys.executable
    w = os.path.join(os.path.dirname(exe), "pythonw.exe")
    if os.name == "nt" and os.path.exists(w):
        exe = w
    flags = 0x08000000 if os.name == "nt" else 0  # sem janela de console
    try:
        os.makedirs(os.path.join(root, "cache"), exist_ok=True)
        err = open(os.path.join(root, "cache", "overlay_erro.log"), "a", encoding="utf-8")
    except OSError:
        err = subprocess.DEVNULL
    STATE["proc"] = subprocess.Popen([exe, "-m", "coach", "overlay", "--port", str(port), "--token", TOKEN], cwd=root,
                                     stdout=subprocess.DEVNULL, stderr=err,
                                     **({"creationflags": flags} if os.name == "nt" else {}))
    STATE["started"] = time.time()
    return True


_LOGGED = {}


_SIT = {}


def situational(con, champ, pos, foes, items):
    """Itens que a composicao inimiga pede (guardado por partida: so muda quando os campeoes mudam)."""
    from . import liveview
    names = tuple(sorted(liveview.champ_id(p) for p in foes))
    key = (champ, pos, names)
    if key in _SIT:
        return _SIT[key]
    out = []
    try:
        from . import pregame, voicecues
        from .ddragon import DataDragon
        chs = DataDragon(cache_dir=os.path.join(os.path.dirname(CFG_PATH), "cache")).champions()
        dfn = {"AP": voicecues.defensive_pick(con, champ, pos, items, "magico"), "AD": voicecues.defensive_pick(con, champ, pos, items, "fisico")}
        lane_ = next((liveview.champ_id(p) for p in foes if pos and (p.get("position") or "").upper() == pos), None)
        out = pregame.comp_adjust(list(names), chs, pregame.my_dtype(chs, champ), items, dfn, pos, mine=champ, con=con, laner=lane_)
    except Exception:
        out = []
    if len(_SIT) > 20:
        _SIT.clear()
    _SIT[key] = out
    return out


_WARM = {}


def warm_game(con, live_data):
    """Na primeira vez que ve a partida: baixa as fichas dos 10 campeoes e calcula a leitura do cacador inimigo
    em segundo plano. Antes isso acontecia dentro do pedido do overlay e travava a voz no comeco do jogo."""
    from . import liveview
    key = "|".join(sorted(liveview.champ_id(p) for p in live_data.get("allPlayers") or []))
    if key in _WARM:
        return
    _WARM.clear()
    _WARM[key] = time.time()
    try:
        dbp = con.execute("PRAGMA database_list").fetchone()[2]
    except Exception:
        dbp = None
    cids = [liveview.champ_id(p) for p in live_data.get("allPlayers") or []]
    jgs = [liveview.champ_id(p) for p in live_data.get("allPlayers") or [] if (p.get("position") or "").upper() == "JUNGLE"]
    ddir = os.path.dirname(CFG_PATH)

    def go():
        try:
            from .ddragon import DataDragon
            dd = DataDragon(cache_dir=os.path.join(ddir, "cache"))
            for cid in cids:
                try:
                    dd.champion(cid)
                except Exception:
                    pass
            from . import voicecues, champtips, jungle, db as _db
            for cid in cids:
                try:
                    voicecues._CD.pop(cid, None)
                    voicecues.champ_cds(ddir, cid)
                    champtips._MEM.pop((cid, 1), None)
                    champtips._MEM.pop((cid, 2), None)
                except Exception:
                    pass
            if dbp:
                c2 = _db.connect(dbp)
                try:
                    for cid in jgs:
                        jungle.summary(c2, cid)
                finally:
                    c2.close()
            log("partida: dados dos campeões prontos")
        except Exception as ex:
            log(f"partida: aquecimento falhou ({type(ex).__name__}: {ex})")
    threading.Thread(target=go, daemon=True).start()


def data_for(con, puuid, live_data, items, tags, games):
    """Monta o que o overlay mostra e fala. Nunca espera a internet: o que falta e baixado em segundo plano."""
    from .ddragon import NOFETCH
    if live_data:
        try:
            warm_game(con, live_data)
        except Exception:
            pass
    prev = getattr(NOFETCH, "on", False)
    NOFETCH.on = True
    try:
        return _data_for(con, puuid, live_data, items, tags, games)
    finally:
        NOFETCH.on = prev


def _data_for(con, puuid, live_data, items, tags, games):
    """So o essencial, curto: proximo item (com icone), os 2 seguintes e no maximo uma linha de aviso quando importa."""
    from . import gameview, icons, live, liveview
    if not live_data:
        return {"in_game": False}
    me = live._find_me(live_data)
    if not me:
        return {"in_game": False}
    gt = (live_data.get("gameData") or {}).get("gameTime") or 0
    if any(x.get("EventName") == "GameEnd" for x in ((live_data.get("events") or {}).get("Events") or [])):
        return {"in_game": False, "ended": True}       # nexus caiu: para de falar da partida na hora
    if gt < 2:   # tela de carregamento: nada na tela, so a voz com a missao do dia
        sp = []
        try:
            from . import voicecues
            txt = voicecues.profile_stats(con, puuid).get("mission")
            if txt:
                sp.append({"k": "mission_start", "t": f"Missão de hoje: {txt}"})
        except Exception:
            pass
        return {"in_game": False, "loading": True, "speak": sp}
    gold = int((live_data.get("activePlayer") or {}).get("currentGold") or 0)
    from . import visao as _vis
    _vis.update(me, gt)                              # acompanha a Sentinela de Controle (inventario -> mapa)
    champ = liveview.champ_id(me)
    from . import profile as _prof
    pos = _prof.game_pos(me)
    out = {"me_cid": liveview.champ_id(me), "in_game": True, "clock": f"{int(gt) // 60}:{int(gt) % 60:02d}", "champion": me.get("championName"), "ver": icons.version(), "pos": pos,
           "me_dead": bool(me.get("isDead"))}
    foes0 = [p for p in live_data.get("allPlayers") or [] if p.get("team") != me.get("team")]
    _opp = next((p for p in foes0 if pos and p.get("position") == pos), None)
    plan = liveview.build_plan(con, puuid, champ, pos, items, liveview.champ_id(_opp) if _opp else None,
                               tuple(liveview.champ_id(p) for p in foes0)) if items else None
    sit = situational(con, champ, pos, foes0, items) if items else []
    out["sit"] = [{"id": i, "name": nm, "why": why} for i, nm, why, _ in sit]
    if plan:
        owned = {i.get("itemID") for i in me.get("items") or []}
        seq = list(plan["order"]) + ([plan["boots"]] if plan["boots"] else [])
        # item obrigatorio pela composicao inimiga (corta escudo, anticura, Zhonya...): entra logo depois do 1o item
        from . import builds as _b
        done_leg = sum(1 for i in owned if i and _b.is_complete(items, i) and "Boots" not in ((items.get(str(i)) or {}).get("tags") or []))
        why_next = None
        from . import itemfit as _if, pregame as _pg
        has_boots = any(i and _if.is_boots(items, i) and ((items.get(str(i)) or {}).get("gold") or {}).get("total", 0) >= 900 for i in owned)
        owned_fam = set()
        for i in owned:
            if i:
                owned_fam |= _if.family(items, i)
        anti = {i for v in _pg.ANTIHEAL.values() for i in v}
        pen = {i for v in _pg.PEN.values() for i in v}

        def covered(i):
            """Voce ja tem esse item (ou a versao dele), ja tem botas, ou ja tem outro item da mesma funcao."""
            if i in owned_fam:
                return True
            if _if.is_boots(items, i):
                return has_boots
            for grp in (anti, pen):
                if i in grp and any(x in owned_fam for x in grp):
                    return True
            return False
        sit_boots = [i for i, *_ in sit if _if.is_boots(items, i)]
        if sit_boots and not has_boots and plan.get("boots") and plan["boots"] not in sit_boots:      # botas pela composicao no lugar das botas da build
            seq = [x for x in seq if x != plan["boots"]] + [sit_boots[0]]
        if has_boots:
            seq = [x for x in seq if not _if.is_boots(items, x) or x in owned]          # nunca um segundo par de botas
        for i, nm, why, _ in sit:
            if i in owned or covered(i):
                continue
            if done_leg >= 1 or i in (3111, 3047, 3140, 3123, 3916, 3076):     # botas e componentes baratos podem vir antes
                seq = [i] + [x for x in seq if x != i]
                why_next = why
                break
        rest = [i for i in seq if i not in owned]
        start = [i for i in plan.get("start") or [] if i not in owned]
        if gt < 75 and start and not any(i and _b.is_complete(items, i) for i in owned) and len(owned - {None, 3340, 3363, 3364}) == 0:
            nm_ = " + ".join((items.get(str(i)) or {}).get("name", str(i)) for i in start[:3])
            out["next"] = {"id": start[0], "name": nm_, "cost": 0, "gold": gold, "pct": 100, "why": "começo dos melhores"}
            out["after"] = rest[:2]
            out["_start"] = {"k": f"start_{champ}", "t": f"Comece com {nm_}."}
            rest = []
        if rest:
            nxt = rest[0]
            it = items.get(str(nxt)) or {}
            cost = (it.get("gold") or {}).get("total") or 0
            out["next"] = {"id": nxt, "name": it.get("name", str(nxt)), "cost": cost, "gold": gold, "pct": min(100, round(100 * gold / cost)) if cost else 0}
            if why_next and nxt == seq[0]:
                out["next"]["why"] = why_next
            out["after"] = rest[1:3]
            try:
                comp = next_component(nxt, [i.get("itemID") for i in me.get("items") or []], gold, items)
                if comp:
                    out["next"]["comp"] = comp
                from . import visao
                out["shop"] = shopping(nxt, [i.get("itemID") for i in me.get("items") or []], gold, items, cw=visao.needs(me, gt))
            except Exception:
                pass
    foes = [p for p in live_data.get("allPlayers") or [] if p.get("team") != me.get("team")]
    note = None
    dead = [f"{p.get('championName')} {int(p.get('respawnTimer') or 0)}s" for p in foes if p.get("isDead")]
    if dead:
        note = ("dead", "Mortos: " + ", ".join(dead[:3]))
    else:
        ev = (live_data.get("events") or {}).get("Events") or []
        drag = [x for x in ev if x.get("EventName") == "DragonKill"]
        nxt_d = ((drag[-1].get("EventTime") or 0) + liveview.DRAGON_RESPAWN) if drag else 300
        if 0 < nxt_d - gt <= 60:
            left = int(nxt_d - gt)
            note = ("obj", f"Dragão em {left // 60}:{left % 60:02d}")
        elif gt < 120:
            lp = next((p for p in foes if pos and p.get("position") == pos), None)
            if lp:
                from . import champtips
                tip_ = champtips.tip_vs(liveview.champ_id(lp), tags=tags.get(liveview.champ_id(lp), []))
                if tip_:
                    note = ("tip", f"{lp.get('championName')}: {tip_}")
    if me.get("isDead") and out.get("shop"):
        note = ("shop", "Na base: " + " + ".join(n for _, n, _ in out["shop"])
                + (f" (rumo a {out['next']['name']}: {out['next']['why']})" if (out.get("next") or {}).get("why") else ""))
    if note:
        out["note"] = {"kind": note[0], "text": note[1]}
    out["timers"] = timers(live_data, gt)
    out["fight"] = in_fight(live_data, gt)
    out["team"] = me.get("team")
    out["enemies"] = [{"id": liveview.champ_id(p), "name": p.get("championName"), "pos": p.get("position")} for p in foes]
    try:
        out["plan"] = macro_plan(live_data, me, foes, pos, gt, out["timers"], items)
        out["lanes"] = lane_gold(live_data, me, items)
    except Exception:
        pass
    try:
        out["panel"] = panel_data(con, puuid, live_data, me, foes, pos, gt, items, out["timers"])
    except Exception:
        pass
    if (out.get("panel") or {}).get("cd"):
        out["cdl"] = out["panel"]["cd"]
    out["alerts"] = alerts(con, puuid, live_data, me, foes, pos, gt, out)
    if out.get("_start"):
        out["alerts"].append(out.pop("_start"))
    try:
        from . import macrocues
        out["alerts"] += macrocues.cues(live_data, me, foes, pos, gt, items, out.get("timers") or {}, out.get("next"))
        out["alerts"] += macrocues.extras(live_data, me, foes, pos, gt, items, out.get("timers") or {}, gold)
    except Exception as ex:
        if not _LOGGED.get("macro"):
            _LOGGED["macro"] = 1
            log(f"macro: {type(ex).__name__}: {ex}")
    try:
        from . import lanecues
        lc = lanecues.cues(live_data, me, foes, pos, gt, os.path.dirname(CFG_PATH))
        if any(a["k"] == "esc_6" for a in lc):
            out["alerts"] = [a for a in out["alerts"] if a["k"] != "lane6"]
        out["alerts"] += lc
    except Exception as ex:
        if not _LOGGED.get("lanecues"):
            _LOGGED["lanecues"] = 1
            log(f"avisos de rota: {type(ex).__name__}: {ex}")
    try:
        from . import ficha
        out["alerts"] += ficha.cues(con, puuid, live_data, me, foes, pos, gt, items)
    except Exception as ex:
        if not _LOGGED.get("ficha"):
            _LOGGED["ficha"] = 1
            log(f"ficha do confronto: {type(ex).__name__}: {ex}")
    try:
        from . import meuerro
        out["alerts"] += meuerro.cues(con, puuid, live_data, me, foes, pos, gt, items)
    except Exception as ex:
        if not _LOGGED.get("meuerro"):
            _LOGGED["meuerro"] = 1
            log(f"seu erro principal: {type(ex).__name__}: {ex}")
    try:
        from . import detalhes
        out["alerts"] += detalhes.cues(live_data, me, foes, pos, gt, items, os.path.dirname(CFG_PATH))
    except Exception as ex:
        if not _LOGGED.get("detalhes"):
            _LOGGED["detalhes"] = 1
            log(f"detalhes: {type(ex).__name__}: {ex}")
    try:
        from . import mytips
        gk_ = "|".join(sorted(liveview.champ_id(p) for p in live_data.get("allPlayers") or []))
        out["alerts"] += mytips.live_cues(os.path.dirname(CFG_PATH), liveview.champ_id(me), me, gt, gk_)
    except Exception as ex:
        if not _LOGGED.get("mytips"):
            _LOGGED["mytips"] = 1
            log(f"dicas do campeão: {type(ex).__name__}: {ex}")
    try:
        from . import midgame
        dec = midgame.decide(live_data, me, pos, gt, items, out.get("timers") or {})
        if dec:
            out["alerts"].append({"k": "macro_mid_" + dec[0], "t": dec[1]})
            out["decision"] = dec[1]
        out["alerts"] += midgame.tempo_cues(live_data, me, pos, gt, out.get("timers") or {})
    except Exception as ex:
        log(f"midgame: {type(ex).__name__}: {ex}")
    try:
        from . import wavemap
        out["alerts"] += wavemap.enemy_jungle_read(con, live_data, me, foes, pos, gt)
        out["alerts"] += wavemap.jungler_tempo(foes, pos, gt)
        out["alerts"] += wavemap.wave_cues(me, pos, gt, gold, out.get("next"))
        lp_ = next((p for p in foes if pos and p.get("position") == pos), None)
        if lp_:
            out["alerts"] += wavemap.freeze_hint(pos, _item_value(me, items) - _item_value(lp_, items), gt)
    except Exception as ex:
        log(f"wavemap: {type(ex).__name__}: {ex}")
    try:
        from . import spelltimers
        out["marks"] = spelltimers.line(live_data, gt)
        out["alerts"] += spelltimers.alerts(live_data, gt)
        out["mark_who"] = [p.get("championName") for p in spelltimers.enemies(live_data, me)]
    except Exception:
        pass
    if me.get("isDead") and out.get("shop"):
        d = int((me.get("scores") or {}).get("deaths") or 0)
        names = [n for _, n, _ in out["shop"]]
        txt = (", ".join(names[:-1]) + " e " + names[-1]) if len(names) > 1 else names[0]
        out["alerts"].append({"k": f"self_shop_{d}", "t": f"Com {gold} de ouro dá para comprar: {txt}.", "v": f"Na base, dá para comprar {txt}."})
    nx = out.get("next") or {}
    if nx.get("why") and nx.get("cost"):    # item pedido pela composicao: fala uma vez por item
        out["alerts"].append({"k": f"sit_{nx['id']}", "t": f"Seu próximo item precisa ser {nx['name']} ({nx['why']}).",
                              "v": f"Seu próximo item precisa ser {nx['name']}: {nx['why']}."})
    if nx.get("cost") and gold >= nx["cost"] and gt >= 90:      # ja da para comprar: fala uma vez por item
        if me.get("isDead"):
            out["alerts"].append({"k": f"nitem_{nx['id']}", "t": f"Na base: compre {nx['name']} agora ({gold} de ouro).",
                                  "v": f"Compre {nx['name']} agora."})
        else:
            out["alerts"].append({"k": f"nitem_{nx['id']}", "t": f"Já dá para comprar {nx['name']}: {gold} de ouro. Volte para a base quando a onda deixar.",
                                  "v": f"Já dá pra comprar {nx['name']}. Volte quando a onda deixar."})
    try:
        from . import voicecues
        out["alerts"] += voicecues.game_cues(con, puuid, live_data, me, foes, pos, gt, items)
        out["alerts"] += voicecues.extra_cues(con, puuid, os.path.dirname(CFG_PATH), live_data, me, foes, pos, gt, live_data.get("activePlayer"), items)
    except Exception:
        pass
    try:
        from . import voicecues
        out["alerts"] += voicecues.matchup_cues(con, os.path.dirname(CFG_PATH), live_data, me, foes, pos, gt, items)
    except Exception as ex:
        if not _LOGGED.get("mu"):
            _LOGGED["mu"] = 1
            log(f"dicas de duelo: {type(ex).__name__}: {ex}")
    try:
        from . import jungle, roles
        out["alerts"] += roles.live_cues(live_data, me, foes, pos, gt, items)
        out["alerts"] += jungle.live_cues(con, live_data, me, foes, pos, gt, champ)
    except Exception as ex:
        if not _LOGGED.get("role"):
            _LOGGED["role"] = 1
            log(f"dicas da rota: {type(ex).__name__}: {ex}")
    return out


# ---------------- plano do momento, ouro por rota e dicas da fase (so o placar) ----------------
ROLE_SHORT = [("TOP", "TOP"), ("JUNGLE", "JG"), ("MIDDLE", "MID"), ("BOTTOM", "ADC"), ("UTILITY", "SUP")]


def lane_gold(live_data, me, items):
    """Diferenca de valor de itens por rota (seu time menos o inimigo) e o total."""
    players = live_data.get("allPlayers") or []
    mine = [p for p in players if p.get("team") == me.get("team")]
    foes = [p for p in players if p.get("team") != me.get("team")]
    out = []
    for pos, lb in ROLE_SHORT:
        a = next((p for p in mine if p.get("position") == pos), None)
        b = next((p for p in foes if p.get("position") == pos), None)
        if a and b:
            from .liveview import est_gold
            gt_ = (live_data.get("gameData") or {}).get("gameTime") or 0
            out.append({"pos": pos, "lb": lb, "v": _item_value(a, items) - _item_value(b, items), "me": a is me,
                        "g": est_gold(a, gt_) - est_gold(b, gt_)})
    total = sum(_item_value(p, items) for p in mine) - sum(_item_value(p, items) for p in foes)
    return {"roles": out, "total": total} if out else None


def macro_plan(live_data, me, foes, pos, gt, tmr, items):
    """{'title', 'phase', 'tips'}: o que fazer agora, por fase e pelo estado do placar (regra geral do app)."""
    players = live_data.get("allPlayers") or []
    allies = [p for p in players if p.get("team") == me.get("team")]
    tv = sum(_item_value(p, items) for p in allies) - sum(_item_value(p, items) for p in foes)
    phase = "Fase de rotas" if gt < 840 else "Meio do jogo" if gt < 1500 else "Fim de jogo"
    edead = [p for p in foes if p.get("isDead")]
    adead = [p for p in allies if p.get("isDead")]
    lp = next((p for p in foes if pos and p.get("position") == pos), None)
    ejg = next((p for p in foes if p.get("position") == "JUNGLE"), None)
    drag, baron = tmr.get("dragon"), tmr.get("baron")
    soon = None
    for nm, at, ok in (("Dragão", drag, True), ("Barão", baron, gt >= 1140), ("Larvas do Vazio", 480, gt < 480), ("Arauto", 900, 480 <= gt < 900)):
        if ok and at and 0 < at - gt <= 60:
            soon = (nm, int(at - gt))
            break
    alive = [nm for nm, at, ok in (("Barão", baron, gt >= 1200), ("Dragão", drag, True)) if ok and at and at <= gt]
    mmss = lambda v: f"{v // 60}:{v % 60:02d}"
    if len(edead) >= 2:
        obj = alive[0] if alive else "uma torre"
        title = f"{len(edead)} inimigos mortos: hora de pegar {obj}"
    elif len(adead) >= 2:
        r = max(int(p.get("respawnTimer") or 0) for p in adead)
        title = f"{len(adead)} aliados mortos: jogue seguro por {r}s"
    elif soon:
        title = f"{soon[0]} em {mmss(soon[1])}: empurre a onda e chegue antes no rio"
    elif lp and lp.get("isDead") and int(lp.get("respawnTimer") or 0) >= 8:
        title = f"{lp.get('championName')} morto: empurre e pegue placa ou torre"
    elif phase == "Fase de rotas":
        title = {"TOP": "Controle a onda e guarde o Teleporte para o dragão", "MIDDLE": "Empurre e ajude o caçador no rio quando ele vier",
                 "BOTTOM": "Farme seguro e troque junto com o suporte", "UTILITY": "Visão no rio antes do dragão e proteja o atirador",
                 "JUNGLE": "Ganke a rota com vantagem e siga o tempo dos objetivos"}.get(pos, "Farme e troque quando o oponente errar")
    elif phase == "Meio do jogo":
        title = ("Vocês estão na frente: agrupem e forcem objetivo" if tv > 1500 else
                 "Atrás no ouro: farme seguro e espere o erro deles" if tv < -1500 else "Pressione a rota lateral antes de disputar objetivos")
    else:
        title = ("Agrupem para o Barão ou o inibidor" if tv > 1500 else
                 "Defenda perto das torres e espere a luta certa" if tv < -1500 else "Ande com o time: uma luta decide a partida")
    tips = []
    jgn = ejg.get("championName") if ejg else "o caçador inimigo"
    if phase == "Fase de rotas":
        if lp and pos != "JUNGLE":
            tips.append(f"Troque quando {lp.get('championName')} gastar a habilidade principal; com as habilidades prontas do outro lado, fique atrás dos minions.")
        if pos != "JUNGLE":
            tips.append(f"Recue para a metade da rota quando {jgn} sumir do mapa, até ele aparecer de novo.")
        else:
            tips.append("Antes de gankar, confira se a onda está do lado certo e se o oponente gastou o Flash.")
        tips.append("Volte à base com ouro para um componente e Sentinela de Controle, não com a onda batendo na sua torre.")
    elif phase == "Meio do jogo":
        tips.append("Empurre a onda lateral antes de ir para o próximo objetivo. Se não der para disputar, pegue a torre disponível em vez de chegar atrasado.")
        tips.append(f"Mantenha visão entre a sua rota e a selva inimiga. Recue quando {jgn} sumir do mapa.")
        ss = me.get("summonerSpells") or {}
        names = " ".join(((ss.get(k) or {}).get("displayName") or "") for k in ("summonerSpellOne", "summonerSpellTwo")).lower()
        if "telep" not in names:
            tips.append("Sem Teleporte, aproxime-se do time mais cedo. Evite trocas longas na lateral pouco antes do objetivo nascer.")
    else:
        tips.append("Não fique sozinho em rota lateral sem visão: depois dos 25 min o tempo de morte é longo e custa Barão.")
        tips.append("Antes do Barão ou do Ancião: visão no rio, o time inteiro vivo e as ondas laterais empurradas.")
    fed = max(foes, key=lambda p: int((p.get("scores") or {}).get("kills") or 0) - int((p.get("scores") or {}).get("deaths") or 0), default=None)
    if fed:
        k, d = int((fed.get("scores") or {}).get("kills") or 0), int((fed.get("scores") or {}).get("deaths") or 0)
        if k - d >= 4:
            tips.insert(0, f"{fed.get('championName')} está forte ({k}/{d}): não lute sozinho perto dele.")
    return {"title": title, "phase": phase, "tips": tips[:3]}


# ---------------- lote 1: compra, componente, objetivos, farm por onda, luta ----------------
def _cost(items, i):
    return int(((items.get(str(i)) or {}).get("gold") or {}).get("total") or 0)


def missing_parts(next_id, owned, items):
    """Componentes do proximo item que voce ainda nao tem (descendo a receita), do mais caro para o mais barato."""
    have = list(owned)
    out = []

    def walk(i):
        if i in have:
            have.remove(i)
            return
        frm = [int(x) for x in ((items.get(str(i)) or {}).get("from") or [])]
        if not frm:
            out.append(i)
            return
        out.append(i)          # o proprio item (se der para comprar inteiro)
        for c in frm:
            walk(c)
    walk(int(next_id))
    return out


def shopping(next_id, owned, gold, items, cw=True):
    """O que comprar com o ouro na mao: o item inteiro se der; senao os maiores componentes que cabem + sentinela de controle
    (cw=False quando voce ja tem uma no mapa)."""
    if not next_id:
        return []
    total = _cost(items, next_id)
    if gold >= total:
        buy = [next_id]
        gold -= total
    else:
        buy = []
        parts = [p for p in missing_parts(next_id, owned, items) if p != int(next_id)]
        for p in sorted(set(parts), key=lambda x: -_cost(items, x)):
            c = _cost(items, p)
            if c and c <= gold and not any(p in [int(y) for y in ((items.get(str(b)) or {}).get("from") or [])] for b in buy):
                buy.append(p)
                gold -= c
    if cw and 2055 not in owned and gold >= 75:
        buy.append(2055)
    return [(b, (items.get(str(b)) or {}).get("name") or str(b), _cost(items, b)) for b in buy]


def next_component(next_id, owned, gold, items):
    """Componente mais barato que ainda falta: 'faltam 150 para Espada Serrilhada'."""
    parts = [p for p in missing_parts(next_id, owned, items) if p != int(next_id) and _cost(items, p) > gold]
    if not parts:
        return None
    p = min(parts, key=lambda x: _cost(items, x))
    return {"name": (items.get(str(p)) or {}).get("name") or str(p), "need": _cost(items, p) - gold}


DRAKE_PT = {"Fire": "Infernal", "Water": "Oceano", "Earth": "Montanha", "Air": "Nuvem", "Hextech": "Hextec", "Chemtech": "Quimtec", "Elder": "Ancião"}


def objectives_line(live_data, me):
    from . import live
    ev = (live_data.get("events") or {}).get("Events") or []
    team_of = {live._name(p): p.get("team") for p in live_data.get("allPlayers") or []}
    mine, d_us, d_them, herald, grubs_us, grubs_them = me.get("team"), [], [], None, 0, 0
    for x in ev:
        n = x.get("EventName")
        ours = team_of.get(x.get("KillerName")) == mine
        if n == "DragonKill":
            (d_us if ours else d_them).append(DRAKE_PT.get(x.get("DragonType") or "", "?"))
        elif n == "HeraldKill":
            herald = "nosso" if ours else "deles"
        elif n == "HordeKill":
            if ours:
                grubs_us += 1
            else:
                grubs_them += 1
    parts = [f"Dragões: nós {len(d_us)}" + (f" ({', '.join(d_us)})" if d_us else "") + f" · eles {len(d_them)}" + (f" ({', '.join(d_them)})" if d_them else "")]
    if grubs_us or grubs_them:
        parts.append(f"Larvas {grubs_us} x {grubs_them}")
    if herald:
        parts.append(f"Arauto {herald}")
    return " · ".join(parts)


def in_fight(live_data, gt):
    ev = (live_data.get("events") or {}).get("Events") or []
    return sum(1 for x in ev if x.get("EventName") == "ChampionKill" and (x.get("EventTime") or 0) >= gt - 12) >= 2


def _item_value(p, items):
    tot = 0
    for it in p.get("items") or []:
        info = (items or {}).get(str(it.get("itemID"))) or {}
        tot += ((info.get("gold") or {}).get("total") or it.get("price") or 0) * max(1, int(it.get("count") or 1))
    return tot


def _k(v):
    return f"{v / 1000:.1f}k"


def panel_data(con, puuid, live_data, me, foes, pos, gt, items, tmr):
    """Segundo overlay: placar util (o que o TAB mostra para todos, resumido) + o seu farm contra a sua media."""
    from . import voicecues
    mins = max(gt / 60, 0.5)
    sc = me.get("scores") or {}
    cs = int(sc.get("creepScore") or 0)
    avg = voicecues.profile_stats(con, puuid).get("cspm")
    cs_txt = f"{cs} de farm · {cs / mins:.1f}/min"
    if avg and gt >= 150:
        diff = round(cs - avg * (gt - 60) / 60)        # 2026: a primeira onda chega por volta de 1:00
        waves = abs(diff) / 6.5
        cs_txt += (f" · +{diff} da sua média" if diff >= 0 else f" · {diff} da sua média (~{waves:.0f} onda{'s' if round(waves) != 1 else ''})")
    out = {"head": f"{int(gt) // 60}:{int(gt) % 60:02d} · {me.get('championName')} · nível {me.get('level') or 1}",
           "cs": cs_txt, "cs_ok": (cs / mins >= avg) if avg else None}
    lp = next((p for p in foes if pos and p.get("position") == pos), None)
    if lp:
        d = int(me.get("level") or 1) - int(lp.get("level") or 1)
        word = "mesmo nível" if d == 0 else (f"{d} nível à frente" if d == 1 else f"{d} níveis à frente" if d > 1 else
                                            f"{-d} nível atrás" if d == -1 else f"{-d} níveis atrás")
        out["lane"] = f"{lp.get('championName')} nível {lp.get('level') or 1} · {word}" + (" · morto" if lp.get("isDead") else "")
        out["lane_k"] = (d > 0) - (d < 0)
        mv, ov = _item_value(me, items), _item_value(lp, items)
        out["gold"] = f"você {_k(mv)} · {lp.get('championName')} {_k(ov)}"
        out["gold_k"] = (mv > ov + 300) - (ov > mv + 300)
        try:
            from . import liveview
            cds = voicecues.champ_cds(os.path.dirname(CFG_PATH), liveview.champ_id(lp))
            line = voicecues.cd_line(cds, int(lp.get("level") or 1))
            if line:
                out["cd"] = f"{lp.get('championName')}: {line}"
        except Exception:
            pass
    players = live_data.get("allPlayers") or []
    mine = [p for p in players if p.get("team") == me.get("team")]
    tv = sum(_item_value(p, items) for p in mine) - sum(_item_value(p, items) for p in foes)
    kills = lambda ps: sum(int((p.get("scores") or {}).get("kills") or 0) for p in ps)
    out["team"] = f"{'+' if tv >= 0 else '-'}{_k(abs(tv))} em itens · abates {kills(mine)} x {kills(foes)}"
    out["team_k"] = (tv > 1000) - (tv < -1000)
    parts = []
    for nm, at in (("Dragão", tmr.get("dragon")), ("Barão", tmr.get("baron") if gt >= 840 else None)):
        if at and at > gt:
            left = int(at - gt)
            parts.append(f"{nm} {left // 60}:{left % 60:02d}")
        elif at:
            parts.append(f"{nm} vivo")
    out["obj"] = " · ".join(parts)
    try:
        out["drg"] = objectives_line(live_data, me)
    except Exception:
        pass
    try:
        out["tm"] = voicecues.timers_line(live_data, me, gt)
    except Exception:
        pass
    return out


def alerts(con, puuid, live_data, me, foes, pos, gt, out):
    """Avisos curtos sobre o que o jogo mostra para todos (nunca ordens nem informacao escondida).
    Cada aviso tem uma chave; o overlay mostra cada chave uma vez so."""
    al = []
    tmr = out.get("timers") or {}
    for key, name, at in (("drag", "Dragão", tmr.get("dragon")), ("baron", "Barão", tmr.get("baron") if gt >= 900 else None),
                          ("grubs", "Larvas do Vazio", 480), ("herald", "Arauto", 900)):
        if at and 0 < at - gt <= 30:      # o aviso de 1 minuto (com o que fazer) vem do macrocues
            al.append({"k": f"obj_{key}_{int(at)}", "t": f"{name} {'nascem' if name.startswith('Larvas') else 'nasce'} em {int(at - gt)}s", "at": at, "nm": name})
    n = out.get("next")
    if n and n["cost"] and n["gold"] >= n["cost"]:
        al.append({"k": f"gold_{n['id']}", "t": f"Ouro suficiente para {n['name']}"})
    lp = next((p for p in foes if pos and p.get("position") == pos), None)
    if lp:
        r = int(lp.get("respawnTimer") or 0)
        if lp.get("isDead") and r >= 8:
            # o que fazer com a rota livre, pela rota e pelo proximo objetivo
            drag_soon = tmr.get("dragon") and 0 < tmr["dragon"] - gt <= 90
            top_obj = (gt < 480 and 480 - gt <= 90) or (480 <= gt < 900 and 900 - gt <= 90)
            if pos == "TOP":
                do = "empurre a onda e pegue placa" + ("; depois vá para o rio de cima" if top_obj else "")
            elif pos == "MIDDLE":
                do = "empurre a onda e ajude " + ("o dragão" if drag_soon else "o seu caçador ou uma rota do lado")
            elif pos in ("BOTTOM", "UTILITY"):
                do = "empurre e pegue placa" + ("; o dragão está chegando, puxe o time para lá" if drag_soon else "")
            elif pos == "JUNGLE":
                do = "a rota dele está livre: ajude a derrubar a torre ou pegue o objetivo do lado"
            else:
                do = "a rota está livre"
            al.append({"k": f"lane_dead_{int((gt + r) // 5)}", "t": f"{lp.get('championName')} morto por {r}s: {do}"})
        if (lp.get("level") or 0) >= 6 and (me.get("level") or 0) < 6:
            al.append({"k": "lane6", "t": f"{lp.get('championName')} já tem a ultimate (nível 6)"})
        if (me.get("level") or 0) >= 6 and (lp.get("level") or 0) < 6:
            al.append({"k": "me6", "t": f"Você chegou ao nível 6 antes de {lp.get('championName')}"})
    dead = [p for p in foes if p.get("isDead")]
    if len(dead) >= 3:
        m = min(int(p.get("respawnTimer") or 0) for p in dead)
        if m >= 10:
            al.append({"k": f"edead_{int(gt // 45)}", "t": f"{len(dead)} inimigos mortos, o primeiro volta em {m}s"})
    if gt < 600:
        d = int((me.get("scores") or {}).get("deaths") or 0)
        if d == 1:
            try:
                from . import missions, report
                st = missions.ensure_today(con, report.my_games(con, puuid, ""))
                if st["mission"]["metric"] == "deaths_before_10":
                    al.append({"k": "mission_d10", "t": "Missão de hoje: já foi 1 morte antes dos 10 min"})
            except Exception:
                pass
    return al


def timers(live_data, gt):
    """Hora (tempo de jogo, em segundos) em que dragao e barao nascem de novo, a partir dos abates que o jogo anuncia para todos."""
    from . import live
    ev = (live_data.get("events") or {}).get("Events") or []
    players = live_data.get("allPlayers") or []
    team_of = {live._name(p): p.get("team") for p in players}
    drag = [x for x in ev if x.get("EventName") == "DragonKill"]
    per_team = {}
    for x in drag:
        t = team_of.get(x.get("KillerName"))
        per_team[t] = per_team.get(t, 0) + 1
    if drag:
        soul = max(per_team.values() or [0]) >= 4
        nxt_d = (drag[-1].get("EventTime") or 0) + (360 if soul else 300)
    else:
        nxt_d = 300
    bar = [x for x in ev if x.get("EventName") == "BaronKill"]
    nxt_b = ((bar[-1].get("EventTime") or 0) + 360) if bar else 1200
    hk = any(x.get("EventName") == "HeraldKill" for x in ev)
    return {"t": gt, "dragon": nxt_d, "baron": nxt_b, "dk": bool(drag), "bk": bool(bar), "hk": hk}


# ---- a janela ----------------------------------------------------------------
PANEL, INK, MUTE, LINE, ACC, OKC, BAD = "#0D0D0D", "#F0F0F0", "#9A9A9A", "#2B2B2B", "#E0384C", "#6FCB98", "#EE6F78"
GOLD, CELL, CELL_ME, NOTE_BG = "#D9B45A", "#181818", "#22131A", "#1A1616"


def _load_fonts():
    """Fontes do app (Barlow Condensed, Chakra Petch, Barlow) so para este processo, sem instalar no Windows."""
    if os.name != "nt":
        return
    try:
        import ctypes
        d = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "fonts", "ttf")
        for f in os.listdir(d):
            if f.endswith(".ttf"):
                ctypes.windll.gdi32.AddFontResourceExW(os.path.join(d, f), 0x10, 0)
    except Exception:
        pass

CDN = "https://ddragon.leagueoflegends.com/cdn"


def _click_through(hwnd, on):
    import ctypes
    GWL_EXSTYLE, WS_EX_LAYERED, WS_EX_TRANSPARENT, WS_EX_TOOLWINDOW = -20, 0x80000, 0x20, 0x80
    u = ctypes.windll.user32
    st = u.GetWindowLongW(hwnd, GWL_EXSTYLE) | WS_EX_LAYERED | WS_EX_TOOLWINDOW
    st = (st | WS_EX_TRANSPARENT) if on else (st & ~WS_EX_TRANSPARENT)
    u.SetWindowLongW(hwnd, GWL_EXSTYLE, st)


def _hotkeys(flags):
    """Ctrl+Shift+O (mostrar/esconder), Ctrl+Shift+M (arrastar) e Ctrl+Shift+J (timer da selva sob o mouse) em todo o Windows."""
    import ctypes
    from ctypes import wintypes
    u = ctypes.windll.user32
    MOD = 0x0002 | 0x0004  # CTRL | SHIFT
    u.RegisterHotKey(None, 1, MOD, ord("O"))
    u.RegisterHotKey(None, 2, MOD, ord("M"))
    u.RegisterHotKey(None, 3, MOD, ord("J"))
    u.RegisterHotKey(None, 4, MOD, ord("A"))
    u.RegisterHotKey(None, 9, MOD, ord("R"))       # repetir o ultimo aviso
    u.RegisterHotKey(None, 10, MOD, ord("S"))      # silenciar a voz por 2 minutos (de novo: volta)

    msg = wintypes.MSG()
    while u.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
        if msg.message == 0x0312:  # WM_HOTKEY
            flags.append(msg.wParam)


def run(port, token):
    import base64
    import tkinter as tk
    url = f"http://127.0.0.1:{port}/api/overlay?t={token}"
    root = tk.Tk()
    root.title("Carry overlay")
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    root.attributes("-alpha", 0.86)
    root.configure(bg=PANEL)
    import tkinter.font as tkfont
    pos = load_cfg()
    pos.setdefault("x", 14)   # canto de cima a esquerda: o HUD do LoL quase nao usa
    pos.setdefault("y", 14)
    ui = dict(DEFAULT_UI)
    ui.update({k: v for k, v in (pos.get("ui") or {}).items() if k in ui})
    sw0, sh0 = root.winfo_screenwidth(), root.winfo_screenheight()
    if ui.get("fx") is not None and ui.get("fy") is not None:
        pos["x"], pos["y"] = round(ui["fx"] * sw0), round(ui["fy"] * sh0)
    look = {"W": 244, "ic": 34, "sm": 20, "ac": ACC, "applied": None, "root_xy": (pos["x"], pos["y"])}
    _load_fonts()
    _fams = set(tkfont.families(root))
    _pick = lambda *fs: next((f for f in fs if f in _fams), "Segoe UI")
    FH = _pick("Barlow Condensed", "Bahnschrift SemiBold Condensed", "Bahnschrift", "Segoe UI Semibold")     # titulos
    FT = _pick("Chakra Petch", "Bahnschrift SemiBold", "Segoe UI Semibold")                                   # numeros e rotulos
    FB = _pick("Barlow", "Segoe UI")                                                                           # texto
    FBS = _pick("Barlow SemiBold", "Segoe UI Semibold")
    look["fonts"] = (FH, FT, FB, FBS)
    F = {"name": tkfont.Font(family=FH, size=11, weight="bold"), "sub": tkfont.Font(family=FB, size=9),
         "toast": tkfont.Font(family=FBS, size=9), "num": tkfont.Font(family=FT, size=8, weight="bold")}
    W = look["W"]
    root.geometry(f"{W}x52+{pos['x']}+{pos['y']}")
    KEY2 = "#010204"     # cor que vira transparente: cantos arredondados de verdade
    try:
        root.attributes("-transparentcolor", KEY2)
        root.configure(bg=KEY2)
    except tk.TclError:
        KEY2 = PANEL
    F["kick"] = tkfont.Font(family=FT, size=7, weight="bold")
    sc = tk.Canvas(root, bg=KEY2, highlightthickness=0, width=W, height=60)
    sc.pack(fill="both", expand=True)
    sc.imgs = []

    def rrect(cv, x1, y1, x2, y2, r, **kw):
        r = max(1, min(r, (x2 - x1) / 2, (y2 - y1) / 2))
        pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
        return cv.create_polygon(pts, smooth=True, **kw)

    def wrap(text, font, width):
        out, line = [], ""
        for w in str(text).split():
            t = (line + " " + w).strip()
            if font.measure(t) <= width or not line:
                line = t
            else:
                out.append(line)
                line = w
        if line:
            out.append(line)
        return out or [""]

    def card(cv, Wd, H, accent, top=GOLD):
        """Bloco reto (cantos de 3 px) com a linha fina em cima, como no app."""
        s_ = ui["scale"] / 100
        bg = rrect(cv, 0, 0, Wd - 1, H - 1, 3, fill=PANEL, outline=ACC if state["drag"] else LINE, width=2 if state["drag"] else 1)
        ln = cv.create_line(0, 1, round(Wd * 0.46), 1, fill=top, width=2)
        cv.tag_lower(ln)
        cv.tag_lower(bg)

    def kick(cv, x, y, text, fill=None, dia=GOLD):
        """Rotulo em caixa alta com o losango na frente. Devolve a altura da linha."""
        s_ = ui["scale"] / 100
        lh = F["kick"].metrics("linespace")
        d = max(3, round(3 * s_))
        cy = y + lh / 2
        cv.create_polygon(x + d, cy - d, x + 2 * d, cy, x + d, cy + d, x, cy, fill=dia, outline="")
        cv.create_text(x + 2 * d + round(5 * s_), y, text=text.upper(), anchor="nw", fill=fill or MUTE, font=F["kick"])
        return lh

    seen, tq = set(), {"cur": None, "until": 0.0, "queue": []}
    import queue as _q
    import urllib.parse as _up

    def fetch_voice(txt):
        """Gera o audio no app (MP3 ou WAV). Roda em paralelo enquanto outra frase toca."""
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/overlay/voz?t={token}&txt={_up.quote(txt)}", timeout=25) as r:
            return r.status, (r.read() if r.status == 200 else b"")

    speak_q = SpeakQueue(fetch_voice)
    vstate = {}

    def _vol(pct):
        """Volume do proprio Carry no mixer do Windows (o jogo nao muda)."""
        if os.name != "nt":
            return
        try:
            import ctypes
            v = int(0xFFFF * max(0, min(100, pct)) / 100)
            ctypes.windll.winmm.waveOutSetVolume(None, v | (v << 16))
        except Exception:
            pass

    def play_mp3(data):
        """Toca MP3 pelo proprio Windows (MCI), esperando acabar. Arquivo temporario apagado depois."""
        if os.name != "nt":
            return
        import ctypes
        import tempfile
        fp = os.path.join(tempfile.gettempdir(), f"carry_voz_{secrets.token_hex(4)}.mp3")
        with open(fp, "wb") as fh:
            fh.write(data)
        alias = "carryvoz" + secrets.token_hex(3)
        buf = ctypes.create_unicode_buffer(256)
        send = ctypes.windll.winmm.mciSendStringW
        try:
            send(f'open "{fp}" type mpegvideo alias {alias}', buf, 255, 0)
            send(f"play {alias} wait", buf, 255, 0)
        finally:
            send(f"close {alias}", buf, 255, 0)
            try:
                os.remove(fp)
            except OSError:
                pass

    def speaker():
        """Fala os avisos em fila, um de cada vez (voz natural gerada pelo app; o Windows toca o WAV)."""
        try:
            import winsound
        except ImportError:
            winsound = None
        if winsound is None:
            log("voz: este sistema nao tem o tocador do Windows (winsound)")
        while True:
            item = speak_q.get()
            if isinstance(item, str):
                item = {"t": item, "made": time.time()}
            txt, made, at, nm, fut = item["t"], item.get("made") or time.time(), item.get("at"), item.get("nm"), item.get("fut")
            if time.time() < state.get("mute_until", 0) and not item.get("force") and not txt.startswith(("Coach", "Teste")):
                log(f"voz: silenciada (Ctrl+Shift+S): {txt[:60]}")
                continue
            waited = 0
            duck = ui.get("luta_vol", 100) < 100 and time.time() < state.get("fight_until", 0)
            _vol(ui.get("luta_vol", 100) if duck else 100)      # luta grande: baixa o volume em vez de calar (ideia 85)
            while (not duck and time.time() < state.get("fight_until", 0) and waited < 6 and item.get("pri", 1) < 3
                   and not item.get("live") and not txt.startswith(("Coach", "Teste"))):   # luta grande: fala depois
                time.sleep(0.5)
                waited += 0.5
            if item.get("live") and item.get("k") not in state.get("cur_keys", set()):
                log(f"voz: pulou (não vale mais): {txt[:60]}")
                continue
            if item.get("k") and state.get("me_dead") and not str(item["k"]).startswith(VOZ_MORTO_OK) and ui.get("voz_essencial", 1):
                log(f"voz: pulou (você está morto): {txt[:60]}")
                continue
            if at is not None:
                # objetivo: recalcula o tempo na hora de falar (a fila pode ter atrasado) e nao fala se ja nasceu
                td = tm.get("data") or {}
                if td.get("t") is not None:
                    left = at - (td["t"] + (time.time() - tm["at"]))
                    if left < 8:
                        log(f"voz: pulou (objetivo já nascendo): {nm}")
                        continue
                    sec = int(round(left / 5.0) * 5) if left > 20 else int(left)     # de 5 em 5: a mesma frase volta do cache
                    txt = f"{nm} {'nascem' if nm.startswith('Larvas') else 'nasce'} em {sec} segundos."
                    fut = None
            elif time.time() - made > item.get("ttl", 20) and not txt.startswith(("Coach", "Teste", "Resumo")):
                log(f"voz: pulou (aviso velho, {int(time.time() - made)}s): {txt[:60]}")
                continue
            try:
                code, wav = fut.result(timeout=25) if fut else fetch_voice(txt)
                if not wav:
                    log(f"voz: o app nao devolveu audio (codigo {code}) para: {txt[:60]}")
                elif wav[:4] != b"RIFF":
                    play_mp3(wav)
                    log(f"voz: falou mp3 ({len(wav) // 1000} KB): {txt[:60]}")
                elif winsound:
                    winsound.PlaySound(wav, winsound.SND_MEMORY | winsound.SND_NODEFAULT)
                    log(f"voz: falou ({len(wav) // 1000} KB): {txt[:60]}")
                if wav:
                    state["last_said"] = txt
            except urllib.error.HTTPError as ex:
                try:
                    why = ex.read().decode("utf-8", "ignore")[:200]
                except Exception:
                    why = ""
                log(f"voz: erro {ex.code} {why}")
            except Exception as ex:
                log(f"voz: falhou ({type(ex).__name__}: {ex})")
    threading.Thread(target=speaker, daemon=True).start()

    bub = {"q": [], "cur": None, "until": 0.0, "t0": 0.0}

    def show_bubble(vt, txt=None):
        """Balão curto na tela (thread-safe: so entra na fila; a janela desenha no proximo tique)."""
        if not ui.get("balao", 1) or not vt:
            return
        try:
            from .mytips import short
            vt = short(vt, 110)
        except Exception:
            pass
        if vt in bub["q"] or vt == bub.get("cur"):
            return
        bub["q"].append(vt)
        del bub["q"][:-2]          # nunca acumula: so os 2 mais novos esperam

    def jg_watch():
        """Beta: avisa quando o icone do cacador inimigo aparece no seu minimapa (le so a regiao do minimapa na tela)."""
        if os.name != "nt":
            return
        from . import mmvision
        sigs, last_seen, last_log = {}, 0.0, 0.0
        js = {}

        def say_alert(k, txt, vt):
            """Aviso do minimapa: balão + voz (passa pelo mesmo filtro de 'só o necessário' e pelos interruptores)."""
            if not alert_on(ui, k):
                return
            if ui.get("voz_essencial", 1) and not voz_essencial(k, vstate, dead=state.get("me_dead")):
                return
            if ui.get("balao", 1):
                show_bubble(vt, txt)
            elif ui.get("toasts"):
                tq["queue"].insert(0, txt)
            speak_q.put({"t": vt if ui.get("voz_essencial", 1) else txt, "made": time.time(), "pri": 3, "bub": False})
        while True:
            time.sleep(1.2)
            try:
                if not state.get("in_game") or state.get("hidden") or not ui.get("a_jgvis", 1):
                    continue
                ens, ver, team = state.get("jgdata") or (None, None, None)
                if not ens or not ver:
                    continue
                for en in ens:
                    if en["id"] and en["id"] not in sigs:
                        try:
                            req = urllib.request.Request(f"{CDN}/{ver}/img/champion/{en['id']}.png", headers={"User-Agent": "lol-coach-overlay"})
                            with urllib.request.urlopen(req, timeout=8) as r:
                                sigs[en["id"]] = mmvision.signature_from_png(r.read())
                        except Exception as ex:
                            sigs[en["id"]] = None
                            log(f"selva: sem ícone de {en['id']} ({type(ex).__name__})")
                jg = next((en for en in ens if en.get("pos") == "JUNGLE"), None)
                if not jg or not sigs.get(jg["id"]):
                    continue
                x, y, w, h = state.get("mmrect") or (0, 0, 0, 0)
                if w < 100:
                    continue
                img = mmvision.capture(x, y, w, h)
                blobs = mmvision.find_enemy_icons(img, w, h)
                found = mmvision.identify(img, w, h, blobs, {k: v for k, v in sigs.items() if v})
                if time.time() - last_log > 60:
                    last_log = time.time()
                    log(f"selva: {len(blobs)} ícones inimigos no minimapa; melhores: " + ", ".join(f"{c} {d1:.0f}/{d2:.0f}" for c, d1, d2, _, _ in found[:5]))
                hit = next((f for f in found if f[0] == jg["id"] and f[1] < 70 and f[2] - f[1] > 12), None)
                now_ = time.time()
                td = tm.get("data") or {}
                gt_ = (td.get("t") or 0) + (now_ - tm.get("at", now_)) if td else 0
                if gt_ and gt_ + 5 < js.get("gt", 0):                  # partida nova
                    js.clear()
                js["gt"] = gt_
                if hit:
                    js["ever"] = True
                    where_ = mmvision.where(hit[3], hit[4], team)
                    sd = mmvision.side(hit[3], hit[4])
                    if now_ - last_seen > 20:
                        near = jg_near(state.get("mypos"), hit[3], hit[4], where_)
                        txt = f"Cuidado: jungler inimigo visível, {jg['name']} {where_}."
                        log("selva: " + txt + (" (perto da sua rota)" if near else " (longe: sem voz)"))
                        # so fala quando ele aparece perto da sua rota, na fase de rotas (depois dos 14 min a sua posicao muda)
                        if near and gt_ < 840 and now_ - js.get("said", 0) >= 30:
                            js["said"] = now_
                            esc_ = ""
                            try:
                                from . import escapes
                                e_ = escapes.escape_of(state.get("me_cid"), os.path.dirname(CFG_PATH))
                                esc_ = f" Guarde o {e_[0]}." if e_ else ""
                            except Exception:
                                pass
                            say_alert("jgvis_", txt + esc_, f"Cuidado, jungler deles perto: {where_}.{esc_}")
                    # janela de objetivo: caçador deles do lado oposto
                    if td and now_ - js.get("win", 0) >= 90:
                        drag_at, baron_at = td.get("dragon"), td.get("baron")
                        if drag_at and drag_at - gt_ <= 45 and sd == "cima":
                            js["win"] = now_
                            say_alert("jgwin_", f"Jungler deles ({jg['name']}) no lado de cima: bom momento para o Dragão.",
                                      "Jungler deles em cima: bom momento pro Dragão.")
                        elif baron_at and gt_ >= 1200 and baron_at - gt_ <= 30 and sd == "baixo":
                            js["win"] = now_
                            say_alert("jgwin_", f"Jungler deles ({jg['name']}) no lado de baixo: bom momento para o Barão, se o time estiver perto.",
                                      "Jungler deles embaixo: bom momento pro Barão.")
                    last_seen = now_
                elif (ui.get("a_mmlook", 1) and js.get("ever") and 150 <= gt_ < 840 and now_ - last_seen >= 50
                      and now_ - js.get("look", 0) >= 100 and js.get("nlook", 0) < 6 and not state.get("me_dead")):
                    js["look"] = now_
                    js["nlook"] = js.get("nlook", 0) + 1
                    gone = int(now_ - last_seen)
                    vt = ["Jungler deles sumido: olhe o minimapa e coloque sentinela no rio.", "Jungler sumido. Olhe o mapa antes de avançar.",
                          "Faz tempo que o jungler sumiu: sentinela no rio e jogue seguro."][js["nlook"] % 3]
                    say_alert("mmlook_", f"Olhe o minimapa: o jungler deles ({jg['name']}) sumiu há {gone} segundos.", vt)
            except Exception as ex:
                log(f"selva: erro {type(ex).__name__}: {ex}")
                time.sleep(5)
    threading.Thread(target=jg_watch, daemon=True).start()
    flags, state = [], {"hidden": False, "drag": False, "fails": 0, "in_game": False}
    raw, imgs = {}, {}

    def fetch(ver, iid):
        key = (ver, iid)
        if key in raw:
            return
        raw[key] = None
        def go():
            try:
                url = f"{CDN}/{ver}/img/{iid}" if isinstance(iid, str) else f"{CDN}/{ver}/img/item/{int(iid)}.png"
                req = urllib.request.Request(url, headers={"User-Agent": "lol-coach-overlay"})
                with urllib.request.urlopen(req, timeout=6) as r:
                    raw[key] = r.read()
            except Exception:
                raw[key] = b""
        threading.Thread(target=go, daemon=True).start()

    def photo(ver, iid, size):
        k = (ver, iid, size)
        if k in imgs:
            return imgs[k]
        b = raw.get((ver, iid))
        if not b:
            fetch(ver, iid)
            return None
        try:
            im = tk.PhotoImage(data=base64.b64encode(b))
            r = size / max(1, im.width())
            a, bb = min(((x, y) for x in range(1, 7) for y in range(1, 13)), key=lambda t: abs(t[0] / t[1] - r))
            if a > 1:
                im = im.zoom(a, a)
            if bb > 1:
                im = im.subsample(bb, bb)
        except Exception:
            im = None
        imgs[k] = im
        return im

    def apply_ui(new):
        """Aplica tamanho, transparencia, cor e posicao escolhidos na pagina do app."""
        ui.update({k: v for k, v in (new or {}).items() if k in ui})
        sig = (ui["scale"], ui["opacity"], ui["accent"], ui.get("ac"))
        if sig != look["applied"]:
            look["applied"] = sig
            s_ = ui["scale"] / 100
            look.update(W=round(244 * s_), ic=round(34 * s_), sm=round(20 * s_))
            F["name"].configure(size=max(8, round(11 * s_)))
            F["sub"].configure(size=max(6, round(9 * s_)))
            F["toast"].configure(size=max(7, round(9 * s_)))
            F["kick"].configure(size=max(6, round(7 * s_)))
            F["num"].configure(size=max(6, round(8 * s_)))
            root.attributes("-alpha", max(0.4, min(1.0, ui["opacity"] / 100)))
            try:
                PB.attributes("-alpha", max(0.4, min(1.0, ui["opacity"] / 100)))
                F["phead"].configure(size=max(8, round(12 * s_)))
            except NameError:
                pass
            look["ac"] = {"gold": "#c8aa6e", "green": OKC, "blue": "#8DA2C0"}.get(ui["accent"]) or ui.get("ac") or ACC
        mk = (ui.get("mm_side"), ui.get("mm_size"))
        if mk != look.get("mm_key") and not state["drag"]:
            first = look.get("mm_key") is None
            look["mm_key"] = mk
            if not (first and pos.get("mm") and pos.get("mm_from") == list(mk)):
                sw_, sh_ = root.winfo_screenwidth(), root.winfo_screenheight()
                size = round(sh_ * (ui.get("mm_size") or 26) / 100)
                x = 4 if ui.get("mm_side") == "left" else sw_ - size - 4
                mcfg.update(size=size, x=x, y=sh_ - size - 4)
                mm.geometry(f"{size}x{size}+{mcfg['x']}+{mcfg['y']}")
                cv.config(width=size, height=size)
                try:
                    save_cfg(mm=mcfg, mm_from=list(mk))
                except OSError:
                    pass
        p2 = (ui.get("fx2") if ui.get("fx2") is not None else 0.86, ui.get("fy2") if ui.get("fy2") is not None else 0.46)
        if not state["drag"] and p2 != look.get("pos2"):
            look["pos2"] = p2
            look["pb_xy"] = (round(p2[0] * root.winfo_screenwidth()), round(p2[1] * root.winfo_screenheight()))
            PB.geometry(f"+{look['pb_xy'][0]}+{look['pb_xy'][1]}")
        fx, fy = ui.get("fx"), ui.get("fy")
        if fx is not None and fy is not None and not state["drag"] and (fx, fy) != look.get("pos"):
            look["pos"] = (fx, fy)
            look["root_xy"] = (round(fx * root.winfo_screenwidth()), round(fy * root.winfo_screenheight()))
            root.geometry(f"+{look['root_xy'][0]}+{look['root_xy'][1]}")

    hwnd = None
    if os.name == "nt":
        root.update_idletasks()
        import ctypes
        hwnd = ctypes.windll.user32.GetParent(root.winfo_id())
        _click_through(hwnd, True)
        threading.Thread(target=_hotkeys, args=(flags,), daemon=True).start()

    # ---- tempos no minimapa: janela transparente do tamanho do minimapa ----
    KEY = "#010203"
    mm = tk.Toplevel(root)
    mm.overrideredirect(True)
    mm.attributes("-topmost", True)
    try:
        mm.attributes("-transparentcolor", KEY)
    except tk.TclError:
        pass
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    mcfg = pos.get("mm") or {"size": round(sh * 0.26), "x": sw - round(sh * 0.26) - 4, "y": sh - round(sh * 0.26) - 4}
    mm.geometry(f"{mcfg['size']}x{mcfg['size']}+{mcfg['x']}+{mcfg['y']}")
    cv = tk.Canvas(mm, bg=KEY, highlightthickness=0, width=mcfg["size"], height=mcfg["size"])
    cv.pack(fill="both", expand=True)
    SPOTS = {"dragon": (0.665, 0.705), "baron": (0.335, 0.295)}   # posicao dos fossos no minimapa (0 a 1)
    # acampamentos (lado azul embaixo a esquerda; o vermelho e o espelho). Tempo de volta padrao em segundos.
    CAMPS = {"azul": ((0.25, 0.46), 300), "gromp": ((0.15, 0.43), 135), "lobos": ((0.26, 0.56), 135), "aves": ((0.47, 0.63), 135),
             "vermelho": ((0.52, 0.74), 300), "krugs": ((0.57, 0.83), 135)}
    CAMP_POS = {}
    for k, ((cx, cy), dur) in CAMPS.items():
        CAMP_POS["b_" + k] = ((cx, cy), dur)
        CAMP_POS["r_" + k] = ((1 - cx, 1 - cy), dur)
    CAMP_POS["arauto_caranguejo_t"] = ((0.29, 0.36), 150)
    CAMP_POS["arauto_caranguejo_b"] = ((0.71, 0.64), 150)
    jt = {}   # acampamento -> hora local em que volta
    tm = {"data": None, "at": 0.0}
    mm_hwnd = None
    if os.name == "nt":
        mm.update_idletasks()
        import ctypes
        mm_hwnd = ctypes.windll.user32.GetParent(mm.winfo_id())
        _click_through(mm_hwnd, True)
    mm.withdraw()

    # ---- segundo overlay: painel da partida (placar util) ----
    PB = tk.Toplevel(root)
    PB.overrideredirect(True)
    PB.attributes("-topmost", True)
    try:
        PB.attributes("-transparentcolor", KEY2)
        PB.configure(bg=KEY2)
    except tk.TclError:
        PB.configure(bg=PANEL)
    pc = tk.Canvas(PB, bg=KEY2, highlightthickness=0, width=236, height=80)
    pc.pack(fill="both", expand=True)
    F["phead"] = tkfont.Font(family=FH, size=12, weight="bold")
    PK = ("cs", "lane", "gold", "cd", "team", "tm", "obj", "drg")
    PLAB = {"cs": "FARM", "lane": "ROTA", "gold": "ITENS", "cd": "RECARGAS", "team": "TIMES", "tm": "TIMERS", "obj": "OBJETIVOS", "drg": "PLACAR"}
    plabels = {"head": None}
    pb_hwnd = None
    if os.name == "nt":
        PB.update_idletasks()
        import ctypes
        pb_hwnd = ctypes.windll.user32.GetParent(PB.winfo_id())
        _click_through(pb_hwnd, True)
    PB.withdraw()

    # ---- terceiro overlay: barra dos inimigos (Flash, outro feitico e ult). Segure Tab para clicar e marcar ----
    EB = tk.Toplevel(root)
    EB.overrideredirect(True)
    EB.attributes("-topmost", True)
    try:
        EB.attributes("-transparentcolor", KEY2)
        EB.configure(bg=KEY2)
    except tk.TclError:
        EB.configure(bg=PANEL)
    ec = tk.Canvas(EB, bg=KEY2, highlightthickness=0, width=120, height=150)
    ec.pack(fill="both", expand=True)
    eb_hwnd = None
    if os.name == "nt":
        EB.update_idletasks()
        import ctypes
        eb_hwnd = ctypes.windll.user32.GetParent(EB.winfo_id())
        _click_through(eb_hwnd, True)
        try:       # clicar na barra nao tira o foco do jogo
            u32 = ctypes.windll.user32
            u32.SetWindowLongW(eb_hwnd, -20, u32.GetWindowLongW(eb_hwnd, -20) | 0x08000000)
        except Exception:
            pass
    EB.withdraw()
    ebs = {"data": None, "at": 0.0, "hits": [], "geo": None}

    def render_ebar():
        rows = ebs["data"]
        if not rows or not ui.get("ebar", 1):
            return False
        s_ = ui["scale"] / 100
        R = round(26 * s_)
        gap = round(3 * s_)
        pad = round(5 * s_)
        ver = ebs.get("ver")
        tab = state.get("tabmode")
        head = round(16 * s_) if tab else 0
        Wd = pad * 2 + R * 4 + gap * 3
        H = pad * 2 + head + len(rows) * R + (len(rows) - 1) * gap
        ec.delete("all")
        rrect(ec, 0, 0, Wd, H, round(8 * s_), fill=PANEL, outline=(look["ac"] if tab or state["drag"] else LINE), width=2 if tab else 1)
        if tab:
            ec.create_text(Wd / 2, pad + head / 2 - 1, text="clique para marcar", fill=INK, font=F["kick"])
        el = time.time() - ebs["at"]
        hits = []
        y = pad + head
        for r in rows:
            x = pad
            im = photo(ver, f"champion/{r['champ']}.png", R) if ver and r.get("champ") else None
            if im:
                ec.create_image(x, y, image=im, anchor="nw")
            else:
                ec.create_rectangle(x, y, x + R, y + R, fill="#2A1F1E", outline="")
                ec.create_text(x + R / 2, y + R / 2, text=(r["name"] or "?")[:2], fill=INK, font=F["kick"])
            if r.get("dead"):
                ec.create_rectangle(x, y, x + R, y + R, fill="#000000", stipple="gray50", outline="")
            ec.create_text(x + R - 1, y + R - 1, text=str(r["lvl"]), anchor="se", fill="#E9C46A", font=F["kick"])
            x += R + gap
            for c in r["cells"]:
                left = c.get("left")
                if left is not None:
                    left = left - el
                ic = photo(ver, f"spell/{c['icon']}.png", R) if ver and c.get("icon") else None
                if ic:
                    ec.create_image(x, y, image=ic, anchor="nw")
                else:
                    ec.create_rectangle(x, y, x + R, y + R, fill="#2A1F1E", outline="#3a2d2b")
                    ec.create_text(x + R / 2, y + R / 2, text="R" if c["t"] == "r" else (c["label"] or "?")[:2], fill=INK, font=F["name"])
                if c["t"] == "r" and not c.get("has"):
                    ec.create_rectangle(x, y, x + R, y + R, fill="#000000", stipple="gray50", outline="")
                if left is not None and left > 0:
                    ec.create_rectangle(x, y, x + R, y + R, fill="#000000", stipple="gray75", outline="")
                    t_ = f"{int(left) // 60}:{int(left) % 60:02d}" if left >= 60 else f"{int(left)}"
                    ec.create_text(x + R / 2, y + R / 2, text=t_, fill="#FFFFFF", font=F["name"])
                elif left is not None:
                    ec.create_rectangle(x + 1, y + 1, x + R - 1, y + R - 1, outline=OKC, width=2)
                hits.append((x, y, x + R, y + R, r["slot"], c, left))
                x += R + gap
            y += R + gap
        ebs["hits"] = hits
        ec.config(width=Wd, height=H)
        EB.update_idletasks()
        p3 = (ui.get("fx3") if ui.get("fx3") is not None else 0.93, ui.get("fy3") if ui.get("fy3") is not None else 0.36)
        if look.get("eb_from") != p3 and not state["drag"]:
            look["eb_from"] = p3
            look["eb_xy"] = (round(p3[0] * root.winfo_screenwidth()), round(p3[1] * root.winfo_screenheight()))
        ex, ey = look.get("eb_xy") or (EB.winfo_x(), EB.winfo_y())
        EB.geometry(f"{Wd}x{H}+{ex}+{ey}")
        return True


    EB_DEMO = [{"slot": i + 1, "name": n, "champ": n, "lvl": 6, "dead": False,
                "cells": [{"t": "s", "key": "flash", "label": "Flash", "icon": "SummonerFlash", "left": None},
                          {"t": "s", "key": "ignite", "label": "Incendiar", "icon": "SummonerDot", "left": None},
                          {"t": "r", "key": "r", "label": "Ult", "icon": None, "has": True, "left": None}]}
               for i, n in enumerate(["Garen", "LeeSin", "Ahri", "Jinx", "Thresh"])]

    def eb_show(on):
        if on:
            EB.deiconify()
            EB.attributes("-topmost", True)
        else:
            EB.withdraw()

    def eb_tick():
        if state.get("in_game") and not state.get("hidden") and ebs["data"] and ui.get("ebar", 1):
            render_ebar()
        root.after(1000, eb_tick)

    def eb_click(ev, clear=False):
        if state["drag"]:
            return
        for x0, y0, x1, y1, slot, c, left in ebs["hits"]:
            if x0 <= ev.x <= x1 and y0 <= ev.y <= y1:
                kind = "r" if c["t"] == "r" else "f"
                ck = (slot, kind, c.get("key"))
                if time.time() - ebs.setdefault("last_click", {}).get(ck, 0) < 1.5:
                    return                      # clique repetido (ou duplo): nao recomeca a contagem
                ebs["last_click"][ck] = time.time()
                if not clear and left is not None and left > 0:
                    return                      # ja esta contando: so o botao direito desmarca
                undo = clear
                spell_mark(slot, kind, c.get("key") if kind == "f" else None, undo)
                if undo:
                    c["left"] = None
                render_ebar()
                return

    def eb_start(ev):
        state["edx"], state["edy"] = ev.x_root - EB.winfo_x(), ev.y_root - EB.winfo_y()

    def eb_move(ev):
        if state["drag"]:
            look["eb_xy"] = (ev.x_root - state["edx"], ev.y_root - state["edy"])
            EB.geometry(f"+{look['eb_xy'][0]}+{look['eb_xy'][1]}")
    ec.bind("<Button-1>", lambda ev: (eb_start(ev), eb_click(ev)))
    ec.bind("<B1-Motion>", eb_move)
    ec.bind("<Button-3>", lambda ev: eb_click(ev, clear=True))

    # ---- quarto overlay: balão de aviso (a mesma frase da voz, curta; some sozinho; o clique atravessa) ----
    BB = tk.Toplevel(root)
    BB.overrideredirect(True)
    BB.attributes("-topmost", True)
    try:
        BB.attributes("-transparentcolor", KEY2)
        BB.configure(bg=KEY2)
    except tk.TclError:
        BB.configure(bg=PANEL)
    bc = tk.Canvas(BB, bg=KEY2, highlightthickness=0, width=200, height=50)
    bc.pack(fill="both", expand=True)
    F["bub"] = tkfont.Font(family=FBS, size=10)
    bb_hwnd = None
    if os.name == "nt":
        BB.update_idletasks()
        import ctypes
        bb_hwnd = ctypes.windll.user32.GetParent(BB.winfo_id())
        _click_through(bb_hwnd, True)
        try:
            u32 = ctypes.windll.user32
            u32.SetWindowLongW(bb_hwnd, -20, u32.GetWindowLongW(bb_hwnd, -20) | 0x08000000)
        except Exception:
            pass
    BB.withdraw()
    BB_DEMO = "Cuidado, jungler inimigo visível: arraste o balão para onde quiser."

    def render_bubble(text):
        s_ = ui["scale"] / 100 * ui.get("bub_size", 100) / 100          # tamanho do balao e da fonte separados (ideia 89)
        F["bub"].configure(size=max(8, round(10 * ui["scale"] / 100 * ui.get("bub_font", 100) / 100)))
        pad, R = round(10 * s_), round(26 * s_)
        maxw = round(300 * s_)
        lines = wrap(text, F["bub"], maxw)[:3]
        lh = F["bub"].metrics("linespace")
        tw = max(F["bub"].measure(ln) for ln in lines)
        bw = pad + R + round(8 * s_) + tw + pad + round(4 * s_)
        bh = max(R + pad, lh * len(lines) + pad * 2 - round(4 * s_))
        bc.delete("all")
        rrect(bc, 0, 0, bw, bh, 3, fill=PANEL, outline="#5A2330" if not state["drag"] else GOLD, width=1)
        bc.create_line(0, 1, round(bw * 0.46), 1, fill=ACC, width=2)
        cx, cy = pad + R / 2, bh / 2
        bc.create_polygon(cx, cy - R / 2, cx + R / 2, cy, cx, cy + R / 2, cx - R / 2, cy, fill=ACC, outline="")
        bc.create_text(cx, cy, text="C", fill="#FFFFFF", font=F["name"])
        ty = (bh - lh * len(lines)) / 2
        for i, ln in enumerate(lines):
            bc.create_text(pad + R + round(8 * s_), ty + i * lh, text=ln, anchor="nw", fill="#FFFFFF", font=F["bub"])
        bc.config(width=bw + 1, height=bh + 1)
        p4 = (ui.get("fx4") if ui.get("fx4") is not None else 0.74, ui.get("fy4") if ui.get("fy4") is not None else 0.62)
        if look.get("bb_from") != p4 and not state["drag"]:
            look["bb_from"] = p4
            look["bb_xy"] = (round(p4[0] * root.winfo_screenwidth()), round(p4[1] * root.winfo_screenheight()))
        bx, by = look.get("bb_xy") or (0, 0)
        BB.geometry(f"{bw + 1}x{bh + 1}+{bx}+{by}")

    def bb_alpha(a):
        try:
            BB.attributes("-alpha", max(0.0, min(1.0, a)) * ui["opacity"] / 100)
        except tk.TclError:
            pass

    def bb_tick():
        now_ = time.time()
        try:
            if state["drag"] and ui.get("balao", 1):
                if bub.get("cur") != BB_DEMO:
                    bub.update(cur=BB_DEMO, until=now_ + 3600, t0=now_)
                    render_bubble(BB_DEMO)
                    BB.deiconify()
                    BB.attributes("-topmost", True)
                bb_alpha(1)
            elif bub.get("cur") == BB_DEMO:
                bub.update(cur=None, until=0)
                BB.withdraw()
            elif not state.get("in_game") or state.get("hidden") or not ui.get("balao", 1):
                if bub.get("cur"):
                    bub.update(cur=None, until=0)
                    BB.withdraw()
                bub["q"].clear()
            elif bub.get("cur") and now_ >= bub["until"]:
                bub["cur"] = None
                BB.withdraw()
            elif bub.get("cur"):
                left = bub["until"] - now_
                el = now_ - bub["t0"]
                bb_alpha(min(1.0, el / 0.15, left / 0.45))
            elif bub["q"]:
                t_ = bub["q"].pop(0)
                dur = max(3.5, min(6.0, len(t_) / 14))
                bub.update(cur=t_, until=now_ + dur, t0=now_)
                render_bubble(t_)
                bb_alpha(0)
                BB.deiconify()
                BB.attributes("-topmost", True)
        except Exception as ex:
            log(f"balão: {type(ex).__name__}: {ex}")
        root.after(60 if bub.get("cur") else 200, bb_tick)

    def bb_start(ev):
        state["bdx"], state["bdy"] = ev.x_root - BB.winfo_x(), ev.y_root - BB.winfo_y()

    def bb_move(ev):
        if state["drag"]:
            look["bb_xy"] = (ev.x_root - state["bdx"], ev.y_root - state["bdy"])
            BB.geometry(f"+{look['bb_xy'][0]}+{look['bb_xy'][1]}")
    bc.bind("<Button-1>", bb_start)
    bc.bind("<B1-Motion>", bb_move)

    def render_panel(p):
        if not ui.get("panel") or not p:
            return False
        s_ = ui["scale"] / 100
        Wd, pad = round(250 * s_), round(10 * s_)
        col = lambda v: OKC if v and v > 0 else BAD if v and v < 0 else INK
        pc.delete("all")
        y = pad + round(3 * s_)
        head = p.get("head") or "Partida"
        plabels["head"] = head
        pc.create_text(pad, y, text=head.upper(), anchor="nw", fill=INK, font=F["phead"])
        y += F["phead"].metrics("linespace") + round(5 * s_)
        pc.create_line(pad, y, Wd - pad, y, fill=LINE)
        y += round(6 * s_)
        lh = F["sub"].metrics("linespace")
        kw = F["kick"].measure("OBJETIVOS") + round(8 * s_)
        pp = p.get("plan") if ui.get("p_plan", 1) else None
        if pp and pp.get("tips"):
            y += kick(pc, pad, y, pp["phase"]) + round(3 * s_)
            for tip_ in pp["tips"]:
                d_ = max(2, round(2.5 * s_))
                pc.create_polygon(pad + d_, y + lh / 2 - d_, pad + 2 * d_, y + lh / 2, pad + d_, y + lh / 2 + d_, pad, y + lh / 2, fill=look["ac"], outline="")
                tl = wrap(tip_, F["sub"], Wd - pad * 2 - round(12 * s_))
                for i, ln in enumerate(tl):
                    pc.create_text(pad + round(12 * s_), y + i * lh, text=ln, anchor="nw", fill=INK, font=F["sub"])
                y += lh * len(tl) + round(5 * s_)
            pc.create_line(pad, y, Wd - pad, y, fill=LINE)
            y += round(6 * s_)
        for k in PK:
            txt = p.get(k)
            opt = {"cs": "p_cs", "lane": "p_lane", "gold": "p_gold", "team": "p_team", "obj": "p_obj", "cd": "p_cd", "tm": "p_tm", "drg": "p_obj"}[k]
            if not txt or not ui.get(opt, 1):
                continue
            v = {"cs": 1 if p.get("cs_ok") else (-1 if p.get("cs_ok") is False else 0), "lane": p.get("lane_k"),
                 "gold": p.get("gold_k"), "team": p.get("team_k")}.get(k)
            fg = GOLD if k in ("obj", "tm") else (INK if k in ("cd", "drg") else col(v))
            pc.create_text(pad, y + 1, text=PLAB[k], anchor="nw", fill=MUTE, font=F["kick"])
            lines = wrap(txt, F["sub"], Wd - pad * 2 - kw)
            for i, ln in enumerate(lines):
                pc.create_text(pad + kw, y + i * lh, text=ln, anchor="nw", fill=fg, font=F["sub"])
            y += lh * len(lines) + round(4 * s_)
        H = y + pad - round(2 * s_)
        card(pc, Wd, H, look["ac"])
        pc.config(width=Wd, height=H)
        PB.update_idletasks()
        px, py = look.get("pb_xy") or (PB.winfo_x(), PB.winfo_y())     # escondido, o winfo_x volta 0 e jogava o painel no canto
        PB.geometry(f"{Wd}x{H}+{px}+{py}")
        return True

    def pb_show(on):
        if on:
            PB.deiconify()
            PB.attributes("-topmost", True)
        else:
            PB.withdraw()

    def draw_mm():
        cv.delete("all")
        size = mcfg["size"]
        if state["drag"]:
            cv.create_rectangle(1, 1, size - 2, size - 2, outline=ACC, width=2)
            cv.create_text(size / 2, size / 2, text="Alinhe com o minimapa\nRoda do mouse: tamanho", fill=INK, font=("Segoe UI Semibold", 9), justify="center")
        d = tm["data"]
        if d and state["in_game"] and not state["hidden"]:
            now = d["t"] + (time.time() - tm["at"])
            fs = max(9, round(size / 24 * ui["mm_text"] / 100))
            for k, (rx, ry) in (SPOTS.items() if ui["mm_obj"] else ()):
                left = d.get(k, 0) - now
                killed = d.get("dk" if k == "dragon" else "bk")
                if left <= 0 or (not killed and left > 180):   # 1o nascimento: so nos 3 minutos finais
                    continue
                txt = f"{int(left) // 60}:{int(left) % 60:02d}"
                x, y = rx * size, ry * size
                for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1), (1, 1)):
                    cv.create_text(x + dx, y + dy, text=txt, fill="#000000", font=("Segoe UI Black", fs))
                cv.create_text(x, y, text=txt, fill="#E9C46A" if left <= 30 else INK, font=("Segoe UI Black", fs))
        if d and state["in_game"] and not state["hidden"]:
            # nascimentos fixos do comeco da partida (temporada 2026, ver gametimes.py): acampamentos 0:55
            # (Gromp e Krugs 1:07), caranguejos 2:55, larvas do Vazio 8:00 e Arauto 15:00 no fosso de cima
            now = d["t"] + (time.time() - tm["at"])
            size = mcfg["size"]
            fs = max(8, round(size / 30 * ui["mm_text"] / 100))
            fsb = max(9, round(size / 24 * ui["mm_text"] / 100))

            def put(x, y, left, big=False, color=None):
                txt = f"{int(left) // 60}:{int(left) % 60:02d}"
                f = ("Segoe UI Black", fsb) if big else ("Segoe UI Semibold", fs)
                for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    cv.create_text(x + dx, y + dy, text=txt, fill="#000000", font=f)
                cv.create_text(x, y, text=txt, fill=color or ("#E9C46A" if left <= 30 else INK), font=f)
            from . import gametimes as GT
            if ui["mm_camps"]:
                for k, ((rx, ry), _) in CAMP_POS.items():
                    first = GT.CAMP_FIRST.get(k[2:])
                    if first and now < first and not k.startswith("arauto") and k not in jt:
                        put(rx * size, ry * size, first - now, color="#DDD3C7")
            if now < GT.SCUTTLE_FIRST and ui["mm_camps"]:
                for k in ("arauto_caranguejo_t", "arauto_caranguejo_b"):
                    if k not in jt:
                        (rx, ry), _ = CAMP_POS[k]
                        put(rx * size, ry * size, GT.SCUTTLE_FIRST - now, color="#DDD3C7")
            bx, by = SPOTS["baron"]
            for at in (GT.GRUBS_AT, GT.HERALD_AT):
                if at - 180 <= now < at and ui["mm_obj"]:
                    put(bx * size, by * size, at - now, big=True)
        if state["in_game"] and not state["hidden"] and ui["mm_jungle"]:
            size = mcfg["size"]
            fs = max(8, round(size / 30 * ui["mm_text"] / 100))
            for k, end in list(jt.items()):
                left = end - time.time()
                if left <= -3:
                    jt.pop(k, None)
                    continue
                (rx, ry), _ = CAMP_POS[k]
                txt = "já" if left <= 0 else f"{int(left) // 60}:{int(left) % 60:02d}"
                x, y = rx * size, ry * size
                for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    cv.create_text(x + dx, y + dy, text=txt, fill="#000000", font=("Segoe UI Semibold", fs))
                cv.create_text(x, y, text=txt, fill=OKC if left <= 15 else "#DDD3C7", font=("Segoe UI Semibold", fs))
        mm.after(500, draw_mm)

    def spell_mark(slot, kind, spell=None, clear=False):
        """Marca (ou desmarca) o Flash, o outro feitico ou a ult do inimigo; o app conta e avisa quando volta."""
        def go():
            try:
                extra = (f"&s={spell}" if spell else "") + ("&clear=1" if clear else "")
                with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/overlay/marcar?t={token}&slot={slot}&k={kind}{extra}", timeout=6) as r:
                    res = json.loads(r.read().decode("utf-8"))
            except Exception as ex:
                res = {"t": None}
                log(f"marcar: falhou ({type(ex).__name__})")
            if res.get("t"):
                tq["queue"].insert(0, res["t"])
                tq["cur"] = None
                log("marcar: " + res["t"])
                if res.get("v"):
                    speak_q.put({"t": res["v"], "made": time.time(), "k": "spellmark"})
        threading.Thread(target=go, daemon=True).start()

    def jungle_mark():
        """Ctrl+Shift+J: comeca (ou cancela) o timer do acampamento mais perto do mouse no minimapa."""
        if not ui["mm_jungle"]:
            return
        px, py = root.winfo_pointerxy()
        size = mcfg["size"]
        x0, y0 = mm.winfo_x(), mm.winfo_y()
        if not (x0 <= px <= x0 + size and y0 <= py <= y0 + size):
            return
        rx, ry = (px - x0) / size, (py - y0) / size
        best = min(CAMP_POS.items(), key=lambda kv: (kv[1][0][0] - rx) ** 2 + (kv[1][0][1] - ry) ** 2)
        (bx, by), dur = best[1]
        if (bx - rx) ** 2 + (by - ry) ** 2 > 0.09 ** 2:
            return
        if best[0] in jt:
            jt.pop(best[0])
        else:
            jt[best[0]] = time.time() + dur

    def mm_show(on):
        if on:
            mm.deiconify()
            mm.attributes("-topmost", True)
        else:
            mm.withdraw()

    def mm_wheel(ev):
        if not state["drag"]:
            return
        step = 8 if (getattr(ev, "delta", 0) > 0 or getattr(ev, "num", 0) == 4) else -8
        mcfg["size"] = max(120, min(700, mcfg["size"] + step))
        mm.geometry(f"{mcfg['size']}x{mcfg['size']}+{mm.winfo_x()}+{mm.winfo_y()}")
        cv.config(width=mcfg["size"], height=mcfg["size"])

    def mm_start(ev):
        state["mdx"], state["mdy"] = ev.x_root - mm.winfo_x(), ev.y_root - mm.winfo_y()

    def mm_move(ev):
        if state["drag"]:
            mm.geometry(f"+{ev.x_root - state['mdx']}+{ev.y_root - state['mdy']}")
    cv.bind("<Button-1>", mm_start)
    cv.bind("<B1-Motion>", mm_move)
    cv.bind("<MouseWheel>", mm_wheel)
    cv.bind("<Button-4>", mm_wheel)
    cv.bind("<Button-5>", mm_wheel)
    mm.after(500, draw_mm)

    def render(d):
        ver = d.get("ver")
        n = d.get("next")
        s_ = ui["scale"] / 100
        W, IC, SM, AC = look["W"], look["ic"], look["sm"], look["ac"]
        pad = round(10 * s_)
        sc.delete("all")
        sc.imgs = []
        y = pad + round(3 * s_)
        pl = d.get("plan") if ui.get("plan", 1) else None
        if pl and pl.get("title"):
            cx = pad
            ch = round(9 * s_)
            for k in (0, 1):      # dois chevrons na cor de destaque
                yy = y + round(2 * s_) + k * round(5 * s_)
                sc.create_line(cx, yy + ch // 2, cx + ch // 2, yy, cx + ch, yy + ch // 2, fill=AC, width=max(2, round(2 * s_)))
            tx = pad + ch + round(8 * s_)
            lines = wrap(pl["title"], F["name"], W - pad - tx)
            lh = F["name"].metrics("linespace")
            for i, ln in enumerate(lines[:3]):
                sc.create_text(tx, y + i * lh, text=ln, anchor="nw", fill=INK, font=F["name"])
            y += max(lh * min(len(lines), 3), ch + round(6 * s_)) + round(7 * s_)
            sc.create_line(pad, y, W - pad, y, fill=LINE)
            y += round(7 * s_)
        show_top = ui["item"] or ui["after"] or bool(pl)
        if ui["item"] or ui["after"]:
            x0 = pad
            if ui["item"]:
                im = photo(ver, n["id"], IC) if (ver and n) else None
                if im:
                    sc.create_image(pad, y, image=im, anchor="nw")
                    sc.imgs.append(im)
                else:
                    sc.create_rectangle(pad, y, pad + IC, y + IC, fill=CELL, outline="")
                sc.create_rectangle(pad, y, pad + IC, y + IC, outline="#785A28")
                x0 = pad + IC + round(9 * s_)
            right = W - pad
            if ui["after"] and n:
                for iid in reversed((d.get("after") or [])[:2]):
                    s_im = photo(ver, iid, SM) if ver else None
                    right -= SM
                    if s_im:
                        sc.create_image(right, y, image=s_im, anchor="nw")
                        sc.imgs.append(s_im)
                    else:
                        sc.create_rectangle(right, y, right + SM, y + SM, fill=CELL, outline=LINE)
                    right -= round(4 * s_)
            if ui["item"]:
                kick(sc, x0, y, "Próximo item" if n else "Em partida")
                nm = (n["name"] if n else (d.get("champion") or "Em partida"))
                maxw = right - x0 - 4
                while F["name"].measure(nm) > maxw and len(nm) > 4:
                    nm = nm[:-2].rstrip() + "…" if not nm.endswith("…") else nm[:-2] + "…"
                ty = y + F["kick"].metrics("linespace")
                sc.create_text(x0, ty, text=nm, anchor="nw", fill=INK, font=F["name"])
                ty += F["name"].metrics("linespace") + round(3 * s_)
                if n and ui["gold"]:
                    ready = n["gold"] >= n["cost"]
                    bw = W - pad - x0
                    bh = max(3, round(4 * s_))
                    sc.create_rectangle(x0, ty, x0 + bw, ty + bh, fill="#242535", outline="")
                    if n["pct"] > 0:
                        sc.create_rectangle(x0, ty, x0 + max(bh, int(bw * n["pct"] / 100)), ty + bh, fill=OKC if ready else AC, outline="")
                    ty += bh + round(3 * s_)
                    comp = n.get("comp")
                    sub_t = ("pode comprar" if ready else (f"faltam {comp['need']} para {comp['name']}" if comp else f"faltam {n['cost'] - n['gold']} de ouro"))
                    while F["sub"].measure(sub_t) > W - pad - x0 and len(sub_t) > 8:
                        sub_t = sub_t[:-2].rstrip("…") + "…"
                    sc.create_text(x0, ty, text=sub_t, anchor="nw", fill=OKC if ready else MUTE, font=F["sub"])
                    ty += F["sub"].metrics("linespace")
                elif not n:
                    sc.create_text(x0, ty, text="sem build sugerida ainda", anchor="nw", fill=MUTE, font=F["sub"])
                    ty += F["sub"].metrics("linespace")
                y = max(y + IC, ty)
            else:
                y += SM
            y += round(7 * s_)
        lg = d.get("lanes") if ui.get("lanes", 1) else None
        if lg and lg.get("roles"):
            tot = lg["total"]
            kick(sc, pad, y + round(2 * s_), "Rota · itens e ouro")
            sc.create_text(W - pad, y, text=f"{'+' if tot >= 0 else '−'}{abs(tot) / 1000:.1f}k".replace(".", ","), anchor="ne",
                           fill=OKC if tot > 0 else BAD if tot < 0 else INK, font=F["num"])
            y += max(F["num"].metrics("linespace"), F["kick"].metrics("linespace")) + round(5 * s_)
            n_ = len(lg["roles"])
            gap = round(3 * s_)
            bw = (W - 2 * pad - gap * (n_ - 1)) / n_
            bh = F["kick"].metrics("linespace") * 2 + F["sub"].metrics("linespace") + round(10 * s_)
            for i, r in enumerate(lg["roles"]):
                x1 = pad + i * (bw + gap)
                sc.create_rectangle(x1, y, x1 + bw, y + bh, fill=CELL_ME if r["me"] else CELL, outline=AC if r["me"] else "")
                sc.create_text(x1 + bw / 2, y + round(4 * s_), text=r["lb"], anchor="n", fill=INK if r["me"] else MUTE, font=F["kick"])
                v = r["v"]
                sc.create_text(x1 + bw / 2, y + round(4 * s_) + F["kick"].metrics("linespace"), text=(f"+{v}" if v > 0 else str(v).replace("-", "−")),
                               anchor="n", fill=OKC if v > 0 else BAD if v < 0 else INK, font=F["num"])
                g_ = r.get("g")
                if g_ is not None:
                    sc.create_text(x1 + bw / 2, y + round(5 * s_) + F["kick"].metrics("linespace") + F["sub"].metrics("linespace"),
                                   text=(f"+{g_}" if g_ > 0 else str(g_).replace("-", "−")), anchor="n",
                                   fill=OKC if g_ > 0 else BAD if g_ < 0 else MUTE, font=F["kick"])
            y += bh + round(8 * s_)
        state["cur_keys"] = {a["k"] for a in d.get("alerts") or []}
        state["me_dead"] = bool(d.get("me_dead"))
        for a in d.get("alerts") or []:
            if a["k"] not in seen and alert_on(ui, a["k"]):
                seen.add(a["k"])
                ok_ = not ui.get("voz_essencial", 1) or voz_essencial(a["k"], vstate, dead=bool(d.get("me_dead")))
                txt_ = (voice_short(a["k"], a["t"]) if ui.get("voz_essencial", 1) else None) or a.get("v") or a["t"]
                if ok_ and ui.get("balao", 1):
                    show_bubble(txt_, a["t"])
                elif ui["toasts"] and ok_:       # no modo enxuto, a tela mostra so o que a voz fala
                    tq["queue"].append(a["t"])
                if d.get("voice") and ok_:
                    speak_q.put({"t": txt_, "made": time.time(), "at": a.get("at"), "nm": a.get("nm"), "k": a["k"],
                                 "live": a["k"].startswith(VOZ_VIVA)})
        if tq["cur"] and time.time() > tq["until"]:
            tq["cur"] = None
        if not tq["cur"] and tq["queue"]:
            tq["cur"], tq["until"] = tq["queue"].pop(0), time.time() + ui["toast_secs"]
        shown = False
        if tq["cur"] and ui["toasts"]:
            lh = F["toast"].metrics("linespace")
            lines = wrap(tq["cur"], F["toast"], W - pad * 2 - round(16 * s_))
            h = lh * len(lines) + round(12 * s_)
            sc.create_rectangle(pad, y, W - pad, y + h, fill=NOTE_BG, outline="")
            sc.create_rectangle(pad, y, pad + max(2, round(3 * s_)), y + h, fill=AC, width=0)
            for i, ln in enumerate(lines):
                sc.create_text(pad + round(12 * s_), y + round(6 * s_) + i * lh, text=ln, anchor="nw", fill=INK, font=F["toast"])
            y += h + round(6 * s_)
            shown = True
        if d.get("cdl") and ui.get("cdstrip", 1):
            lh = F["sub"].metrics("linespace")
            nm_, _, rest_ = d["cdl"].partition(": ")
            y += kick(sc, pad, y, "Recargas · " + nm_, dia=ACC) + round(4 * s_)
            parts = [x.strip() for x in (rest_ or "").split("·") if x.strip()]
            cells = [x.split(" ", 1) for x in parts]
            if parts and len(parts) <= 5 and all(len(c) == 2 and len(c[0]) == 1 for c in cells):
                gap = round(3 * s_)
                cw = (W - 2 * pad - gap * (len(cells) - 1)) / len(cells)
                chh = F["num"].metrics("linespace") + round(6 * s_)
                for i, (kk, vv) in enumerate(cells):
                    x1 = pad + i * (cw + gap)
                    sc.create_rectangle(x1, y, x1 + cw, y + chh, fill=CELL, outline="#5A2330" if kk == "R" else LINE)
                    t1 = sc.create_text(0, 0, text=kk, anchor="nw", fill=GOLD, font=F["num"])
                    t2 = sc.create_text(0, 0, text=vv, anchor="nw", fill=INK, font=F["num"])
                    w1, w2 = F["num"].measure(kk), F["num"].measure(vv)
                    sx = x1 + (cw - (w1 + round(4 * s_) + w2)) / 2
                    sc.coords(t1, sx, y + round(3 * s_))
                    sc.coords(t2, sx + w1 + round(4 * s_), y + round(3 * s_))
                y += chh + round(6 * s_)
            else:
                cl = wrap(rest_ or d["cdl"], F["sub"], W - pad * 2)
                for i, ln in enumerate(cl):
                    sc.create_text(pad, y + i * lh, text=ln, anchor="nw", fill=INK, font=F["sub"])
                y += lh * len(cl) + round(6 * s_)
            shown = True
        if False and d.get("marks"):          # feiticos marcados nao aparecem na tela (regra da Riot): o aviso e so falado
            lh = F["sub"].metrics("linespace")
            sc.create_text(pad, y, text="MARCADOS", anchor="nw", fill=MUTE, font=F["sub"])
            y += lh
            ml = wrap(d["marks"], F["sub"], W - pad * 2)
            for i, ln in enumerate(ml):
                sc.create_text(pad, y + i * lh, text=ln, anchor="nw", fill="#E9C46A", font=F["sub"])
            y += lh * len(ml) + round(6 * s_)
            shown = True
        nt = None if not ui["note"] else d.get("note")
        if nt:
            lh = F["sub"].metrics("linespace")
            col_ = {"dead": BAD, "obj": GOLD, "tip": MUTE, "shop": OKC}.get(nt["kind"], MUTE)
            ip = round(6 * s_)
            lines = wrap(nt["text"], F["sub"], W - pad * 2 - ip * 2 - round(3 * s_))
            h = lh * len(lines) + ip * 2
            sc.create_rectangle(pad, y, W - pad, y + h, fill=NOTE_BG, outline="")
            sc.create_rectangle(pad, y, pad + max(2, round(3 * s_)), y + h, fill=col_, outline="")
            for i, ln in enumerate(lines):
                sc.create_text(pad + ip + round(3 * s_), y + ip + i * lh, text=ln, anchor="nw", fill=INK if nt["kind"] != "tip" else MUTE, font=F["sub"])
            y += h + round(6 * s_)
            shown = True
        if not (show_top or shown):
            return False
        H = y + pad - round(6 * s_)
        card(sc, W, H, AC)
        sc.config(width=W, height=H)
        root.update_idletasks()
        rx, ry = look.get("root_xy") or (root.winfo_x(), root.winfo_y())
        root.geometry(f"{W}x{H}+{rx}+{ry}")
        state["last"] = d
        return True

    def poll():
        try:
            with urllib.request.urlopen(url, timeout=6) as r:
                d = json.loads(r.read().decode("utf-8"))
            state["fails"] = 0
        except Exception:
            state["fails"] += 1
            d = {"in_game": False}
            if state["fails"] > 60:  # app fechado ha ~2 min: fecha o overlay tambem
                root.destroy()
                return
        was = state["in_game"]
        state["in_game"] = bool(d.get("in_game"))
        if state["in_game"] and not was and time.time() - state.get("qa_t", 0) > 60:
            # pergunta feita na selecao: nao mostra a resposta velha quando a partida comeca
            tq["queue"] = [x for x in tq["queue"] if not str(x).startswith(("Você:", "Coach:", "Pensando"))]
            if str(tq["cur"] or "").startswith(("Você:", "Coach:", "Pensando")):
                tq["cur"] = None
        if d.get("pos"):
            state["mypos"] = d["pos"]
        if d.get("me_cid"):
            state["me_cid"] = d["me_cid"]
        if was and not state["in_game"]:
            speak_q.clear(); vstate.clear()        # a partida acabou: nada do que estava na fila serve mais
        try:
            state["mmrect"] = (mm.winfo_rootx(), mm.winfo_rooty(), mm.winfo_width(), mm.winfo_height())
            state["jgdata"] = (d.get("enemies"), d.get("ver"), d.get("team"))
        except Exception:
            pass
        if was and not state["in_game"] and not d.get("demo") and not state.get("demo") and not d.get("loading"):   # partida acabou: falas novas na proxima
            seen.clear()
            tq.update(cur=None, queue=[])
        if not state["in_game"] and not d.get("speak") and not d.get("loading"):
            state["quiet"] = state.get("quiet", 0) + 1
            if state["quiet"] > 15:      # ~30 s fora da selecao (fila de novo, esquiva): a proxima selecao fala tudo de novo
                for k in [k for k in seen if k.startswith("sel_")]:
                    seen.discard(k)
        else:
            state["quiet"] = 0
        if d.get("ui"):
            apply_ui(d["ui"])
        mt_ = d.get("mictest")
        if mt_ and mt_ != state.get("mictest_id"):
            state["mictest_id"] = mt_
            mic_test(mt_)
        sy = d.get("say")
        if sy and sy.get("id") != state.get("say_id"):
            state["say_id"] = sy["id"]
            log("voz: teste pedido pelo app")
            speak_q.put(sy["t"])
        if d.get("alerts") and not d.get("voice") and not state.get("novoice_logged"):
            state["novoice_logged"] = True
            log("voz: desligada ou sem chave no app (os avisos ficam só escritos)")
        for a in d.get("speak") or []:      # fora da partida (selecao de campeoes): so a voz
            if a["k"] not in seen and alert_on(ui, a["k"]):
                seen.add(a["k"])
                if d.get("voice"):
                    speak_q.put(a.get("v") or a["t"])
        if d.get("timers"):
            tm["data"], tm["at"] = d["timers"], time.time()
        if d.get("fight") and ui.get("quiet_fight", 1):
            state["fight_until"] = time.time() + 6
        if d.get("demo") and not state.get("demo"):
            seen.clear()
            tq.update(cur=None, queue=[])
        state["demo"] = bool(d.get("demo"))
        if state["in_game"] and not state["hidden"]:
            if render(d) or state["drag"]:
                root.deiconify()
                root.attributes("-topmost", True)
            else:
                root.withdraw()
            # o painel (plano, farm, timers...) so aparece com voce morto: vivo, ele tapava a visao do jogo
            pb_show((render_panel(dict(d["panel"], plan=d.get("plan")) if d.get("panel") and (d.get("me_dead") or d.get("demo")) else None))
                    or (state["drag"] and ui.get("panel")))
            ebs.update(data=d.get("ebar") or (EB_DEMO if state["drag"] else None), at=time.time(), ver=d.get("ver"))
            eb_show(render_ebar())
            mm_show(True)
        else:
            root.withdraw()
            pb_show(state["drag"] and ui.get("panel"))
            if state["drag"] and ui.get("ebar", 1):
                ebs.update(data=EB_DEMO, at=time.time(), ver=d.get("ver") or ebs.get("ver"))
                eb_show(render_ebar())
            else:
                eb_show(False)
            mm_show(state["drag"])
        root.after(2000, poll)

    def keys():
        while flags:
            k = flags.pop(0)
            if k == 1:
                state["hidden"] = not state["hidden"]
                if state["hidden"]:
                    root.withdraw()
                    mm_show(False)
                    pb_show(False)
                    eb_show(False)
                elif state["in_game"]:
                    root.deiconify()
                    mm_show(True)
                    pb_show(bool(ui.get("panel")) and state.get("me_dead"))
                    eb_show(render_ebar())
            elif k in (7, 8):          # Tab segurado: a barra dos inimigos aceita clique
                state["tabmode"] = (k == 7) and state["in_game"] and not state["hidden"]
                if eb_hwnd and not state["drag"]:
                    _click_through(eb_hwnd, not state["tabmode"])
                if ebs["data"]:
                    render_ebar()
            elif k == 3 and state["in_game"]:
                jungle_mark()
            elif (11 <= k <= 15 or 21 <= k <= 25) and state["in_game"]:
                spell_mark(k % 10, "r" if k > 20 else "f")
            elif k == 4:
                ask_toggle()
            elif k == 9:          # repetir o ultimo aviso
                if state.get("last_said"):
                    speak_q.put({"t": state["last_said"], "made": time.time(), "force": True, "pri": 3})
            elif k == 10:         # silenciar 2 min (apertar de novo volta)
                if time.time() < state.get("mute_until", 0):
                    state["mute_until"] = 0
                    say_toast("Voz ligada de novo.")
                else:
                    state["mute_until"] = time.time() + 120
                    say_toast("Voz silenciada por 2 minutos (Ctrl+Shift+S de novo para voltar).")
            elif k == 5:          # botao de falar apertado
                now_ = time.time()
                if now_ - state.get("ptt_up", 0) < 0.15:          # repique do botao
                    continue
                log("ptt: botão de falar apertado")
                if ui.get("ptt_mode") == "toggle" or state.get("rec"):
                    state["ptt_sent"] = bool(state.get("rec"))     # ja gravando (clique curto antes): este clique envia
                    ask_toggle()
                else:
                    state["ptt_down"] = now_
                    state["ptt_sent"] = False
                    ask_start(limit=8000)
            elif k == 6:          # soltou
                state["ptt_up"] = time.time()
                if ui.get("ptt_mode") == "toggle" or state.get("ptt_sent") or not state.get("rec"):
                    state["ptt_sent"] = False
                    continue
                held = time.time() - state.get("ptt_down", 0)
                log(f"ptt: soltou depois de {held:.1f} s")
                if held >= 0.6:
                    ask_send()                                      # segurou e falou: envia ao soltar
                else:                                               # clique rapido: continua ouvindo ate o proximo clique (ou 8 s)
                    say_toast("Ouvindo… fale e clique de novo para enviar")
            elif k == 2 and hwnd:
                state["drag"] = not state["drag"]
                _click_through(hwnd, not state["drag"])
                if mm_hwnd:
                    _click_through(mm_hwnd, not state["drag"])
                if pb_hwnd:
                    _click_through(pb_hwnd, not state["drag"])
                if eb_hwnd:
                    _click_through(eb_hwnd, not state["drag"])
                if bb_hwnd:
                    _click_through(bb_hwnd, not state["drag"])
                if state.get("last"):
                    render(state["last"])
                if state["drag"]:
                    root.deiconify()
                    mm_show(True)
                    if ui.get("panel"):
                        if not plabels["head"]:
                            render_panel({"head": "Painel da partida", "cs": "arraste para posicionar"})
                        pb_show(True)
                    if ui.get("ebar", 1):
                        if not ebs["data"]:
                            ebs.update(data=EB_DEMO, at=time.time())
                        eb_show(render_ebar())
                else:
                    mcfg.update({"x": mm.winfo_x(), "y": mm.winfo_y()})
                    try:
                        cur_ui = load_cfg().get("ui") or {}
                        rx, ry = look.get("root_xy") or (root.winfo_x(), root.winfo_y())
                        px, py = look.get("pb_xy") or (PB.winfo_x(), PB.winfo_y())
                        fx = round(min(0.98, max(0.0, rx / max(1, root.winfo_screenwidth()))), 4)
                        fy = round(min(0.98, max(0.0, ry / max(1, root.winfo_screenheight()))), 4)
                        fx2 = round(min(0.98, max(0.0, px / max(1, root.winfo_screenwidth()))), 4)
                        fy2 = round(min(0.98, max(0.0, py / max(1, root.winfo_screenheight()))), 4)
                        ex_, ey_ = look.get("eb_xy") or (EB.winfo_x(), EB.winfo_y())
                        fx3 = round(min(0.98, max(0.0, ex_ / max(1, root.winfo_screenwidth()))), 4)
                        fy3 = round(min(0.98, max(0.0, ey_ / max(1, root.winfo_screenheight()))), 4)
                        look["eb_from"] = (fx3, fy3)
                        bx_, by_ = look.get("bb_xy") or (BB.winfo_x(), BB.winfo_y())
                        fx4 = round(min(0.98, max(0.0, bx_ / max(1, root.winfo_screenwidth()))), 4)
                        fy4 = round(min(0.98, max(0.0, by_ / max(1, root.winfo_screenheight()))), 4)
                        look["bb_from"] = (fx4, fy4)
                        cur_ui.update(fx=fx, fy=fy, fx2=fx2, fy2=fy2, fx3=fx3, fy3=fy3, fx4=fx4, fy4=fy4)
                        ui.update(fx=fx, fy=fy, fx2=fx2, fy2=fy2, fx3=fx3, fy3=fy3, fx4=fx4, fy4=fy4)
                        look["pos"], look["pos2"] = (fx, fy), (fx2, fy2)
                        save_cfg(x=root.winfo_x(), y=root.winfo_y(), mm=mcfg, ui=cur_ui, mm_from=[ui.get("mm_side"), ui.get("mm_size")])
                    except OSError:
                        pass
                    if not state["in_game"]:
                        root.withdraw()
                        mm_show(False)
                        pb_show(False)
                        eb_show(False)
                    elif ebs["data"] is EB_DEMO:
                        eb_show(False)
        if time.time() - state.get("hb", 0) > 4:
            state["hb"] = time.time()
            heartbeat("jogo" if state.get("in_game") else "fora")
        root.after(150, keys)

    # ---- pergunta falada para a IA: Ctrl+Shift+A comeca a gravar, de novo envia (ou para sozinho em 10 s) ----
    import tempfile
    recf = os.path.join(tempfile.gettempdir(), "carry_pergunta.wav")

    def mci(cmd):
        if os.name != "nt":
            return 1
        import ctypes
        buf = ctypes.create_unicode_buffer(256)
        return ctypes.windll.winmm.mciSendStringW(cmd, buf, 255, 0)

    def say_toast(txt, secs=8):
        tq["queue"].insert(0, txt)
        tq["cur"] = None

    def ask_send():
        if not state.get("rec"):
            return
        state["rec"] = False
        mci("stop carryrec")
        mci(f'save carryrec "{recf}"')
        mci("close carryrec")
        say_toast("Pensando…")

        def go():
            try:
                wav = open(recf, "rb").read()
                req = urllib.request.Request(f"http://127.0.0.1:{port}/api/overlay/pergunta?t={token}", data=wav, method="POST",
                                             headers={"Content-Type": "audio/wav"})
                with urllib.request.urlopen(req, timeout=60) as r:
                    res = json.loads(r.read().decode("utf-8"))
            except Exception as ex:
                res = {"erro": f"falhou ({type(ex).__name__})"}
            state["qa_t"] = time.time()
            if res.get("a"):
                tq["queue"][:0] = [f"Você: {res.get('q', '')}", f"Coach: {res['a']}"]
                speak_q.put(res["a"])
                log(f"pergunta: {res.get('q', '')[:80]} -> {res['a'][:120]}")
            else:
                tq["queue"].insert(0, "Coach: " + (res.get("erro") or "sem resposta"))
                if res.get("erro"):
                    speak_q.put("Coach: " + res["erro"].split(".")[0])
                log(f"pergunta falhou: {res.get('erro')}")
            tq["cur"] = None
        threading.Thread(target=go, daemon=True).start()

    def mic_setup():
        mci("set carryrec time format ms bitspersample 16 channels 1 samplespersec 16000 bytespersec 32000 alignment 2")
        try:
            m = int(ui.get("mic", -1))
        except (TypeError, ValueError):
            m = -1
        if m >= 0:
            rc = mci(f"set carryrec input {m}")
            if rc != 0 and not state.get("mic_warned"):
                state["mic_warned"] = True
                log(f"microfone: não consegui escolher o microfone {m} (erro MCI {rc}); usando o padrão do Windows")

    def mic_names():
        if os.name != "nt":
            return []
        import ctypes
        from ctypes import wintypes

        class CAPS(ctypes.Structure):
            _fields_ = [("wMid", wintypes.WORD), ("wPid", wintypes.WORD), ("vDriverVersion", wintypes.UINT),
                        ("szPname", wintypes.WCHAR * 32), ("dwFormats", wintypes.DWORD), ("wChannels", wintypes.WORD), ("wReserved1", wintypes.WORD)]
        w = ctypes.windll.winmm
        out = []
        for i in range(min(16, w.waveInGetNumDevs())):
            c = CAPS()
            if w.waveInGetDevCapsW(i, ctypes.byref(c), ctypes.sizeof(c)) == 0:
                out.append(c.szPname)
        return out

    def mic_report():
        try:
            names = mic_names()
            log("microfones no Windows: " + (", ".join(f"{i}: {n}" for i, n in enumerate(names)) or "nenhum"))
            req = urllib.request.Request(f"http://127.0.0.1:{port}/api/overlay/mics?t={token}", data=json.dumps(names).encode("utf-8"),
                                         method="POST", headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=5).close()
        except Exception as ex:
            log(f"microfones: não consegui listar ({type(ex).__name__})")
    threading.Thread(target=mic_report, daemon=True).start()

    def mic_test(tid):
        """Teste pedido no Editar overlay: grava 3 s e manda para o app medir o volume e transcrever."""
        if state.get("rec") or os.name != "nt":
            return
        mci("close carrytest")
        if mci("open new type waveaudio alias carrytest") != 0:
            log("teste do microfone: não abriu")
            return
        mci("set carrytest time format ms bitspersample 16 channels 1 samplespersec 16000 bytespersec 32000 alignment 2")
        try:
            m = int(ui.get("mic", -1))
        except (TypeError, ValueError):
            m = -1
        if m >= 0:
            mci(f"set carrytest input {m}")
        mci("record carrytest")
        say_toast("Teste do microfone: fale qualquer coisa agora (3 segundos)")
        tf = os.path.join(tempfile.gettempdir(), "carry_teste_mic.wav")

        def done():
            mci("stop carrytest")
            mci(f'save carrytest "{tf}"')
            mci("close carrytest")

            def go():
                try:
                    names = mic_names()
                    nm = names[m] if 0 <= m < len(names) else "padrão do Windows"
                    req = urllib.request.Request(f"http://127.0.0.1:{port}/api/overlay/mictest?t={token}&mic={_up.quote(nm)}",
                                                 data=open(tf, "rb").read(), method="POST", headers={"Content-Type": "audio/wav"})
                    with urllib.request.urlopen(req, timeout=40) as r:
                        res = json.loads(r.read().decode("utf-8"))
                    log(f"teste do microfone ({nm}): volume {res.get('level')}%, entendi: {res.get('text', '')[:60]}")
                except Exception as ex:
                    log(f"teste do microfone falhou: {type(ex).__name__}")
            threading.Thread(target=go, daemon=True).start()
        root.after(3000, done)

    def ask_toggle():
        if state.get("rec"):
            ask_send()
            return
        ask_start()

    def ask_start(limit=10000):
        if state.get("rec") or os.name != "nt":
            return
        mci("close carryrec")
        if mci("open new type waveaudio alias carryrec") != 0:
            say_toast("Coach: não consegui abrir o microfone")
            log("pergunta: microfone não abriu")
            return
        mic_setup()
        rc = mci("record carryrec")
        if rc != 0:
            log(f"pergunta: o microfone não começou a gravar (erro MCI {rc})")
        state["rec"] = True
        say_toast("Ouvindo… fale a pergunta")
        stamp = time.time()
        state["rec_at"] = stamp
        root.after(limit, lambda: ask_send() if state.get("rec") and state.get("rec_at") == stamp else None)

    def ptt_watch():
        """Botao do mouse/tecla escolhido no site: segurar para falar (ou apertar para comecar e de novo para enviar)."""
        import ctypes
        u = ctypes.windll.user32
        prev = tab_prev = False
        while True:
            vk = PTT_VK.get(ui.get("ptt") or "none") or 0
            if vk:
                down = bool(u.GetAsyncKeyState(vk) & 0x8000)
                if down != prev:
                    flags.append(5 if down else 6)
                    prev = down
            else:
                prev = False
            if ui.get("ebar", 1):
                tdown = bool(u.GetAsyncKeyState(0x09) & 0x8000)      # Tab (placar do jogo)
                if tdown != tab_prev:
                    flags.append(7 if tdown else 8)
                    tab_prev = tdown
            time.sleep(0.03)
    if os.name == "nt":
        threading.Thread(target=ptt_watch, daemon=True).start()

    def start_drag(ev):
        state["dx"], state["dy"] = ev.x_root - root.winfo_x(), ev.y_root - root.winfo_y()

    def do_drag(ev):
        if state["drag"]:
            look["root_xy"] = (ev.x_root - state['dx'], ev.y_root - state['dy'])
            root.geometry(f"+{look['root_xy'][0]}+{look['root_xy'][1]}")
    sc.bind("<Button-1>", start_drag)
    sc.bind("<B1-Motion>", do_drag)

    def pstart(ev):
        state["pdx"], state["pdy"] = ev.x_root - PB.winfo_x(), ev.y_root - PB.winfo_y()

    def pmove(ev):
        if state["drag"]:
            look["pb_xy"] = (ev.x_root - state['pdx'], ev.y_root - state['pdy'])
            PB.geometry(f"+{look['pb_xy'][0]}+{look['pb_xy'][1]}")
    pc.bind("<Button-1>", pstart)
    pc.bind("<B1-Motion>", pmove)
    root.withdraw()
    root.after(300, poll)
    root.after(300, keys)
    root.after(1000, eb_tick)
    root.after(500, bb_tick)
    root.mainloop()


def live_snapshot(live_data, items, ddir=None):
    """Texto curto com o que o placar mostra (para a IA responder no jogo)."""
    from . import live, liveview, voicecues
    me = live._find_me(live_data) or {}
    gt = (live_data.get("gameData") or {}).get("gameTime") or 0
    act = live_data.get("activePlayer") or {}
    nm = lambda i: ((items or {}).get(str(i)) or {}).get("name") or str(i)
    def who(p):
        sc = p.get("scores") or {}
        its = ", ".join(nm(it.get("itemID")) for it in p.get("items") or [] if it.get("itemID") not in (3340, 3363, 3364))
        dead = f", morto ({int(p.get('respawnTimer') or 0)}s)" if p.get("isDead") else ""
        return (f"{p.get('championName')} ({p.get('position') or '?'}) nível {p.get('level')}, {sc.get('kills', 0)}/{sc.get('deaths', 0)}/{sc.get('assists', 0)}, "
                f"{sc.get('creepScore', 0)} CS{dead}; itens: {its or 'nenhum'}")
    lines = [f"Tempo de jogo: {int(gt) // 60}:{int(gt) % 60:02d}",
             f"Eu: {who(me)}; ouro na mão: {int(act.get('currentGold') or 0)}"]
    players = live_data.get("allPlayers") or []
    lines.append("Meu time: " + " | ".join(who(p) for p in players if p.get("team") == me.get("team") and p is not me))
    foes = [p for p in players if p.get("team") != me.get("team")]
    lines.append("Time inimigo: " + " | ".join(who(p) for p in foes))
    if ddir:
        for p in foes:
            line = voicecues.cd_line(voicecues.champ_cds(ddir, liveview.champ_id(p)), int(p.get("level") or 1))
            if line:
                lines.append(f"Recargas base de {p.get('championName')}: {line}")
            tips = voicecues.matchup_text(ddir, liveview.champ_id(p))
            if tips:
                lines.append(f"Dicas oficiais contra {p.get('championName')}: " + " ".join(tips[:3]))
    t = timers(live_data, gt)
    when = lambda at: "vivo agora" if at <= gt else f"nasce em {int(at - gt) // 60}:{int(at - gt) % 60:02d}"
    lines.append(f"Dragão: {when(t['dragon'])}; Barão: {when(t['baron'])}")
    try:
        lines.append("Timers: " + (voicecues.timers_line(live_data, me, gt) or "nenhum"))
    except Exception:
        pass
    return "\n".join(lines)[:6000]
