"""Visual "ROTK" (pedido do Lucas: o app inteiro com a cara do launcher).

Preto puro (sem azul), branco, vermelho vivo; cantos retos; rotulos em caixa alta com espacamento; linhas finas cinza;
destaque ativo com traco vermelho. Vem por ultimo no CSS e troca os dourados/bronzes antigos por branco e vermelho.
"""
import re

RED, RED2 = "#E0263A", "#B3121F"

# troca de cores fixas espalhadas nas telas (dourado/bronze -> vermelho/branco/cinza)
_SWAP = [
    (re.compile(r"#c8aa6e|#C8AA6E"), RED),
    (re.compile(r"#e9c46a|#E9C46A"), "#F2F2F2"),
    (re.compile(r"#d9b45a|#D9B45A|#c9a85a|#C9A85A"), "#F2F2F2"),
    (re.compile(r"rgba\(\s*200\s*,\s*170\s*,\s*110\s*,\s*([0-9.]+)\s*\)"), lambda m: f"rgba(255,255,255,{float(m.group(1)) * .45:.3f})"),
    (re.compile(r"rgba\(\s*233\s*,\s*196\s*,\s*106\s*,\s*([0-9.]+)\s*\)"), lambda m: f"rgba(224,38,58,{m.group(1)})"),
    (re.compile(r"#C1121F|#c1121f"), RED),
    (re.compile(r"#120E0E|#120e0e"), "#050505"),
    (re.compile(r"#1A1414|#1a1414"), "#0E0E0E"),
    (re.compile(r"#221A19|#221a19"), "#151515"),
    (re.compile(r"#2E2523|#2e2523"), "#222222"),
    (re.compile(r"#F1E9DF|#f1e9df"), "#F2F2F2"),
]


_HEX = re.compile(r"#([0-9a-fA-F]{6})\b")
_RGB = re.compile(r"rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*([,)])")


def _gray(r, g, b):
    """Escuro azulado/arroxeado vira cinza neutro do mesmo brilho (fundo preto, sem azul)."""
    if max(r, g, b) < 90 and (b - r >= 4 or b - g >= 4):
        v = round(0.3 * r + 0.59 * g + 0.11 * b)
        return v, v, v
    return None


def _hex(m):
    h = m.group(1)
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    gr = _gray(r, g, b)
    return "#%02x%02x%02x" % gr if gr else m.group(0)


def _rgb(m):
    r, g, b = int(m.group(1)), int(m.group(2)), int(m.group(3))
    gr = _gray(r, g, b)
    if not gr:
        return m.group(0)
    head = m.group(0).split("(")[0]
    return f"{head}({gr[0]},{gr[1]},{gr[2]}{m.group(4)}"


def apply(html):
    for rx, to in _SWAP:
        html = rx.sub(to, html)
    html = _HEX.sub(_hex, html)
    return _RGB.sub(_rgb, html)


CSS = """
/* ================= ROTK: ultima camada ================= */
:root{--night:#050505;--raised:#0E0E0E;--raised2:#151515;--line:#222222;--bone:#F2F2F2;--steel:#8E8E8E;
--bg:#050505;--panel:#0E0E0E;--panel2:#151515;--rule:#222222;--ink:#F2F2F2;--mute:#8E8E8E;
--ac:#E0263A;--acs:rgba(224,38,58,.12);--acm:rgba(224,38,58,.35);--gold:#F2F2F2;--regra:#F2F2F2;
--nx-red:#E0263A;--nx-red2:#B3121F;--nx-bronze:#F2F2F2;--r-card:2px;--r-btn:0px;--line-hover:#333333}
html,body{background:#050505 !important}
body::after{content:'';position:fixed;inset:0;z-index:-1;pointer-events:none;
background:linear-gradient(115deg,transparent 62%,rgba(224,38,58,.05) 62%,rgba(224,38,58,.05) 70%,transparent 70%,transparent 73%,rgba(224,38,58,.035) 73%,rgba(224,38,58,.035) 78%,transparent 78%)}
/* cantos retos e linhas finas */
.card,.hpn,.ln-card,.ll,.cr-s,.kv4,.vm,.mi,.cq,.ccol,.lq,.cr-ai,.lh,.ln-hero,.psum,.dcard,.cs-wrap,.td-row,.cidea,.sbteam,.gscore,.aian,
.side-me,.chip,.pill,input,select,textarea,.btn,button,.tile,.box,.panel,details,.sg a,.subnav a{border-radius:2px !important}
.card,.hpn,.dcard,.psum,.cs-wrap{background:#0E0E0E !important;border:1px solid #222222 !important;box-shadow:none !important}
.card:hover,.hpn:hover{border-color:#333333 !important}
/* menu lateral */
.side{background:#0A0A0A !important;border-right:1px solid #222222 !important;border-image:none !important}
.side-me{background:#0E0E0E !important;border:1px solid #222222 !important}.side-me::before{display:none}
.sg small{color:#8E8E8E !important;letter-spacing:.22em;text-transform:uppercase;font-size:10.5px !important;font-weight:700 !important}
.sg small::before{background:#E0263A !important;transform:none;width:14px;height:1px}
.sg a{letter-spacing:.02em}
.sg a[aria-current]{background:rgba(255,255,255,.04) !important;color:#fff !important}
.sg a[aria-current]::before{background:#E0263A !important;border-radius:0 !important}
/* sub-abas: traco vermelho embaixo, como o launcher */
.subnav a{background:transparent !important;color:#8E8E8E !important;text-transform:uppercase;letter-spacing:.14em;font-size:12px !important;font-weight:700 !important;position:relative}
.subnav a:hover{color:#fff !important}
.subnav a[aria-current]{color:#fff !important;background:transparent !important}
.subnav a[aria-current]::after{content:'';position:absolute;left:10px;right:10px;bottom:2px;height:2px;background:#E0263A}
/* titulos: caixa alta, pesados, com rotulo vermelho */
h1,h2,.h1,.ttl,.hero h1{text-transform:uppercase;letter-spacing:.02em}
h2,h3{letter-spacing:.04em}
.kick,.eyebrow,.lbl{letter-spacing:.2em !important;text-transform:uppercase}
b.gl{letter-spacing:.06em !important;text-transform:uppercase}
b.gl::before,.gl::before{background:#E0263A !important}
/* botoes: bloco vermelho, reto */
.btn,button.btn,.btn.gold,.btn.primary{background:#E0263A !important;color:#fff !important;border:0 !important;text-transform:uppercase;letter-spacing:.14em;font-weight:800 !important;box-shadow:none !important}
.btn:hover{background:#F23447 !important}.btn:active{background:#B3121F !important}
.btn.ghost,.btn.sec,.btn.line{background:transparent !important;color:#F2F2F2 !important;border:1px solid #333333 !important}
.btn.ghost:hover,.btn.sec:hover,.btn.line:hover{border-color:#E0263A !important}
input,select,textarea{background:#0A0A0A !important;border:1px solid #222222 !important;color:#F2F2F2 !important}
input:focus,select:focus,textarea:focus{border-color:#E0263A !important;outline:none}
/* chips e etiquetas */
.chip{background:#0A0A0A !important;border:1px solid #222222 !important}
.chip.good{border-color:rgba(111,203,152,.45) !important}.chip.bad{border-color:rgba(224,38,58,.55) !important}
/* abas e segmentos selecionados: aba = traco vermelho; segmento/pilula = bloco vermelho */
.hp-tabs button[aria-selected=true],.hp-tabs [role=tab][aria-selected=true]{background:transparent !important;color:#fff !important;box-shadow:inset 0 -2px 0 #E0263A !important;border-color:transparent !important}
.p4-seg a.on,.vod-f button[aria-pressed=true],.seg button[aria-pressed=true],.seg a[aria-current],.rolef.on,.modes .on,.chip.on,.sgc i.on{background:#E0263A !important;color:#fff !important;border-color:#E0263A !important}
.ctab.on{border-bottom-color:#E0263A !important;color:#fff !important}
a{color:#F2F2F2}a:hover{color:#fff}
::selection{background:rgba(224,38,58,.4)}
:focus-visible{outline-color:#E0263A !important}
"""
