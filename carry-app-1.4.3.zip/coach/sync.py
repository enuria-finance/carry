"""Baixa partidas novas e grava no banco."""
from . import db


def sync_player(client, con, puuid, count=100, queue=420, log=print):
    """Baixa as ultimas `count` partidas (só as que ainda não estão no banco)."""
    ids = client.match_ids(puuid, count=count, queue=queue)
    known = db.known_match_ids(con)
    new = [m for m in ids if m not in known]
    log(f"{len(ids)} partidas encontradas, {len(new)} novas.")
    saved = 0
    for i, mid in enumerate(new, 1):
        m = client.match(mid)
        if not m:
            log(f"  [{i}/{len(new)}] {mid}: partida indisponível, pulando")
            continue
        tl = client.timeline(mid)
        db.save_match(con, m, tl)
        saved += 1
        log(f"  [{i}/{len(new)}] {mid} ok" + ("" if tl else " (sem timeline)"))
    return saved
