"""Tempos do mapa da temporada 2026 (Summoner's Rift), num lugar so. Conferidos em out/2026 (patch 26.20).

Fontes: wiki oficial do LoL (wiki.leagueoflegends.com), riftpatchnotes.com e notas do patch 26.1.
O patch 26.1 adiantou o comeco da partida em 35 s: acampamentos, caranguejos e a primeira onda nascem antes.
Se a Riot mudar algum tempo, corrija SO aqui.
"""
# primeira onda de minions e intervalo entre ondas
FIRST_WAVE = 30                 # 0:30 (antes 1:05)
MINIONS_IN_LANE = 60            # a primeira onda chega no meio por volta de 1:00
WAVE_EVERY = ((0, 30), (14 * 60, 25), (30 * 60, 20))

# selva: primeiro nascimento e volta (segundos)
CAMP_FIRST = {"azul": 55, "vermelho": 55, "lobos": 55, "aves": 55, "gromp": 67, "krugs": 67}
CAMP_RESPAWN = {"azul": 300, "vermelho": 300, "lobos": 135, "aves": 135, "gromp": 135, "krugs": 135}
SCUTTLE_FIRST, SCUTTLE_RESPAWN = 175, 150      # 2:55 (antes 3:30) e volta em 2:30

# objetivos grandes
DRAGON_FIRST, DRAGON_RESPAWN = 300, 300        # 5:00, volta 5 min depois de morto
ELDER_RESPAWN = 360                            # Anciao: 6 min depois da alma e depois de cada abate
GRUBS_AT, GRUBS_GONE = 480, 885                # Larvas do Vazio: 8:00, uma vez so; somem 14:45
HERALD_AT, HERALD_GONE = 900, 1185             # Arauto: 15:00, some 19:45
BARON_FIRST, BARON_RESPAWN = 1200, 360         # Barao: 20:00, volta 6 min depois
INHIB_RESPAWN = 300                            # inibidor volta em 5 min

# placas: as da torre externa NAO caem mais aos 14 min (ficam ate a torre cair); torres 2 e 3 tambem tem 3 placas


def mmss(sec):
    sec = max(0, int(sec))
    return f"{sec // 60}:{sec % 60:02d}"
