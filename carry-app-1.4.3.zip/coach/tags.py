"""Toda dica do app vem marcada. Nunca misturar os tres tipos."""

DADO = "dado"            # saiu dos seus jogos ou da amostra dos melhores (com n)
REGRA = "regra geral"    # principio de jogo, nao verificado neste patch
HIPOTESE = "hipotese"    # o app suspeita, mas nao prova

LOW_SAMPLE = 30


def tip(kind, text, n=None):
    return {"kind": kind, "text": text, "n": n}


def sample_note(n):
    if n is None:
        return ""
    if n < LOW_SAMPLE:
        return f"amostra pequena ({n} jogos): não é conclusivo"
    return f"{n} jogos"


def as_text(t):
    """Versao em texto puro, para o terminal."""
    n = f" [{sample_note(t['n'])}]" if t.get("n") is not None else ""
    return f"[{t['kind'].upper()}] {t['text']}{n}"
