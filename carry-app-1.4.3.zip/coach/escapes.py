"""Habilidade de fuga de cada campeao (para lembrar de GUARDAR ela quando o perigo aparece).

Lista feita a mao para os campeoes em que a fuga e obvia; para o resto, procura nas descricoes oficiais (Data Dragon)
uma habilidade basica que avanca, salta ou teleporta. Sem fuga clara: nao lembra nada (melhor calar do que errar).
"""
import os
import re

ESC = {
    "Zed": "W", "Akali": "E", "Yasuo": "E", "Yone": "E", "Ahri": "R", "Leblanc": "W", "Katarina": "E", "Talon": "E",
    "Fizz": "E", "Ekko": "E", "Irelia": "Q", "Riven": "E", "Vayne": "Q", "Ezreal": "E", "Lucian": "E", "Tristana": "W",
    "Corki": "W", "Graves": "E", "Kindred": "Q", "LeeSin": "W", "Khazix": "E", "Nidalee": "W", "Sylas": "E",
    "Qiyana": "W", "Kassadin": "R", "Shaco": "Q", "Evelynn": "W", "Kayn": "E", "Vi": "Q", "Hecarim": "E",
    "MasterYi": "Q", "Gragas": "E", "Jax": "Q", "Fiora": "Q", "Camille": "E", "Gwen": "E", "Kalista": "Q",
    "Samira": "E", "Zeri": "E", "Nilah": "E", "Viego": "W", "Belveth": "Q", "Hwei": "E", "Naafiri": "E",
    "Aurora": "R", "Smolder": "E", "Ambessa": "E", "Briar": "E", "Elise": "E", "KSante": "E", "Renekton": "E",
    "Tryndamere": "E", "Pantheon": "W", "Diana": "E", "Nocturne": "W", "Lissandra": "E", "Vex": "R",
    "Kaisa": "E", "Twitch": "Q", "Rengar": "R", "Gnar": "E", "Poppy": "E", "Shyvana": "W", "Udyr": "E",
    "Rammus": "Q", "Singed": "Q", "Rakan": "W", "Pyke": "E", "Bard": "E", "Ivern": "Q", "Zac": "E",
}
WORDS = r"(avança|avanca|salta|pula|teleporta|dispara para|investe|se lança|se lanca|desliza|rola|corre)"
_MEM = {}


def escape_of(cid, ddir=None):
    """('W', 'Sombra Viva') ou None."""
    if cid in _MEM:
        return _MEM[cid]
    data = {}
    try:
        from .ddragon import DataDragon, clean
        data = DataDragon(cache_dir=os.path.join(ddir, "cache") if ddir else "cache").champion(cid) or {}
    except Exception:
        clean = lambda x: x or ""
    spells = data.get("spells") or []
    key = ESC.get(cid)
    if not key and len(spells) >= 3:
        for k, sp in zip("QWE", spells[:3]):
            if re.search(WORDS, clean(sp.get("description") or "").lower()):
                key = k
                break
    if not key:
        _MEM[cid] = None if data else None
        return None
    name = ""
    if len(spells) >= 4:
        name = spells["QWER".index(key)].get("name") or ""
    out = (key, name)
    if data:
        _MEM[cid] = out
    return out


def phrase(cid, ddir=None):
    e = escape_of(cid, ddir)
    if not e:
        return ""
    return f"Guarde o {e[0]} pra fugir."
