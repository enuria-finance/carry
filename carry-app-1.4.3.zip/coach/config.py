"""Configuracao local (chave da Riot e Riot ID) guardada em config.json ao lado do banco.

A chave fica so no seu PC, em texto simples, e nunca e mostrada na tela nem enviada
para outro lugar alem da Riot. Se o arquivo nao existir, vale a variavel RIOT_API_KEY.
"""
import json
import os


class Config:
    def __init__(self, db_path):
        self.path = os.path.join(os.path.dirname(os.path.abspath(db_path)), "config.json")

    def load(self):
        try:
            with open(self.path, encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def save(self, **kw):
        data = self.load()
        for k, v in kw.items():
            if v is None:
                continue
            if v == "":
                data.pop(k, None)
            else:
                data[k] = v
        import time
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        # a pasta fica no OneDrive: enquanto ele sincroniza, o Windows trava o arquivo por alguns instantes.
        # Antes isso dava erro e a chave nao salvava; agora tenta de novo por ate ~5 s.
        last = None
        for i in range(25):
            try:
                os.replace(tmp, self.path)
                return
            except PermissionError as ex:
                last = ex
                time.sleep(0.2)
        try:                      # ultimo recurso: escreve direto no arquivo
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump(data, f)
            os.remove(tmp)
        except OSError:
            raise last

    def riot_key(self):
        return (self.load().get("riot_api_key") or os.environ.get("RIOT_API_KEY") or "").strip()

    def riot_id(self):
        """Riot ID salvo; senao a variavel RIOT_ID; senao o unico ja conhecido no banco (quem ja usava o app)."""
        v = (self.load().get("riot_id") or os.environ.get("RIOT_ID") or "").strip()
        if v:
            return v
        try:
            import sqlite3
            db = os.path.join(os.path.dirname(self.path), os.environ.get("COACH_DB", "coach.sqlite"))
            if os.path.exists(db):
                con = sqlite3.connect(db)
                try:
                    rows = con.execute("SELECT k FROM meta WHERE k LIKE 'puuid:%'").fetchall()
                finally:
                    con.close()
                if len(rows) == 1:
                    return rows[0][0][len("puuid:"):]
        except Exception:
            pass
        return ""

    def region(self):
        r = (self.load().get("region") or os.environ.get("RIOT_REGION") or "br1").strip().lower()
        from .riot import REGIONS
        return r if r in REGIONS else "br1"

    def key_status(self):
        """Texto seguro sobre a chave (nunca a chave)."""
        k = self.riot_key()
        if not k:
            return "nenhuma chave configurada"
        ok = k.startswith("RGAPI-") and len(k) >= 30
        src = "salva no app" if self.load().get("riot_api_key") else "da variável RIOT_API_KEY"
        return f"chave {src}, {len(k)} caracteres" + ("" if ok else " (formato estranho: deveria começar com RGAPI-)")
