"""Amostra dos melhores jogadores do BR, so pela API oficial da Riot.

Para cada jogador do Desafiante/Grao-Mestre/Mestre, olha as ultimas partidas
solo/duo e guarda as em que ele jogou o campeao e a posicao pedidos.
Com chave de desenvolvimento isso e lento (100 requisicoes a cada 2 min);
o comando pode ser rodado varias vezes: continua de onde parou.
"""
import time

from . import db

TIERS = ("challenger", "grandmaster", "master")


def collect_players(client, con, max_players, log=print):
    entries = []
    for tier in TIERS:
        for e in client.league_entries(tier):
            entries.append((tier, e))
        if len(entries) >= max_players:
            break
    entries.sort(key=lambda te: -te[1].get("leaguePoints", 0))
    players = []
    for tier, e in entries[:max_players]:
        puuid = e.get("puuid")
        if not puuid and e.get("summonerId"):
            puuid = client.puuid_by_summoner(e["summonerId"])
        if not puuid:
            continue
        con.execute("INSERT OR REPLACE INTO top_players VALUES (?,?,?,?)",
                    (puuid, tier, e.get("leaguePoints"), db.now_ms()))
        players.append(puuid)
    con.commit()
    log(f"{len(players)} jogadores do topo na lista.")
    return players


def sample(client, con, champion, champion_id=None, position=None, target_games=30,
           max_players=300, per_player=20, min_mastery=2000, log=print):
    """Guarda ate `target_games` partidas novas do campeao entre os melhores."""
    if position is None:
        from . import profile
        position = profile.position()
    log("Buscando a lista dos melhores do BR…")
    players = collect_players(client, con, max_players, log)
    known = db.known_match_ids(con)
    seen = {r[0] for r in con.execute("SELECT match_id FROM seen_matches")}
    have = con.execute(
        """SELECT COUNT(*) FROM participants p JOIN match_source s USING (match_id)
           WHERE s.source='top' AND p.champion=? AND p.position=?""",
        (champion, position)).fetchone()[0]
    log(f"Já tenho {have} partidas do topo no {champion}; meta {target_games}.")
    saved = 0
    pulados = 0
    for i, puuid in enumerate(players, 1):
        if have + saved >= target_games:
            break
        if i % 5 == 0:
            log(f"Olhando jogador {i}/{len(players)} (com {champion}: {i - pulados - 1}, salvas: {saved})…")
        if champion_id:
            m = client.mastery(puuid, champion_id)
            if not m or m.get("championPoints", 0) < min_mastery:
                pulados += 1
                continue
        for mid in client.match_ids(puuid, count=per_player, queue=420):
            if have + saved >= target_games:
                break
            if mid in known or mid in seen:
                continue
            match = client.match(mid)
            seen.add(mid)
            con.execute("INSERT OR IGNORE INTO seen_matches VALUES (?)", (mid,))
            if not match:
                continue
            me = next((p for p in match["info"]["participants"] if p["puuid"] == puuid), None)
            if not me or me["championName"] != champion or me.get("teamPosition") != position:
                continue
            db.save_match(con, match, client.timeline(mid), source="top")
            saved += 1
            log(f"  jogador {i}/{len(players)}: {mid} salvo ({have + saved}/{target_games})")
        con.commit()
    if saved == 0:
        log(f"Nenhum dos {len(players)} melhores tinha jogos recentes de {champion} nessa posição ({pulados} sem maestria suficiente). Tente outro campeão ou rode de novo mais tarde.")
    log(f"Pronto: {saved} partidas novas do topo.")
    return saved


def _players_cached(client, con, max_players, log):
    """Lista do topo guardada ha menos de 1 dia; senao busca de novo (3 chamadas)."""
    cut = db.now_ms() - 86400000
    rows = [r[0] for r in con.execute("SELECT puuid FROM top_players WHERE fetched_ms>=? ORDER BY lp DESC", (cut,))]
    if len(rows) >= 50:
        return rows[:max_players]
    return collect_players(client, con, max_players, log)


def collect_general(client, con, max_new=30, max_players=300, per_player=10, should_stop=lambda: False, log=print):
    """Base geral: guarda TODA partida solo/duo nova dos melhores do servidor (partida + linha do tempo).
    Cada partida vira dados dos 10 campeoes, entao a base cobre todo mundo (ate a Kalista) sem ninguem pedir.
    Continua de onde parou (cursor) e para cedo se alguem estiver esperando na fila."""
    con.execute("CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)")
    players = _players_cached(client, con, max_players, log)
    if not players:
        return 0
    r = con.execute("SELECT v FROM meta WHERE k='gen_cursor'").fetchone()
    cur = int(r[0]) % len(players) if r else 0
    known = db.known_match_ids(con)
    seen = {x[0] for x in con.execute("SELECT match_id FROM seen_matches")}
    saved, looked = 0, 0
    while saved < max_new and looked < len(players):
        if should_stop():
            break
        puuid = players[cur]
        cur = (cur + 1) % len(players)
        looked += 1
        for mid in client.match_ids(puuid, count=per_player, queue=420):
            if saved >= max_new or should_stop():
                break
            if mid in known or mid in seen:
                continue
            seen.add(mid)
            con.execute("INSERT OR IGNORE INTO seen_matches VALUES (?)", (mid,))
            m = client.match(mid)
            if not m or (m.get("info") or {}).get("queueId") != 420:
                continue
            db.save_match(con, m, client.timeline(mid), source="top")
            con.commit()            # grava partida por partida: nao segura o banco enquanto espera a Riot
            __import__("time").sleep(0.05)   # deixa o app respirar entre uma partida e outra
            known.add(mid)
            saved += 1
        con.execute("INSERT OR REPLACE INTO meta VALUES ('gen_cursor', ?)", (str(cur),))
        con.commit()
    total = con.execute("SELECT COUNT(*) FROM match_source WHERE source='top'").fetchone()[0]
    if total > CAP:
        prune(con, total - CAP)
        total = CAP
    log(f"Base geral: +{saved} partidas de alto elo (total {total}).")
    return saved


CAP = 5000   # partidas guardadas na base geral; as mais antigas saem (o meta muda a cada patch)


def prune(con, n):
    old = [r[0] for r in con.execute(
        "SELECT m.match_id FROM matches m JOIN match_source s USING(match_id) WHERE s.source='top' ORDER BY m.started_ms LIMIT ?", (n,))]
    for i in range(0, len(old), 400):
        chunk = old[i:i + 400]
        q = ",".join("?" * len(chunk))
        for t in ("participants", "participant_extra", "frames", "deaths", "wards", "events", "match_source", "matches"):
            con.execute(f"DELETE FROM {t} WHERE match_id IN ({q})", chunk)
    con.commit()
