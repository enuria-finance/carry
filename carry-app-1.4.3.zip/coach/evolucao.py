"""Onde esta a diferenca entre voce e os melhores com o MESMO campeao, e o treino do dia que ataca o maior buraco.

Compara as suas ultimas partidas com o campeao com a mediana das partidas de alto elo guardadas (amostra oficial da Riot).
"""
import html
import time

e = lambda x: html.escape("" if x is None else str(x))

# chave, nome, maior e melhor?, escala (o que conta como diferenca grande), formato
METRICS = [
    ("cs10", "Farm aos 10 min", True, 10, "{:.0f}"),
    ("csdiff10", "Farm contra o oponente aos 10", True, 8, "{:+.0f}"),
    ("deaths_before_10", "Mortes antes dos 10", False, 0.4, "{:.1f}"),
    ("deaths_before_15", "Mortes antes dos 15", False, 0.5, "{:.1f}"),
    ("golddiff15", "Ouro contra o oponente aos 15", True, 500, "{:+.0f}"),
    ("kp", "Participação em abates", True, 0.08, "{:.0%}"),
    ("vision_per_min", "Visão por minuto", True, 0.25, "{:.2f}"),
    ("cs_per_min", "Farm por minuto", True, 0.6, "{:.1f}"),
]

# numeros que a Riot registra em cada partida (challenges da match-v5). Acerto de habilidade e por 10 minutos:
# a Riot conta os acertos, nao as tentativas, entao nao existe "porcentagem de acerto" oficial.
CHALLENGES = [
    ("skillshotsHit", "Acertos de habilidade de tiro (por 10 min)", True, 2.0, "{:.1f}", True),
    ("skillshotsDodged", "Habilidades inimigas desviadas (por 10 min)", True, 2.0, "{:.1f}", True),
    ("laneMinionsFirst10Minutes", "Minions da rota nos primeiros 10 min", True, 8, "{:.0f}", False),
    ("soloKills", "Abates solo por partida", True, 0.5, "{:.1f}", False),
    ("turretPlatesTaken", "Placas derrubadas por partida", True, 0.6, "{:.1f}", False),
    ("maxCsAdvantageOnLaneOpponent", "Maior vantagem de farm na rota", True, 8, "{:.0f}", False),
    ("killsNearEnemyTurret", "Abates perto da torre inimiga", True, 0.5, "{:.1f}", False),
]
METRICS += [("ch_" + k, lb, hi, sc, fm) for k, lb, hi, sc, fm, _ in CHALLENGES]
_RAW = {}


def add_challenges(con, games, limit=150):
    """Coloca nas partidas os numeros da Riot (ch_*), lendo o JSON oficial guardado de cada partida."""
    from .db import load_raw
    per10 = {k for k, *_r, p10 in CHALLENGES if p10}
    for g in games[:limit]:
        key = (g["match_id"], g["participant_id"])
        ch = _RAW.get(key)
        if ch is None:
            ch = {}
            try:
                mj = load_raw(con, g["match_id"], "match") or {}
                info = mj.get("info") or {}
                p = next((x for x in info.get("participants") or [] if x.get("participantId") == g["participant_id"]), None)
                c = (p or {}).get("challenges") or {}
                dur = (info.get("gameDuration") or g.get("duration_s") or 0) or 1
                for k, *_r in CHALLENGES:
                    if c.get(k) is not None:
                        ch["ch_" + k] = c[k] / (dur / 600) if k in per10 else c[k]
            except Exception:
                ch = {}
            _RAW[key] = ch
            if len(_RAW) > 4000:
                for k_ in list(_RAW)[:1000]:
                    _RAW.pop(k_, None)
        g.update(ch)
    return games


DRILL = {
    "cs10": "Modo de treino, 5 minutos: farm só com ataque básico até os 10 min do relógio, sem usar habilidade. Depois 5 minutos pegando o canhão e os minions à distância com Q.",
    "cs_per_min": "Hoje, em toda partida: depois da fase de rotas, pegue a onda do lado antes de ir para qualquer luta ou objetivo que não seja agora.",
    "csdiff10": "Hoje: não troque enquanto um canhão ou dois minions estiverem com pouca vida. Pegue o farm primeiro, troque depois.",
    "deaths_before_10": "Hoje: antes de cada troca, olhe o minimapa e responda 'onde está o jungler deles?'. Se não sabe, não troca. Meta: zero mortes antes dos 10.",
    "deaths_before_15": "Hoje: depois dos 3 minutos, só avance depois do meio da rota se souber onde está o jungler deles. Meta: no máximo 1 morte antes dos 15.",
    "golddiff15": "Hoje: volte para a base só depois de empurrar a onda (de preferência a do canhão) e com ouro para um componente. Nada de voltar com a onda chegando na sua torre.",
    "kp": "Hoje: quando a sua onda estiver empurrada e tiver luta ou objetivo perto do rio, vá. Meta: participação em abates acima de 55%.",
    "ch_skillshotsHit": "Modo de treino, 10 minutos: bonecos andando (Robôs de treino em movimento) e só habilidade de tiro. No jogo, jogue a habilidade quando o alvo está pegando farm, está lento ou acabou de usar o deslocamento, nunca no alcance máximo num alvo livre.",
    "ch_skillshotsDodged": "Hoje: na troca, ande de lado (nunca em linha reta para trás) e fique atrás dos seus minions quando a habilidade principal dele estiver pronta.",
    "ch_laneMinionsFirst10Minutes": "Modo de treino, 5 minutos: último golpe só com ataque básico. Na partida, não troque com dois ou mais minions com pouca vida.",
    "ch_soloKills": "Hoje: procure a troca quando o oponente gastar a habilidade principal ou estiver abaixo de 60% de vida no seu nível 6.",
    "ch_turretPlatesTaken": "Hoje: depois de um abate ou de o oponente voltar para a base, empurre a onda e bata na torre antes de ir para outro lugar.",
    "ch_maxCsAdvantageOnLaneOpponent": "Hoje: congele a onda perto da sua torre quando estiver na frente, para o oponente perder farm.",
    "ch_killsNearEnemyTurret": "Hoje: depois do nível 6 e do primeiro item, procure o abate quando ele estiver farmando sob a torre com pouca vida.",
    "vision_per_min": "Hoje: Sentinela de Controle em toda volta à base e amuleto usado no rio sempre que estiver pronto.",
}

_C = {}


def gaps(con, puuid, champion=None, position=None, n=30):
    """[(chave, nome, voce, eles, tamanho_da_diferenca)] do maior buraco para o menor, e os pontos fortes."""
    from . import profile, report
    champion = champion or profile.champion()
    if not champion:
        return None
    key = (puuid, champion, position or "")
    hit = _C.get(key)
    if hit and time.time() - hit[0] < 1800:
        return hit[1]
    mine = [dict(g) for g in report.my_games(con, puuid, position) if g["champion"] == champion][:n]
    top = [dict(g) for g in report.top_games(con, champion, position)][:150]
    try:
        add_challenges(con, mine)
        add_challenges(con, top)
    except Exception:
        pass
    if len(mine) < 5 or len(top) < 10:
        _C[key] = (time.time(), None)
        return None
    import statistics
    bad, good = [], []
    for k, label, higher, scale, fmt in METRICS:
        mv = [g[k] for g in mine if g.get(k) is not None]
        tv = [g[k] for g in top if g.get(k) is not None]
        if len(mv) < 5 or len(tv) < 10:
            continue
        m, t = sum(mv) / len(mv), statistics.median(tv)
        d = (t - m) / scale if higher else (m - t) / scale      # > 0: voce esta pior
        row = (k, label, fmt.format(m), fmt.format(t), d)
        (bad if d > 0.5 else good if d < -0.5 else []).append(row)
    bad.sort(key=lambda r: -r[4])
    good.sort(key=lambda r: r[4])
    res = {"champion": champion, "n_mine": len(mine), "n_top": len(top), "bad": bad, "good": good}
    _C[key] = (time.time(), res)
    return res


def drill_text(res):
    if not res or not res["bad"]:
        return None
    k, label, m, t, _ = res["bad"][0]
    return f"Treino do dia. Seu maior buraco com {res['champion']}: {label.lower()}, você {m}, os melhores {t}. {DRILL.get(k, '')}"


def html_card(res):
    if not res:
        return ("<div class='card'><b class='gl'>Onde está a diferença</b><p class='n'>Precisa de 5 partidas suas com o campeão e 10 partidas dos melhores "
                "na amostra. Baixe a amostra do topo em Comparar.</p></div>")
    row = lambda r, cls: (f"<div style='display:grid;grid-template-columns:1fr 90px 90px;gap:8px;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.05)'>"
                          f"<span>{e(r[1])}</span><b class='{cls}' style='text-align:right'>{e(r[2])}</b><span style='text-align:right;color:var(--mute)'>{e(r[3])}</span></div>")
    head = ("<div style='display:grid;grid-template-columns:1fr 90px 90px;gap:8px;font-size:12px;color:var(--mute)'><span></span>"
            "<span style='text-align:right'>você</span><span style='text-align:right'>os melhores</span></div>")
    body = (f"<div class='card'><b class='gl'>Onde está a diferença: você contra os melhores de {e(res['champion'])}</b>"
            f"<p class='n'>Suas últimas {res['n_mine']} partidas com ele contra {res['n_top']} partidas de alto elo (mediana).</p>")
    if res["bad"]:
        body += "<p><b>Onde você perde para eles</b> (do maior para o menor)</p>" + head + "".join(row(r, "dn") for r in res["bad"])
    if res["good"]:
        body += "<p style='margin-top:12px'><b>Onde você já joga como eles</b></p>" + head + "".join(row(r, "up") for r in res["good"])
    dt = drill_text(res)
    if dt:
        body += f"<div class='card verdict' style='margin-top:12px'><b class='gl'>Treino do dia</b><p>{e(DRILL.get(res['bad'][0][0], ''))}</p></div>"
    return body + "</div>"


def match_card(con, puuid, g):
    """Os numeros da Riot desta partida contra a sua media e a dos melhores com o mesmo campeao."""
    import statistics
    from . import report
    try:
        cur = add_challenges(con, [dict(g)])[0]
        mine = add_challenges(con, [dict(x) for x in report.my_games(con, puuid, g.get("position")) if x["champion"] == g["champion"]][:30])
        top = add_challenges(con, [dict(x) for x in report.top_games(con, g["champion"], g.get("position"))][:150])
    except Exception:
        return ""
    rows = ""
    for k, lb, hi, sc, fm, _p in CHALLENGES:
        kk = "ch_" + k
        if cur.get(kk) is None:
            continue
        mv = [x[kk] for x in mine if x.get(kk) is not None]
        tv = [x[kk] for x in top if x.get(kk) is not None]
        avg = sum(mv) / len(mv) if len(mv) >= 3 else None
        med = statistics.median(tv) if len(tv) >= 10 else None
        cls = "up" if med is not None and cur[kk] >= med else "dn" if med is not None else ""
        rows += (f"<div style='display:grid;grid-template-columns:1fr 80px 80px 80px;gap:8px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,.05)'>"
                 f"<span>{e(lb)}</span><b class='{cls}' style='text-align:right'>{e(fm.format(cur[kk]))}</b>"
                 f"<span style='text-align:right;color:var(--mute)'>{e(fm.format(avg)) if avg is not None else '-'}</span>"
                 f"<span style='text-align:right;color:var(--mute)'>{e(fm.format(med)) if med is not None else '-'}</span></div>")
    if not rows:
        return ""
    head = ("<div style='display:grid;grid-template-columns:1fr 80px 80px 80px;gap:8px;font-size:12px;color:var(--mute)'><span></span>"
            "<span style='text-align:right'>nesta</span><span style='text-align:right'>sua média</span><span style='text-align:right'>os melhores</span></div>")
    return ("<div class='card'><b class='gl'>Números da Riot nesta partida</b><p class='n'>A Riot conta as habilidades de tiro que acertaram, não as que "
            "foram jogadas: por isso é acertos por 10 minutos, não porcentagem.</p>" + head + rows + "</div>")
