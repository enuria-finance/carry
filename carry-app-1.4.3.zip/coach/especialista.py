"""Dicas de especialista por confronto (tiradas de guias em vídeo de jogadores de alto elo, resumidas).
Aparecem marcadas como "especialista" para não confundir com os números das suas partidas.
Chave: (seu campeão, oponente), com os nomes internos do Data Dragon."""

DICAS = {
    ("Zed", "Fizz"): {
        "sel": "Dica de especialista contra Fizz: Osso Revestido na secundária. A runa principal pode ser a que você joga melhor: Conquistador, Eletrocutar ou Primeiro Ataque.",
        "ficha": "Contra Fizz: ele costuma maximizar o E e desvia fácil da sua Q. Suba o seu E cedo, desse ele não escapa. Eclipse de primeiro item: quando ele entrar com o Q, responda com ataque básico e E.",
        "jogo": [
            (150, 900, "fizz_roam", "Se o Fizz sair para roamar com a onda dele empurrando para você, segure a onda perto da sua torre: ele perde farm e experiência."),
        ],
    },
    ("Zed", "Xerath"): {
        "sel": "Dica de especialista contra Xerath: Eletrocutar é muito bom neste confronto.",
        "ficha": "Contra Xerath: entre para matar assim que ele gastar o E, o atordoamento. Se não matar e sair com pouca vida, ele te mata com a ultimate.",
        "jogo": [
            ("ult", 0, "xerath_ult", "O Xerath tem ultimate agora: só entre se der para matar. Com pouca vida, volte para a base."),
        ],
    },
}


def _norm(n):
    return (n or "").lower().replace(" ", "").replace("'", "").replace(".", "")


def get(mine, enemy):
    m, e = _norm(mine), _norm(enemy)
    for (a, b), v in DICAS.items():
        if _norm(a) == m and _norm(b) == e:
            return v
    return None


def sel_text(mine, enemy):
    d = get(mine, enemy)
    return d and d.get("sel")


def ficha_text(mine, enemy):
    d = get(mine, enemy)
    return d and d.get("ficha")


def jogo(mine, enemy, gt, enemy_level=1):
    """[(chave, texto)] das dicas que valem agora."""
    d = get(mine, enemy)
    out = []
    for a, b, k, t in (d or {}).get("jogo", []):
        if a == "ult":
            if int(enemy_level or 1) >= 6:
                out.append((k, t))
        elif a <= gt <= b:
            out.append((k, t))
    return out
