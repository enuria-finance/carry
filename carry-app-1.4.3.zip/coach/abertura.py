"""Tela de abertura do Carry (como o launcher da Riot): logo animado, confere se tem versao nova, atualiza se tiver,
e fica aberta ate a janela do app aparecer.

Roda num processo separado (o app principal precisa da thread principal para a janela). Conversa com ele por arquivo:
quando termina a parte da atualizacao, grava cache/abertura_ok.txt; o app so carrega o codigo depois disso."""
import math
import os
import socket
import sys
import threading
import time

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OK_FILE = os.path.join(RAIZ, "cache", "abertura_ok.txt")
PORTA = 8765
BG, LINE, INK, MUTE, GOLD, RED = "#0B0A10", "#262335", "#EEE8F2", "#ABA3B8", "#D9B45A", "#E0384C"


def _fonte(tk_root, *familias):
    from tkinter import font
    tem = set(font.families(tk_root))
    return next((f for f in familias if f in tem), "Segoe UI")


def _porta_ok():
    try:
        with socket.create_connection(("127.0.0.1", PORTA), timeout=0.4):
            return True
    except OSError:
        return False


def _estrela(cx, cy, r, ri, ang):
    pts = []
    for i in range(8):
        a = ang + i * math.pi / 4
        rr = r if i % 2 == 0 else ri
        pts += [cx + rr * math.cos(a), cy + rr * math.sin(a)]
    return pts


def run(rapida=False):
    import tkinter as tk
    os.makedirs(os.path.dirname(OK_FILE), exist_ok=True)
    try:
        os.remove(OK_FILE)
    except OSError:
        pass
    root = tk.Tk()
    root.overrideredirect(True)
    root.configure(bg=BG)
    W, H = 560, 330
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    root.geometry(f"{W}x{H}+{(sw - W) // 2}+{(sh - H) // 2}")
    root.attributes("-topmost", True)
    try:
        root.iconbitmap(os.path.join(RAIZ, "carry.ico"))
    except Exception:
        pass
    cond = _fonte(root, "Bahnschrift SemiBold Condensed", "Bahnschrift", "Arial Narrow", "Segoe UI")
    corpo = _fonte(root, "Segoe UI", "Bahnschrift")
    c = tk.Canvas(root, width=W, height=H, bg=BG, highlightthickness=1, highlightbackground=LINE)
    c.pack()
    # moldura e brilho
    c.create_line(0, 1, W * 0.45, 1, fill=GOLD)
    for i in range(40):                                   # brilho suave atras do logo
        t = i / 40
        col = "#%02x%02x%02x" % (int(11 + (60 - 11) * (1 - t) * .35), int(10 + (20 - 10) * (1 - t) * .35), int(16 + (30 - 16) * (1 - t) * .35))
        c.create_oval(140 - 110 * t - 20, 135 - 110 * t - 20, 140 + 110 * t + 20, 135 + 110 * t + 20, outline="", fill=col)
    s1 = c.create_polygon(_estrela(140, 135, 62, 14, 0), fill=RED, outline="")
    s2 = c.create_polygon(_estrela(140, 135, 34, 8, math.pi / 8), fill=INK, outline="")
    c.create_oval(134, 129, 146, 141, fill=BG, outline="")
    c.create_text(240, 112, text="CARRY", fill=INK, anchor="w", font=(cond, 44))
    v = "?"
    try:
        v = open(os.path.join(RAIZ, "VERSAO.txt"), encoding="utf-8").read().strip()
    except OSError:
        pass
    c.create_text(243, 152, text=f"Coach de LoL  ·  versão {v}", fill=MUTE, anchor="w", font=(corpo, 11))
    status = c.create_text(40, 262, text="Verificando atualizações…", fill=INK, anchor="w", font=(corpo, 11))
    c.create_rectangle(40, 284, W - 40, 288, fill=LINE, outline="")
    bar = c.create_rectangle(40, 284, 40, 288, fill=GOLD, outline="")
    c.create_text(W - 40, 310, text="Quem treina, carrega.", fill=MUTE, anchor="e", font=(corpo, 9))
    st = {"msg": "Verificando atualizações…", "pct": None, "fase": "check", "t0": time.time(), "fim": None}

    def trabalho():
        if rapida:                                   # o app ja estava aberto (em segundo plano): so a abertura
            st.update(msg="Abrindo o Carry…", fase="abrindo")
            time.sleep(1.4)
            st["fim"] = time.time()
            return
        try:
            from coach import atualizar
            info = atualizar.checar(force=True)
            if info:
                st.update(msg=f"Baixando a versão {info.get('versao')}…", pct=None)
                ok, m = atualizar.aplicar(info, log=lambda s: st.update(msg=s))
                st.update(msg=("Versão nova instalada. Abrindo o Carry…" if ok else "Não deu para atualizar agora. Abrindo o Carry…"))
            elif atualizar.STATE.get("err"):
                st.update(msg="Não deu para conferir atualizações agora. Abrindo o Carry…")
            else:
                st.update(msg="Você está na versão mais nova. Abrindo o Carry…")
        except Exception:
            st.update(msg="Abrindo o Carry…")
        try:
            with open(OK_FILE, "w") as fh:
                fh.write(str(time.time()))
        except OSError:
            pass
        st["fase"] = "abrindo"
        t0 = time.time()
        while time.time() - t0 < 45:                     # espera a janela do app aparecer
            if _porta_ok():
                time.sleep(2.5)
                break
            time.sleep(0.4)
        st["fim"] = time.time()
    threading.Thread(target=trabalho, daemon=True).start()

    def anima():
        t = time.time() - st["t0"]
        c.coords(s1, *_estrela(140, 135, 62, 14, t * 0.9))
        c.coords(s2, *_estrela(140, 135, 34, 8, math.pi / 8 - t * 1.6))
        c.itemconfigure(status, text=st["msg"])
        if st["fase"] == "check":
            x = 40 + (W - 80) * (0.08 + 0.3 * (0.5 + 0.5 * math.sin(t * 2)))
        else:
            x = c.coords(bar)[2] + ((W - 40) - c.coords(bar)[2]) * 0.06
        c.coords(bar, 40, 284, x, 288)
        if st["fim"]:
            root.destroy()
            return
        root.after(33, anima)
    anima()
    root.mainloop()


def esperar_ok(limite=25):
    """No app principal: espera a abertura terminar a parte da atualizacao (ou desistir)."""
    t0 = time.time()
    while time.time() - t0 < limite:
        if os.path.exists(OK_FILE):
            return True
        time.sleep(0.2)
    return False


if __name__ == "__main__":
    sys.path.insert(0, RAIZ)
    run()
