"""Voz de macro: so o que ajuda a ganhar a partida, pela sua rota e pelo que o placar mostra (regra geral do app).

- Vantagem/desvantagem de itens contra o oponente de rota: quando trocar e quando segurar.
- 1 minuto antes de cada objetivo: o que fazer com a sua onda e para onde ir (lado do objetivo x sua rota).
- Janela de vantagem numerica: inimigos mortos + objetivo vivo = pegue agora.
- Voltar para a base na hora certa: ouro para o item com a rota livre.
"""
from . import gametimes as GT

SIDE = {"TOP": "cima", "JUNGLE": None, "MIDDLE": None, "BOTTOM": "baixo", "UTILITY": "baixo"}


def _val(p, items):
    tot = 0
    for it in p.get("items") or []:
        info = (items or {}).get(str(it.get("itemID"))) or {}
        tot += ((info.get("gold") or {}).get("total") or it.get("price") or 0) * max(1, int(it.get("count") or 1))
    return tot


def cues(live_data, me, foes, pos, gt, items, tmr, nxt=None):
    al = []
    add = lambda k, t: al.append({"k": "macro_" + k, "t": t})
    lp = next((p for p in foes if pos and p.get("position") == pos), None)
    nm = (lp or {}).get("championName") or "o oponente"

    # 1) itens contra o oponente de rota (a cada ~3 min, so com diferenca que muda a troca)
    if lp and 240 <= gt < 1500 and pos != "JUNGLE":
        d = _val(me, items) - _val(lp, items)
        slot = int(gt // 180)
        if d >= 900:
            tip = {"UTILITY": "jogue agressivo com o seu atirador e procure abate",
                   "BOTTOM": "force troca com o seu suporte"}.get(pos, "force troca e empurre para pegar placa")
            add(f"ahead_{slot}", f"Você tem {d} de ouro em itens a mais que {nm}: {tip}.")
        elif d <= -900:
            add(f"behind_{slot}", f"Você está {-d} de ouro atrás de {nm} em itens: não troque, farme perto da torre e espere ajuda.")

    # 2) 1 minuto antes do objetivo: onda primeiro, depois o rio do objetivo
    objs = []
    if tmr.get("dragon"):
        objs.append(("dragao", "Dragão", tmr["dragon"], "baixo"))
    if gt < GT.GRUBS_AT:
        objs.append(("larvas", "Larvas do Vazio", GT.GRUBS_AT, "cima"))
    elif gt < GT.HERALD_AT:
        objs.append(("arauto", "Arauto", GT.HERALD_AT, "cima"))
    if tmr.get("baron") and gt >= GT.BARON_FIRST - 90:
        objs.append(("barao", "Barão", tmr["baron"], "cima"))
    for key, name, at, side in objs:
        left = at - gt
        if 55 <= left <= 75:
            mine = SIDE.get(pos)
            if pos == "JUNGLE":
                t = f"{name} em 1 minuto: limpe os acampamentos do lado de {side} e chame as rotas para o rio."
            elif mine is None:      # mid
                t = f"{name} em 1 minuto: empurre a sua onda e vá para o rio de {side} antes do inimigo."
            elif mine == side:
                t = f"{name} em 1 minuto, do seu lado: empurre a onda agora e coloque visão no rio de {side}."
            else:
                t = f"{name} em 1 minuto, do outro lado: empurre e pegue placa, ou use o Teleporte para a luta."
            add(f"obj_{key}_{int(at)}", t)

    # 3) vantagem numerica: 2+ inimigos mortos por bastante tempo e objetivo vivo
    dead = [p for p in foes if p.get("isDead") and int(p.get("respawnTimer") or 0) >= 15]
    if len(dead) >= 2 and 300 <= gt < 840:          # depois dos 14 min o midgame.py decide
        alive = [n for k, n, at, s in objs if at <= gt]
        if gt >= GT.BARON_FIRST and tmr.get("baron") and tmr["baron"] <= gt:
            alive = ["Barão"] + [a for a in alive if a != "Barão"]
        m = min(int(p.get("respawnTimer") or 0) for p in dead)
        what = alive[0] if alive else "uma torre"
        add(f"window_{int(gt // 40)}", f"{len(dead)} inimigos mortos por {m} segundos: peguem {what} agora.")

    # 4) voltar para a base na hora certa
    if lp and lp.get("isDead") and int(lp.get("respawnTimer") or 0) >= 10 and nxt and nxt.get("cost") and nxt["gold"] >= nxt["cost"]:
        add(f"recall_{int(gt // 60)}", f"{nm} morto e você tem ouro para {nxt['name']}: empurre a onda e volte para a base agora.")
    return al


# ---------------- mais macro (pedido: "mais coisas de macrogame") ----------------
_LANE = {"TOP": "L", "MIDDLE": "C", "BOTTOM": "R", "UTILITY": "R"}
_OUTER = {"L": "03", "C": "05", "R": "03"}
_OBJ_NAME = {"dragon": "o Dragão", "baron": "o Barão"}


def _turret(tid):
    """'Turret_T1_L_03_A' -> ('ORDER', 'L', '03')."""
    parts = (tid or "").split("_")
    if len(parts) < 4:
        return None
    owner = "ORDER" if parts[1] == "T1" else "CHAOS" if parts[1] == "T2" else None
    return (owner, parts[2], parts[3]) if owner else None


def extras(live_data, me, foes, pos, gt, items, tmr, gold=0):
    """Decisoes de macro que faltavam: voltar antes do objetivo, placas, torre da sua rota, caçador deles morto,
    ace e o carregador inimigo morto no fim. Chaves macro_x_* (o overlay fala uma vez cada)."""
    al = []
    add = lambda k, t, v=None: al.append({"k": "macro_x_" + k, "t": t, **({"v": v} if v else {})})
    mine_t = me.get("team")
    alive = not me.get("isDead")
    ev = (live_data.get("events") or {}).get("Events") or []
    up_objs = []
    for key in ("dragon", "baron"):
        at = tmr.get(key)
        if at and (key == "dragon" or gt >= GT.BARON_FIRST - 120):
            up_objs.append((key, at))
    obj_now = next((_OBJ_NAME[k] for k, at in sorted(up_objs, key=lambda o: o[1]) if at <= gt + 30), None)

    # 1) voltar para a base antes do objetivo (1 min e meio antes, com ouro para gastar)
    if alive and gt >= 300 and gold >= 1100:
        for key, at in up_objs:
            left = at - gt
            if 80 <= left <= 110:
                nm = "Dragão" if key == "dragon" else "Barão"
                add(f"reset_{key}_{int(at)}", f"{nm} em 1 minuto e meio e você tem {gold} de ouro: volte à base agora, compre e chegue com visão no objetivo.",
                    f"{nm} em um minuto e meio: volte agora, compre e chegue com controle de visão.")
                break

    # 3) torre externa da sua rota caiu (fase de rotas)
    lane = _LANE.get(pos)
    if lane and gt < 900:
        for x in ev:
            if x.get("EventName") != "TurretKilled" or gt - (x.get("EventTime") or 0) > 40:
                continue
            t = _turret(x.get("TurretKilled"))
            if not t or t[1] != lane or t[2] != _OUTER[lane]:
                continue
            if t[0] != mine_t:
                add(f"tw_{x.get('TurretKilled')}", "Torre deles caiu na sua rota: agora rode. Empurre a onda e vá para o meio ou para o objetivo com o seu caçador.",
                    "Torre deles caiu. Empurre e rode pro meio ou pro objetivo.")
            else:
                add(f"tw_{x.get('TurretKilled')}", "Sua torre caiu: a onda vai até a segunda torre. Farme com cuidado, coloque sentinela no rio e não avance sem ver o caçador deles.",
                    "Sua torre caiu. Farme com cuidado e ponha sentinela no rio.")

    # 4) caçador deles morto
    jg = next((p for p in foes if (p.get("position") or "").upper() == "JUNGLE"), None)
    if jg and jg.get("isDead") and int(jg.get("respawnTimer") or 0) >= 20 and gt >= 300 and alive:
        r = int(jg.get("respawnTimer") or 0)
        d = int((jg.get("scores") or {}).get("deaths") or 0)
        nm = jg.get("championName") or "O caçador deles"
        if obj_now:
            add(f"jgdead_{d}", f"{nm} morto por {r} segundos: sem Golpear do outro lado, peguem {obj_now} agora.",
                f"Caçador deles morto: peguem {obj_now} agora.")
        elif gt < 840 and pos in ("TOP", "MIDDLE", "BOTTOM", "UTILITY"):
            add(f"jgdead_{d}", f"{nm} morto por {r} segundos: sem risco de gank, jogue agressivo e empurre a sua onda.",
                "Caçador deles morto: jogue agressivo na rota.")

    # 5) ace
    if foes and all(p.get("isDead") for p in foes) and gt >= 600:
        what = "o Barão" if tmr.get("baron") and tmr["baron"] <= gt and gt >= GT.BARON_FIRST else "torres e o inibidor"
        add(f"ace_{int(gt // 45)}", f"Ace! O time deles inteiro está morto: peguem {what} agora, rápido, e voltem antes de eles nascerem.",
            f"Ace! Peguem {what} agora.")

    # 6) fim de jogo: só o carregador deles morto (2+ mortos o midgame ja fala)
    if gt >= 1500 and alive:
        dead = [p for p in foes if p.get("isDead") and int(p.get("respawnTimer") or 0) >= 30]
        if len(dead) == 1:
            carry = max(foes, key=lambda p: _val(p, items), default=None)
            p = dead[0]
            if carry is p:
                r = int(p.get("respawnTimer") or 0)
                what = obj_now or "uma torre"
                add(f"carry_{p.get('championName')}_{int((p.get('scores') or {}).get('deaths') or 0)}",
                    f"{p.get('championName')}, o mais forte deles, morto por {r} segundos: forcem {what} agora.",
                    f"{p.get('championName')} morto: forcem {what} agora.")
    return al
