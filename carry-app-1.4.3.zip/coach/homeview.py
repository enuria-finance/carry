"""Painel do inicio: indicadores com mini-graficos, evolucao, pool e matchups (so dos seus jogos)."""
from . import icons, report

W_IN = "var(--win)"


def _avg(vals):
    vals = [v for v in vals if v is not None]
    return sum(vals) / len(vals) if vals else None


def kda(g):
    return (g["kills"] + g["assists"]) / max(g["deaths"], 1)


# (rotulo, funcao, formato, maior_e_melhor)
METRICS = [
    ("KDA", kda, "{:.2f}", True),
    ("CS/min", lambda g: g.get("cs_per_min"), "{:.1f}", True),
    ("Mortes antes dos 10", lambda g: g.get("deaths_before_10"), "{:.1f}", False),
    ("Visão/min", lambda g: g.get("vision_per_min"), "{:.2f}", True),
    ("Part. em abates", lambda g: (g["kp"] * 100) if g.get("kp") is not None else None, "{:.0f}%", True),
]


def spark(values, e, fmt, width=120, height=30):
    """Mini-grafico de linha (uma serie, sem eixos). Passe o mouse num ponto para ver o valor."""
    pts = [(i, v) for i, v in enumerate(values) if v is not None]
    if len(pts) < 2:
        return "<svg class='spark' viewBox='0 0 120 30'></svg>"
    lo, hi = min(v for _, v in pts), max(v for _, v in pts)
    span = (hi - lo) or 1.0
    x = lambda i: 3 + (width - 6) * i / max(len(values) - 1, 1)
    y = lambda v: height - 4 - (height - 8) * (v - lo) / span
    line = " ".join(f"{x(i):.1f},{y(v):.1f}" for i, v in pts)
    dots = "".join(f"<circle cx='{x(i):.1f}' cy='{y(v):.1f}' r='5' class='hit'><title>jogo {i + 1} (do mais antigo): "
                   f"{e(fmt.format(v))}</title></circle>" for i, v in pts)
    li, lv = pts[-1]
    return (f"<svg class='spark' viewBox='0 0 {width} {height}' role='img'><polyline points='{line}'/>"
            f"<circle cx='{x(li):.1f}' cy='{y(lv):.1f}' r='3' class='last'/>{dots}</svg>")


def kpi_tiles(games, e, recent_n=10, spark_n=20):
    """games: mais novos primeiro. Cada indicador compara os ultimos N com a media de todos."""
    if not games:
        return ""
    chron = list(reversed(games[:spark_n]))
    out = ""
    # vitorias: tira de V/D (forma + cor), nao so cor
    rec = games[:recent_n]
    wr = 100 * sum(1 for g in rec if g["win"]) / len(rec)
    wr_all = 100 * sum(1 for g in games if g["win"]) / len(games)
    strip = "".join(f"<i class='{'w' if g['win'] else 'l'}' title='{'Vitória' if g['win'] else 'Derrota'}: {e(g['champion'])}'></i>"
                    for g in chron)
    out += _tile("Vitórias (últimos %d)" % len(rec), f"{wr:.0f}%", wr - wr_all, "{:+.0f} pp", True,
                 f"<div class='wl'>{strip}</div>", len(rec), len(games))
    for label, fn, fmt, higher in METRICS:
        vals_recent = [fn(g) for g in rec]
        vals_all = [fn(g) for g in games]
        a, b = _avg(vals_recent), _avg(vals_all)
        if a is None:
            out += _tile(label, "—", None, "", higher, "<p class='n'>sem dados (precisa da timeline)</p>", 0, len(games))
            continue
        delta = None if b is None else a - b
        out += _tile(label, fmt.format(a), delta, "{:+" + fmt[2:] if False else None, higher,
                     spark([fn(g) for g in chron], e, fmt), len([v for v in vals_recent if v is not None]), len(games), fmt=fmt)
    return f"<div class='kpis'>{out}</div>"


def _tile(label, value, delta, dfmt, higher, viz, n_recent, n_all, fmt=None):
    d = ""
    if delta is not None:
        good = (delta >= 0) == higher
        if abs(delta) < 1e-9:
            good = None
        arrow = "▲" if delta > 0 else ("▼" if delta < 0 else "■")
        if dfmt is None:  # numero com o mesmo formato
            txt = ("{:+.2f}" if fmt and "2f" in fmt else "{:+.1f}" if fmt and "1f" in fmt else "{:+.0f}").format(delta)
            if fmt and fmt.endswith("%"):
                txt += "%"
        else:
            txt = dfmt.format(delta)
        cls = "same" if good is None else ("good" if good else "bad")
        d = f"<span class='dl {cls}'>{arrow} {txt} <small>vs média geral</small></span>"
    note = f"{n_recent} de {n_all} jogos" if n_recent is not None else ""
    return (f"<div class='kpi'><span class='kl'>{label}</span><b class='kv'>{value}</b>{d}{viz}"
            f"<span class='kn'>dado · {note}</span></div>")


def rolling_winrate_svg(games, e, window=10):
    """Vitorias moveis (janela de N jogos) ao longo do tempo. Uma linha, linha de 50% tracejada."""
    chron = list(reversed(games))
    if len(chron) < window + 2:
        return f"<p class='n'>Precisa de pelo menos {window + 2} jogos para a evolução.</p>"
    pts = []
    for i in range(window - 1, len(chron)):
        w = chron[i - window + 1:i + 1]
        pts.append((i, 100 * sum(1 for g in w if g["win"]) / window))
    W, H, L, T, B = 640, 210, 40, 12, 26
    n = len(chron) - 1
    x = lambda i: L + (W - L - 12) * i / n
    y = lambda v: T + (H - T - B) * (1 - v / 100)
    line = " ".join(f"{x(i):.1f},{y(v):.1f}" for i, v in pts)
    s = [f"<svg class='evo' viewBox='0 0 {W} {H}' role='img' aria-label='Vitórias móveis'>"]
    for v in (0, 50, 100):
        s.append(f"<line class='{'mid' if v == 50 else 'g'}' x1='{L}' x2='{W - 12}' y1='{y(v):.1f}' y2='{y(v):.1f}'/>"
                 f"<text class='ax' x='{L - 6}' y='{y(v) + 4:.0f}' text-anchor='end'>{v}%</text>")
    s.append(f"<polyline class='ln' points='{line}'/>")
    s.append(f"<text class='ax' x='{x(0):.0f}' y='{H - 6}'>mais antigo</text><text class='ax' x='{x(n):.0f}' y='{H - 6}' text-anchor='end'>mais novo</text>")
    for i, v in pts:
        g = chron[i]
        s.append(f"<circle class='pt' cx='{x(i):.1f}' cy='{y(v):.1f}' r='6'><title>até o jogo {i + 1}: {v:.0f}% de vitórias "
                 f"nos últimos {window} ({e(g['champion'])}, {'vitória' if g['win'] else 'derrota'})</title></circle>")
    s.append("</svg>")
    return "".join(s)


def pool_bars(games, e, top=7):
    rows = report.by_key(games, "champion")[:top]
    if not rows:
        return ""
    out = ""
    for name, n, w, wr in rows:
        low = n < 10
        out += (f"<div class='pb{' low' if low else ''}'><span class='pn'>{icons.champ(name, 26, 'me')} {e(name)}</span>"
                f"<span class='pt2'><i style='width:{round(100 * wr)}%'></i><u></u></span>"
                f"<span class='pv'>{round(100 * wr)}% <small>· {n} jogo(s)</small></span></div>")
    return out + "<p class='n'>A marca no meio é 50%. Linhas apagadas = menos de 10 jogos (pode ser só amostra).</p>"


def matchup_bars(games, e, top=5, min_games=5):
    rows = [r for r in report.by_key(games, "opp_champion", min_games=min_games) if report.suave(r[2], r[1]) < 0.5]
    rows.sort(key=lambda r: report.suave(r[2], r[1]))
    rows = rows[:top]
    if not rows:
        return f"<p class='n'>Ainda sem oponentes com {min_games} jogos ou mais.</p>"
    out = ""
    for name, n, w, wr in rows:
        out += (f"<div class='pb'><span class='pn'>{icons.champ(name, 26, 'foe')} {e(name)}</span><span class='pt2'><i style='width:{round(100 * wr)}%'></i><u></u></span>"
                f"<span class='pv'>{round(100 * wr)}% <small>· {n}</small></span></div>")
    return out + "<p class='n'>Seus piores confrontos de rota (menor % de vitória).</p>"
