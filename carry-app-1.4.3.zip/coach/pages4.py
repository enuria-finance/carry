"""Paginas novas: explorador de duelos, tier list, calendario, historico de PDL estimado e patch (diferenca entre versoes do Data Dragon).

Fontes: SUAS partidas e a amostra dos melhores guardada pelo app (dado, com n), as dicas oficiais e os numeros do Data Dragon.
Nada de raspagem de site: o patch e calculado comparando a versao atual com a anterior do Data Dragon.
"""
import html
import json
import os
import time
from collections import Counter, defaultdict

from . import builds, draft, icons, ranks, report

e = lambda s: html.escape("" if s is None else str(s), quote=True)
LANE_PT = {"TOP": "Topo", "JUNGLE": "Selva", "MIDDLE": "Meio", "BOTTOM": "Atirador", "UTILITY": "Suporte"}
POSITIONS = ["TOP", "JUNGLE", "MIDDLE", "BOTTOM", "UTILITY"]

CSS_BASE = """
.p4-f{display:flex;gap:10px;flex-wrap:wrap;align-items:end;margin:0 0 16px}.p4-f label{display:flex;flex-direction:column;gap:4px;font-size:12px;color:var(--mute)}
.p4-f input,.p4-f select{min-width:180px}.p4-f button{width:auto !important;flex:none}
.p4-seg{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 14px}.p4-seg a{padding:7px 14px;border-radius:999px;border:1px solid var(--rule);color:#D6CCC0;text-decoration:none;font:600 13px var(--head)}
.p4-seg a.on{background:var(--gold);color:#1a1405;border-color:var(--gold)}
.duel-h{display:grid;grid-template-columns:1fr auto 1fr;gap:18px;align-items:center;border:1px solid var(--rule);border-radius:18px;padding:18px;background:var(--panel);margin-bottom:16px}
.duel-h .s{display:flex;align-items:center;gap:14px}.duel-h .s.r{justify-content:flex-end;text-align:right}
.duel-h b{font:800 24px var(--head);color:#fff;display:block}.duel-h .vs{font:800 22px var(--d,var(--head));color:var(--gold)}
.duel-g{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}
.kv4{display:flex;flex-direction:column;gap:2px;padding:14px 16px;border:1px solid var(--rule);border-radius:14px;background:rgba(16,11,11,.45)}
.kv4 small{font:700 11px var(--mono);letter-spacing:.12em;text-transform:uppercase;color:var(--mute)}.kv4 b{font:800 28px var(--d,var(--head));color:#fff}
.kv4 b.w{color:#8FD4A8}.kv4 b.l{color:#E8817C}.kv4 span{font-size:12.5px;color:var(--mute)}
@media (max-width:1000px){.duel-g{grid-template-columns:1fr}.duel-h{grid-template-columns:1fr}}
.tl{width:100%;border-collapse:collapse}.tl th{text-align:left;font:700 11px var(--mono);letter-spacing:.1em;color:var(--mute);padding:8px;border-bottom:1px solid var(--rule)}
.tl td{padding:8px;border-bottom:1px solid rgba(255,255,255,.04);font-size:14px;color:#E6DDD2;vertical-align:middle}
.cal-t td .g,.cal-t td.g{color:#8FD4A8}.cal-t td .r,.cal-t td.r{color:#E8817C}
.tl tr.mine td{background:rgba(233,196,106,.08)}.tl tr.mine td:first-child{box-shadow:inset 3px 0 0 var(--gold)}.tl .cn{display:flex;align-items:center;gap:10px;text-decoration:none}.tl .cn b{color:#fff}
.tier{display:inline-flex;width:30px;height:30px;border-radius:9px;align-items:center;justify-content:center;font:800 15px var(--head);color:#111}
.tier.S{background:#ff7a7a}.tier.A{background:#ffb36b}.tier.B{background:#e8d27a}.tier.C{background:#8fd4a5}.tier.D{background:#8DA2C0}
.wbar{height:6px;border-radius:99px;background:#261C1B;overflow:hidden;width:110px}.wbar i{display:block;height:100%;background:#6BBF8A}
.cal{overflow-x:auto;padding-bottom:6px}.cal-g{display:grid;grid-auto-flow:column;grid-template-rows:repeat(7,14px);grid-auto-columns:14px;gap:3px;justify-content:start}
.cal-g i{width:14px;height:14px;border-radius:3px;background:#2C2120;display:block}
.cal-g i.n1{background:#3b4a6b}.cal-g i.n2{background:#5f7bb8}.cal-g i.n3{background:#8fb1ff}.cal-g i.w{box-shadow:inset 0 -3px 0 #6BBF8A}.cal-g i.l{box-shadow:inset 0 -3px 0 #D9534F}
.cal-m{display:flex;gap:0;white-space:nowrap;overflow:visible;font-size:11px;color:var(--mute);margin:0 0 4px}.cal-k{display:flex;gap:10px;align-items:center;font-size:12px;color:var(--mute);margin-top:8px}
.cal-k i{width:12px;height:12px;border-radius:3px;display:inline-block}
.hbars{display:flex;gap:4px;align-items:end;height:120px;margin-top:8px}.hbars div{flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;font-size:10.5px;color:var(--mute)}
.hbars span{width:100%;border-radius:5px 5px 0 0;background:#3b4a6b;display:block;position:relative}.hbars span.g{background:#6BBF8A}.hbars span.r{background:#D9534F}
.pch{display:flex;flex-direction:column;gap:10px}.pch .it{border:1px solid var(--rule);border-radius:14px;padding:12px 14px;background:var(--panel);display:grid;grid-template-columns:auto minmax(0,1fr) auto;gap:12px;align-items:start}
.pch .it h3{margin:0;font:700 15px var(--head);color:#fff}.pch .it ul{margin:6px 0 0;padding-left:18px;font-size:13px;color:#D6CCC0}
.pch .it ul{list-style:none;padding-left:0}.pch .it li{margin:6px 0;line-height:1.45}.pch .it li b{color:#fff;margin-right:6px}.pch .it li .was,.pch .it li .now{display:block;margin-top:2px}.pch .it li .was{color:#8F8378;text-decoration:line-through;text-decoration-color:rgba(232,129,124,.5)}.pch .it li .now{color:#F0E4CC}.pch .pt{display:inline-block;font:700 10px var(--head);text-transform:uppercase;letter-spacing:.04em;padding:2px 7px;border-radius:6px;margin-right:8px;font-style:normal;vertical-align:1px}.pch .pt.up{background:rgba(107,191,138,.18);color:#8FD4A8}.pch .pt.dn{background:rgba(217,83,79,.18);color:#E8817C}.pch .pt.mx{background:rgba(233,196,106,.16);color:var(--gold)}.pch .tg{font:700 11px var(--head);padding:3px 9px;border-radius:999px;background:#2C2120;color:#D6CCC0}
.pch .tg.up{background:rgba(107,191,138,.16);color:#8FD4A8}.pch .tg.dn{background:rgba(217,83,79,.14);color:#E8817C}.pch .tg.mx{background:rgba(233,196,106,.16);color:var(--gold)}
.psum{border:1px solid rgba(233,196,106,.4);border-radius:14px;padding:14px 16px;background:rgba(233,196,106,.06);margin-bottom:14px}.psum p{margin:4px 0;color:#F0E4CC}
.pdl-m{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}.pdl-m span{font-size:12px;padding:4px 10px;border-radius:999px;background:#261C1B;color:#D6CCC0;border:1px solid var(--rule)}
.pdl-m span b{color:var(--gold)}
svg.pdl .ln{fill:none;stroke:var(--gold);stroke-width:2}svg.pdl .ex{fill:none;stroke:#8DA2C0;stroke-width:2;stroke-dasharray:4 4}
svg.pdl .mk{stroke:#fff;stroke-width:1.5}svg.pdl text{font:600 10px var(--body);fill:var(--mute)}
.kb-help{position:fixed;inset:0;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;z-index:9999}
.kb-help>div{background:var(--panel);border:1px solid var(--rule);border-radius:16px;padding:20px 24px;min-width:340px}
.kb-help h3{margin:0 0 10px;color:#fff}.kb-help li{display:flex;justify-content:space-between;gap:20px;padding:4px 0;color:#D6CCC0;font-size:14px}
.kb-help kbd{font:700 12px var(--mono);background:#261C1B;border:1px solid var(--rule);border-radius:6px;padding:2px 7px;color:#fff}
"""


def _sw(w, n):
    return draft.smooth(w, n)


# ---------------- explorador de duelos ----------------
def duel_rows(con, mine, opp):
    """Partidas dos melhores em que `mine` enfrentou `opp` na mesma rota."""
    return con.execute(
        """SELECT p1.*, m.duration_s, x.items, x.perks, x.spells FROM participants p1 JOIN participants p2 ON p2.match_id=p1.match_id AND p2.team_id<>p1.team_id
           AND p2.position=p1.position JOIN match_source s ON s.match_id=p1.match_id JOIN matches m ON m.match_id=p1.match_id
           LEFT JOIN participant_extra x ON x.match_id=p1.match_id AND x.participant_id=p1.participant_id
           WHERE s.source='top' AND p1.champion=? AND p2.champion=?""", (mine, opp)).fetchall()


def duel_page(con, puuid, mine, opp, champs, ddir, items, ver, champ_options):
    opts = "".join(f"<option value='{e(k)}'>{e(v.get('name', k))}</option>" for k, v in sorted(champs.items(), key=lambda kv: kv[1].get("name", kv[0])))
    form = (f"<form class='p4-f' method='get' action='/duelos'><datalist id='chl'>{opts}</datalist>"
            f"<label>Seu campeão<input name='a' list='chl' value='{e(mine or '')}' placeholder='ex.: Zed'></label>"
            f"<label>Contra<input name='b' list='chl' value='{e(opp or '')}' placeholder='ex.: Ahri'></label><button class='btn gold'>Ver duelo</button></form>")
    if not mine or not opp:
        common = report.by_key(report.my_games(con, puuid, ""), "opp_champion", min_games=2)[:8]
        sug = "".join(f"<a class='btn' href='/duelos?a={e(mine or '')}&b={e(r[0])}'>{icons.champ(r[0], 22)} {e(r[0])}</a> " for r in common if r[0])
        return form + ("<p class='n'>Escolha os dois campeões. Seus oponentes mais comuns:</p><div class='row' style='flex-wrap:wrap;gap:8px'>" + sug + "</div>" if sug else "")
    name = lambda k: (champs.get(k) or {}).get("name", k)
    mg = [g for g in report.my_games(con, puuid, "") if g["champion"] == mine and (g.get("opp_champion") or "") == opp]
    anyvs = [g for g in report.my_games(con, puuid, "") if (g.get("opp_champion") or "") == opp]
    rows = duel_rows(con, mine, opp)
    tw = sum(r["win"] for r in rows)
    rev = duel_rows(con, opp, mine)
    head = (f"<div class='duel-h'><div class='s'>{icons.champ(mine, 72, 'me')}<div><small class='n'>Você</small><b>{e(name(mine))}</b></div></div>"
            f"<span class='vs'>VS</span><div class='s r'><div><small class='n'>Oponente</small><b>{e(name(opp))}</b></div>{icons.champ(opp, 72, 'foe')}</div></div>")
    def kv(lbl, val, sub, cls=""):
        return f"<div class='kv4'><small>{e(lbl)}</small><b class='{cls}'>{val}</b><span>{e(sub)}</span></div>"
    mw = sum(1 for g in mg if g["win"])
    nums = "<div class='duel-g'>"
    nums += kv("Seu histórico", f"{mw}V {len(mg) - mw}D" if mg else "–", f"com {name(mine)} contra {name(opp)}" if mg else "você ainda não jogou esse duelo",
               "w" if mg and mw * 2 >= len(mg) else "l" if mg else "")
    aw = sum(1 for g in anyvs if g["win"])
    nums += kv("Contra ele com qualquer campeão", f"{round(100 * aw / len(anyvs))}%" if anyvs else "–", f"{len(anyvs)} partidas suas")
    if rows:
        nums += kv("Entre os melhores", f"{round(100 * tw / len(rows))}%", f"{name(mine)} venceu {tw} de {len(rows)} partidas", "w" if tw * 2 >= len(rows) else "l")
    elif rev:
        rw = sum(r["win"] for r in rev)
        nums += kv("Entre os melhores", f"{round(100 * (len(rev) - rw) / len(rev))}%", f"pelo lado de {name(opp)} ({len(rev)} partidas)")
    else:
        nums += kv("Entre os melhores", "–", "sem partidas desse duelo na amostra")
    nums += "</div>"
    out = form + head + nums
    # numeros do duelo entre os melhores: farm e ouro aos 10/15
    if rows:
        d10, g15 = [], []
        for r in rows:
            opp_pid = con.execute("SELECT participant_id FROM participants WHERE match_id=? AND team_id<>? AND position=?",
                                  (r["match_id"], r["team_id"], r["position"])).fetchone()
            if not opp_pid:
                continue
            a = con.execute("SELECT cs, gold FROM frames WHERE match_id=? AND participant_id=? AND minute=10", (r["match_id"], r["participant_id"])).fetchone()
            b = con.execute("SELECT cs, gold FROM frames WHERE match_id=? AND participant_id=? AND minute=10", (r["match_id"], opp_pid[0])).fetchone()
            if a and b:
                d10.append(a["cs"] - b["cs"])
            a = con.execute("SELECT gold FROM frames WHERE match_id=? AND participant_id=? AND minute=15", (r["match_id"], r["participant_id"])).fetchone()
            b = con.execute("SELECT gold FROM frames WHERE match_id=? AND participant_id=? AND minute=15", (r["match_id"], opp_pid[0])).fetchone()
            if a and b:
                g15.append(a["gold"] - b["gold"])
        if d10 or g15:
            out += "<h2>Como o duelo anda entre os melhores</h2><div class='duel-g'>"
            if d10:
                v = sum(d10) / len(d10)
                out += kv("Farm aos 10 min", f"{v:+.0f}", f"média de {len(d10)} partidas", "w" if v >= 0 else "l")
            if g15:
                v = sum(g15) / len(g15)
                out += kv("Ouro aos 15 min", f"{v:+.0f}", f"média de {len(g15)} partidas", "w" if v >= 0 else "l")
            out += "</div>"
        if len(rows) >= 15 and items:
            st = builds.item_stats(con, rows, items)
            ks = builds.keystone_stats(rows)
            try:
                from . import champpage
                out += "<h2>O que os melhores fazem nesse duelo</h2><div class='card'>"
                if st["order"] and st["order"][0]:
                    out += champpage._items_row(builds.full_build(st)[:3], items, ver, "Primeiros itens (caminho dos melhores)")
                if st["boots"]:
                    out += champpage._items_row([st["boots"][0][0]], items, ver, "Botas")
                if ks:
                    k0 = ks[0]
                    out += f"<p class='n'><span class='tag dado'>dado</span> Runa mais usada no duelo: {e(_keystone_name(k0, ddir))} ({k0[1]} partidas, {round(100 * k0[2] / max(k0[1], 1))}% de vitória).</p>"
                out += "</div>"
            except Exception:
                pass
    # dicas oficiais e recargas do oponente
    try:
        from . import voicecues
        cds = voicecues.champ_cds(ddir, opp) or {}
        tips = cds.get("tips") or []
        out += "<h2>Como jogar contra " + e(name(opp)) + "</h2><div class='card'>"
        out += "".join(f"<p class='n' style='margin:6px 0'><span class='tag dado'>dica oficial</span> {e(t)}</p>" for t in tips[:4]) or "<p class='n'>Sem dicas oficiais.</p>"
        line = voicecues.cd_line(cds, 6)
        if line:
            out += f"<p class='n'><span class='tag dado'>dado</span> Recargas base: {e(line)}</p>"
        out += "</div>"
    except Exception:
        pass
    return out


def _keystone_name(k, ddir):
    try:
        from .ddragon import DataDragon
        return DataDragon(cache_dir=os.path.join(ddir, "cache")).rune_names().get(k[0][2][0]) or "runa principal"
    except Exception:
        return "runa principal"


# ---------------- tier list ----------------
def tier_rows(con, position):
    rows = con.execute(
        """SELECT p.champion, COUNT(*) n, SUM(p.win) w FROM participants p JOIN match_source s USING (match_id)
           WHERE s.source='top' AND p.position=? GROUP BY p.champion HAVING n >= 12""", (position,)).fetchall()
    total = con.execute("""SELECT COUNT(DISTINCT p.match_id) FROM participants p JOIN match_source s USING (match_id) WHERE s.source='top'""").fetchone()[0] or 1
    out = []
    for nm, n, w in rows:
        sw = ((w or 0) + 10) / (n + 20)     # suavizacao forte: amostra pequena fica perto de 50%
        out.append({"champion": nm, "n": n, "w": w or 0, "wr": 100 * (w or 0) / n, "sw": sw, "pick": 100 * n / total})
    out.sort(key=lambda r: -(r["sw"] + min(r["pick"], 15) / 400))
    for i, r in enumerate(out):
        q = i / max(len(out), 1)
        r["tier"] = "S" if q < 0.08 else "A" if q < 0.25 else "B" if q < 0.55 else "C" if q < 0.8 else "D"
    return out, total


def tierlist_page(con, puuid, position, champs, pool):
    segs = "".join(f"<a href='/tierlist?pos={p}' class='{'on' if p == position else ''}'>{LANE_PT[p]}</a>" for p in POSITIONS)
    rows, total = tier_rows(con, position)
    if not rows:
        return (f"<div class='p4-seg'>{segs}</div><div class='empty'><b>Sem amostra dessa rota ainda</b>"
                "<span>Em Sincronizar, baixe a amostra dos melhores: a tier list sai dessas partidas.</span></div>")
    mine = {g["champion"] for g in report.my_games(con, puuid, "")[:60]} | set(pool or [])
    body = (f"<div class='p4-seg'>{segs}</div><p class='n'><span class='tag dado'>dado</span> {total} partidas dos melhores do servidor guardadas pelo app. "
            "A ordem usa a vitória suavizada (poucos jogos puxam para 50%) e um pouco da popularidade. Linha dourada: campeão que você joga.</p>"
            "<table class='tl'><tr><th>#</th><th>Tier</th><th>Campeão</th><th>Vitória</th><th></th><th>Partidas</th><th>Escolha</th></tr>")
    for i, r in enumerate(rows, 1):
        nm = (champs.get(r["champion"]) or {}).get("name", r["champion"])
        body += (f"<tr class='{'mine' if r['champion'] in mine else ''}'><td>{i}</td><td><span class='tier {r['tier']}'>{r['tier']}</span></td>"
                 f"<td><a class='cn' href='/campeao/{e(icons.champ_id(r['champion']))}'>{icons.champ(r['champion'], 32)}<b>{e(nm)}</b></a></td>"
                 f"<td>{r['wr']:.1f}%</td><td><div class='wbar'><i style='width:{max(4, min(100, (r['wr'] - 35) * 3.3)):.0f}%'></i></div></td>"
                 f"<td>{r['n']}</td><td>{r['pick']:.1f}%</td></tr>")
    return body + "</table>"


# ---------------- calendario ----------------
QUEUES = {420: "Solo/Duo", 440: "Flex", 400: "Normal", 430: "Normal", 450: "ARAM", 490: "Normal rápida"}


def calendar_full(con, games, view, champ, queue, champs):
    """Filtros (campeao, fila, visao por dia/semana/mes) + tabela por periodo + o mapa de calor filtrado."""
    qmap = {r[0]: r[1] for r in con.execute("SELECT match_id, queue_id FROM matches")}
    cnames = sorted({g["champion"] for g in games})
    queues = sorted({qmap.get(g["match_id"]) for g in games if qmap.get(g["match_id"])})
    sel = [g for g in games if (not champ or g["champion"] == champ) and (not queue or str(qmap.get(g["match_id"])) == queue)]
    nm = lambda c: (champs.get(c) or {}).get("name", c)
    form = ("<form method='get' action='/calendario' class='p4-f'>"
            "<label>Visão<select name='vista'>" + "".join(f"<option value='{k}'{' selected' if view == k else ''}>{t}</option>" for k, t in (("dia", "Por dia"), ("semana", "Por semana"), ("mes", "Por mês"))) + "</select></label>"
            "<label>Campeão<select name='c'><option value=''>Todos</option>" + "".join(f"<option value='{e(c)}'{' selected' if champ == c else ''}>{e(nm(c))}</option>" for c in cnames) + "</select></label>"
            "<label>Fila<select name='fila'><option value=''>Todas</option>" + "".join(f"<option value='{q}'{' selected' if queue == str(q) else ''}>{e(QUEUES.get(q, q))}</option>" for q in queues) + "</select></label>"
            "<button class='btn gold'>Filtrar</button></form>")
    if not sel:
        return form + "<div class='empty'><b>Nenhuma partida com esse filtro</b></div>"
    def key(g):
        lt = time.localtime(g["started_ms"] / 1000)
        if view == "mes":
            return time.strftime("%Y-%m", lt), time.strftime("%m/%Y", lt)
        if view == "semana":
            mon = g["started_ms"] / 1000 - lt.tm_wday * 86400
            return time.strftime("%Y-%m-%d", time.localtime(mon)), "semana de " + time.strftime("%d/%m", time.localtime(mon))
        return time.strftime("%Y-%m-%d", lt), time.strftime("%a %d/%m", lt).replace("Mon", "seg").replace("Tue", "ter").replace("Wed", "qua").replace("Thu", "qui").replace("Fri", "sex").replace("Sat", "sáb").replace("Sun", "dom")
    groups = {}
    for g in sel:
        k, lb = key(g)
        groups.setdefault(k, [lb, []])[1].append(g)
    rows = ""
    for k in sorted(groups, reverse=True)[:60]:
        lb, gs = groups[k]
        n = len(gs)
        w = sum(1 for g in gs if g["win"])
        ranked = [g for g in gs if qmap.get(g["match_id"]) == 420]
        lp = sum(WIN_LP if g["win"] else -LOSS_LP for g in ranked)
        cspm = sum(g["cs"] / max(1, (g["duration_s"] or 60) / 60) for g in gs) / n
        k_, d_, a_ = (sum(g[x] for g in gs) / n for x in ("kills", "deaths", "assists"))
        champs_used = {}
        for g in gs:
            champs_used[g["champion"]] = champs_used.get(g["champion"], 0) + 1
        top = sorted(champs_used.items(), key=lambda kv: -kv[1])[:3]
        rows += (f"<tr><td><b>{e(lb)}</b></td><td>{n}</td><td><span class='g'>{w}V</span> <span class='r'>{n - w}D</span></td>"
                 f"<td class='{'g' if w * 2 > n else 'r' if w * 2 < n else ''}'>{round(100 * w / n)}%</td>"
                 f"<td class='{'g' if lp > 0 else 'r' if lp < 0 else ''}'>{'+' if lp > 0 else ''}{lp if ranked else '–'}</td>"
                 f"<td>{cspm:.1f}</td><td>{k_:.1f} / {d_:.1f} / {a_:.1f}</td>"
                 f"<td>{''.join(icons.champ(c, 22) for c, _ in top)}</td></tr>")
    tw = sum(1 for g in sel if g["win"])
    table = (f"<div class='card'><b class='gl'>{len(sel)} partidas · {tw}V {len(sel) - tw}D ({round(100 * tw / len(sel))}%)</b>"
             "<table class='tl cal-t'><tr><th>Período</th><th>Partidas</th><th>Resultado</th><th>Vitória</th><th>PDL (estimado)</th><th>Farm/min</th><th>K / D / A</th><th>Campeões</th></tr>"
             + rows + "</table><p class='n'><span class='tag hipotese'>hipótese</span> PDL estimado: +21 por vitória e -19 por derrota na Solo/Duo (a Riot não informa o PDL de cada partida).</p></div>")
    return form + calendar_page(sel) + "<h2>Por período</h2>" + table


def calendar_page(games):
    if not games:
        return "<div class='empty'><b>Sem partidas</b><span>Sincronize para ver o calendário.</span></div>"
    by_day = defaultdict(list)
    for g in games:
        by_day[time.strftime("%Y-%m-%d", time.localtime(g["started_ms"] / 1000))].append(g)
    today = time.time()
    start = today - 364 * 86400
    lt = time.localtime(start)
    start -= lt.tm_wday * 86400 if lt.tm_wday != 6 else 0   # comeca no domingo da semana
    start -= ((time.localtime(start).tm_wday + 1) % 7) * 86400
    cells, months, last_m = [], [], None
    t = start
    col = 0
    while t <= today:
        d = time.strftime("%Y-%m-%d", time.localtime(t))
        gs = by_day.get(d, [])
        n = len(gs)
        w = sum(1 for g in gs if g["win"])
        cls = ("n3" if n >= 5 else "n2" if n >= 3 else "n1" if n else "") + ((" w" if w * 2 > n else " l" if w * 2 < n else "") if n else "")
        tip = f"{time.strftime('%d/%m', time.localtime(t))}: " + (f"{n} partidas, {w}V {n - w}D" if n else "sem partidas")
        cells.append(f"<i class='{cls}' title='{e(tip)}'></i>")
        if time.localtime(t).tm_wday == 6:
            m = time.strftime("%m", time.localtime(t))
            months.append(m if m != last_m else "")
            last_m = m
        t += 86400
    MN = {"01": "jan", "02": "fev", "03": "mar", "04": "abr", "05": "mai", "06": "jun", "07": "jul", "08": "ago", "09": "set", "10": "out", "11": "nov", "12": "dez"}
    mrow = "".join(f"<span style='width:17px;flex:none'>{MN.get(m, '')}</span>" for m in months)
    days = len(by_day)
    best = max(by_day.items(), key=lambda kv: len(kv[1]))
    body = (f"<p class='n'>{len(games)} partidas em {days} dias diferentes. Dia com mais partidas: "
            f"{time.strftime('%d/%m/%Y', time.strptime(best[0], '%Y-%m-%d'))} ({len(best[1])}).</p>"
            f"<div class='card cal'><div class='cal-m'>{mrow}</div><div class='cal-g'>{''.join(cells)}</div>"
            "<div class='cal-k'><span><i style='background:#3b4a6b'></i> 1-2</span><span><i style='background:#5f7bb8'></i> 3-4</span>"
            "<span><i style='background:#8fb1ff'></i> 5+</span><span><i style='background:#211918;box-shadow:inset 0 -3px 0 #6BBF8A'></i> mais vitórias</span>"
            "<span><i style='background:#211918;box-shadow:inset 0 -3px 0 #D9534F'></i> mais derrotas</span></div></div>")
    # dia da semana e hora
    wd = defaultdict(list)
    hr = defaultdict(list)
    for g in games:
        lt = time.localtime(g["started_ms"] / 1000)
        wd[lt.tm_wday].append(g["win"])
        hr[lt.tm_hour // 3].append(g["win"])
    WDN = ["seg", "ter", "qua", "qui", "sex", "sáb", "dom"]
    def bars(groups, labels):
        mx = max((len(v) for v in groups.values()), default=1)
        out = "<div class='hbars'>"
        for k, lb in labels:
            v = groups.get(k, [])
            wr = round(100 * sum(v) / len(v)) if v else None
            h = 8 + 100 * len(v) / mx if v else 4
            cls = "g" if wr is not None and wr >= 55 and len(v) >= 3 else "r" if wr is not None and wr <= 45 and len(v) >= 3 else ""
            out += f"<div title='{len(v)} partidas'><small>{'' if wr is None else str(wr) + '%'}</small><span class='{cls}' style='height:{h:.0f}px'></span>{lb}</div>"
        return out + "</div>"
    body += ("<div class='hpn-2 hpn-gap' style='margin-top:16px'><div class='card'><b class='gl'>Vitória por dia da semana</b>"
             + bars(wd, list(enumerate(WDN))) + "</div><div class='card'><b class='gl'>Vitória por horário</b>"
             + bars(hr, [(i, f"{i * 3}h") for i in range(8)]) + "<p class='n'>Verde: 55%+ (3 jogos ou mais). Vermelho: 45% ou menos.</p></div></div>")
    return body


# ---------------- historico de PDL ----------------
WIN_LP, LOSS_LP = 21, 19   # media aproximada (hipotese): a Riot nao informa o PDL de cada partida


def lp_series(con, puuid, hist):
    """Linha estimada partida a partida, ancorada no ultimo PDL conhecido, e as marcacoes de troca."""
    rows = con.execute(
        """SELECT p.match_id, p.champion, p.position, p.win, m.started_ms, x.perks FROM participants p JOIN matches m USING (match_id)
           LEFT JOIN participant_extra x ON x.match_id=p.match_id AND x.participant_id=p.participant_id
           WHERE p.puuid=? AND m.queue_id=420 AND COALESCE(m.duration_s,0)>=300 ORDER BY m.started_ms""", (puuid,)).fetchall()
    if not rows or not hist:
        return [], []
    v = hist[-1]["v"]
    anchor_t = hist[-1]["at_ms"]
    pts = []
    for r in reversed(rows):
        if r["started_ms"] > anchor_t:
            continue
        pts.append({"t": r["started_ms"], "v": v, "r": r})
        v -= WIN_LP if r["win"] else -LOSS_LP
    pts.reverse()
    marks = []
    prev = None
    recent = []
    roles = []
    main_role = None
    for p in pts:
        r = p["r"]
        ks = None
        try:
            pg = builds.page_from_perks(json.loads(r["perks"] or "null"))
            ks = pg[2][0] if pg else None
        except Exception:
            pass
        cur = (r["champion"], r["position"], ks)
        roles = (roles + [r["position"]])[-5:]
        mode = Counter(x for x in roles if x).most_common(1)
        mode = mode[0][0] if mode and mode[0][1] >= 3 else main_role
        if prev:
            if mode and main_role and mode != main_role:
                marks.append({"t": p["t"], "v": p["v"], "k": "rota", "txt": f"rota principal: {LANE_PT.get(main_role, main_role)} para {LANE_PT.get(mode, mode)}"})
            elif r["champion"] != prev[0] and recent.count(r["champion"]) == 0 and len(recent) >= 3:
                marks.append({"t": p["t"], "v": p["v"], "k": "camp", "txt": f"campeão novo: {r['champion']}"})
            elif ks and prev[2] and ks != prev[2] and r["champion"] == prev[0]:
                marks.append({"t": p["t"], "v": p["v"], "k": "runa", "txt": f"runa trocada com {r['champion']}"})
        prev = cur
        main_role = mode or main_role
        recent = (recent + [r["champion"]])[-8:]
    return pts, marks


def _rank_of(v):
    """Numero da escada -> ('EMERALD', 'I', 65)."""
    if v >= ranks.APEX:
        return "MASTER", "", int(v - ranks.APEX)
    v = max(0, v)
    t = ranks.TIERS[min(int(v // 400), 6)]
    d = ["IV", "III", "II", "I"][min(int((v % 400) // 100), 3)]
    return t, d, int(v % 100)


def _rank_txt(v):
    t, d, lp = _rank_of(v)
    return f"{ranks.TIER_PT[t]} {d} · {lp} PDL".replace("  ", " ")


def _smooth_path(pts):
    """Curva suave (Catmull-Rom para Bezier) passando pelos pontos."""
    if len(pts) < 3:
        return "M" + " L".join(f"{x:.1f},{y:.1f}" for x, y in pts)
    d = f"M{pts[0][0]:.1f},{pts[0][1]:.1f}"
    for i in range(len(pts) - 1):
        p0 = pts[i - 1] if i else pts[i]
        p1, p2 = pts[i], pts[i + 1]
        p3 = pts[i + 2] if i + 2 < len(pts) else p2
        c1 = (p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6)
        c2 = (p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6)
        d += f" C{c1[0]:.1f},{c1[1]:.1f} {c2[0]:.1f},{c2[1]:.1f} {p2[0]:.1f},{p2[1]:.1f}"
    return d


PDL_CSS = """
.pdlc{position:relative}.pdlc svg{width:100%;height:auto;display:block;touch-action:none}
.pdlc .band-l{font:700 12px var(--head)}.pdlc .div-l{font:600 10px var(--mono);fill:#7C716A}
.pdlc .ax{font:600 11px var(--body);fill:#9A8F86}.pdlc .step{fill:none;stroke:#F2B04A;stroke-width:2.4;stroke-linejoin:round}
.pdlc .xh{stroke:rgba(255,255,255,.35);stroke-width:1;stroke-dasharray:3 4}.pdlc .xd{fill:#E9A23B;stroke:#150F0F;stroke-width:2}
.pdlc .real{fill:#fff;opacity:.85}.pdlc .zsel{fill:rgba(233,196,106,.15);stroke:#E9C46A;stroke-dasharray:4 3}.pdlc svg{cursor:crosshair}.pdlc .bw{fill:#3E9B6A}.pdlc .bl{fill:#C2453F}
.pdl-tip{position:absolute;pointer-events:none;background:#1E1716;border:1px solid var(--rule);border-radius:10px;padding:7px 10px;font-size:12.5px;color:#F0E4CC;
white-space:nowrap;transform:translate(-50%,-115%);box-shadow:0 8px 24px rgba(0,0,0,.45);display:none;z-index:4}.pdl-tip b{color:#fff}
.lpb{font:700 12.5px var(--mono,monospace)}.lpb.w{color:#8FD4A8}.lpb.l{color:#E8817C}
.pdl-top{display:flex;gap:14px;flex-wrap:wrap;margin:0 0 14px}
.pdl-top .kv4{flex:1;min-width:180px;flex-direction:row;align-items:center;gap:12px}
.pdl-top .kv4 img{width:54px;height:54px;object-fit:contain}.pdl-top .kv4 div{display:flex;flex-direction:column}
.pdl-top .kv4 b{font-size:20px}
.pdl-per{display:flex;gap:6px;margin:0 0 12px;flex-wrap:wrap}.pdl-per a{padding:7px 14px;border-radius:999px;border:1px solid var(--rule);color:#D6CCC0;text-decoration:none;font:600 13px var(--body)}
.pdl-per a.on{background:var(--gold);color:#1a1405;border-color:var(--gold)}
.pdl-leg{display:flex;gap:14px;flex-wrap:wrap;font-size:12px;color:var(--mute);margin-top:8px}.pdl-leg i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:5px;vertical-align:-1px}
"""

PDL_JS = """<script>(function(){document.querySelectorAll('.pdlc').forEach(function(c){if(c.dataset.on)return;c.dataset.on=1;
var D=JSON.parse(c.dataset.pts||'[]'),svg=c.querySelector('svg'),tip=c.querySelector('.pdl-tip'),xh=svg.querySelector('.xh'),xd=svg.querySelector('.xd'),zs=svg.querySelector('.zsel');
if(!D.length)return;var L=+c.dataset.l,R=+c.dataset.r,drag=null;
function sx(ev){var r=svg.getBoundingClientRect(),vb=svg.viewBox.baseVal;return [(ev.clientX-r.left)*vb.width/r.width,r,vb]}
function near(x){var best=D[0],bd=1e9;for(var i=0;i<D.length;i++){var d=Math.abs(D[i][0]-x);if(d<bd){bd=d;best=D[i]}}return best}
function tAt(x){var a=null,b=null;for(var i=0;i<D.length;i++){if(D[i][0]<=x)a=D[i];if(D[i][0]>=x&&!b)b=D[i]}a=a||D[0];b=b||D[D.length-1];
if(b[0]===a[0])return a[3];return a[3]+(b[3]-a[3])*(x-a[0])/(b[0]-a[0])}
function mv(ev){var s=sx(ev),x=s[0],r=s[1],vb=s[2],best=near(x);
if(drag!==null){var a=Math.max(L,Math.min(drag,x)),b=Math.min(R,Math.max(drag,x));zs.setAttribute('x',a);zs.setAttribute('width',b-a);zs.style.display=''}
xh.setAttribute('x1',best[0]);xh.setAttribute('x2',best[0]);xh.style.display='';xd.setAttribute('cx',best[0]);xd.setAttribute('cy',best[1]);xd.style.display='';
tip.innerHTML=best[2];tip.style.display='block';tip.style.left=(best[0]*r.width/vb.width)+'px';tip.style.top=(best[1]*r.height/vb.height)+'px'}
svg.addEventListener('pointermove',mv);svg.addEventListener('pointerleave',function(){tip.style.display='none';xh.style.display='none';xd.style.display='none'});
if(c.dataset.zoom==='1'){svg.addEventListener('pointerdown',function(ev){drag=sx(ev)[0];svg.setPointerCapture(ev.pointerId)});
svg.addEventListener('pointerup',function(ev){if(drag===null)return;var x=sx(ev)[0],a=Math.min(drag,x),b=Math.max(drag,x);drag=null;zs.style.display='none';
if(b-a<12)return;var u=new URL(location.href);u.searchParams.set('de',Math.round(tAt(a)));u.searchParams.set('ate',Math.round(tAt(b)));location.href=u.toString()})}})})();</script>"""


def _anchored(pts, hist):
    """Corrige a linha estimada para passar pelos PDL reais guardados (o erro e distribuido entre um ponto real e outro)."""
    if not pts or not hist:
        return pts
    anchors = []
    for h in hist:
        before = [i for i, p in enumerate(pts) if p["t"] <= h["at_ms"]]
        if not before:
            continue
        i = before[-1]
        after_v = pts[i]["v"] + (WIN_LP if pts[i]["r"]["win"] else -LOSS_LP)      # PDL depois da partida i
        anchors.append((i, h["v"] - after_v))
    if not anchors:
        return pts
    ai = {}
    for i, off in anchors:
        ai[i] = off
    idx = sorted(ai)
    out = []
    for k, p in enumerate(pts):
        if k <= idx[0]:
            off = ai[idx[0]]
        elif k >= idx[-1]:
            off = ai[idx[-1]]
        else:
            j = next(n for n in range(len(idx) - 1) if idx[n] <= k <= idx[n + 1])
            a_, b_ = idx[j], idx[j + 1]
            off = ai[a_] + (ai[b_] - ai[a_]) * (k - a_) / max(b_ - a_, 1)
        out.append(dict(p, v=p["v"] + off))
    return out


def lp_per_game(con, puuid):
    """{match_id: (pdl, real)} de todas as ranqueadas solo: real quando o app guardou o elo antes e depois da partida;
    senao, a estimativa corrigida pelos pontos reais (assim a soma bate com o PDL de verdade)."""
    hist = ranks.history(con)
    pts, _ = lp_series(con, puuid, hist)
    if not pts:
        return {}
    pts = _anchored(pts, hist)
    out = {}
    end_v = hist[-1]["v"] if hist else None
    for i, p in enumerate(pts):
        nxt = pts[i + 1]["v"] if i + 1 < len(pts) else end_v
        if nxt is None:
            continue
        out[p["r"]["match_id"]] = (int(round(nxt - p["v"])), False)
    try:
        from . import desempenho
        real = desempenho.lp_by_match(con, [{"match_id": p["r"]["match_id"], "started_ms": p["t"],
                                             "duration_s": (con.execute("SELECT duration_s FROM matches WHERE match_id=?", (p["r"]["match_id"],)).fetchone() or [0])[0]}
                                            for p in pts[-200:]])
        for k, v in real.items():
            out[k] = (int(v), True)
    except Exception:
        pass
    return out


def lp_badge(x):
    """'+21' (real) ou '~+19' (estimado) com a cor certa."""
    if not x:
        return ""
    v, real = x
    return f"<span class='lpb {'w' if v >= 0 else 'l'}' title='{'PDL real' if real else 'estimado'}'>{'' if real else '~'}{v:+d}</span>"


def pdl_seq(con, puuid, hist, t_from=0, t_to=None):
    """Partidas ranqueadas com o PDL antes (v0) e depois (v) de cada uma, corrigido pelos pontos reais."""
    pts, marks = lp_series(con, puuid, hist)
    if len(pts) < 2:
        return [], marks
    pts = _anchored(pts, hist)
    seq = []
    for i, p in enumerate(pts):
        nxt = pts[i + 1]["v"] if i + 1 < len(pts) else (hist[-1]["v"] if hist else p["v"] + (WIN_LP if p["r"]["win"] else -LOSS_LP))
        seq.append({"t": p["t"], "v0": p["v"], "v": nxt, "r": p["r"]})
    sel = [d for d in seq if d["t"] >= t_from and (t_to is None or d["t"] <= t_to)]
    return sel, marks


def pdl_svg(seq, hist, colors, H=470, CH=330, bars=True, zoom=True, emblems=True):
    """O grafico de PDL (degraus + area + barras de vitoria/derrota), com mouse em cima e zoom por arrasto."""
    from . import ranksimg
    emb = lambda t: f"/static/ranks/{t.lower()}.png" if (emblems and ranksimg.available(t)) else None
    W, L, R, T = 1100, 120, 24, 16
    if not bars:
        H = CH + 26
    vs = [d["v"] for d in seq] + [seq[0]["v0"]]
    lo = (min(vs) // 100) * 100 - 20
    hi = (max(vs) // 100 + 1) * 100 + 20
    t0, t1 = seq[0]["t"], max(seq[-1]["t"], seq[0]["t"] + 3600000)
    X = lambda t: L + (W - L - R) * (t - t0) / max(t1 - t0, 1)
    Y = lambda v: T + (CH - T) * (1 - (v - lo) / max(hi - lo, 1))
    g = ""
    for i, tn in enumerate(ranks.TIERS[:7]):
        b0, b1 = i * 400, (i + 1) * 400
        if b1 <= lo or b0 >= hi:
            continue
        y0, y1 = Y(min(b1, hi)), Y(max(b0, lo))
        c = colors.get(tn, "#888")
        g += f"<rect x='{L}' y='{y0:.1f}' width='{W - L - R}' height='{y1 - y0:.1f}' fill='{c}' opacity='.07'/>"
        if lo < b0 < hi:
            g += f"<line x1='{L}' x2='{W - R}' y1='{Y(b0):.1f}' y2='{Y(b0):.1f}' stroke='{c}' stroke-opacity='.6'/>"
        cy = (y0 + y1) / 2
        im = emb(tn)
        if y1 - y0 > 30:
            if im:
                g += f"<image href='{im}' x='4' y='{cy - 20:.1f}' width='36' height='36'/>"
            g += f"<text x='{44 if im else 10}' y='{cy + 4:.1f}' class='band-l' fill='{c}'>{e(ranks.TIER_PT[tn])}</text>"
        for d in range(1, 4):
            yv = b0 + d * 100
            if lo < yv < hi:
                g += f"<line x1='{L}' x2='{W - R}' y1='{Y(yv):.1f}' y2='{Y(yv):.1f}' stroke='rgba(255,255,255,.06)' stroke-dasharray='2 5'/>"
        for d in range(4):
            yv = b0 + d * 100 + 50
            if lo < yv < hi:
                g += f"<text x='{L - 8}' y='{Y(yv) + 3:.1f}' class='div-l' text-anchor='end'>{['IV', 'III', 'II', 'I'][d]}</text>"
    MN = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"]
    span_d = (t1 - t0) / 86400000
    ticks = []
    if span_d > 70:
        lt = time.localtime(t0 / 1000)
        y_, m_ = lt.tm_year, lt.tm_mon
        while True:
            m_ += 1
            if m_ > 12:
                m_, y_ = 1, y_ + 1
            tm = time.mktime((y_, m_, 1, 0, 0, 0, 0, 0, -1)) * 1000
            if tm > t1:
                break
            ticks.append((tm, MN[m_ - 1]))
    elif span_d > 1.5:
        step = 7 if span_d > 20 else 3 if span_d > 8 else 1
        tm = time.mktime(time.localtime(t0 / 1000)[:3] + (0, 0, 0, 0, 0, -1)) * 1000 + 86400000
        while tm < t1:
            ticks.append((tm, time.strftime("%d/%m", time.localtime(tm / 1000))))
            tm += step * 86400000
    else:
        tm = (t0 // 3600000 + 1) * 3600000
        while tm < t1:
            ticks.append((tm, time.strftime("%Hh", time.localtime(tm / 1000))))
            tm += 3600000 * (2 if span_d > 0.5 else 1)
    for tm, lab in ticks:
        g += (f"<line x1='{X(tm):.1f}' x2='{X(tm):.1f}' y1='{T}' y2='{CH}' stroke='rgba(255,255,255,.05)'/>"
              f"<text x='{X(tm):.1f}' y='{CH + 16}' class='ax' text-anchor='middle'>{lab}</text>")
    x_prev, y_prev = X(seq[0]["t"]), Y(seq[0]["v0"])
    path = f"M{x_prev:.1f},{y_prev:.1f}"
    data = []
    for d in seq:
        x, y = X(d["t"]), Y(d["v"])
        path += f" H{x:.1f} V{y:.1f}"
        r = d["r"]
        dl = int(round(d["v"] - d["v0"]))
        data.append([round(x, 1), round(y, 1),
                     f"<b>{e(_rank_txt(d['v']))}</b> <span style='color:{'#8FD4A8' if dl >= 0 else '#E8817C'}'>{dl:+d}</span><br>"
                     f"{time.strftime('%d/%m %H:%M', time.localtime(d['t'] / 1000))} · {e(r['champion'])} · {'vitória' if r['win'] else 'derrota'}", d["t"]])
    path += f" H{W - R:.1f}"
    area = path + f" V{CH} H{X(seq[0]['t']):.1f} Z"
    g = (f"<defs><linearGradient id='pdla' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#F2B04A' stop-opacity='.45'/>"
         f"<stop offset='.6' stop-color='#E9A23B' stop-opacity='.12'/><stop offset='1' stop-color='#E9A23B' stop-opacity='0'/></linearGradient>"
         f"<filter id='pglow' x='-5%' y='-20%' width='110%' height='140%'><feGaussianBlur stdDeviation='3' result='b'/><feMerge><feMergeNode in='b'/><feMergeNode in='SourceGraphic'/></feMerge></filter></defs>"
         f"<rect x='{L}' y='{T}' width='{W - L - R}' height='{CH - T}' fill='rgba(255,255,255,.015)' rx='6'/>"
         + g + f"<path d='{area}' fill='url(#pdla)'/><path d='{path}' class='step' filter='url(#pglow)'/>")
    for h_ in hist:
        if t0 <= h_["at_ms"] <= t1 + 3600000 and lo <= h_["v"] <= hi:
            g += f"<circle cx='{X(min(h_['at_ms'], t1)):.1f}' cy='{Y(h_['v']):.1f}' r='2.2' class='real'><title>PDL guardado: {_rank_txt(h_['v'])}</title></circle>"
    pk = max(seq, key=lambda d: d["v"])
    g += (f"<circle cx='{X(pk['t']):.1f}' cy='{Y(pk['v']):.1f}' r='5' fill='none' stroke='#fff' stroke-width='1.5'/>"
          f"<text x='{X(pk['t']):.1f}' y='{Y(pk['v']) - 10:.1f}' class='ax' text-anchor='middle' fill='#fff'>pico</text>")
    if bars:
        bucket = 86400000 * (7 if span_d > 45 else 1)
        bk = {}
        for d in seq:
            k = int((d["t"] - t0) // bucket)
            b = bk.setdefault(k, [0, 0])
            b[0 if d["r"]["win"] else 1] += 1
        mx = max([max(b) for b in bk.values()] + [1])
        base = CH + 70
        bw = max(3, min(28, (W - L - R) * bucket / max(t1 - t0, 1) * 0.6))
        g += f"<line x1='{L}' x2='{W - R}' y1='{base}' y2='{base}' stroke='rgba(255,255,255,.12)'/>"
        g += f"<text x='{L - 8}' y='{base - 22}' class='ax' text-anchor='end' fill='#3E9B6A'>V</text><text x='{L - 8}' y='{base + 30}' class='ax' text-anchor='end' fill='#C2453F'>D</text>"
        for k, (w_, l_) in bk.items():
            xc = min(X(t0 + (k + 0.5) * bucket), W - R - bw / 2)
            hw, hl = 38 * w_ / mx, 38 * l_ / mx
            g += (f"<rect x='{xc - bw / 2:.1f}' y='{base - hw:.1f}' width='{bw:.1f}' height='{hw:.1f}' rx='2' class='bw'><title>{w_} vitórias</title></rect>"
                  f"<rect x='{xc - bw / 2:.1f}' y='{base:.1f}' width='{bw:.1f}' height='{hl:.1f}' rx='2' class='bl'><title>{l_} derrotas</title></rect>")
    g += (f"<line class='xh' x1='0' x2='0' y1='{T}' y2='{CH}' style='display:none'/><circle class='xd' r='5' style='display:none'/>"
          f"<rect class='zsel' x='0' y='{T}' width='0' height='{CH - T}' style='display:none'/>")
    return (f"<div class='pdlc' data-pts='{e(json.dumps(data))}' data-zoom='{1 if zoom else 0}' data-l='{L}' data-r='{W - R}'>"
            f"<svg viewBox='0 0 {W} {H}' role='img' aria-label='Histórico de PDL'>{g}</svg><div class='pdl-tip'></div></div>")


def pdl_page(con, puuid, hist, colors, n_year, period="tudo", t_from=None, t_to=None):
    from . import ranksimg
    year_btn = ("<form method='post' action='/sincronizar/iniciar' class='row' style='margin:0 0 14px'><input type='hidden' name='kind' value='ano'>"
                "<input type='hidden' name='back' value='1'><button class='btn gold' style='width:auto;flex:none'>Buscar todas as ranqueadas do ano</button>"
                f"<span class='n'>{n_year} ranqueadas suas salvas deste ano. A busca roda em segundo plano (pode levar alguns minutos).</span></form>")
    now_ms = time.time() * 1000
    cut = {"30": now_ms - 30 * 86400000, "90": now_ms - 90 * 86400000, "7": now_ms - 7 * 86400000,
           "temporada": time.mktime((time.localtime().tm_year, 1, 1, 0, 0, 0, 0, 0, -1)) * 1000}.get(period, 0)
    zoomed = t_from is not None and t_to is not None and t_to > t_from
    seq, marks = pdl_seq(con, puuid, hist, t_from if zoomed else cut, t_to if zoomed else None)
    if len(seq) < 2:
        allseq, marks = pdl_seq(con, puuid, hist)
        seq = allseq[-20:]
    if len(seq) < 2:
        return year_btn + ranks.chart(hist, colors) if len(hist) >= 2 else year_btn + (
            "<div class='empty'><b>Sem ranqueadas ou sem elo para ancorar</b><span>Sincronize (ou busque as ranqueadas do ano) e o app desenha a linha.</span></div>")
    emb = lambda t: f"/static/ranks/{t.lower()}.png" if ranksimg.available(t) else None
    svg = pdl_svg(seq, hist, colors)
    now_v = hist[-1]["v"] if hist else seq[-1]["v"]
    pk = max(seq, key=lambda d: d["v"])

    def card(lbl, v, sub):
        t = _rank_of(v)[0]
        im = emb(t)
        return (f"<div class='kv4'>" + (f"<img src='{im}' alt=''>" if im else "") + f"<div><small>{e(lbl)}</small><b style='color:{colors.get(t, '#fff')}'>{e(_rank_txt(v))}</b><span>{e(sub)}</span></div></div>")
    wins = sum(1 for d in seq if d["r"]["win"])
    losses = len(seq) - wins
    delta = seq[-1]["v"] - seq[0]["v0"]
    top = ("<div class='pdl-top'>" + card("Agora", now_v, "elo atual")
           + card("Pico do período", pk["v"], time.strftime('%d/%m/%Y', time.localtime(pk['t'] / 1000)))
           + f"<div class='kv4'><div><small>No período</small><b class='{'w' if delta >= 0 else 'l'}'>{delta:+.0f} PDL</b>"
           f"<span>{wins}V {losses}D · {round(100 * wins / max(1, len(seq)))}% em {len(seq)} ranqueadas</span></div></div></div>")
    per = ("<div class='pdl-per'>" + "".join(f"<a href='/pdl?periodo={k}' class='{'on' if period == k and not zoomed else ''}'>{t}</a>"
                                              for k, t in (("7", "7 dias"), ("30", "30 dias"), ("90", "90 dias"), ("temporada", "Temporada"), ("tudo", "Tudo")))
           + (f"<a href='/pdl?periodo={period}' class='on'>Zoom: {time.strftime('%d/%m', time.localtime(t_from / 1000))} a {time.strftime('%d/%m', time.localtime(t_to / 1000))} · desfazer</a>" if zoomed else "")
           + "<span class='n' style='align-self:center;font-size:12px'>Arraste no gráfico para dar zoom.</span></div>")
    legend = ("<div class='pdl-leg'><span><i style='background:#E9A23B'></i>PDL depois de cada partida</span><span><i style='background:#fff;border-radius:50%'></i>PDL real guardado</span>"
              "<span><i style='background:#3E9B6A'></i>vitórias</span><span><i style='background:#C2453F'></i>derrotas</span></div>")
    note = ("<p class='n'><span class='tag hipotese'>hipótese</span> A Riot não informa o PDL de cada partida: entre os pontos reais guardados "
            f"(brancos), a linha estima +{WIN_LP} por vitória e -{LOSS_LP} por derrota e é corrigida para passar pelos reais.</p>")
    lst = "".join(f"<li>{e(time.strftime('%d/%m', time.localtime(m['t'] / 1000)))} · {e(m['txt'])}</li>" for m in reversed(marks[-12:]))
    return (year_btn + per + top + f"<div class='card'>{svg}{legend}{note}</div>" + PDL_JS
            + (f"<div class='card'><b class='gl'>Últimas trocas</b><ul class='n'>{lst}</ul></div>" if lst else ""))


# ---------------- patch: diferenca entre a versao atual e a anterior do Data Dragon ----------------
ITEM_STAT = {"FlatPhysicalDamageMod": "dano de ataque", "FlatMagicDamageMod": "poder de habilidade", "FlatHPPoolMod": "vida",
             "FlatArmorMod": "armadura", "FlatSpellBlockMod": "resistência mágica", "PercentAttackSpeedMod": "velocidade de ataque",
             "FlatCritChanceMod": "chance de crítico", "PercentMovementSpeedMod": "velocidade de movimento %",
             "FlatMovementSpeedMod": "velocidade de movimento", "FlatMPPoolMod": "mana", "PercentLifeStealMod": "roubo de vida"}
STAT_PT = {"hp": "vida", "hpperlevel": "vida por nível", "mp": "mana", "armor": "armadura", "armorperlevel": "armadura por nível",
           "spellblock": "resistência mágica", "spellblockperlevel": "resist. mágica por nível", "movespeed": "velocidade",
           "attackrange": "alcance", "hpregen": "regeneração de vida", "attackdamage": "dano de ataque",
           "attackdamageperlevel": "dano por nível", "attackspeedperlevel": "vel. de ataque por nível", "attackspeed": "velocidade de ataque"}
GOOD_UP = set(STAT_PT)


def _plain(t):
    import re
    t = re.sub(r"<br\s*/?>", ". ", t or "")
    t = re.sub(r"<[^>]+>", " ", t)
    return re.sub(r"\s+", " ", t).strip()


LOWER_IS_BETTER = ("recarga", "custo", "mana", "energia", "vida atual", "tempo de espera", "preço", "atraso", "conjuração")


def _sentences(t):
    import re
    return [x.strip() for x in re.split(r"(?<=[.!?])\s+", _plain(t)) if x.strip()]


def _num_dir(old_s, new_s):
    """'up' (buff), 'dn' (nerf) ou 'mx': compara os numeros das duas frases. Recarga, custo e afins: menor e melhor."""
    import re
    rx = r"\d+(?:[.,]\d+)?"
    on = [float(x.replace(",", ".")) for x in re.findall(rx, old_s)]
    nn = [float(x.replace(",", ".")) for x in re.findall(rx, new_s)]
    if not on or len(on) != len(nn):
        if nn and not on:
            return "up"
        if on and not nn:
            return "dn"
        return "mx"
    inv = any(w in new_s.lower() for w in LOWER_IS_BETTER)
    ups = sum(1 for o, n in zip(on, nn) if (n > o) != inv and n != o)
    dns = sum(1 for o, n in zip(on, nn) if (n < o) != inv and n != o)
    return "up" if ups and not dns else "dn" if dns and not ups else "mx"


def _cut(x, n=240):
    return x if len(x) <= n else x[:n].rsplit(" ", 1)[0] + "…"


def text_diff(old, new, limit=5):
    """O que mudou no texto, frase inteira: [(tipo, 'Antes: ...', 'Agora: ...')]. tipo: up=buff, dn=nerf, mx=ajuste."""
    import difflib
    a, b = _sentences(old), _sentences(new)
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    out = []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            continue
        olds, news = a[i1:i2], b[j1:j2]
        if tag == "replace" and len(olds) == len(news):
            pairs = list(zip(olds, news))
        else:
            pairs = [(" ".join(olds), " ".join(news))]
        for o, n in pairs:
            if o and n:
                out.append((_num_dir(o, n), _cut(o), _cut(n)))
            elif n:
                out.append(("mx", "", "Novo: " + _cut(n)))
            else:
                out.append(("dn", _cut(o), "Removido."))
    if len(out) > limit:
        out = out[:limit] + [("mx", "", f"e mais {len(out) - limit} mudança(s) no texto")]
    return out


def _versions(ddir):
    from .ddragon import DataDragon, BASE
    dd = DataDragon(cache_dir=os.path.join(ddir, "cache"))
    vs = dd._fetch(f"{BASE}/api/versions.json")
    return vs[0], vs[1]


def _dd(ddir, ver):
    from .ddragon import DataDragon
    return DataDragon(cache_dir=os.path.join(ddir, "cache"), version=ver)


def patch_diff(ddir, focus):
    """{'cur','prev','champs': [...], 'items': [...]} com o que mudou. focus = campeoes que interessam (pool e oponentes)."""
    cur, prev = _versions(ddir)
    a, b = _dd(ddir, prev), _dd(ddir, cur)
    ca = a._get("champion", "champion.json")["data"]
    cb = b._get("champion", "champion.json")["data"]
    champs = []
    for k, v in cb.items():
        old = ca.get(k)
        if not old:
            champs.append({"id": k, "name": v["name"], "changes": [("new", "campeão novo")], "dir": "mx"})
            continue
        ch = []
        for s, nv in (v.get("stats") or {}).items():
            ov = (old.get("stats") or {}).get(s)
            if ov is not None and nv != ov and s in STAT_PT:
                ch.append(("up" if nv > ov else "dn", f"{STAT_PT[s]}: {ov:g} → {nv:g}"))
        if k in focus:
            try:
                sa = (a.champion(k).get("spells") or [])
                sb = (b.champion(k).get("spells") or [])
                for key, x, y in zip("QWER", sa, sb):
                    if x.get("cooldown") != y.get("cooldown"):
                        dn = sum(y.get("cooldown") or [0]) < sum(x.get("cooldown") or [0])
                        ch.append(("up" if dn else "dn", f"{key} ({y.get('name')}): recarga {'/'.join(f'{c:g}' for c in x.get('cooldown') or [])} → {'/'.join(f'{c:g}' for c in y.get('cooldown') or [])}"))
                    if x.get("cost") != y.get("cost"):
                        ch.append(("dn" if sum(y.get("cost") or [0]) > sum(x.get("cost") or [0]) else "up", f"{key}: custo {'/'.join(f'{c:g}' for c in x.get('cost') or [])} → {'/'.join(f'{c:g}' for c in y.get('cost') or [])}"))
                    if x.get("range") != y.get("range"):
                        ch.append(("mx", f"{key}: alcance mudou"))
                    if (x.get("tooltip") or "") != (y.get("tooltip") or ""):
                        for kd, o_, n_ in text_diff(x.get("tooltip"), y.get("tooltip"), 3):
                            ch.append((kd, f"{key} ({y.get('name')})", o_, n_))
                pa, pb = a.champion(k).get("passive") or {}, b.champion(k).get("passive") or {}
                if (pa.get("description") or "") != (pb.get("description") or ""):
                    for kd, o_, n_ in text_diff(pa.get("description"), pb.get("description"), 3):
                        ch.append((kd, f"Passiva ({pb.get('name')})", o_, n_))
            except Exception:
                pass
        if ch:
            ups, dns = sum(1 for c in ch if c[0] == "up"), sum(1 for c in ch if c[0] == "dn")
            champs.append({"id": k, "name": v["name"], "changes": ch, "dir": "up" if ups > dns else "dn" if dns > ups else "mx"})
    ia, ib = a.items(), b.items()
    items = []
    for k, v in ib.items():
        if not (v.get("maps") or {}).get("11") or not (v.get("gold") or {}).get("purchasable", True):
            continue
        old = ia.get(k)
        if not old:
            if (v.get("gold") or {}).get("total", 0) >= 1000:
                items.append({"id": k, "name": v.get("name"), "changes": [("mx", "item novo")], "dir": "mx"})
            continue
        ch = []
        og, ng = (old.get("gold") or {}).get("total"), (v.get("gold") or {}).get("total")
        if og and ng and og != ng:
            ch.append(("up" if ng < og else "dn", f"preço: {og} → {ng}"))
        for s, nv in (v.get("stats") or {}).items():
            ov = (old.get("stats") or {}).get(s)
            if ov != nv:
                ch.append(("up" if (ov or 0) < nv else "dn", f"{ITEM_STAT.get(s, s)}: {ov or 0:g} → {nv:g}"))
        if (old.get("description") or "") != (v.get("description") or ""):
            ch += [(kd, "Efeito", o_, n_) for kd, o_, n_ in text_diff(old.get("description"), v.get("description"))]
        if ch:
            ups, dns = sum(1 for c in ch if c[0] == "up"), sum(1 for c in ch if c[0] == "dn")
            items.append({"id": k, "name": v.get("name"), "changes": ch, "dir": "up" if ups > dns else "dn" if dns > ups else "mx"})
    return {"cur": cur, "prev": prev, "champs": champs, "items": items}


def _change_li(x, tags):
    t = x[0]
    lab = f"<em class='pt {t}'>{tags.get(t, 'ajuste')}</em>"
    if len(x) == 4:          # texto: frase antes e agora
        _, what, o, n = x
        return (f"<li class='{t}'>{lab}<b>{e(what)}</b>"
                + (f"<span class='was'>Antes: {e(o)}</span>" if o else "")
                + f"<span class='now'>{'' if n.startswith(('Novo', 'Removido', 'e mais')) else 'Agora: '}{e(n)}</span></li>")
    return f"<li class='{t}'>{lab}{e(x[1])}</li>"


def patch_page(ddir, focus, show_all, ver):
    try:
        d = patch_diff(ddir, focus)
    except Exception as ex:
        return f"<div class='empty'><b>Não consegui comparar as versões</b><span>{e(str(ex)[:160])}</span></div>"
    tags = {"up": "buff", "dn": "nerf", "mx": "ajuste"}
    champs = d["champs"] if show_all else [c for c in d["champs"] if c["id"] in focus]
    champs.sort(key=lambda c: (c["id"] not in focus, -len(c["changes"])))
    big_items = sorted(d["items"], key=lambda i: -len(i["changes"]))
    items = big_items if show_all else big_items[:8]
    fx = [c for c in d["champs"] if c["id"] in focus]
    summary = (f"<div class='psum'><b class='gl'>Resumo da versão {e(d['cur'])} (comparada com {e(d['prev'])})</b>"
               f"<p>{len(d['champs'])} campeões e {len(d['items'])} itens com números diferentes no Data Dragon.</p>"
               + (f"<p>No que te interessa: {', '.join(e(c['name']) + ' (' + tags[c['dir']] + ')' for c in fx[:8])}.</p>" if fx
                  else "<p>Nenhum campeão do seu pool ou dos seus oponentes comuns mudou nos números.</p>")
               + "<p class='n'><span class='tag hipotese'>hipótese</span> O Data Dragon só mostra números de base (status, recargas, custos, preços). "
               "Quando muda o texto de uma habilidade ou item, o app mostra o trecho que mudou (antes → agora). Buff: ficou mais forte (número maior, ou recarga, custo e preço menores). Nerf: ficou mais fraco. Ajuste: mudou sem lado claro. Para a explicação da Riot, veja as notas oficiais no cliente.</p></div>")
    seg = (f"<div class='p4-seg'><a href='/patch' class='{'' if show_all else 'on'}'>Só o que interessa</a>"
           f"<a href='/patch?tudo=1' class='{'on' if show_all else ''}'>Ver tudo</a></div>")
    def block(lst, kind):
        out = "<div class='pch'>"
        for c in lst:
            ic = icons.champ(c["id"], 40) if kind == "c" else (f"<img src='https://ddragon.leagueoflegends.com/cdn/{e(ver)}/img/item/{e(c['id'])}.png' width='40' height='40' style='border-radius:8px' alt=''>" if ver else "")
            lis = "".join(_change_li(x, tags) for x in c["changes"][:10])
            mark = " <small class='n'>(seu pool ou oponente comum)</small>" if kind == "c" and c["id"] in focus else ""
            out += f"<div class='it'>{ic}<div><h3>{e(c['name'])}{mark}</h3><ul>{lis}</ul></div><span class='tg {c['dir']}'>{tags[c['dir']]}</span></div>"
        return out + "</div>"
    body = seg + summary + "<h2>Campeões</h2>" + (block(champs, "c") if champs else "<p class='n'>Nada para mostrar neste filtro.</p>")
    body += "<h2>Itens</h2>" + (block(items, "i") if items else "<p class='n'>Nenhum item mudou.</p>")
    return body


# ---------------- atalhos de teclado ----------------
KEYS = [("g i", "/", "Início"), ("g p", "/partidas", "Partidas"), ("g j", "/jogo", "Partida ao vivo"), ("g c", "/campeoes", "Campeões"),
        ("g d", "/diagnostico", "Diagnóstico"), ("g e", "/erros", "Meus erros"), ("g u", "/duelos", "Explorador de duelos"),
        ("g t", "/tierlist", "Tier list"), ("g o", "/overlay", "Editar overlay"), ("g a", "/coach", "Coach IA")]
KEYS_JS = ("<script>(function(){var M=" + json.dumps({k.split()[1]: h for k, h, _ in KEYS}) + ",L=" + json.dumps([[k, t] for k, _, t in KEYS])
           + ",g=0,tm=0;function help(){var x=document.querySelector('.kb-help');if(x){x.remove();return}"
           "var d=document.createElement('div');d.className='kb-help';d.innerHTML='<div><h3>Atalhos do teclado</h3><ul style=\"list-style:none;padding:0;margin:0\">'"
           "+L.map(function(r){return '<li><span>'+r[1]+'</span><span>'+r[0].split(' ').map(function(k){return '<kbd>'+k+'</kbd>'}).join(' ')+'</span></li>'}).join('')"
           "+'<li><span>Voltar ao topo</span><span><kbd>t</kbd></span></li><li><span>Esta ajuda</span><span><kbd>?</kbd></span></li></ul></div>';"
           "d.onclick=function(){d.remove()};document.body.appendChild(d)}"
           "document.addEventListener('keydown',function(ev){var t=ev.target;if(ev.ctrlKey||ev.metaKey||ev.altKey)return;"
           "if(t&&(t.tagName==='INPUT'||t.tagName==='TEXTAREA'||t.tagName==='SELECT'||t.isContentEditable))return;"
           "if(ev.key==='?'){help();ev.preventDefault();return}if(ev.key==='Escape'){var x=document.querySelector('.kb-help');if(x)x.remove();return}"
           "if(g&&M[ev.key]){location.href=M[ev.key];g=0;return}if(ev.key==='g'){g=1;clearTimeout(tm);tm=setTimeout(function(){g=0},1200);return}"
           "if(ev.key==='t'){scrollTo({top:0,behavior:'smooth'})}})})();</script>")


CSS = CSS_BASE + PDL_CSS
