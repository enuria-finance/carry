"""Revisao estilo analise de VOD: erros E acertos da partida, com a leitura do coach em cada lance.

Fonte: linha do tempo oficial da partida (uma foto de posicao/ouro/nivel por minuto, abates e objetivos com posicao).
Numeros = dado. A leitura ("o que aconteceu de verdade") = hipotese do app a partir desses numeros.
O "o que fazer" = regra geral. Nada aqui e usado durante a partida.
"""
import html
import json
import math

from . import review

e = lambda s: html.escape("" if s is None else str(s), quote=True)
NEAR = 2600          # unidades do mapa: "perto" (cerca de uma tela e meia)
OBJ_PT = {"DRAGON": "Dragão", "BARON_NASHOR": "Barão", "RIFTHERALD": "Arauto", "HORDE": "Larvas do Vazio", "ATAKHAN": "Atakhan",
          "ELDER_DRAGON": "Dragão Ancião"}

GOOD = {"G": "Boa troca ou abate na rota", "H": "Boa leitura do mapa (sabia onde estavam)", "I": "Boa rotação ou ajuda",
        "J": "Objetivo bem jogado", "K": "Boa luta em equipe", "L": "Bom posicionamento"}
BAD = dict(review.CAUSES)
BAD.update({"F": "Luta em desvantagem numérica", "M": "Avancei sem visão", "N": "Fiquei sozinho no fim do jogo"})


def _mmss(t):
    s = int(t // 1000)
    return f"{s // 60}:{s % 60:02d}"


def _dist(a, b):
    if not a or not b or None in (a[0], a[1], b[0], b[1]):
        return None
    return math.hypot(a[0] - b[0], a[1] - b[1])


class Game:
    """Carrega a partida uma vez (participantes, fotos por minuto, abates e objetivos)."""

    def __init__(self, con, puuid, mid):
        self.con, self.mid = con, mid
        self.parts = {r["participant_id"]: dict(r) for r in con.execute("SELECT * FROM participants WHERE match_id=?", (mid,))}
        me = next((p for p in self.parts.values() if p["puuid"] == puuid), None)
        self.me = me
        if not me:
            return
        self.pid, self.team = me["participant_id"], me["team_id"]
        self.allies = [p for p in self.parts.values() if p["team_id"] == self.team and p["participant_id"] != self.pid]
        self.foes = [p for p in self.parts.values() if p["team_id"] != self.team]
        self.opp = next((p for p in self.foes if p["position"] == me["position"]), None)
        self.ejg = next((p for p in self.foes if p["position"] == "JUNGLE"), None)
        self.frames = {}
        for f in con.execute("SELECT participant_id, minute, cs, gold, level, x, y FROM frames WHERE match_id=?", (mid,)):
            self.frames[(f["participant_id"], f["minute"])] = dict(f)
        self.kills = []
        rows = con.execute("SELECT t_ms, pid, x, y, data FROM events WHERE match_id=? AND type='CHAMPION_KILL' ORDER BY t_ms", (mid,)).fetchall()
        if rows:
            for r in rows:
                d = json.loads(r["data"] or "{}")
                self.kills.append({"t": r["t_ms"], "victim": r["pid"], "killer": d.get("killer"), "assists": d.get("assists") or [], "x": r["x"], "y": r["y"]})
        else:
            for r in con.execute("SELECT t_ms, victim_id, killer_id, x, y FROM deaths WHERE match_id=? ORDER BY t_ms", (mid,)):
                self.kills.append({"t": r["t_ms"], "victim": r["victim_id"], "killer": r["killer_id"], "assists": [], "x": r["x"], "y": r["y"]})
        self.objs = []
        for r in con.execute("SELECT t_ms, type, team_id, x, y, data FROM events WHERE match_id=? AND type IN ('ELITE_MONSTER_KILL','BUILDING_KILL') ORDER BY t_ms", (mid,)):
            d = json.loads(r["data"] or "{}")
            if r["type"] == "ELITE_MONSTER_KILL":
                name = OBJ_PT.get(d.get("monsterType"), d.get("monsterType") or "monstro")
                self.objs.append({"t": r["t_ms"], "kind": "monstro", "name": name, "team": r["team_id"], "x": r["x"], "y": r["y"],
                                  "killer": d.get("killerId")})
            else:
                # BUILDING_KILL: team_id e o time DONO da estrutura derrubada
                self.objs.append({"t": r["t_ms"], "kind": "torre", "name": "torre" if d.get("buildingType") == "TOWER_BUILDING" else "inibidor",
                                  "team": 300 - (r["team_id"] or 0) if r["team_id"] else None, "x": r["x"], "y": r["y"]})
        dur = con.execute("SELECT duration_s FROM matches WHERE match_id=?", (mid,)).fetchone()
        self.duration = (dur[0] or 0) if dur else 0

    def fr(self, pid, t):
        m = int(round(t / 60000))
        return self.frames.get((pid, m)) or self.frames.get((pid, m - 1))

    def pos(self, pid, t):
        f = self.fr(pid, t)
        return (f["x"], f["y"]) if f else None

    def team_gold(self, team_ids, t):
        return sum((self.fr(p["participant_id"], t) or {}).get("gold") or 0 for p in team_ids)

    def name(self, pid):
        p = self.parts.get(pid)
        return p["champion"] if p else "torre ou monstro"

    def near(self, plist, where, t):
        return [p for p in plist if (_dist(self.pos(p["participant_id"], t), where) or 1e9) < NEAR]


def _enemy_half(xy, team):
    if not xy or xy[0] is None:
        return False
    s = xy[0] + xy[1]
    return s > 16800 if team == 100 else s < 12900


def _after(G, t, secs=90):
    mine, theirs = [], []
    for o in G.objs:
        if t < o["t"] <= t + secs * 1000:
            (mine if o["team"] == G.team else theirs).append(o["name"])
    return mine, theirs


def moments(con, puuid, mid):
    """Lances da partida, bons e ruins, cada um com fatos, leitura do coach e o que fazer."""
    G = Game(con, puuid, mid)
    if not G.me:
        return [], None
    out = []
    me_id = G.pid
    my_deaths = [k for k in G.kills if k["victim"] == me_id]
    my_kills = [k for k in G.kills if k["killer"] == me_id or me_id in k["assists"]]
    # ---------- suas mortes ----------
    for k in my_deaths:
        t, where = k["t"], (k["x"], k["y"])
        allies = G.near(G.allies, where, t)
        foes = G.near(G.foes, where, t)
        ids = {p["participant_id"] for p in foes}
        for pid_ in [k["killer"]] + list(k["assists"]):      # quem matou ou ajudou estava la, mesmo que a foto do minuto mostre longe
            p_ = G.parts.get(pid_)
            if p_ and p_["team_id"] != G.team and pid_ not in ids:
                foes.append(p_)
                ids.add(pid_)
        killer = G.parts.get(k["killer"])
        fm = G.fr(me_id, t)
        _kill = k
        facts, read, todo = [], [], []
        facts.append(f"Você morreu aos {_mmss(t)} para {G.name(k['killer'])}" + (f" com {len(k['assists'])} assistência(s)" if k["assists"] else "") + ".")
        facts.append(f"Por perto: {len(allies)} aliado(s) seu(s) e {len(foes)} inimigo(s) (foto do minuto + quem participou do abate).")
        if fm and killer:
            fk = G.fr(killer["participant_id"], t)
            if fk:
                facts.append(f"Você nível {fm['level']} com {fm['gold'] / 1000:.1f}k de ouro; {killer['champion']} nível {fk['level']} com {fk['gold'] / 1000:.1f}k.")
        gd = G.team_gold(G.allies + [G.me], t) - G.team_gold(G.foes, t)
        facts.append(f"Ouro do time naquele minuto: {'+' if gd >= 0 else ''}{gd / 1000:.1f}k.")
        if G.ejg and G.ejg["participant_id"] in ids:
            facts.append(f"{G.ejg['champion']} (caçador inimigo) participou do abate.")
        elif G.ejg:
            dj = _dist(G.pos(G.ejg["participant_id"], t), where)
            if dj is not None:
                facts.append(f"{G.ejg['champion']} (caçador inimigo) estava a cerca de {int(dj)} unidades.")
        mine_after, their_after = _after(G, t)
        if their_after:
            facts.append("Em até 90 s o inimigo fez: " + ", ".join(their_after) + ".")
        zone = review.zone(*where)
        # leitura do coach
        nf, na = len(foes), len(allies) + 1
        if nf >= na + 1:
            read.append(f"Luta em desvantagem numérica ({na} contra {nf}). Isso decide quase sozinho.")
            todo.append("Antes de entrar, conte: quantos inimigos sumiram do mapa? Sem saber, considere que estão ali.")
        if _enemy_half(where, G.team) and t < 20 * 60000:
            read.append(f"Morte no lado inimigo do mapa ({zone}).")
            todo.append("No lado inimigo, só com visão e com a sua rota empurrada; senão, jogue do seu lado do rio.")
        if killer and killer["position"] == "JUNGLE" and G.me["position"] != "JUNGLE" and t < 15 * 60000:
            read.append("Pego pelo caçador inimigo.")
            todo.append("Quando o caçador inimigo some do mapa, recue até a metade da rota até ele aparecer de novo.")
        if fm and G.opp:
            fo = G.fr(G.opp["participant_id"], t)
            if fo and fm["gold"] - fo["gold"] >= 700:
                read.append(f"Você estava {(fm['gold'] - fo['gold']) / 1000:.1f}k à frente do oponente: morrer aqui devolve a vantagem.")
                todo.append("Com vantagem, troque abate por torre ou objetivo; não procure mais abates em lugar escuro.")
            if fo and killer and killer["participant_id"] == G.opp["participant_id"] and fo["level"] > fm["level"]:
                read.append(f"Trocou com o oponente com nível a menos ({fm['level']} contra {fo['level']}).")
                todo.append("Evite trocar quando ele está um nível acima: espere a próxima onda ou o seu nível.")
        if not allies and t > 22 * 60000:
            read.append("Sozinho no fim de jogo: o tempo de morte é longo e o inimigo ganha um objetivo de graça.")
            todo.append("Depois dos 20 min, ande com o time ou empurre só com visão e sabendo onde estão os 5.")
        if their_after:
            read.append(f"A morte custou objetivo: {', '.join(their_after)}.")
            todo.append("Antes de um objetivo nascer (dragão, larvas, barão), jogue para não morrer nos 60 s antes.")
        if not read:
            read.append("Nada óbvio pelos números: pode ter sido mecânica, habilidade errada ou recarga. Reveja no replay.")
        out.append({"t_ms": t, "kind": "morte", "good": False, "title": f"Morte aos {_mmss(t)}", "facts": facts, "read": read, "todo": todo,
                    "minute": t // 60000, "kill": _kill})
    # ---------- seus abates e assistencias (acertos) ----------
    scored = []
    for k in my_kills:
        t, where = k["t"], (k["x"], k["y"])
        mine_after, their_after = _after(G, t)
        died_soon = any(d["t"] - t < 30000 and d["t"] >= t for d in my_deaths)
        allies = G.near(G.allies, where, t)
        foes = G.near(G.foes, where, t)
        imp = (2 if t < 10 * 60000 else 1) + 2 * len(mine_after) - (2 if died_soon else 0) + (1 if k["killer"] == me_id else 0)
        scored.append((imp, k, mine_after, died_soon, allies, foes))
    scored.sort(key=lambda x: -x[0])
    for imp, k, mine_after, died_soon, allies, foes in scored[:5]:
        t = k["t"]
        facts, read, todo = [], [], []
        how = "abateu" if k["killer"] == me_id else "deu assistência no abate de"
        facts.append(f"Você {how} {G.name(k['victim'])} aos {_mmss(t)}.")
        facts.append(f"Por perto: {len(allies) + 1} do seu time e {len(foes)} inimigo(s).")
        if mine_after:
            facts.append("Em até 90 s o seu time fez: " + ", ".join(mine_after) + ".")
        if mine_after:
            read.append(f"Abate convertido em {', '.join(mine_after)}: é assim que vantagem vira vitória.")
        elif died_soon:
            read.append("Abate, mas você morreu logo depois: a saída demorou.")
            todo.append("Depois do abate, saia ou empurre a onda e volte à base; não fique para o segundo abate sem visão.")
        else:
            read.append("Abate sem objetivo depois: a vantagem ficou só no ouro.")
            todo.append("Depois de um abate, olhe o que está disponível: placa da torre, dragão, larvas ou empurrar e voltar com ouro.")
        if t < 10 * 60000 and k["killer"] == me_id:
            read.append("Abate na fase de rota: vale muito porque pesa no item e na prioridade da rota.")
        out.append({"t_ms": t, "kind": "abate", "good": not died_soon, "title": f"{'Abate' if k['killer'] == me_id else 'Assistência'} aos {_mmss(t)}",
                    "facts": facts, "read": read, "todo": todo, "minute": t // 60000})
    # ---------- objetivos grandes ----------
    for o in G.objs:
        if o["kind"] != "monstro" or o["name"] not in OBJ_PT.values():
            continue
        t = o["t"]
        d = _dist(G.pos(me_id, t), (o["x"], o["y"]))
        ours = o["team"] == G.team
        facts = [f"{'Seu time' if ours else 'O inimigo'} fez {o['name']} aos {_mmss(t)}."]
        read, todo = [], []
        if d is not None:
            facts.append(f"Você estava a cerca de {int(d)} unidades do objetivo.")
        if ours:
            read.append("Objetivo do seu time." + (" Você estava lá." if d is not None and d < NEAR else " Você estava longe: o time fez sem você."))
        else:
            dead = any(k["victim"] == me_id and t - 45000 <= k["t"] <= t for k in G.kills)
            if dead:
                read.append("Você estava morto quando o inimigo fez o objetivo.")
                todo.append("Os 60 s antes de um objetivo são os mais perigosos: não morra nesse tempo.")
            elif d is not None and d > 6000:
                read.append("Você estava longe do objetivo do inimigo.")
                todo.append("Quando o objetivo for nascer, empurre a sua onda e chegue antes no rio.")
            else:
                read.append("Você estava por perto, mas o objetivo foi do inimigo.")
                todo.append("Sem chance de contestar, troque por outro lado do mapa (torre, larvas, invasão) em vez de lutar perdendo.")
        out.append({"t_ms": t, "kind": "objetivo", "good": ours, "title": f"{o['name']} {'do seu time' if ours else 'do inimigo'} aos {_mmss(t)}",
                    "facts": facts, "read": read, "todo": todo, "minute": t // 60000})
    out.sort(key=lambda m: m["t_ms"])
    return out, G


def overview(G, ms):
    """Leitura geral da partida em poucas linhas (como um coach abrindo a revisão)."""
    if not G or not G.me:
        return []
    lines = []
    me = G.me
    if G.opp:
        for m in (10, 15):
            a, b = G.frames.get((G.pid, m)), G.frames.get((G.opp["participant_id"], m))
            if a and b:
                gd = a["gold"] - b["gold"]
                lines.append(("dado", f"Rota aos {m} min contra {G.opp['champion']}: {'+' if gd >= 0 else ''}{gd} de ouro, {a['cs'] - b['cs']:+d} de farm, nível {a['level']} contra {b['level']}."))
                break
    deaths = [m for m in ms if m["kind"] == "morte"]
    early = [m for m in deaths if m["minute"] < 10]
    if deaths:
        lines.append(("dado", f"{len(deaths)} mortes, {len(early)} antes dos 10 min."))
    num = sum(1 for m in deaths if any("desvantagem numérica" in r for r in m["read"]))
    if num:
        lines.append(("hipotese", f"{num} das suas mortes foram em desvantagem numérica: o principal ponto a corrigir é saber onde os inimigos estão antes de lutar."))
    costly = sum(1 for m in deaths if any("custou objetivo" in r for r in m["read"]))
    if costly:
        lines.append(("hipotese", f"{costly} morte(s) custaram objetivo logo depois."))
    kills = [m for m in ms if m["kind"] == "abate"]
    conv = sum(1 for m in kills if any("convertido" in r for r in m["read"]))
    if kills:
        lines.append(("dado", f"Dos seus {len(kills)} abates/assistências principais, {conv} viraram objetivo em até 90 s."))
    objs_ours = sum(1 for m in ms if m["kind"] == "objetivo" and m["good"])
    objs_theirs = sum(1 for m in ms if m["kind"] == "objetivo" and not m["good"])
    lines.append(("dado", f"Objetivos grandes: seu time {objs_ours}, inimigo {objs_theirs}."))
    if not num and not costly and len(early) <= 1:
        lines.append(("hipotese", "Sem padrão forte de erro nos números: o ganho agora está nos detalhes (onda, recall, recargas). Use o replay nos lances marcados."))
    return lines


AI_SYSTEM = """Você é um coach profissional de League of Legends analisando um lance de VOD com o jogador, em português do Brasil, como um coach de time grande faria.
Seja direto e específico: diga o que provavelmente aconteceu, o erro ou o acerto principal, e o que um jogador de elo alto faria no lugar.
Use só os fatos enviados (posições, números e a resposta do jogador) e conhecimento geral do jogo. Não invente o que não está nos fatos; quando for suposição, diga 'provavelmente'.
No máximo 6 frases curtas, sem emojis, sem listas longas."""


def ai_read(key, model, moment, answer, champ, opp):
    import urllib.request
    from . import coachbot
    txt = (f"Campeão do jogador: {champ}. Oponente de rota: {opp}.\nLance: {moment['title']}.\nFatos: " + " ".join(moment["facts"])
           + "\nLeitura automática do app: " + " ".join(moment["read"])
           + (f"\nO que o jogador disse que via e ia fazer: {answer}" if answer else ""))
    from . import ai
    res = ai.post(key, {"model": model or coachbot.DEFAULT_MODEL, "max_tokens": 450, "system": AI_SYSTEM,
                        "messages": [{"role": "user", "content": txt}]}, 60)
    return "".join(b.get("text", "") for b in res.get("content") or [] if b.get("type") == "text").strip()


def ensure(con):
    con.execute("CREATE TABLE IF NOT EXISTS vod_ai (match_id TEXT, t_ms INTEGER, text TEXT, PRIMARY KEY (match_id, t_ms))")


def ai_get(con, mid):
    ensure(con)
    return {r[0]: r[1] for r in con.execute("SELECT t_ms, text FROM vod_ai WHERE match_id=?", (mid,))}


def ai_save(con, mid, t_ms, text):
    ensure(con)
    con.execute("INSERT OR REPLACE INTO vod_ai VALUES (?,?,?)", (mid, int(t_ms), text))
    con.commit()


CSS = """
.vod-ov{border:1px solid rgba(233,196,106,.4);border-radius:16px;padding:16px 18px;background:rgba(233,196,106,.05);margin:0 0 16px}
.vod-ov h3{margin:0 0 8px;font:700 16px var(--head);color:#fff}.vod-ov .tip{margin:4px 0}
.vod-f{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 14px}.vod-f button{width:auto !important;padding:6px 14px !important;border-radius:999px !important;font:600 13px var(--head) !important}
.vod-f button[aria-pressed=true]{background:var(--gold) !important;color:#1a1405 !important;border-color:var(--gold) !important}
.vm [hidden]{display:none !important}
.vm{border:1px solid var(--rule);border-left:4px solid #D9534F;border-radius:14px;padding:14px 18px;margin:0 0 14px;background:var(--panel);scroll-margin-top:90px}
.vm.good{border-left-color:#6BBF8A}.vm.neutral{border-left-color:#8DA2C0}
.vm h3{margin:0 0 6px;display:flex;gap:10px;align-items:center;font:700 18px var(--head);color:#fff}
.vm h3 .pill{font:700 11px var(--head);padding:3px 9px;border-radius:999px;background:rgba(217,83,79,.14);color:#E8817C}
.vm.good h3 .pill{background:rgba(107,191,138,.16);color:#8FD4A8}.vm.neutral h3 .pill{background:rgba(141,162,192,.16);color:#B5C2D6}
.vm .cols{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:16px;margin-top:8px}
.vm .box{border:1px solid var(--rule);border-radius:12px;padding:10px 12px;background:rgba(16,11,11,.4)}
.vm .box b.gl{display:block;margin-bottom:6px}.vm .box p{margin:4px 0;font-size:13.5px;color:#DDD3C7}
.vm .read p{color:#F0E4CC}.vm .todo p{color:#c9e7d6}
.vm form{margin-top:10px}.vm textarea{width:100%}.vm .row2{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-top:8px}
.vm .row2 label{font-size:13px;color:var(--mute);display:flex;align-items:center;gap:6px}
.vm .seg3{display:flex;gap:6px}.vm .seg3 label{border:1px solid var(--rule);border-radius:999px;padding:4px 12px;cursor:pointer;color:#D6CCC0}
.vm .seg3 input{display:none}.vm .seg3 input:checked+span{color:#fff;font-weight:700}
.vm .seg3 label:has(input:checked){border-color:var(--gold);background:rgba(233,196,106,.12)}
.vm .saved{font-size:12.5px;color:#8FD4A8;margin-left:8px}.vm .ai{margin-top:10px;border:1px dashed rgba(233,196,106,.45);border-radius:12px;padding:10px 12px;color:#F0E4CC;font-size:14px;line-height:1.55}
.vm .lance{float:right;margin:0 0 8px 14px;width:300px}@media (max-width:1000px){.vm .lance{float:none;margin:8px 0}}
.vm .acts{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}.vm .acts .btn{width:auto !important}
@media (max-width:1000px){.vm .cols{grid-template-columns:1fr}}
"""

JS = """<script>(function(){
document.addEventListener('submit',function(ev){var f=ev.target;if(!f.classList.contains('vod-save')&&!f.classList.contains('vod-ai'))return;ev.preventDefault();
var b=f.querySelector('button[type=submit],button:not([type])');var old=b?b.textContent:'';if(b){b.disabled=true;b.textContent=f.classList.contains('vod-ai')?'Analisando…':'Salvando…'}
fetch(f.action,{method:'POST',body:new URLSearchParams(new FormData(f)),headers:{'X-Requested-With':'fetch'}}).then(function(r){return r.text()}).then(function(t){
var box=f.closest('.vm');if(f.classList.contains('vod-ai')){var a=box.querySelector('.ai');if(!a){a=document.createElement('div');a.className='ai';f.after(a)}a.textContent=t}
else{var s=box.querySelector('.saved');if(!s){s=document.createElement('span');s.className='saved';b.after(s)}s.textContent='Salvo';
var r=box.querySelector('.reveal');if(r&&t&&t!=='ok')r.innerHTML=t;var pr=box.querySelector('.pre');if(pr)pr.remove();var k=f.querySelector('input[name=tipo]:checked');box.classList.remove('good','neutral');
if(k&&k.value==='acerto')box.classList.add('good');if(k&&k.value==='neutro')box.classList.add('neutral')}
if(b){b.disabled=false;b.textContent=old}}).catch(function(){if(b){b.disabled=false;b.textContent=old}f.submit()})});
document.addEventListener('change',function(ev){var i=ev.target;if(i.name!=='tipo')return;var f=i.closest('form');
f.querySelectorAll('.c-bad').forEach(function(x){x.hidden=i.value!=='erro'});f.querySelectorAll('.c-good').forEach(function(x){x.hidden=i.value!=='acerto'})});
var fl=document.querySelector('.vod-f');if(fl)fl.addEventListener('click',function(ev){var b=ev.target.closest('button');if(!b)return;
fl.querySelectorAll('button').forEach(function(x){x.setAttribute('aria-pressed',x===b)});var k=b.dataset.k;
document.querySelectorAll('.vm').forEach(function(m){m.hidden=!(k==='all'||m.dataset.k===k)})});
})();</script>"""


def reveal_html(mid, m, ai, ai_on):
    return ("<div class='cols'>"
            "<div class='box'><b class='gl'>O que os números mostram</b>" + "".join(f"<p><span class='tag dado'>dado</span> {e(x)}</p>" for x in m["facts"]) + "</div>"
            "<div class='box read'><b class='gl'>Leitura do coach</b>" + "".join(f"<p><span class='tag hipotese'>hipótese</span> {e(x)}</p>" for x in m["read"])
            + "".join(f"<p class='n' style='color:#c9e7d6'><span class='tag regra'>regra geral</span> {e(x)}</p>" for x in m["todo"]) + "</div></div>"
            f"<div class='acts'><form method='post' action='/partida/{e(mid)}/replay'><input type='hidden' name='t' value='{m['t_ms']}'><button class='btn'>Ver no replay</button></form>"
            + (f"<form method='post' action='/revisao/{e(mid)}/ia' class='vod-ai'><input type='hidden' name='t_ms' value='{m['t_ms']}'><button class='btn gold'>Análise do Coach IA</button></form>"
               if ai_on else "<span class='n'>Ligue o Coach IA em Administração (Gemini grátis) para ter a análise escrita de cada lance.</span>")
            + "</div>" + (f"<div class='ai'>{e(ai[m['t_ms']])}</div>" if m["t_ms"] in ai else ""))


def _sec(mmss):
    try:
        a, b = str(mmss).strip().split(":")[:2]
        return int(a) * 60 + int(b)
    except Exception:
        return None


def _from_full(full, t_ms):
    """Erro ou acerto da analise completa da IA no mesmo minuto do lance (ate 45 s de distancia)."""
    if not full:
        return None
    best, bd = None, 46
    for kind, lst in (("erro", full.get("erros") or []), ("acerto", full.get("acertos") or [])):
        for x in lst:
            s_ = _sec(x.get("minuto"))
            if s_ is None:
                continue
            d = abs(s_ - t_ms / 1000)
            if d < bd:
                best, bd = (kind, x), d
    return best


def _safe_map(G, m):
    try:
        return lance_svg(G, m["kill"])
    except Exception:
        return ""


def coach_box(hit):
    if not hit:
        return ""
    kind, x = hit
    if kind == "erro":
        return ("<div class='ai'><b>Coach IA: " + e(x.get("titulo") or "erro") + "</b><br>" + e(x.get("o_que_aconteceu") or "")
                + ("<br><b>O certo:</b> " + e(x.get("o_certo")) if x.get("o_certo") else "") + "</div>")
    return "<div class='ai'><b>Coach IA: " + e(x.get("titulo") or "acerto") + "</b><br>" + e(x.get("por_que") or "") + "</div>"


def page_html(con, puuid, mid, ans, ai_on, full=None):
    ms, G = moments(con, puuid, mid)
    if not ms:
        return None
    ai = ai_get(con, mid)
    ov = overview(G, ms)
    TAG = {"dado": "dado", "hipotese": "hipótese", "regra": "regra geral"}
    body = ""
    nb = sum(1 for m in ms if m["kind"] == "morte")
    ng = sum(1 for m in ms if m["kind"] == "abate")
    no = sum(1 for m in ms if m["kind"] == "objetivo")
    body += (f"<div class='vod-f'><button type='button' aria-pressed='false' data-k='all'>Todos ({len(ms)})</button>"
             f"<button type='button' aria-pressed='true' data-k='morte'>Mortes ({nb})</button>"
             f"<button type='button' aria-pressed='false' data-k='abate'>Abates ({ng})</button>"
             f"<button type='button' aria-pressed='false' data-k='objetivo'>Objetivos ({no})</button></div>")
    for m in ms:
        a = ans.get((m["t_ms"], m["kind"])) or {}
        cause = a.get("cause") or ""
        tipo = "acerto" if cause in GOOD else ("erro" if cause in BAD else ("acerto" if m["good"] else "erro"))
        answered = bool(cause or a.get("thought"))
        cls = "good" if tipo == "acerto" else ""
        pill = {"morte": "erro provável", "abate": "acerto" if m["good"] else "abate com custo", "objetivo": "objetivo nosso" if m["good"] else "objetivo deles"}[m["kind"]]
        bad_opts = "".join(f"<option value='{k}'{' selected' if cause == k else ''}>{e(v)}</option>" for k, v in BAD.items())
        good_opts = "".join(f"<option value='{k}'{' selected' if cause == k else ''}>{e(v)}</option>" for k, v in GOOD.items())
        kj = a.get("knew_jungler") or ""
        rd = lambda v, lb: f"<label><input type='radio' name='tipo' value='{v}'{' checked' if tipo == v else ''}><span>{lb}</span></label>"
        body += (f"<section class='vm {cls}' id='m{m['t_ms']}' data-k='{m['kind']}'{'' if m['kind'] == 'morte' or not nb else ' hidden'}><h3>{_mmss(m['t_ms'])} <span class='pill'>{e(pill)}</span>"
                 f"<small class='n'>{e(m['title'])}</small></h3>"
                 + coach_box(_from_full(full, m["t_ms"]))
                 + (_safe_map(G, m) if m.get("kill") else "")
                 + (top_minute_html(G, m) if m["kind"] in ("morte", "objetivo") else "")
                 + f"<div class='reveal'>{reveal_html(mid, m, ai, ai_on)}</div>"
                 + "<details style='margin-top:8px'><summary class='n' style='cursor:pointer'>Quer anotar o que você via? (opcional: deixa a análise da IA mais precisa)</summary>"
                 f"<form method='post' action='/revisao/{e(mid)}' class='vod-save'><input type='hidden' name='t_ms' value='{m['t_ms']}'>"
                 f"<input type='hidden' name='kind' value='{e(m['kind'])}'>"
                 "<p class='n' style='margin:0 0 4px'>Primeiro você: o que via e o que ia fazer?</p>"
                 f"<textarea name='thought' rows='2'>{e(a.get('thought') or '')}</textarea>"
                 f"<div class='row2'><span class='seg3'>{rd('acerto', 'Foi acerto')}{rd('erro', 'Foi erro')}{rd('neutro', 'Neutro')}</span>"
                 f"<label class='c-bad'{' hidden' if tipo != 'erro' else ''}>Erro: <select name='cause_bad'><option value=''>-</option>{bad_opts}</select></label>"
                 f"<label class='c-good'{' hidden' if tipo != 'acerto' else ''}>Acerto: <select name='cause_good'><option value=''>-</option>{good_opts}</select></label>"
                 f"<label>Sabia onde estava o caçador inimigo? <select name='knew'><option value=''>-</option>"
                 f"<option value='sim'{' selected' if kj == 'sim' else ''}>sim</option><option value='nao'{' selected' if kj == 'nao' else ''}>não</option></select></label>"
                 f"<button>Salvar resposta</button>{'<span class=saved>Salvo</span>' if answered else ''}</div></form></details>"
                 + "</section>")
    return body


def _interp(G, pid, t):
    """Posicao estimada no instante t (linha reta entre as fotos de minuto)."""
    m0 = int(t // 60000)
    a, b = G.frames.get((pid, m0)), G.frames.get((pid, m0 + 1))
    if a and b and a.get("x") is not None and b.get("x") is not None:
        f = (t - m0 * 60000) / 60000
        return (a["x"] + (b["x"] - a["x"]) * f, a["y"] + (b["y"] - a["y"]) * f)
    f_ = a or b
    return (f_["x"], f_["y"]) if f_ and f_.get("x") is not None else None


def lance_svg(G, k, size=300):
    """O lance no mapa: onde cada um estava, de onde vieram quem matou e quem ajudou (seta de 30 s antes) e o ponto da morte."""
    from . import icons
    from .postview import MAP_IMG, MAP_MAX
    ver = icons.version()
    sc = lambda v: v / MAP_MAX * size
    P = lambda xy: (sc(xy[0]), size - sc(xy[1]))
    t = k["t"]
    part = {k["killer"], *k["assists"]}
    from . import mapa
    out = [f"<svg viewBox='0 0 {size} {size}' width='{size}' height='{size}' style='border-radius:3px;max-width:100%'>"
           + mapa.base(size / 100) +
           "<defs><marker id='ar' markerWidth='6' markerHeight='6' refX='5' refY='3' orient='auto'><path d='M0,0 L6,3 L0,6 z' fill='#E8817C'/></marker>"
           "<clipPath id='cc'><circle cx='0' cy='0' r='9'/></clipPath></defs>"]
    spot = P((k["x"], k["y"])) if k.get("x") is not None else None
    for pid, p in G.parts.items():
        cur = (k["x"], k["y"]) if (pid in part or pid == k["victim"]) and k.get("x") is not None else _interp(G, pid, t)
        if not cur:
            continue
        x, y = P(cur)
        foe = p["team_id"] != G.team
        if pid in part and foe:
            before = _interp(G, pid, t - 30000)
            if before:
                bx, by = P(before)
                if abs(bx - x) + abs(by - y) > 8:
                    out.append(f"<line x1='{bx:.0f}' y1='{by:.0f}' x2='{x:.0f}' y2='{y:.0f}' stroke='#E8817C' stroke-width='2' stroke-dasharray='4 3' marker-end='url(#ar)'/>")
        ring = "#E8817C" if foe else ("#E9C46A" if pid == G.pid else "#7FB3E8")
        op = "1" if (pid in part or pid == G.pid) else ".55"
        img = (f"<image href='{icons.CDN}/cdn/{ver}/img/champion/{icons.champ_id(p['champion'])}.png' x='-9' y='-9' width='18' height='18' clip-path='url(#cc)'/>"
               if ver else "")
        out.append(f"<g transform='translate({x:.0f},{y:.0f})' opacity='{op}'>{img}<circle r='9.5' fill='none' stroke='{ring}' stroke-width='2'/></g>")
    if spot:
        out.append(f"<g transform='translate({spot[0]:.0f},{spot[1]:.0f})'><path d='M-6,-6 L6,6 M6,-6 L-6,6' stroke='#fff' stroke-width='3'/></g>")
    out.append("</svg>")
    return ("<div class='lance'>" + "".join(out) + "<p class='n' style='font-size:12px;margin:4px 0 0'>Dourado: você · azul: aliados · vermelho: inimigos. "
            "Seta tracejada: de onde quem te matou veio (30 s antes). Posições estimadas pela foto de cada minuto da Riot.</p></div>")


ZONA_PT = {"base": "na base (voltando ou comprando)", "meio": "na rota do meio", "cima": "na rota de cima", "baixo": "na rota de baixo",
           "rio": "no rio ou num objetivo", "selva": "na selva"}
_TOPMIN = {}


def zona(x, y):
    """Regiao aproximada do mapa (coordenadas oficiais 0 a 14870; base azul embaixo a esquerda)."""
    if x is None or y is None:
        return None
    if (x < 3600 and y < 3600) or (x > 11200 and y > 11200):
        return "base"
    if x < 2300 or y > 12500:
        return "cima"
    if y < 2300 or x > 12500:
        return "baixo"
    if abs(x - y) < 1500:
        return "meio"
    if abs(x + y - 14870) < 1700:
        return "rio"
    return "selva"


def top_minute(con, champion, position, minute):
    """Onde os melhores com o campeao estavam naquele minuto da partida: [(zona, %)] e n."""
    key = (champion, position, minute)
    if key in _TOPMIN:
        return _TOPMIN[key]
    rows = con.execute(
        """SELECT f.x, f.y FROM frames f JOIN participants p ON p.match_id=f.match_id AND p.participant_id=f.participant_id
           JOIN match_source s ON s.match_id=f.match_id
           WHERE s.source='top' AND p.champion=? AND p.position=? AND f.minute=? LIMIT 400""", (champion, position, minute)).fetchall()
    cnt = {}
    for x, y in rows:
        z = zona(x, y)
        if z:
            cnt[z] = cnt.get(z, 0) + 1
    n = sum(cnt.values())
    res = ([(z, round(100 * c / n)) for z, c in sorted(cnt.items(), key=lambda kv: -kv[1])], n) if n else ([], 0)
    _TOPMIN[key] = res
    return res


def top_minute_html(G, m):
    try:
        mn = int(m["t_ms"] // 60000)
        dist, n = top_minute(G.con, G.me["champion"], G.me["position"], mn)
        if n < 15:
            return ""
        meu = zona(*(G.pos(G.pid, m["t_ms"]) or (None, None)))
        partes = " · ".join(f"{p}% {ZONA_PT[z]}" for z, p in dist[:4] if p >= 5)
        return (f"<div class='box' style='margin-top:8px'><b class='gl'>Os melhores de {e(G.me['champion'])} aos {mn} minutos</b>"
                f"<p>{e(partes)}</p>" + (f"<p class='n'>Você estava {e(ZONA_PT.get(meu, '?'))}.</p>" if meu else "")
                + f"<p class='n' style='font-size:12px'>{n} partidas de alto elo, pela foto de cada minuto da Riot.</p></div>")
    except Exception:
        return ""
