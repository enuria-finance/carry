"""Aba "Partida": uma tela so, que troca sozinha conforme o momento do cliente.

Fila -> Selecao (coach de pick/ban) -> Carregando (plano de jogo) -> Em jogo (painel ao vivo + plano) -> Fim (pos-jogo).
O plano de jogo e de ANTES da partida: historico contra o oponente, build, missao do dia e o lembrete do Diagnostico.
"""
import html
import threading

from . import diagnosis, icons, live, missions, report

e = lambda x: html.escape("" if x is None else str(x))
LAST = {}          # uid -> ultimo resumo da selecao (para o plano na tela de carregamento)
_LOCK = threading.Lock()
STEPS = [("fila", "Fila"), ("selecao", "Seleção"), ("carregando", "Carregando"), ("jogo", "Em jogo"), ("fim", "Pós-jogo")]

CLASS_TIPS = {
    "Assassin": "Ele procura abate quando chega no nível 6: guarde o Flash ou a habilidade de fuga e recue quando ele some da rota.",
    "Mage": "Ele cutuca de longe: fique atrás dos seus minions e entre na troca logo depois que ele gastar a habilidade principal.",
    "Fighter": "Ele ganha trocas longas: troque rápido e saia antes de ele devolver o dano.",
    "Tank": "Pouco dano no começo: farme à vontade e empurre a onda para ajudar o seu caçador.",
    "Marksman": "Fraco quando alguém chega perto: entre quando ele gastar o deslocamento.",
    "Support": "Pouco farm e dano: pressione a onda e use a vantagem de itens.",
}


def remember(uid, snap, laner):
    if snap and snap.get("me") and snap["me"].get("champion"):
        with _LOCK:
            LAST[uid] = {"champion": snap["me"]["champion"], "laner": laner}


def stepper(cur):
    out = ""
    hit = False
    for key, label in STEPS:
        cls = "on" if key == cur else ("done" if not hit else "")
        if key == cur:
            hit = True
        out += f"<span class='gstep {cls}'><i></i>{e(label)}</span>"
    return f"<div class='gsteps'>{out}</div>"


def plan_cards(con, puuid, games, my_champ, laner, tags_by_name, build_html="", wincond=None, compact=False):
    """Cartoes do plano de jogo. compact=True: uma faixa curta para ficar em cima do painel ao vivo."""
    cards = []
    if laner:
        vs = [g for g in games if (g.get("opp_champion") or "").lower() == laner.lower()]
        rec = ""
        if vs:
            w = sum(1 for g in vs if g["win"])
            rec = f"<p class='gp-d'><span class='tag dado'>dado</span>Você contra ele: {w}V {len(vs) - w}D</p>"
        ctags = tags_by_name.get(laner, [])
        from . import champtips
        tl = champtips.tips_vs(laner, 2, tags=ctags) or ["Jogue a rota com calma e farme: a vantagem vem com itens."]
        cards.append(("⚔", f"Contra {laner}", rec + "".join(f"<p><span class='tag regra'>contra ele</span>{e(t)}</p>" for t in tl), icons.champ(laner, 40, "foe")))
    try:
        st = missions.ensure_today(con, report.my_games(con, puuid, ""))
        m = st["mission"]
        ok = sum(1 for c in st["checks"] if c["ok"])
        cards.append(("🔥", "Missão de hoje", f"<p><b>{e(m['text'])}</b></p><p class='n'>{ok}/{len(st['checks'])} hoje · sequência {st['streak']} dia(s)</p>", ""))
    except Exception:
        pass
    try:            # diagnostico da rota desta partida (antes: suporte recebia o lembrete do mid, de farm)
        from . import profile as _pf
        pos_ = _pf.live_pos() or _pf.position()
        gpos = [g for g in games if g.get("position") == pos_]
    except Exception:
        pos_, gpos = None, []
    if len(gpos) >= 20 or len(games) >= 20:
        lv = next((l for l in diagnosis.levers(gpos if len(gpos) >= 20 else games) if l["pesa"] and l["actionable"]
                   and not (pos_ in ("UTILITY", "JUNGLE") and l["key"] == "csdiff10")), None)
        if lv:
            cards.append(("🎯", "Lembrete do seu diagnóstico", f"<p>{e(lv['training'])}</p>", ""))
    if wincond:
        cards.append(("🧭", "Como o seu time vence", f"<p>{e(wincond['text'])}</p>", ""))
    if compact:
        inner = "".join(f"<div class='gp-mini'><i>{ic}</i><div><b>{e(t)}</b>{body}</div></div>" for ic, t, body, _ in cards[:3])
        return f"<div class='gp-strip'>{inner}</div>"
    inner = "".join(f"<div class='gp-card'><div class='gp-h'><i>{ic}</i><b>{e(t)}</b>{pic}</div>{body}</div>" for ic, t, body, pic in cards)
    head = (f"<div class='gp-head'>{icons.champ(my_champ, 64, 'me') if my_champ else ''}<div><small>Plano de jogo</small>"
            f"<b>{e(my_champ or 'Sua partida')}{(' contra ' + e(laner)) if laner else ''}</b></div></div>")
    return f"<section class='gplan'>{head}<div class='gp-grid'>{inner}{build_html}</div></section>"


CSS = """
/* ---------- aba Partida ---------- */
.gsteps{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 14px}
.gstep{display:inline-flex;align-items:center;gap:8px;padding:7px 14px;border-radius:999px;border:1px solid var(--rule);color:var(--mute);font:600 13px var(--head);background:var(--panel)}
.gstep i{width:8px;height:8px;border-radius:50%;background:currentColor;opacity:.5}
.gstep.done{color:#D6CCC0}.gstep.done i{background:var(--win);opacity:1}
.gstep.on{color:#1a1405;background:linear-gradient(135deg,#E9C46A,#b8923f);border-color:transparent;box-shadow:0 4px 18px rgba(233,196,106,.35)}
.gstep.on i{background:#1a1405;opacity:1;animation:ping2 1.4s infinite}
.gplan{border:1px solid rgba(233,196,106,.4);border-radius:18px;padding:18px 20px;margin:0 0 14px;background:radial-gradient(120% 140% at 0% 0%,rgba(233,196,106,.10),transparent 50%),var(--panel)}
.gp-head{display:flex;align-items:center;gap:14px;margin:0 0 14px}.gp-head small{display:block;color:var(--gold);font:600 13px var(--head)}
.gp-head b{font:700 26px var(--head);color:#fff}.gp-head .cic{border-radius:14px}
.gp-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px}
.gp-card{border:1px solid var(--rule);border-radius:14px;padding:12px 14px;background:rgba(16,11,11,.45)}
.gp-h{display:flex;align-items:center;gap:8px;margin-bottom:6px}.gp-h i{font-style:normal;font-size:18px}.gp-h b{font:700 15px var(--head);color:#fff;flex:1}
.gp-card p{margin:4px 0;font-size:14px;color:#DDD3C7}.gp-card .tag{padding:0;margin-right:8px;font-size:10px}
.gp-strip{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin:0 0 14px}
.gp-mini{display:flex;gap:10px;align-items:flex-start;padding:10px 12px;border:1px solid var(--rule);border-radius:12px;background:var(--panel)}
.gp-mini i{font-style:normal;font-size:18px}.gp-mini b{display:block;font:700 13.5px var(--head);color:#fff}
.gp-mini p{margin:2px 0 0;font-size:12.5px;color:#D6CCC0;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.gp-mini .tag{display:none}
.gwait{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(0,1fr);gap:14px}
.ovl{display:flex;align-items:center;gap:12px;flex-wrap:wrap;padding:12px 16px;border:1px dashed rgba(233,196,106,.45);border-radius:14px;margin:14px 0 0;background:rgba(233,196,106,.04)}
.ovl b{font:700 14px var(--head);color:#fff}.ovl span{color:var(--mute);font-size:13px;flex:1;min-width:220px}
@media (max-width:1000px){.gp-strip,.gwait{grid-template-columns:1fr}}
"""
