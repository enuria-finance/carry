"""Mais ajudas: segundo campeao para aprender, duo, janela ideal para jogar, treino de decisao com as suas partidas,
exercicios do modo de treino e uso do app (local, so com permissao)."""
import html
import json
import os
import random
import time

e = lambda x: html.escape("" if x is None else str(x))
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# ---------- 1) qual segundo campeao aprender ----------
def segundo_campeao(con, puuid, position, champs, limit=3):
    """Campeoes que vencem os oponentes contra os quais o seu main perde (alto elo + o seu historico)."""
    from . import counters, report
    gs = report.my_games(con, puuid, position)
    cnt = {}
    for g in gs[:150]:
        cnt[g["champion"]] = cnt.get(g["champion"], 0) + 1
    if not cnt:
        return None
    main = max(cnt, key=cnt.get)
    opps = {}
    for g in gs:
        if g["champion"] == main and g.get("opp_champion"):
            v = opps.setdefault(g["opp_champion"], [0, 0])
            v[0] += 1
            v[1] += 1 if g["win"] else 0
    bad = []
    for o, (n, w) in opps.items():
        mu = counters.matchup(con, main, o, position)
        mine_bad = n >= 3 and w / n <= 0.4
        top_bad = mu and mu[1] <= 47
        if mine_bad or top_bad:
            bad.append((o, n))
    bad.sort(key=lambda x: -x[1])
    bad = [o for o, _ in bad[:8]]
    if len(bad) < 2:
        return {"main": main, "bad": bad, "picks": []}
    score = {}
    for o in bad:
        for c, (n, w) in counters.vs_enemy(con, o, position).items():
            if c == main or n < 10:
                continue
            s = score.setdefault(c, {"win": 0, "cov": 0, "n": 0, "w": 0})
            s["n"] += n
            s["w"] += w
            if (w + 10) / (n + 20) >= 0.52:
                s["cov"] += 1
    picks = sorted(((c, s) for c, s in score.items() if s["cov"] >= 2), key=lambda kv: (-kv[1]["cov"], -kv[1]["w"] / max(1, kv[1]["n"])))[:limit]
    return {"main": main, "bad": bad, "picks": [(c, s["cov"], round(100 * s["w"] / s["n"]), s["n"]) for c, s in picks]}


def segundo_html(R, champs):
    if not R:
        return ""
    nm = lambda c: (champs.get(c) or {}).get("name") or c
    if not R["picks"]:
        return (f"<div class='card'><b class='gl'>Qual segundo campeão aprender</b><p class='n'>Ainda não dá para dizer: precisa de mais partidas suas com "
                f"{e(nm(R['main']))} contra oponentes diferentes, ou de mais amostra do alto elo.</p></div>")
    rows = "".join(f"<p><b>{e(nm(c))}</b>: vence {cov} dos seus {len(R['bad'])} piores confrontos, {wr}% contra eles no alto elo ({n} jogos)</p>"
                   for c, cov, wr, n in R["picks"])
    return (f"<div class='card'><b class='gl'>Qual segundo campeão aprender</b><p class='n'>Os confrontos em que o seu {e(nm(R['main']))} sofre: "
            f"{e(', '.join(nm(o) for o in R['bad']))}. Estes campeões vencem justamente esses, então cobrem os buracos do seu main.</p>{rows}</div>")


# ---------- 7) duo ----------
def duo_card(con, puuid):
    from .db import load_raw
    rows = con.execute(
        """SELECT o.puuid, COUNT(*) n, SUM(me.win) w, MAX(o.match_id) mid FROM participants me JOIN match_source s USING (match_id)
           JOIN participants o ON o.match_id=me.match_id AND o.team_id=me.team_id AND o.puuid<>me.puuid
           WHERE me.puuid=? AND s.source='me' GROUP BY o.puuid HAVING n >= 5 ORDER BY n DESC LIMIT 8""", (puuid,)).fetchall()
    if not rows:
        return ""
    out = ""
    for pu, n, w, mid in rows:
        name = pu[:8]
        try:
            mj = load_raw(con, mid, "match") or {}
            p = next((x for x in (mj.get("info") or {}).get("participants") or [] if x.get("puuid") == pu), {})
            name = p.get("riotIdGameName") or p.get("summonerName") or name
        except Exception:
            pass
        wr = round(100 * (w or 0) / n)
        out += f"<p>{e(name)}: <b class='{'win' if wr >= 55 else 'loss' if wr <= 45 else ''}'>{wr}%</b> em {n} jogos juntos</p>"
    return ("<div class='card'><b class='gl'>Com quem você joga junto</b><p class='n'>Quem esteve no seu time 5 vezes ou mais (normalmente o seu duo).</p>"
            + out + "</div>")


# ---------- 8) janela ideal ----------
DIAS = ["segunda", "terça", "quarta", "quinta", "sexta", "sábado", "domingo"]


def janela_html(gs):
    hr, dw = {}, {}
    for g in gs:
        if not g.get("started_ms"):
            continue
        t = time.localtime(g["started_ms"] / 1000)
        for d, k in ((hr, t.tm_hour), (dw, t.tm_wday)):
            v = d.setdefault(k, [0, 0])
            v[0] += 1
            v[1] += 1 if g["win"] else 0
    if sum(v[0] for v in hr.values()) < 60:
        return ""
    best_h = sorted([(k, v) for k, v in hr.items() if v[0] >= 15], key=lambda kv: -(kv[1][1] + 10) / (kv[1][0] + 20))
    worst_h = [kv for kv in reversed(best_h) if kv[1][1] / kv[1][0] <= 0.46][:2]
    best_d = sorted([(k, v) for k, v in dw.items() if v[0] >= 15], key=lambda kv: -(kv[1][1] + 10) / (kv[1][0] + 20))
    from . import evolucao2
    bo = evolucao2.by_order(gs)
    lim = next((k - 1 for k, v in sorted(bo.items()) if k >= 2 and v[0] >= 15 and v[1] / v[0] <= 0.46), None)
    pr = lambda k, v: f"{k}h ({round(100 * v[1] / v[0])}% em {v[0]})"
    out = "<div class='card'><b class='gl'>A sua janela ideal para jogar</b>"
    if best_h:
        out += "<p>Melhores horários: <b>" + ", ".join(pr(k, v) for k, v in best_h[:3]) + "</b></p>"
    if worst_h:
        out += "<p>Evite: " + ", ".join(pr(k, v) for k, v in worst_h) + "</p>"
    if best_d:
        out += f"<p>Melhores dias: <b>{', '.join(DIAS[k] for k, _ in best_d[:2])}</b></p>"
    if lim:
        out += f"<p>Máximo por dia: <b>{lim} partida{'s' if lim > 1 else ''}</b> (depois disso o seu winrate cai).</p>"
    return out + "</div>"


# ---------- 2) treino de decisao com as suas partidas ----------
OPCOES = {"lado": "Farmar a onda do lado", "rio": "Ir para o rio ou objetivo com o time", "base": "Voltar para a base",
          "rota": "Ficar na sua rota e pressionar"}
ZONA_OPCAO = {"base": "base", "rio": "rio", "selva": "rio", "meio": "rota", "cima": "lado", "baixo": "lado"}


def treino_situacao(con, puuid):
    """Uma situacao real sua (minuto de uma morte depois dos 12 min) e o que a maioria dos melhores fazia nesse minuto."""
    from . import report, vod
    gs = [g for g in report.my_games(con, puuid, "")[:40]]
    random.shuffle(gs)
    for g in gs:
        try:
            ms, G = vod.moments(con, puuid, g["match_id"])
        except Exception:
            continue
        mortes = [m for m in ms if m["kind"] == "morte" and m["t_ms"] >= 12 * 60000]
        if not mortes:
            continue
        m = random.choice(mortes)
        mn = int(m["t_ms"] // 60000)
        dist, n = vod.top_minute(con, G.me["champion"], G.me["position"], mn)
        if n < 15 or not dist:
            continue
        pos = G.me["position"]
        alvo = ZONA_OPCAO.get(dist[0][0])
        if pos != "MIDDLE" and dist[0][0] in ("cima", "baixo"):
            alvo = "rota" if ((pos == "TOP" and dist[0][0] == "cima") or (pos in ("BOTTOM", "UTILITY") and dist[0][0] == "baixo")) else "lado"
        if not alvo:
            continue
        fr = G.fr(G.pid, m["t_ms"]) or {}
        op = G.fr(G.opp["participant_id"], m["t_ms"]) if G.opp else None
        ctx = [f"Partida de {G.me['champion']} contra {G.opp['champion'] if G.opp else '?'}, {mn} minutos."]
        if fr and op:
            ctx.append(f"Você tinha {fr.get('gold', 0) - op.get('gold', 0):+d} de ouro total contra o oponente de rota.")
        nxt = [o for o in G.objs if o["kind"] == "monstro" and 0 <= o["t"] - m["t_ms"] <= 90000]
        if nxt:
            ctx.append(f"Em menos de 1 minuto e meio alguém pegou: {nxt[0]['name']}.")
        return {"mid": g["match_id"], "t": m["t_ms"], "ctx": ctx, "alvo": alvo, "dist": dist[:4], "n": n,
                "voce": vod.ZONA_PT.get(vod.zona(*(G.pos(G.pid, m["t_ms"]) or (None, None))), "?"), "champ": G.me["champion"]}
    return None


def treino_html(S):
    if not S:
        return ("<div class='card'><p class='n'>Ainda não há situação para treinar: precisa de partidas suas com mortes depois dos 12 minutos "
                "e da amostra do alto elo com linha do tempo.</p></div>")
    from .vod import ZONA_PT
    btns = "".join(f"<button type='button' class='btn tq' data-k='{k}' style='width:auto;margin:4px'>{e(v)}</button>" for k, v in OPCOES.items())
    dist = " · ".join(f"{p}% {ZONA_PT[z]}" for z, p in S["dist"])
    return (f"<div class='card'><b class='gl'>O que você faz aqui?</b>" + "".join(f"<p>{e(x)}</p>" for x in S["ctx"])
            + f"<div style='margin:10px 0'>{btns}</div><div id='tqres' hidden>"
            f"<p><b>O que a maioria dos melhores de {e(S['champ'])} fazia nesse minuto:</b> {e(OPCOES[S['alvo']])}.</p>"
            f"<p class='n'>{e(dist)} ({S['n']} partidas).</p><p>Você, nessa partida, estava {e(S['voce'])} e morreu logo depois.</p>"
            f"<p><a class='btn' style='width:auto' href='/revisao/{e(S['mid'])}#m{S['t']}'>Ver essa morte na revisão</a> "
            "<a class='btn gold' style='width:auto' href='/treino'>Outra situação</a></p></div></div>"
            "<script>document.querySelectorAll('.tq').forEach(function(b){b.onclick=function(){var ok=b.dataset.k==='" + S["alvo"] + "';"
            "document.querySelectorAll('.tq').forEach(function(x){x.disabled=true;if(x.dataset.k==='" + S["alvo"] + "')x.classList.add('gold')});"
            "var r=document.getElementById('tqres');r.hidden=false;r.insertAdjacentHTML('afterbegin','<p><b>'+(ok?'Igual aos melhores.':'Diferente dos melhores.')+'</b></p>')}})</script>")


# ---------- 11) exercicios do modo de treino ----------
EXERCICIOS = [
    ("Farm só com ataque básico", 5, "Modo de treino, minions ligados. Até 5 minutos do relógio, último golpe só com ataque básico. Meta: perder no máximo 2 minions por onda."),
    ("Farm com habilidade nos minions longe", 3, "Pegue com a sua habilidade de tiro os minions que você não alcançaria com ataque básico (canhão e os de trás)."),
    ("Combo nos bonecos", 3, "Repita o seu combo completo no boneco até sair sem pensar, depois faça 10 vezes seguidas sem erro."),
    ("Habilidade de tiro em alvo andando", 4, "Ligue os bonecos andando. Acerte só quando o boneco mudar de direção ou parar; nada no alcance máximo em linha reta."),
    ("Desvio", 3, "Com um amigo ou na partida personalizada contra bots: ande de lado o tempo todo e conte quantas habilidades desviou."),
]


def exercicios_html():
    cards = ""
    for i, (t, mins, txt) in enumerate(EXERCICIOS):
        cards += (f"<div class='card'><b class='gl'>{e(t)}</b><p>{e(txt)}</p><div class='row' style='align-items:center'>"
                  f"<button type='button' class='btn gold ex' data-s='{mins * 60}' data-i='{i}' style='width:auto'>Começar {mins} min</button>"
                  f"<b id='ex{i}' style='font:700 22px var(--head);margin-left:12px'></b></div></div>")
    js = ("<script>document.querySelectorAll('.ex').forEach(function(b){b.onclick=function(){var s=+b.dataset.s,o=document.getElementById('ex'+b.dataset.i);"
          "b.disabled=true;var t=setInterval(function(){s--;o.textContent=Math.floor(s/60)+':'+('0'+s%60).slice(-2);if(s<=0){clearInterval(t);o.textContent='Feito';b.disabled=false}},1000)}})</script>")
    return "<p class='n'>Antes da ranqueada, 10 minutos no modo de treino. Escolha o exercício que ataca o seu maior buraco (veja em Comparar).</p>" + cards + js


# ---------- 12) uso do app (local, com permissao) ----------
USO = os.path.join(RAIZ, "cache", "uso.json")
USO_OK = os.path.join(RAIZ, "cache", "uso_permitido.txt")


def uso_permitido():
    return os.path.exists(USO_OK)


def uso_conta(pagina):
    """Conta quantas vezes cada pagina foi aberta (so no seu PC; nada sai daqui enquanto nao houver servidor)."""
    if not uso_permitido() or not pagina or pagina.startswith(("/api", "/static")):
        return
    try:
        d = json.load(open(USO, encoding="utf-8")) if os.path.exists(USO) else {}
        k = "/" + pagina.strip("/").split("/")[0]
        d[k] = d.get(k, 0) + 1
        with open(USO, "w", encoding="utf-8") as fh:
            json.dump(d, fh)
    except Exception:
        pass


def uso_html():
    ok = uso_permitido()
    d = {}
    try:
        d = json.load(open(USO, encoding="utf-8"))
    except Exception:
        pass
    rows = "".join(f"<p>{e(k)}: {v}</p>" for k, v in sorted(d.items(), key=lambda kv: -kv[1])[:15])
    return ("<div class='card'><b class='gl'>Uso do app (anônimo)</b><p class='n'>Conta só quantas vezes cada tela é aberta, sem partidas, nomes ou chaves. "
            "Hoje fica só neste PC; quando o Carry tiver servidor, isso ajuda a decidir o que melhorar.</p>"
            f"<form method='post' action='/uso'><button class='btn' style='width:auto'>{'Desligar' if ok else 'Permitir'}</button></form>" + rows + "</div>")


def uso_alternar():
    try:
        if uso_permitido():
            os.remove(USO_OK)
        else:
            os.makedirs(os.path.dirname(USO_OK), exist_ok=True)
            open(USO_OK, "w").write("1")
    except OSError:
        pass
