"""Runas e itens de quem joga melhor: agrega a amostra do topo (com n e winrate).

Tudo vem das partidas da propria Riot que o comando `topo` guardou. Se a amostra
for pequena o app diz isso; ele nunca inventa numero.
"""
import json
import statistics
from collections import Counter

from . import report

START_MS = 90000          # compras ate 1:30 contam como itens iniciais
COMPLETE_MIN_GOLD = 1100  # definicao do app de "item completo" (inclui botas)


MIN_ROWS = 20          # menos que isso a build e ruido (antes 10)


def top_rows(con, champion, position=None):
    """Jogadores do campeao NA SUA ROTA nas partidas de alto elo guardadas. Nunca troca de rota sozinho: build, runa e
    item de suporte nao servem para o mid (antes, com pouca amostra na rota, pegava a rota em que o campeao mais aparece)."""
    return top_rows_info(con, champion, position)[0]


def top_rows_info(con, champion, position=None, allow_move=False):
    """(linhas, posicao usada, trocou_de_posicao). allow_move so para tela de consulta que avisa a troca."""
    if position is None:
        from . import profile
        position = profile.position()
    rows = _rows_at(con, champion, position)
    if len(rows) >= MIN_ROWS or not allow_move:
        return rows, position, False
    best = con.execute(
        """SELECT p.position, COUNT(*) n FROM participants p JOIN match_source s USING (match_id)
           WHERE s.source='top' AND p.champion=? AND COALESCE(p.position,'')<>'' GROUP BY p.position ORDER BY n DESC LIMIT 1""",
        (champion,)).fetchone()
    if best and best[0] != position and best[1] > len(rows):
        return _rows_at(con, champion, best[0]), best[0], True
    return rows, position, False


def matchup_rows(con, rows, opp=None, foes=(), min_vs=15, min_comp=30):
    """Recorta a amostra para parecer com a partida atual: primeiro contra o MESMO oponente de rota; se tiver pouco,
    contra composicoes com a mesma quantidade de campeoes de dano magico. Devolve (linhas, motivo)."""
    if not rows or not (opp or foes):
        return rows, None
    ids = [r["match_id"] for r in rows]
    enemy = {}
    for i in range(0, len(ids), 400):
        ch = ids[i:i + 400]
        for r in con.execute(
                f"""SELECT me.match_id, me.participant_id, o.champion, o.position, me.position mp FROM participants me
                    JOIN participants o ON o.match_id=me.match_id AND o.team_id<>me.team_id
                    WHERE me.match_id IN ({','.join('?' * len(ch))})""", ch):
            enemy.setdefault((r[0], r[1]), []).append((r[2], r[3], r[4]))
    if opp:
        vs = [r for r in rows if any(c == opp and p_ == mp for c, p_, mp in enemy.get((r["match_id"], r["participant_id"]), []))]
        if len(vs) >= min_vs:
            return vs, f"contra {opp}"
    if foes:
        tags = {}
        try:
            from .ddragon import DataDragon
            got = next((v for k, v in DataDragon._SHARED.items() if k[2] == "champion"), None)     # ja lido pelo app
            if got:
                tags = {k: v.get("tags", []) for k, v in (got.get("data") or {}).items()}
            else:
                import os as _os
                tags = {k: v.get("tags", []) for k, v in DataDragon(cache_dir=_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "cache")).champions().items()}
        except Exception:
            tags = {}
        ap = lambda cs: sum(1 for c in cs if "Mage" in (tags.get(c) or []))
        want = ap(foes)
        cnt = {id(r): ap([c for c, _, _ in enemy.get((r["match_id"], r["participant_id"]), [])]) for r in rows}
        for tol in (0, 1):
            sim = [r for r in rows if abs(cnt[id(r)] - want) <= tol]
            if len(sim) >= min_comp and len(sim) < len(rows) * 0.9:
                return sim, (f"contra times com {want} mago{'s' if want != 1 else ''}" if tol == 0 else
                             ("contra times com muito dano mágico" if want >= 2 else "contra times de pouco dano mágico"))
    return rows, None


def similar_finals(con, champions, position, items_data, exclude=(), limit=5):
    """Itens finais mais comuns de campeoes parecidos (mesma classe e posicao) na base: completa uma build com amostra pequena."""
    if not champions:
        return []
    q = ",".join("?" * len(champions))
    c = Counter()
    for (raw,) in con.execute(
            f"""SELECT x.items FROM participants p JOIN participant_extra x USING (match_id, participant_id)
                JOIN match_source s USING (match_id) WHERE s.source='top' AND p.position=? AND p.champion IN ({q}) LIMIT 4000""",
            (position, *champions)):
        for i in json.loads(raw or "[]")[:6]:
            if i and i not in exclude and is_complete(items_data, i) and "Boots" not in items_data.get(str(i), {}).get("tags", []):
                c[i] += 1
    return [i for i, _ in c.most_common(limit)]


def sane_item(items_data, champ_info, item_id):
    """False para item claramente do tipo de dano errado (ex.: item de dano fisico num mago)."""
    it = items_data.get(str(item_id)) or {}
    tags = set(it.get("tags") or [])
    ctags = (champ_info or {}).get("tags") or []
    info = (champ_info or {}).get("info") or {}
    if not ctags or "Tank" in ctags[:1] or "Support" in ctags[:1]:
        return True
    ap = info.get("magic", 0) > info.get("attack", 0) and "Marksman" not in ctags
    if ap:
        return not ({"Damage", "CriticalStrike"} & tags) or "SpellDamage" in tags
    return not ("SpellDamage" in tags and not ({"Damage", "AttackSpeed", "OnHit"} & tags))


def full_build(st):
    """Os 5 itens grandes em ordem: os 3 primeiros mais comuns por posicao, depois os finais mais comuns."""
    out = list(st.get("path") or [])          # o caminho que os melhores seguem de verdade (1o, depois 2o de quem fez o 1o...)
    for slot in st["order"][len(out):]:
        for i, _ in slot:
            if i not in out:
                out.append(i)
                break
    for slot in st.get("late") or []:          # 4o e 5o itens na ordem em que os melhores compram
        for i, _ in slot:
            if i not in out:
                out.append(i)
                break
    for i, _ in st["finals"]:
        if len(out) >= 5:
            break
        if i not in out:
            out.append(i)
    return out[:5]


def _pkey(p):
    try:
        return tuple(int(x) for x in str(p).split(".")[:2])
    except ValueError:
        return (0, 0)


def _rows_at(con, champion, position):
    """Partidas dos melhores com o campeao na rota, SO do meta atual: o patch mais novo (e os anteriores so se faltar
    amostra, no maximo 3 patches e 45 dias). Build e runa velhas (ex.: Eletrocutar de Zed de meses atras) ficam de fora."""
    import time as _t
    rows = [dict(r) for r in con.execute(
        """SELECT p.match_id, p.participant_id, p.win, x.items, x.perks, x.spells, m.started_ms, m.patch
           FROM participants p JOIN participant_extra x USING (match_id, participant_id)
           JOIN matches m USING (match_id) JOIN match_source s USING (match_id)
           WHERE s.source='top' AND p.champion=? AND p.position=?
             AND COALESCE(m.duration_s,0) >= 300""", (champion, position)).fetchall()]
    if not rows:
        return rows
    cutoff = (_t.time() - 45 * 86400) * 1000
    recent = [r for r in rows if (r.get("started_ms") or 0) >= cutoff] or rows
    patches = sorted({r.get("patch") for r in recent if r.get("patch")}, key=_pkey, reverse=True)
    keep, out = set(), []
    for p in patches[:3]:
        keep.add(p)
        out = [r for r in recent if r.get("patch") in keep]
        if len(out) >= max(MIN_ROWS, 20):
            break
    out = out or recent
    out.sort(key=lambda r: -(r.get("started_ms") or 0))
    return out


def page_from_perks(perks):
    """(estilo_primario, estilo_secundario, [9 ids]) ou None se faltar algo."""
    try:
        styles = {s["description"]: s for s in perks["styles"]}
        prim, sub = styles["primaryStyle"], styles["subStyle"]
        sel = [x["perk"] for x in prim["selections"]] + [x["perk"] for x in sub["selections"]]
        st = perks["statPerks"]
        sel += [st["offense"], st["flex"], st["defense"]]
        if len(sel) != 9:
            return None
        return prim["style"], sub["style"], sel
    except (KeyError, TypeError):
        return None


def rune_stats(rows):
    """Paginas de runa mais usadas: [(page, n, wins)] da mais frequente."""
    c, w = Counter(), Counter()
    for r in rows:
        page = page_from_perks(json.loads(r["perks"] or "{}"))
        if page:
            key = (page[0], page[1], tuple(page[2]))
            c[key] += 1
            w[key] += r["win"]
    return [(k, n, w[k]) for k, n in c.most_common()]


def is_complete(items_data, item_id):
    it = items_data.get(str(item_id))
    if not it or it.get("into"):
        return False
    g = it.get("gold", {})
    return g.get("purchasable", True) and g.get("total", 0) >= COMPLETE_MIN_GOLD \
        and "Consumable" not in it.get("tags", [])


def _purchases(con, mid, pid):
    return [(r["t_ms"], json.loads(r["data"])["itemId"]) for r in con.execute(
        "SELECT t_ms, data FROM events WHERE match_id=? AND type='ITEM_PURCHASED' AND pid=? "
        "ORDER BY t_ms", (mid, pid)) if "itemId" in json.loads(r["data"])]


def start_inventory(con, mid, pid):
    """Itens que a pessoa REALMENTE saiu da base (ate 1:30): compras menos desfazer/vendas, sem o amuleto (trinket)."""
    inv = []
    for (t, typ, data) in con.execute(
            "SELECT t_ms, type, data FROM events WHERE match_id=? AND pid=? AND type IN ('ITEM_PURCHASED','ITEM_UNDO','ITEM_SOLD') "
            "AND t_ms<? ORDER BY t_ms", (mid, pid, START_MS)):
        d = json.loads(data)
        if typ == "ITEM_PURCHASED":
            inv.append(d.get("itemId"))
        elif typ == "ITEM_UNDO":
            before, after = d.get("beforeId"), d.get("afterId")
            if before and before in inv:
                inv.remove(before)          # desfez a compra
            if after:
                inv.append(after)           # desfez a venda
        elif typ == "ITEM_SOLD" and d.get("itemId") in inv:
            inv.remove(d.get("itemId"))
    return tuple(sorted(i for i in inv if i and i not in (3340, 3363, 3364)))


def item_stats(con, rows, items_data):
    """Itens iniciais, ordem dos 3 primeiros completos, botas e itens finais mais comuns."""
    starts, orders, boots, finals = Counter(), [Counter(), Counter(), Counter()], Counter(), Counter()
    paths = []
    late = [Counter(), Counter()]          # 4o e 5o itens
    first_min = []
    for r in rows:
        buys = _purchases(con, r["match_id"], r["participant_id"])
        if not buys:
            continue
        st = start_inventory(con, r["match_id"], r["participant_id"])
        if st:
            starts[st] += 1
        seen, got_boots = [], False
        for t, i in buys:
            it_ = items_data.get(str(i), {})
            if not got_boots and "Boots" in it_.get("tags", []) and (it_.get("gold") or {}).get("total", 0) >= 900:
                boots[i] += 1          # botas de nivel 2 (as de nivel 3 viram 'into' e nao contam como item completo)
                got_boots = True
            if t >= START_MS and is_complete(items_data, i) and i not in seen:
                seen.append(i)
                if len(seen) == 1:
                    first_min.append(t / 60000)
        legend = []
        for i in seen:
            if "Boots" in items_data.get(str(i), {}).get("tags", []):
                continue
            else:
                legend.append(i)
        for k, i in enumerate(legend[:3]):
            orders[k][i] += 1
        paths.append(tuple(legend[:3]))
        for k, i in enumerate(legend[3:5]):
            late[k][i] += 1
        for i in json.loads(r["items"] or "[]")[:6]:
            if i and is_complete(items_data, i) and "Boots" not in items_data.get(str(i), {}).get("tags", []):
                finals[i] += 1
    st_list = starts.most_common(3)
    # suporte: o item de suporte (Atlas Mundial) agora sai de graça e não aparece como compra na Riot.
    # Sem isto o item inicial ficava só com as poções.
    try:
        rr = list(rows)[:40]
        pos = [con.execute("SELECT position FROM participants WHERE match_id=? AND participant_id=?",
                           (r["match_id"], r["participant_id"])).fetchone() for r in rr]
        sup = sum(1 for p in pos if p and (p[0] or "").upper() == "UTILITY")
        if rr and sup >= len(rr) / 2:
            atlas = next((k for k, it in items_data.items() if (it.get("gold") or {}).get("purchasable")
                          and {"GoldPer", "Vision", "Lane"} <= set(it.get("tags") or []) and not it.get("from")
                          and (it.get("gold") or {}).get("total", 0) >= 300 and len(k) == 4), None)
            if atlas:
                atlas = int(atlas)
                st_list = [(tuple([atlas] + [i for i in ids if i != atlas]), n) for ids, n in st_list] or [((atlas,), 0)]
    except Exception:
        pass
    path = []
    pool = [p for p in paths if p]
    for k in range(3):
        c = Counter(p[k] for p in pool if len(p) > k and p[k] not in path)
        if not c:
            break
        i, n_ = c.most_common(1)[0]
        if n_ < 4 and k:                        # pouca gente seguiu esse caminho: para aqui e completa pelo geral
            break
        path.append(i)
        pool = [p for p in pool if len(p) > k and p[k] == i]
    return {"n": len([1 for r in rows]), "starts": st_list, "path": path,
            "order": [o.most_common(3) for o in orders], "late": [o.most_common(5) for o in late], "boots": boots.most_common(2),
            "finals": finals.most_common(8),
            "first_item_min": statistics.median(first_min) if first_min else None}


def my_first_item_min(con, mid, pid, items_data):
    for t, i in _purchases(con, mid, pid):
        if t >= START_MS and is_complete(items_data, i):
            return t / 60000
    return None


def _champs():
    try:
        from .ddragon import DataDragon
        got = next((v for k, v in DataDragon._SHARED.items() if k[2] == "champion"), None)
        if got:
            return got.get("data") or {}
        import os as _os
        return DataDragon(cache_dir=_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "cache")).champions()
    except Exception:
        return {}


def clean_build(st, items_data, champion, position, champs=None):
    """A build da amostra, ja conferida para o campeao NA ROTA: {"order","boots","extra","start"}.
    Tira item de suporte fora do suporte, filhote fora da selva e item do tipo de dano errado (salvo se 20%+ fecha)."""
    from . import itemfit
    champs = champs if champs is not None else _champs()
    n = st.get("n") or 0
    fin = dict(st.get("finals") or [])
    order = itemfit.clean_seq(champs, items_data, champion, position, full_build(st), fin, n)
    boots = next((i for i, _ in st.get("boots") or [] if itemfit.clean_seq(champs, items_data, champion, position, [i])), None)
    extra = itemfit.clean_seq(champs, items_data, champion, position, [i for i, _ in st.get("finals") or [] if i not in order], fin, n)
    start = []
    if st.get("starts"):
        start = [i for i in st["starts"][0][0]
                 if not ((itemfit.is_support_item(items_data.get(str(i))) and position != "UTILITY")
                         or (itemfit.is_jungle_item(items_data.get(str(i))) and position != "JUNGLE"))]
    return {"order": order, "boots": boots, "extra": extra, "start": start}


def item_set(title, champion_key, stats, items_data, champion=None, position=None):
    """Conjunto de itens no formato do cliente, na ordem do topo (a mesma build conferida que o app mostra)."""
    if champion and position:
        b = clean_build(stats, items_data, champion, position)
        stats = dict(stats, path=b["order"][:3], order=[[(i, 0)] for i in b["order"][:3]],
                     boots=[(b["boots"], 0)] if b["boots"] else [], starts=[(tuple(b["start"]), 0)] if b["start"] else [],
                     finals=[(i, 0) for i in b["order"][3:] + b["extra"]])
    def blk(name, ids):
        cnt = Counter(ids)          # 2 poções viram 1 ícone com "x2", como no cliente
        return {"type": name, "items": [{"id": str(i), "count": cnt[i]} for i in dict.fromkeys(ids)]}
    blocks = []
    if stats["starts"]:
        blocks.append(blk("Inicial (mais comum)", stats["starts"][0][0]))
    order = [o[0][0] for o in stats["order"] if o]
    if order:
        blocks.append(blk("Ordem dos primeiros itens", order))
    if stats["boots"]:
        blocks.append(blk("Botas", [stats["boots"][0][0]]))
    extra = [i for i, n in stats["finals"] if i not in order][:5]
    if extra:
        blocks.append(blk("Situacionais frequentes", extra))
    return {"uid": "lol-coach-" + str(champion_key), "title": title, "type": "custom",
            "map": "any", "mode": "any", "priority": False, "sortrank": 0,
            "associatedChampions": [champion_key], "associatedMaps": [11], "blocks": blocks}


def rune_page(name, page):
    prim, sub, sel = page
    return {"name": name, "primaryStyleId": prim, "subStyleId": sub,
            "selectedPerkIds": list(sel), "current": True}


def spell_stats(rows):
    """Pares de feiticos mais usados: [((a, b), n, vitorias)]."""
    c, w = Counter(), Counter()
    for r in rows:
        try:
            pair = tuple(sorted(x for x in json.loads(r.get("spells") or "[]") if x))
        except ValueError:
            continue
        if len(pair) == 2:
            c[pair] += 1
            w[pair] += r["win"]
    return [(k, n, w[k]) for k, n in c.most_common()]


# ---- runas por tipo de oponente (ex.: Zed contra tanque vai de Conquistador) ----
OPP_CLASS = [("tanque", "Tanques e lutadores", ("Tank", "Fighter")), ("mago", "Magos", ("Mage",)),
             ("assassino", "Assassinos", ("Assassin",)), ("atirador", "Atiradores", ("Marksman",)), ("suporte", "Suportes", ("Support",))]


def class_of(tags):
    t = list(tags or [])
    if not t:
        return None
    first = t[0]
    for key, _, names in OPP_CLASS:
        if first in names:
            return key
    return None


def opponent_of(con, match_id, pid):
    r = con.execute("""SELECT p2.champion FROM participants p1 JOIN participants p2 ON p2.match_id=p1.match_id
                       AND p2.team_id<>p1.team_id AND p2.position=p1.position WHERE p1.match_id=? AND p1.participant_id=? LIMIT 1""",
                    (match_id, pid)).fetchone()
    return r[0] if r else None


def runes_by_opponent(con, rows, champs):
    """{classe: [(pagina, n, vitorias)]} pela classe (Data Dragon) do oponente de rota em cada partida."""
    groups = {}
    for r in rows:
        opp = opponent_of(con, r["match_id"], r["participant_id"])
        cls = class_of((champs.get(opp) or {}).get("tags")) if opp else None
        if cls:
            groups.setdefault(cls, []).append(r)
    return {k: keystone_stats(v) for k, v in groups.items()}, {k: len(v) for k, v in groups.items()}


def keystone_stats(rows):
    """Agrupa pela runa principal + arvore secundaria (o que muda o jeito de jogar); devolve a pagina completa mais comum de cada grupo.
    [(pagina_mais_comum, n, vitorias)]."""
    from collections import defaultdict
    groups = defaultdict(list)
    for page, n, w in rune_stats(rows):
        groups[(page[2][0], page[1])].append((page, n, w))
    out = []
    for lst in groups.values():
        n = sum(x[1] for x in lst)
        w = sum(x[2] for x in lst)
        out.append((max(lst, key=lambda x: x[1])[0], n, w))
    return sorted(out, key=lambda x: -x[1])


def best_page(stats, min_n=3):
    """A runa que os melhores MAIS usam agora. So troca por outra se ela tiver amostra de verdade (15+ jogos e 25% do uso da
    mais comum) e ganhar claramente mais (5 pontos). Antes, uma runa rara com poucas vitorias passava na frente."""
    if not stats:
        return None
    top = stats[0]
    wr = lambda x: (x[2] + 4) / (x[1] + 8)
    cands = [x for x in stats if x[1] >= max(15, 0.25 * top[1], min_n)]
    best = max(cands, key=wr) if cands else top
    return best if best is not top and wr(best) - wr(top) >= 0.05 else top


def rows_with_page(rows, keystone, sub_style):
    """Partidas em que a pessoa usou essa runa principal com essa arvore secundaria."""
    out = []
    for r in rows:
        pg = page_from_perks(json.loads(r["perks"] or "{}"))
        if pg and pg[2][0] == keystone and pg[1] == sub_style:
            out.append(r)
    return out
