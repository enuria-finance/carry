"""Emblemas oficiais de elo (pacote que a Riot publica no portal de desenvolvedores).

Baixa uma vez no PC de quem roda o app e guarda em cache/ranks; se nao der, o app usa o brasao desenhado.
"""
import io
import os
import threading
import urllib.request
import zipfile

URL = "https://static.developer.riotgames.com/docs/lol/ranked-emblems-latest.zip"
TIERS = ["IRON", "BRONZE", "SILVER", "GOLD", "PLATINUM", "EMERALD", "DIAMOND", "MASTER", "GRANDMASTER", "CHALLENGER"]
STATE = {"dir": None}


def folder():
    return STATE["dir"]


def path_for(tier):
    d = STATE["dir"]
    return os.path.join(d, f"{tier.lower()}.png") if d else None


def available(tier):
    p = path_for((tier or "").upper()) if tier else None
    return bool(p and os.path.exists(p))


def _pick(names, tier):
    t = tier.lower()
    cands = [n for n in names if n.lower().endswith(".png") and t in os.path.basename(n).lower()
             and not (t == "master" and "grand" in os.path.basename(n).lower())]
    return sorted(cands, key=len)[0] if cands else None


def ensure(ddir, fetch=None):
    """Em segundo plano: baixa e extrai os emblemas se ainda nao existem."""
    STATE["dir"] = os.path.join(ddir, "cache", "ranks")
    os.makedirs(STATE["dir"], exist_ok=True)
    if all(available(t) for t in TIERS):
        return

    def run():
        try:
            if fetch:
                raw = fetch(URL)
            else:
                req = urllib.request.Request(URL, headers={"User-Agent": "lol-coach/0.1"})
                with urllib.request.urlopen(req, timeout=60) as r:
                    raw = r.read()
            with zipfile.ZipFile(io.BytesIO(raw)) as z:
                names = z.namelist()
                for t in TIERS:
                    n = _pick(names, t)
                    if n:
                        with open(path_for(t), "wb") as fh:
                            fh.write(z.read(n))
        except Exception as ex:  # sem internet ou formato novo: fica o brasao desenhado
            print(f"Emblemas de elo não baixados: {ex}")
    threading.Thread(target=run, daemon=True).start()
