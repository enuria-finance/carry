"""Telas de progresso: missao do dia (com sequencia e selos), subida de PDL, tendencias e comparacao com o proximo elo."""
import html

from . import icons, ranks

e = lambda x: html.escape("" if x is None else str(x))


def _fmtv(metric, v):
    if v is None:
        return "sem dado"
    if metric == "deaths_before_10":
        return f"{int(v)} morte{'s' if int(v) != 1 else ''}"
    if metric in ("csdiff10",):
        return f"{int(v):+d} CS"
    if metric == "golddiff15":
        return f"{int(v):+d} de ouro"
    if metric == "cs_per_min":
        return f"{v:.1f} CS/min".replace(".", ",")
    return f"{v:.1f}"


FLAME = ("<svg class='flame' viewBox='0 0 80 104' aria-hidden='true'><path d='M40 2C46 22 70 34 70 64a30 30 0 0 1-60 0C10 46 22 38 26 22c6 10 10 14 14 16C40 26 36 14 40 2z'/>"
         "<path class='in' d='M40 44c4 10 16 16 16 30a16 16 0 0 1-32 0c0-8 6-12 8-20 3 4 5 6 8 7 0-6-2-11 0-17z'/></svg>")


def mission_card(st, splash_url):
    m = st["mission"]
    checks = ""
    for c in st["checks"]:
        cls = "ok" if c["ok"] else ("no" if c["value"] is not None else "na")
        mark = "✓" if c["ok"] else ("✕" if c["value"] is not None else "–")
        checks += (f"<a class='mchk {cls}' href='/partida/{e(c['match_id'])}'>{icons.champ(c['champion'], 26)}"
                   f"<span>{e(c['champion'])}</span><em>{mark} {e(_fmtv(m['metric'], c['value']))}</em></a>")
    checks += "<span class='mchk wait'>próxima partida…</span>"
    why = ""
    if st["why"]:
        hi, lo, gap = st["why"]
        why = (f"<p class='msub'>Nos seus jogos com {e(hi['label'].lower())} você vence <b class='win'>{hi['wr']}%</b>; "
               f"com {e(lo['label'].lower())}, <b class='loss'>{lo['wr']}%</b>. Cumpra em pelo menos metade das partidas de hoje.</p>")
    else:
        why = "<p class='msub'>Cumpra em pelo menos metade das partidas de hoje. O app confere sozinho a cada sincronização.</p>"
    status = {"done": ("done", "Missão de hoje cumprida"), "failed": ("failed", "Ainda dá tempo de virar o dia"),
              "pending": ("", "Missão de hoje")}[m["status"]]
    lvl = " · nível 2" if m.get("level") else ""
    badges = "".join(f"<i class='{'got' if got else ''}' title='{e(name)}: {e(sub)}'>{d}</i>" for d, name, sub, got in st["badges"])
    nxt = next((d for d, _, _, got in st["badges"] if not got), None)
    goal = (f"faltam {nxt - st['streak']} para o selo de {nxt}" if nxt and st["streak"] < nxt else "todos os selos conquistados")
    from . import bg
    art = bg.art("m-art", splash_url)
    return (f"<section class='mhero {status[0]}' id='mhero'>{art}<div class='m-fade'></div><canvas class='m-fx'></canvas><div class='m-sweep'></div>"
            f"<div class='m-copy'><span class='m-k'>{e(status[1])}{lvl}</span><h1 class='m-t'>{e(m['text'])}</h1>{why}"
            f"<div class='mchks'>{checks}</div></div>"
            f"<div class='m-streak'>{FLAME}<b>{st['streak']}</b><span>dia{'s' if st['streak'] != 1 else ''} seguido{'s' if st['streak'] != 1 else ''} cumprindo</span>"
            f"<div class='m-badges'>{badges}</div><small>{e(goal)} · recorde {st['best']}</small></div></section>")


def rise_section(hist, games, tier_colors, link, wide=False):
    d = ranks.delta_days(hist)
    head = ""
    if d is not None:
        head = (f"<span class='pill {'okp' if d > 0 else 'badp' if d < 0 else ''}'><small>14 dias</small>{d:+d} PDL</span>")
    out = (f"<div class='card rise'><div class='rise-h'><div><b class='gl'>Sua subida</b>"
           f"<p class='n'>PDL a cada sincronização, com as faixas de elo ao fundo.</p></div>{head}</div>"
           + (ranks.chart(hist, tier_colors, 1150, 300) if wide else ranks.chart(hist, tier_colors)) + "</div>")
    tr = ranks.trends(games)
    if tr:
        cards = ""
        for t in tr:
            cls = "flat" if t["flat"] else ("up" if t["better"] else "dn")
            arrow = "→" if t["flat"] else ("▲" if t["diff"] > 0 else "▼")
            word = "estável" if t["flat"] else ("melhorando" if t["better"] else "piorando")
            s = t["series"][-20:]
            sp = ""
            if len(s) >= 3:
                lo_, hi_ = min(s), max(s)
                rng = (hi_ - lo_) or 1
                pts = " ".join(f"{i * 120 / (len(s) - 1):.1f},{28 - (v - lo_) / rng * 24:.1f}" for i, v in enumerate(s))
                sp = f"<svg class='tsp' viewBox='0 0 120 30' preserveAspectRatio='none'><polyline points='{pts}' pathLength='1'/></svg>"
            fmt = lambda v: f"{v:.{t['nd']}f}".replace(".", ",") + ("%" if t["label"].startswith("Participa") else "")
            cards += (f"<div class='trend {cls}'><small>{e(t['label'])}</small><b>{e(fmt(t['now']))}</b>"
                      f"<span class='tw'>{arrow} {word} <em>antes {e(fmt(t['before']))}</em></span>{sp}</div>")
        out += ("<h2>Sua evolução · últimos 10 jogos contra os 10 anteriores</h2><div class='trends'>" + cards + "</div>")
    return out


def elo_compare(my_tier, target, rows, n_target, tier_pt, crest, form_html):
    """Voce x mediana dos jogadores do proximo elo na sua posicao."""
    leg = (f"<div class='lg'><span><i style='background:#8cc4ff'></i>Você (média)</span>"
           f"<span><i style='background:#E9C46A'></i>Mediana {e(tier_pt.get(target, target))}</span></div>")
    out = ""
    for r in rows:
        m, t = r["mine"], r["top"]
        mx = max([abs(v) for v in (m, t) if v is not None] + [0.0001])
        wm = 0 if m is None else max(3, 100 * abs(m) / mx)
        wt = 0 if t is None else max(3, 100 * abs(t) / mx)
        if m is None or t is None:
            d, dc = "–", "eq"
        else:
            diff = m - t
            good = (diff > 0) == r.get("higher", True)
            dc = "eq" if abs(diff) < 10 ** (-r["nd"]) else ("up" if good else "dn")
            d = f"{'+' if diff > 0 else ''}{diff:.{r['nd']}f}"
        fm = lambda v: "–" if v is None else f"{v:.{r['nd']}f}"
        out += (f"<div class='duel rv'><div class='dl'>{e(r['label'])}<small>você {r['n_mine']} · {e(tier_pt.get(target, target))} {r['n_top']} jogos</small></div>"
                f"<div class='dtrack'><div class='dbar me'><i style='width:{wm:.0f}%'></i><b>{fm(m)}</b></div>"
                f"<div class='dbar top'><i style='width:{wt:.0f}%'></i><b>{fm(t)}</b></div></div><div class='dd {dc}'>{d}</div></div>")
    hero = (f"<div class='eloh'><div class='eloh-c'>{crest(my_tier, 84)}<b>Você</b><small>{e(tier_pt.get(my_tier, my_tier or 'sem elo'))}</small></div>"
            f"<div class='eloh-arrow'><span></span><em>o que falta</em></div>"
            f"<div class='eloh-c'>{crest(target, 96)}<b>{e(tier_pt.get(target, target))}</b><small>{n_target} partidas na amostra</small></div></div>")
    return hero + form_html + (f"<div class='card'>{leg}{out}</div>" if rows else "")


CSS = """
/* ---------- missao do dia ---------- */
.mhero{position:relative;overflow:hidden;isolation:isolate;display:grid;grid-template-columns:minmax(0,1.2fr) minmax(260px,.8fr);min-height:380px;
border-radius:18px;border:1px solid var(--rule);background:#150F0F;margin:0 0 18px}
.m-art{position:absolute;inset:-40px;z-index:-3;background-size:cover;background-position:center 18%;animation:mdrift 26s ease-in-out infinite alternate;transition:translate .6s cubic-bezier(.2,.8,.2,1)}
@keyframes mdrift{from{transform:scale(1.06)}to{transform:scale(1.16) translate3d(-2.5%,-1.5%,0)}}
.m-fade{position:absolute;inset:0;z-index:-2;background:linear-gradient(90deg,rgba(16,11,11,.96) 30%,rgba(16,11,11,.3) 72%,rgba(16,11,11,.7)),linear-gradient(0deg,rgba(16,11,11,.85),transparent 50%)}
.m-fx{position:absolute;inset:0;width:100%;height:100%;z-index:-1;pointer-events:none;mix-blend-mode:screen}
.m-sweep{position:absolute;inset:0;z-index:-1;background:linear-gradient(105deg,transparent 35%,rgba(255,255,255,.07) 48%,transparent 60%);background-size:260% 100%;animation:sweep 8s ease-in-out infinite}
@keyframes sweep{0%{background-position:160% 0}55%,100%{background-position:-80% 0}}
.m-copy{padding:38px 42px;display:flex;flex-direction:column;justify-content:flex-end;gap:12px}
.m-k{align-self:flex-start;padding:5px 12px;border-radius:999px;font:600 13px var(--head);color:var(--gold);background:rgba(233,196,106,.12);border:1px solid rgba(233,196,106,.4)}
.mhero.done .m-k{color:var(--win);background:rgba(94,224,192,.12);border-color:rgba(94,224,192,.45)}
.m-t{margin:0;font:700 clamp(30px,3.6vw,50px)/1.05 var(--head);color:#fff;max-width:16ch;text-wrap:balance;text-shadow:0 4px 30px rgba(0,0,0,.6)}
.msub{margin:0;color:#D6CCC0;max-width:50ch}
.mchks{display:flex;flex-wrap:wrap;gap:8px;margin-top:4px}
.mchk{display:inline-flex;align-items:center;gap:8px;padding:5px 12px 5px 5px;border-radius:999px;background:rgba(16,11,11,.6);border:1px solid var(--rule);backdrop-filter:blur(8px);color:var(--ink);text-decoration:none;font-size:13px}
.mchk .cic{border-radius:50%}.mchk em{font-style:normal;font-weight:700}
.mchk.ok em{color:var(--win)}.mchk.no em{color:var(--loss)}.mchk.na em{color:var(--mute)}
.mchk.wait{border-style:dashed;color:var(--mute);padding:8px 14px}
.m-streak{align-self:center;justify-self:center;margin:26px;display:flex;flex-direction:column;align-items:center;gap:8px;padding:26px 30px;border-radius:16px;
background:rgba(16,11,11,.55);border:1px solid rgba(255,255,255,.1);backdrop-filter:blur(14px);text-align:center}
.flame{width:78px;height:100px;filter:drop-shadow(0 0 20px var(--gold))}
.flame path{fill:var(--gold);transform-origin:50% 100%;animation:fl 1.6s ease-in-out infinite alternate}
.flame path.in{fill:#fff2cf;animation-duration:1.1s}
.mhero.done .flame{filter:drop-shadow(0 0 26px #ffb347)}
@keyframes fl{to{transform:scaleY(1.06) scaleX(.95)}}
.m-streak>b{font:800 64px/1 var(--head);color:#fff}
.m-streak>span{color:#D6CCC0;font-size:14px}.m-streak small{color:var(--mute);font-size:12.5px}
.m-badges{display:flex;gap:7px;margin:4px 0}
.m-badges i{width:32px;height:32px;border-radius:9px;display:grid;place-items:center;font:700 13px var(--head);font-style:normal;color:var(--mute);border:1px solid var(--rule);background:rgba(255,255,255,.03)}
.m-badges i.got{color:#1a1405;background:linear-gradient(135deg,#ffe39a,#E9C46A);border-color:transparent;box-shadow:0 0 16px rgba(233,196,106,.6)}
@media (max-width:1000px){.mhero{grid-template-columns:1fr}.m-copy{padding:28px 22px}}
@media (prefers-reduced-motion:reduce){.m-art,.m-sweep,.flame path{animation:none}}

/* ---------- subida e evolucao ---------- */
.rise-h{display:flex;justify-content:space-between;align-items:flex-start;gap:12px}
.ladder{width:100%;height:auto;display:block;margin-top:8px;overflow:visible}
.ladder .lb{font:600 11px var(--body);fill:var(--mute)}
.ladder .ln{fill:none;stroke:var(--gold);stroke-width:3;stroke-linejoin:round;stroke-linecap:round;stroke-dasharray:1;stroke-dashoffset:1;
animation:ldraw 1.8s .2s cubic-bezier(.3,.7,.2,1) forwards;filter:drop-shadow(0 0 6px rgba(233,196,106,.6))}
.ladder .ar{opacity:0;animation:lfade 1s 1.2s forwards}.ladder .pt{fill:#0e1116;stroke:var(--gold);stroke-width:2}
.ladder .now{fill:var(--gold);animation:lpulse 1.8s ease-in-out infinite}
@keyframes ldraw{to{stroke-dashoffset:0}}@keyframes lfade{to{opacity:1}}@keyframes lpulse{50%{r:9;opacity:.6}}
.trends{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:12px}
.trend{position:relative;overflow:hidden;padding:16px 18px 40px;border-radius:14px;border:1px solid var(--rule);background:var(--panel)}
.trend small{color:var(--mute);font-size:13px}.trend b{display:block;font:700 28px var(--head);color:#fff;margin:4px 0}
.trend .tw{font-size:13px;font-weight:700}.trend .tw em{font-style:normal;font-weight:400;color:var(--mute);margin-left:4px}
.trend.up .tw{color:var(--win)}.trend.dn .tw{color:var(--loss)}.trend.flat .tw{color:var(--mute)}
.tsp{position:absolute;left:0;right:0;bottom:0;width:100%;height:34px}
.tsp polyline{fill:none;stroke-width:2;stroke-dasharray:1;stroke-dashoffset:1;animation:ldraw 1.6s .4s ease forwards}
.trend.up .tsp polyline{stroke:var(--win)}.trend.dn .tsp polyline{stroke:var(--loss)}.trend.flat .tsp polyline{stroke:var(--mute)}

/* ---------- proximo elo ---------- */
.modes{display:inline-flex;gap:4px;padding:4px;border-radius:999px;border:1px solid var(--rule);background:var(--panel);margin:0 0 18px}
.modes a{padding:8px 16px;border-radius:999px;color:var(--mute);text-decoration:none;font:600 13.5px var(--head)}
.modes a[aria-current]{background:var(--purple);color:#fff;box-shadow:0 4px 16px rgba(59,158,255,.35)}
.eloh{display:flex;align-items:center;justify-content:center;gap:34px;padding:26px;border:1px solid var(--rule);border-radius:18px;margin:0 0 16px;
background:radial-gradient(circle at 75% 50%,rgba(233,196,106,.14),transparent 55%),radial-gradient(circle at 25% 50%,rgba(59,158,255,.12),transparent 55%),#11161e}
.eloh-c{display:flex;flex-direction:column;align-items:center;gap:4px}.eloh-c b{font:700 18px var(--head);color:#fff}.eloh-c small{color:var(--mute);font-size:12.5px}
.eloh-arrow{display:flex;flex-direction:column;align-items:center;gap:6px;min-width:120px}
.eloh-arrow span{display:block;width:140px;height:2px;background:linear-gradient(90deg,#8cc4ff,#E9C46A);position:relative;overflow:hidden}
.eloh-arrow span::after{content:"";position:absolute;top:-2px;left:-30%;width:30%;height:6px;background:linear-gradient(90deg,transparent,#fff,transparent);animation:run 2s linear infinite}
@keyframes run{to{left:130%}}
.eloh-arrow em{font-style:normal;color:var(--gold);font:600 13px var(--head)}
"""

MOTION_JS = r"""<script>(function(){var h=document.getElementById('mhero');if(!h)return;var a=h.querySelector('.m-art'),cv=h.querySelector('.m-fx');
if(a)h.addEventListener('mousemove',function(e){var r=h.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;a.style.translate=(-x*26)+'px '+(-y*16)+'px'});
if(a)h.addEventListener('mouseleave',function(){a.style.translate='0 0'});
if(!cv||matchMedia('(prefers-reduced-motion: reduce)').matches)return;var c=cv.getContext('2d'),P=[],dpr=window.devicePixelRatio||1;
function sz(){cv.width=h.clientWidth*dpr;cv.height=h.clientHeight*dpr}sz();addEventListener('resize',sz);
for(var i=0;i<60;i++)P.push({x:Math.random(),y:Math.random(),r:Math.random()*1.8+.6,s:Math.random()*.0011+.0004,o:Math.random()*.6+.2,w:Math.random()*6.28});
var col=getComputedStyle(document.documentElement).getPropertyValue('--gold').trim()||'#E9C46A';
function t(ms){if(document.hidden){requestAnimationFrame(t);return}c.clearRect(0,0,cv.width,cv.height);P.forEach(function(p){p.y-=p.s;p.x+=Math.sin(ms/1600+p.w)*.0004;
if(p.y<-.02){p.y=1.02;p.x=Math.random()}c.globalAlpha=p.o*(.6+.4*Math.sin(ms/500+p.w));c.fillStyle=col;c.shadowColor=col;c.shadowBlur=10;
c.beginPath();c.arc(p.x*cv.width,p.y*cv.height,p.r*dpr,0,6.28);c.fill()});requestAnimationFrame(t)}requestAnimationFrame(t)})();</script>"""
