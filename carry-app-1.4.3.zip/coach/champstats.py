"""Tabela de estatisticas por campeao (estilo sites de estatistica): cada campeao seu e, abrindo, cada oponente que voce enfrentou com ele.

Fonte: suas partidas (dado). Dano, sentinelas e abates multiplos vem do JSON completo da partida que o app guarda (tabela raw);
partidas antigas sem esse JSON mostram "–" nessas colunas.
"""
import html
import json

from . import db, icons, postmore

e = lambda s: html.escape("" if s is None else str(s), quote=True)


def _ensure(con):
    con.execute("""CREATE TABLE IF NOT EXISTS game_extra (match_id TEXT, participant_id INTEGER, dmg INTEGER, team_dmg INTEGER,
                   wards INTEGER, cwards INTEGER, d2 INTEGER, d3 INTEGER, d4 INTEGER, d5 INTEGER, PRIMARY KEY (match_id, participant_id))""")


def extra(con, mid, pid):
    """Dano, sentinelas e abates multiplos dessa partida (do JSON completo, guardado em cache)."""
    _ensure(con)
    r = con.execute("SELECT * FROM game_extra WHERE match_id=? AND participant_id=?", (mid, pid)).fetchone()
    if r:
        return dict(r) if r["dmg"] is not None else None
    try:
        m = db.load_raw(con, mid, "match")
    except Exception:
        m = None
    row = None
    if m:
        ps = (m.get("info") or {}).get("participants") or []
        me = next((p for p in ps if p.get("participantId") == pid), None)
        if me is None and 1 <= (pid or 0) <= len(ps):
            me = ps[pid - 1]
        if me:
            team = sum(p.get("totalDamageDealtToChampions", 0) for p in ps if p.get("teamId") == me.get("teamId"))
            row = (mid, pid, me.get("totalDamageDealtToChampions", 0), team, me.get("wardsPlaced", 0), me.get("detectorWardsPlaced", 0),
                   me.get("doubleKills", 0), me.get("tripleKills", 0), me.get("quadraKills", 0), me.get("pentaKills", 0))
    con.execute("INSERT OR REPLACE INTO game_extra VALUES (?,?,?,?,?,?,?,?,?,?)", row or (mid, pid) + (None,) * 8)
    con.commit()
    if not row:
        return None
    return dict(zip(["match_id", "participant_id", "dmg", "team_dmg", "wards", "cwards", "d2", "d3", "d4", "d5"], row))


def agg(con, games):
    n = len(games)
    if not n:
        return None
    w = sum(1 for g in games if g["win"])
    k = sum(g["kills"] for g in games) / n
    d = sum(g["deaths"] for g in games) / n
    a = sum(g["assists"] for g in games) / n
    kps = [g["kp"] for g in games if g.get("kp") is not None]
    mins = [max(1, (g["duration_s"] or 60) / 60) for g in games]
    lane = [g for g in games if g.get("golddiff15") is not None]
    lw = sum(1 for g in lane if g["golddiff15"] > 0)
    sc = [postmore.score(g)["total"] for g in games]
    sc = [x for x in sc if x is not None]
    def _ex(g):
        try:
            return extra(con, g["match_id"], g["participant_id"])
        except Exception:
            return None
    ex = [(g, _ex(g)) for g in games]
    exs = [(g, x) for g, x in ex if x]
    out = {"n": n, "w": w, "l": n - w, "wr": round(100 * w / n), "k": k, "d": d, "a": a,
           "kda": (k + a) / d if d else None, "kp": round(100 * sum(kps) / len(kps)) if kps else None,
           "score": sum(sc) / len(sc) if sc else None,
           "lane_w": lw, "lane_l": len(lane) - lw, "lane_pct": round(100 * lw / len(lane)) if lane else None,
           "cs": sum(g["cs"] for g in games) / n, "cspm": sum(g["cs"] / m for g, m in zip(games, mins)) / n,
           "gold": sum(g["gold"] for g in games) / n, "gpm": sum(g["gold"] / m for g, m in zip(games, mins)) / n}
    if exs:
        out["dpm"] = sum(x["dmg"] / max(1, (g["duration_s"] or 60) / 60) for g, x in exs) / len(exs)
        out["dmg_share"] = round(100 * sum(x["dmg"] / max(1, x["team_dmg"]) for g, x in exs) / len(exs), 1)
        out["wards"] = sum(x["wards"] for g, x in exs) / len(exs)
        out["cwards"] = sum(x["cwards"] for g, x in exs) / len(exs)
        for kx in ("d2", "d3", "d4", "d5"):
            out[kx] = sum(x[kx] for g, x in exs)
    return out


def _row(a, label_html, sub=False, toggle=None):
    if not a:
        return ""
    wbar = (f"<div class='cs-wl'>" + (f"<span class='w' style='flex:{a['w']}'>{a['w']}V</span>" if a["w"] else "")
            + (f"<span class='l' style='flex:{a['l']}'>{a['l']}D</span>" if a["l"] else "") + "</div>"
            f"<b class='cs-wr {'g' if a['wr'] >= 55 else 'r' if a['wr'] < 48 else ''}'>{a['wr']}%</b>")
    kv = f"{a['kda']:.2f}:1" if a["kda"] else "perfeito"
    kda = (f"<b class='{'g' if a['kda'] and a['kda'] >= 3 else ''}'>{kv}</b>"
           f"<small>{a['k']:.1f} / {a['d']:.1f} / {a['a']:.1f}" + (f" ({a['kp']}%)" if a["kp"] is not None else "") + "</small>")
    score = f"<b>{a['score']:.0f}</b>" if a.get("score") is not None else "–"
    lane = (f"<b class='{'g' if a['lane_pct'] >= 55 else 'r' if a['lane_pct'] < 45 else ''}'>{a['lane_w']} : {a['lane_l']}</b><small>{a['lane_pct']}%</small>"
            if a.get("lane_pct") is not None else "–")
    dmg = f"<b>{a['dpm']:.0f}/min</b><small>{a['dmg_share']}% do time</small>" if a.get("dpm") is not None else "–"
    wards = f"<b>{a['wards']:.0f}</b><small>{a['cwards']:.1f} de controle</small>" if a.get("wards") is not None else "–"
    cs = f"<b>{a['cs']:.0f}</b><small>{a['cspm']:.1f}/min</small>"
    gold = f"<b>{a['gold'] / 1000:.1f}k</b><small>{a['gpm']:.0f}/min</small>"
    multi = "".join(f"<td>{a[k] if a.get(k) else '–'}</td>" for k in ("d2", "d3", "d4", "d5"))
    tg = (f"<td><button type='button' class='cs-tg' data-t='{toggle}' aria-label='Ver oponentes'></button></td>" if toggle else "<td></td>")
    return (f"<tr class='{'sub' if sub else 'main'}'>"
            f"<td><div class='cs-c'>{label_html}</div></td><td>{wbar}</td><td class='cs-k'>{kda}</td><td>{score}</td><td class='cs-k'>{lane}</td>"
            f"<td class='cs-k'>{dmg}</td><td class='cs-k'>{wards}</td><td class='cs-k'>{cs}</td><td class='cs-k'>{gold}</td>{multi}{tg}</tr>")


def page_html(con, games, champs):
    if not games:
        return "<div class='empty'><b>Sem partidas</b><span>Sincronize para ver as estatísticas.</span></div>"
    name = lambda c: (champs.get(c) or {}).get("name", c)
    by = {}
    for g in games:
        by.setdefault(g["champion"], []).append(g)
    order = sorted(by.items(), key=lambda kv: -len(kv[1]))
    head = ("<table class='cst'><thead><tr><th>Campeão</th><th>Jogado</th><th>KDA</th><th>Nota</th><th>Fase de rotas</th><th>Dano</th>"
            "<th>Sentinelas</th><th>Farm</th><th>Ouro</th><th>Duplo</th><th>Triplo</th><th>Quádruplo</th><th>Penta</th><th></th></tr></thead><tbody>")
    body = _row(agg(con, games), f"<span class='cs-all'>Todos</span><b>Todos os campeões</b>")
    for i, (c, gs) in enumerate(order):
        body += _row(agg(con, gs), f"{icons.champ(c, 34)}<b>{e(name(c))}</b>", toggle=f"t{i}")
        opp = {}
        for g in gs:
            if g.get("opp_champion"):
                opp.setdefault(g["opp_champion"], []).append(g)
        for j, (o, og) in enumerate(sorted(opp.items(), key=lambda kv: -len(kv[1]))):
            body += _row(agg(con, og), f"<small class='vs'>vs</small>{icons.champ(o, 28, 'foe')}<span>{e(name(o))}</span>", sub=True).replace(
                "<tr class='sub'", f"<tr class='sub' hidden data-of='t{i}' data-i='{j}'", 1)
        if len(opp) > 5:
            body += f"<tr class='more' hidden data-of='t{i}'><td colspan='14'><button type='button' class='cs-more' data-t='t{i}'>Mostrar mais oponentes</button></td></tr>"
    note = ("<p class='n'><span class='tag dado'>dado</span> Suas partidas sincronizadas. Fase de rotas = partidas que você terminou os 15 min na frente "
            "do oponente em ouro, contra as que terminou atrás. Nota = média da nota da partida (0 a 100). Dano, sentinelas e abates múltiplos só aparecem nas partidas "
            "baixadas com o JSON completo.</p>")
    js = """<script>(function(){document.addEventListener('click',function(ev){var b=ev.target.closest('.cs-tg');if(b){var t=b.dataset.t,on=!b.classList.contains('on');b.classList.toggle('on',on);
document.querySelectorAll('tr[data-of="'+t+'"]').forEach(function(r){if(r.classList.contains('more'))r.hidden=!on;else r.hidden=!on||+r.dataset.i>=5})}
var m=ev.target.closest('.cs-more');if(m){document.querySelectorAll('tr.sub[data-of="'+m.dataset.t+'"]').forEach(function(r){r.hidden=false});m.closest('tr').hidden=true}})})();</script>"""
    return note + "<div class='cs-wrap'>" + head + body + "</tbody></table></div>" + js


CSS = """
.cs-wrap{overflow-x:auto;border:1px solid var(--rule);border-radius:16px;background:var(--panel)}
.cst{width:100%;border-collapse:collapse;min-width:1200px}
.cst th{position:sticky;top:0;background:#211918;text-align:left;font:700 11px var(--mono);letter-spacing:.06em;color:var(--mute);padding:10px 8px;border-bottom:1px solid var(--rule);white-space:nowrap}
.cst td{padding:8px;border-bottom:1px solid rgba(255,255,255,.05);font-size:13px;color:#E6DDD2;vertical-align:middle;white-space:nowrap}
.cst tr.main td{background:rgba(255,255,255,.015)}.cst tr.sub td{background:rgba(16,11,11,.45)}.cst tr.sub .cs-c{padding-left:20px}
.cs-c{display:flex;align-items:center;gap:10px;min-width:180px}.cs-c b{color:#fff;font:700 13.5px var(--head)}.cs-c .vs{color:var(--mute);font-size:11px}
.cs-all{width:34px;height:34px;border-radius:50%;background:#4A1A1C;display:inline-flex;align-items:center;justify-content:center;font:700 10px var(--head);color:#F0C8C4}
.cs-wl{display:inline-flex;width:110px;height:20px;border-radius:5px;overflow:hidden;vertical-align:middle;font:700 11px var(--head)}
.cs-wl span{display:flex;align-items:center;padding:0 6px;color:#fff;min-width:0;overflow:hidden}.cs-wl .w{background:#5E7290}.cs-wl .l{background:#C1121F;justify-content:flex-end}
.cs-wr{margin-left:8px;font:700 12.5px var(--head)}.cst .g{color:#8FD4A8}.cst .r{color:#E8817C}
.cs-k b{display:block;font:700 13px var(--head);color:#fff}.cs-k b.g{color:#8FD4A8}.cs-k b.r{color:#E8817C}.cs-k small{color:var(--mute);font-size:11.5px}
.cs-tg{width:28px !important;height:28px;padding:0 !important;border-radius:8px !important;position:relative}
.cs-tg:after{content:"";position:absolute;left:50%;top:45%;width:7px;height:7px;border-right:2px solid #D6CCC0;border-bottom:2px solid #D6CCC0;transform:translate(-50%,-50%) rotate(45deg)}
.cs-tg.on:after{transform:translate(-50%,-20%) rotate(-135deg)}
.cs-more{width:100% !important;border:1px solid rgba(141,162,192,.5) !important;color:#B5C2D6 !important;background:rgba(141,162,192,.06) !important}
"""
