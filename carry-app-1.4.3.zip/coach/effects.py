"""Efeitos do app (leves e sem atrapalhar a leitura). Quem liga "reduzir movimento" no sistema nao ve as animacoes.

- logo: a shuriken gira e o clone de sombra desliza ao passar o mouse; entra girando uma vez ao abrir
- numeros grandes contam do zero quando aparecem na tela
- brasas subindo no topo do campeao, na cor do main
- a arte do topo acompanha levemente o mouse (paralaxe)
- botoes com brilho passando e ondinha no clique; blocos levantam e acendem a borda dourada
- carregando: shuriken girando no lugar do circulo
"""
from . import premium

SPIN_SVG = ("data:image/svg+xml," + "%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 48 48'%3E%3Cpath d='"
            + (premium.SHUR_A + premium.SHUR_B).replace("#", "%23") + "' fill='%23c9ced8'/%3E%3Ccircle cx='24' cy='24' r='2.6' fill='%230b0b0e'/%3E%3C/svg%3E")

CSS = """
/* ===== efeitos ===== */
@media (prefers-reduced-motion:no-preference){
/* logo */
.cmark{transition:transform .6s cubic-bezier(.2,.9,.2,1)}.cmark g{transition:transform .5s cubic-bezier(.2,.9,.2,1),opacity .4s}
.side .logo:hover .cmark,.auth-box .brand:hover .cmark{transform:rotate(360deg)}
.side .logo:hover .cmark g:first-of-type{transform:translate(9px,-7px) rotate(40deg);opacity:1}
.side .logo .cmark{animation:fxlogo 1.1s .1s cubic-bezier(.2,.9,.2,1) both}
@keyframes fxlogo{from{transform:rotate(-200deg) scale(.6);opacity:0}}
/* entrada da pagina: uma vez so */
main>*:nth-child(-n+6){animation:fxin .55s cubic-bezier(.2,.8,.2,1) both}
main>*:nth-child(2){animation-delay:.05s}main>*:nth-child(3){animation-delay:.1s}main>*:nth-child(4){animation-delay:.15s}main>*:nth-child(5){animation-delay:.2s}main>*:nth-child(6){animation-delay:.25s}
@keyframes fxin{from{opacity:0;transform:translateY(10px)}}
/* blocos */
.card,.hp-quick a,.chc,.pchamp,.mcard,.dcard,.tile,.gcard,.cnt,.hp-mission,.bx-left,.bx-t{transition:transform .2s ease,border-color .2s ease,box-shadow .25s ease}
.card:hover,.chc:hover,.pchamp:hover,.dcard:hover,.hp-mission:hover{transform:translateY(-2px);box-shadow:0 14px 34px rgba(0,0,0,.35) !important}
.card:hover::after,.hp-quick a:hover::before,.hp-mission:hover::before{background:linear-gradient(90deg,transparent,#f3dda6,transparent) !important;box-shadow:0 0 12px rgba(200,170,110,.6)}
/* linhas de partida */
.hg{transition:background .2s}.hg.w:hover{background:linear-gradient(90deg,rgba(127,178,229,.08),transparent 60%)}.hg.l:hover{background:linear-gradient(90deg,rgba(196,106,120,.08),transparent 60%)}
.hg::before{transition:height .2s,top .2s,box-shadow .2s}.hg:hover::before{box-shadow:0 0 12px currentColor}.hg.w:hover::before{color:#8DA2C0}.hg.l:hover::before{color:#D9534F}
/* botoes: brilho passando */
.btn.gold,button.gold,.gx-side a:not(.alt),form button.wide{position:relative;overflow:hidden}
.btn.gold::after,button.gold::after,.gx-side a:not(.alt)::after,form button.wide::after{content:'' !important;display:block !important;position:absolute;top:0;bottom:0;left:-60%;width:40%;
background:linear-gradient(100deg,transparent,rgba(255,255,255,.55),transparent);transform:skewX(-20deg);transition:left .6s ease}
.btn.gold:hover::after,button.gold:hover::after,.gx-side a:not(.alt):hover::after,form button.wide:hover::after{left:120%}
/* menu */
.sg a .ni{transition:transform .2s,color .2s}.sg a:hover .ni{transform:translateX(2px) scale(1.08);color:#c8aa6e}
.sg a[aria-current]::before{animation:fxbar .4s cubic-bezier(.2,.9,.2,1) both}@keyframes fxbar{from{transform:scaleY(0)}}
/* trilha de elo: brilho no ponto */
.hp-me{animation:hppop .5s 1.5s both,fxpulse 2.4s 2s ease-in-out infinite}
@keyframes fxpulse{50%{box-shadow:0 0 0 10px rgba(61,190,139,.06),0 0 18px rgba(61,190,139,.5)}}
/* pool: retrato gira levemente */
.hp-pool button .cic{transition:transform .3s}.hp-pool button:hover .cic{transform:scale(1.08) rotate(-4deg)}
/* arte do topo acompanha o mouse */
.hp-art.on,.chero .sp{transition:transform .25s ease-out,opacity .8s;transform:translate3d(var(--px,0),var(--py,0),0) scale(1.06) !important}
}
/* ondinha do clique */
.fxr{position:absolute;border-radius:50%;pointer-events:none;background:rgba(255,255,255,.35);transform:scale(0);animation:fxrip .55s ease-out forwards}
@keyframes fxrip{to{transform:scale(2.6);opacity:0}}
/* brasas */
.fxem{position:absolute;inset:0;z-index:0;pointer-events:none;opacity:.75}
.hp-hero .hp-g,.hp-hero .hp-climb,.chero .ch-in,.chero .hsts{position:relative;z-index:1}
/* carregando: shuriken */
.spin{border:0 !important;border-radius:0 !important;background:url("SPIN") center/contain no-repeat !important;animation:fxspin .8s linear infinite !important}
@keyframes fxspin{to{transform:rotate(360deg)}}
""".replace("SPIN", SPIN_SVG)

JS = """<script>(function(){var R=matchMedia('(prefers-reduced-motion: reduce)').matches;
/* numeros contando */
function count(el){var t=el.textContent.trim(),m=t.match(/^([^0-9-]*)(-?[0-9]+(?:[.,][0-9]+)?)(.*)$/);if(!m||el.dataset.fx)return;el.dataset.fx=1;
var pre=m[1],num=parseFloat(m[2].replace(',','.')),suf=m[3],dec=(m[2].split(/[.,]/)[1]||'').length,sep=m[2].indexOf(',')>=0?',':'.';if(!isFinite(num)||R)return;
var t0=performance.now(),D=900;function step(n){var p=Math.min(1,(n-t0)/D),e=1-Math.pow(1-p,3),v=(num*e).toFixed(dec);el.textContent=pre+(sep===','?v.replace('.',','):v)+suf;if(p<1)requestAnimationFrame(step)}requestAnimationFrame(step)}
var sel='.hp-num b,.kpi b.kv,.kpi>b,.hst b,.cnt-r em';
if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting){count(x.target);io.unobserve(x.target)}})},{threshold:.4});
document.querySelectorAll(sel).forEach(function(el){if(el.children.length===0)io.observe(el)})}
/* ondinha */
document.addEventListener('pointerdown',function(e){var b=e.target.closest('button,.btn,.hp-quick a,.gx-side a,.side .sg a');if(!b||R)return;var r=b.getBoundingClientRect(),s=Math.max(r.width,r.height);
var c=getComputedStyle(b);if(c.position==='static')b.style.position='relative';if(c.overflow!=='hidden')b.style.overflow='hidden';
var d=document.createElement('span');d.className='fxr';d.style.width=d.style.height=s+'px';d.style.left=(e.clientX-r.left-s/2)+'px';d.style.top=(e.clientY-r.top-s/2)+'px';b.appendChild(d);setTimeout(function(){d.remove()},600)});
if(R)return;
/* paralaxe da arte */
document.querySelectorAll('.hp-hero,.chero').forEach(function(h){h.addEventListener('mousemove',function(e){var r=h.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;
h.style.setProperty('--px',(-x*14).toFixed(1)+'px');h.style.setProperty('--py',(-y*10).toFixed(1)+'px');h.querySelectorAll('.hp-art,.sp').forEach(function(a){a.style.setProperty('--px',(-x*14).toFixed(1)+'px');a.style.setProperty('--py',(-y*10).toFixed(1)+'px')})});
h.addEventListener('mouseleave',function(){h.querySelectorAll('.hp-art,.sp').forEach(function(a){a.style.setProperty('--px','0px');a.style.setProperty('--py','0px')})})});
/* brasas na cor do main */
document.querySelectorAll('.hp-hero,.chero').forEach(function(h){var c=document.createElement('canvas');c.className='fxem';h.insertBefore(c,h.firstChild.nextSibling);var x=c.getContext('2d'),P=[],W,H,on=true,dpr=Math.min(2,devicePixelRatio||1);
function rs(){W=h.clientWidth;H=h.clientHeight;c.width=W*dpr;c.height=H*dpr;c.style.width=W+'px';c.style.height=H+'px';x.setTransform(dpr,0,0,dpr,0,0)}rs();addEventListener('resize',rs);
function col(){return getComputedStyle(document.documentElement).getPropertyValue('--ac').trim()||'#d7263d'}
for(var i=0;i<38;i++)P.push({x:Math.random()*W,y:Math.random()*H,r:Math.random()*1.8+.4,v:Math.random()*.35+.12,w:Math.random()*Math.PI*2,a:Math.random()*.6+.2});
new IntersectionObserver(function(es){on=es[0].isIntersecting}).observe(h);
function f(){if(on&&!document.hidden){x.clearRect(0,0,W,H);var k=col();x.fillStyle=k;x.shadowColor=k;x.shadowBlur=8;
P.forEach(function(p){p.y-=p.v;p.w+=.02;p.x+=Math.sin(p.w)*.25;if(p.y<-6){p.y=H+6;p.x=Math.random()*W}x.globalAlpha=p.a*(0.4+0.6*Math.min(1,p.y/H*1.4));x.beginPath();x.arc(p.x,p.y,p.r,0,6.283);x.fill()});x.globalAlpha=1}
requestAnimationFrame(f)}f()});
})();</script>"""
