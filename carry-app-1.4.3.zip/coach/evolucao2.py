"""Mais leituras da sua evolucao, so com as suas partidas:
- com que itens e runas VOCE ganha com o seu main;
- cansaco: o winrate pela ordem da partida no dia (1a, 2a, 3a...);
- queda de rendimento recente (mesmo ganhando);
- mapa dos seus confrontos com o main (voce e o alto elo lado a lado);
- o seu main agora contra 3 meses atras."""
import html
import json
import time

e = lambda x: html.escape("" if x is None else str(x))
DAY = 86400000


def _main(gs):
    cnt = {}
    for g in gs[:150]:
        cnt[g["champion"]] = cnt.get(g["champion"], 0) + 1
    return max(cnt, key=cnt.get) if cnt else None


def _wr(w, n):
    return round(100 * w / n) if n else None


def builds_card(con, puuid, champion, items_data, rune_names):
    from . import builds, report
    gs = [g for g in report.my_games(con, puuid, "") if g["champion"] == champion][:200]
    if len(gs) < 15:
        return ""
    it, ks = {}, {}
    for g in gs:
        r = con.execute("SELECT items, perks FROM participant_extra WHERE match_id=? AND participant_id=?", (g["match_id"], g["participant_id"])).fetchone()
        if not r:
            continue
        for i in set(json.loads(r[0] or "[]") or []):
            if i and builds.is_complete(items_data, i):
                v = it.setdefault(i, [0, 0])
                v[0] += 1
                v[1] += 1 if g["win"] else 0
        pg = builds.page_from_perks(json.loads(r[1] or "{}"))
        if pg:
            v = ks.setdefault(pg[2][0], [0, 0])
            v[0] += 1
            v[1] += 1 if g["win"] else 0
    row = lambda nm, v: f"<p>{e(nm)}: <b>{_wr(v[1], v[0])}%</b> em {v[0]} jogos</p>"
    its = sorted([(i, v) for i, v in it.items() if v[0] >= 6], key=lambda kv: -_wr(kv[1][1], kv[1][0]))
    kss = sorted([(k, v) for k, v in ks.items() if v[0] >= 6], key=lambda kv: -_wr(kv[1][1], kv[1][0]))
    if not its and not kss:
        return ""
    out = f"<div class='card'><b class='gl'>Com que itens e runas você ganha de {e(champion)}</b><p class='n'>Só as suas partidas (6 jogos ou mais com o item ou a runa). Item comprado em partida que já estava ganha puxa o número para cima: use como pista, não como regra.</p>"
    if its:
        out += "<p><b>Itens</b></p>" + "".join(row((items_data.get(str(i)) or {}).get("name", i), v) for i, v in its[:8])
    if kss:
        out += "<p style='margin-top:8px'><b>Runa principal</b></p>" + "".join(row(rune_names.get(k, k), v) for k, v in kss[:4])
    return out + "</div>"


def by_order(gs):
    """{n: (jogos, vitorias)} pela ordem da partida no dia (1 = primeira do dia)."""
    days = {}
    for g in gs:
        if not g.get("started_ms"):
            continue
        d = time.strftime("%Y%m%d", time.localtime((g["started_ms"] - 5 * 3600000) / 1000))      # o dia vira as 5h
        days.setdefault(d, []).append(g)
    out = {}
    for lst in days.values():
        for i, g in enumerate(sorted(lst, key=lambda x: x["started_ms"]), 1):
            k = min(i, 6)
            v = out.setdefault(k, [0, 0])
            v[0] += 1
            v[1] += 1 if g["win"] else 0
    return out


def fatigue_card(gs):
    bo = by_order(gs)
    if sum(v[0] for v in bo.values()) < 40:
        return ""
    lab = lambda k: f"{k}ª partida do dia" if k < 6 else "6ª em diante"
    rows = "".join(f"<p>{lab(k)}: <b class='{'win' if _wr(v[1], v[0]) >= 52 else 'loss' if _wr(v[1], v[0]) <= 46 else ''}'>{_wr(v[1], v[0])}%</b> em {v[0]} jogos</p>"
                   for k, v in sorted(bo.items()))
    bad = next((k for k, v in sorted(bo.items()) if k >= 2 and v[0] >= 15 and _wr(v[1], v[0]) <= 46), None)
    tip = f"<p class='n'>A partir da {lab(bad)} o seu winrate cai: esse é o seu limite diário de verdade.</p>" if bad else ""
    return f"<div class='card'><b class='gl'>Cansaço: o seu winrate pela ordem da partida no dia</b>{rows}{tip}</div>"


def fatigue_warn(gs, today_n):
    """Frase para a fila se a PROXIMA partida do dia costuma ser ruim."""
    bo = by_order(gs)
    k = min(today_n + 1, 6)
    v = bo.get(k)
    if k >= 2 and v and v[0] >= 15 and _wr(v[1], v[0]) <= 46:
        return f"A sua {k}ª partida do dia tem {_wr(v[1], v[0])}% em {v[0]} jogos. Se for jogar, que seja só mais esta."
    return None


def slump_warn(gs):
    """Queda de rendimento: as ultimas 3 partidas bem piores que a sua media das 20 anteriores (mortes cedo e farm)."""
    if len(gs) < 23:
        return None
    last, base = gs[:3], gs[3:23]
    av = lambda xs, k: (sum(x[k] for x in xs if x.get(k) is not None) / max(1, sum(1 for x in xs if x.get(k) is not None)))
    d10 = av(last, "deaths_before_10") - av(base, "deaths_before_10")
    cs = av(last, "csdiff10") - av(base, "csdiff10")
    if d10 >= 1.0 and cs <= -8:
        return ("Nas últimas 3 partidas você morreu mais cedo e farmou menos que a sua média. Isso costuma ser cansaço, não falta de nível: "
                "faça uma pausa antes da próxima.")
    return None


def matchups_page(con, puuid, position, champs):
    from . import counters, report
    gs = report.my_games(con, puuid, position)
    main = _main(gs)
    if not main:
        return "<div class='card'><p class='n'>Sem partidas ainda.</p></div>"
    mg = [g for g in gs if g["champion"] == main and g.get("opp_champion")]
    opp = {}
    for g in mg:
        v = opp.setdefault(g["opp_champion"], [0, 0])
        v[0] += 1
        v[1] += 1 if g["win"] else 0
    nm = lambda c: (champs.get(c) or {}).get("name") or c
    rows = []
    for o, (n, w) in opp.items():
        mu = counters.matchup(con, main, o, position)
        rows.append((o, n, w, mu))
    rows.sort(key=lambda r: (-(r[1]), r[0]))
    from . import icons
    cells = ""
    for o, n, w, mu in rows:
        mine = _wr(w, n)
        cls = "win" if mine >= 55 else "loss" if mine <= 45 else ""
        top = f"{mu[1]}% <small>({mu[0]})</small>" if mu else "<small>sem amostra</small>"
        cells += (f"<div style='display:grid;grid-template-columns:34px 1fr 110px 120px;gap:10px;align-items:center;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.05)'>"
                  f"{icons.champ(o, 30)}<span>{e(nm(o))}</span><span><b class='{cls}'>{mine}%</b> <small>em {n}</small></span><span>{top}</span></div>")
    head = ("<div style='display:grid;grid-template-columns:34px 1fr 110px 120px;gap:10px;font-size:12px;color:var(--mute)'><i></i><span>oponente</span>"
            f"<span>você de {e(nm(main))}</span><span>{e(nm(main))} no alto elo</span></div>")
    return (f"<div class='card'><b class='gl'>Seus confrontos de {e(nm(main))}</b><p class='n'>Todos os oponentes de rota que você já enfrentou com ele, "
            "do mais frequente para o menos. Verde/vermelho: onde você vai bem ou mal. A coluna da direita mostra se o confronto é difícil para todo mundo "
            "ou só para você.</p>" + head + cells + "</div>")


def season_card(gs):
    main = _main(gs)
    if not main:
        return ""
    now = int(time.time() * 1000)
    mg = [g for g in gs if g["champion"] == main]
    a = mg[:30]
    b = [g for g in mg if now - 105 * DAY <= (g.get("started_ms") or 0) <= now - 75 * DAY][:30]
    if len(a) < 10 or len(b) < 10:
        return ""
    av = lambda xs, k: (sum(x[k] for x in xs if x.get(k) is not None) / max(1, sum(1 for x in xs if x.get(k) is not None)))
    rows = [("Vitórias", f"{_wr(sum(1 for x in a if x['win']), len(a))}%", f"{_wr(sum(1 for x in b if x['win']), len(b))}%"),
            ("Farm aos 10", f"{av(a, 'cs10'):.0f}", f"{av(b, 'cs10'):.0f}"),
            ("Farm contra o oponente aos 10", f"{av(a, 'csdiff10'):+.0f}", f"{av(b, 'csdiff10'):+.0f}"),
            ("Mortes antes dos 10", f"{av(a, 'deaths_before_10'):.1f}", f"{av(b, 'deaths_before_10'):.1f}"),
            ("Participação em abates", f"{av(a, 'kp'):.0%}", f"{av(b, 'kp'):.0%}")]
    body = "".join(f"<div style='display:grid;grid-template-columns:1fr 100px 100px;gap:8px;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.05)'>"
                   f"<span>{e(l)}</span><b style='text-align:right'>{e(x)}</b><span style='text-align:right;color:var(--mute)'>{e(y)}</span></div>" for l, x, y in rows)
    head = ("<div style='display:grid;grid-template-columns:1fr 100px 100px;gap:8px;font-size:12px;color:var(--mute)'><span></span>"
            "<span style='text-align:right'>agora</span><span style='text-align:right'>3 meses atrás</span></div>")
    return f"<div class='card'><b class='gl'>O seu {e(main)} agora contra 3 meses atrás</b><p class='n'>Últimas {len(a)} partidas contra {len(b)} de 3 meses atrás.</p>{head}{body}</div>"
