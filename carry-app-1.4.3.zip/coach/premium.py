"""Visual premium (o escolhido): fundo noite, texto osso, numeros e titulos em Big Shoulders Display, texto em Hanken Grotesk.

- a cor de destaque vem do campeao principal de cada usuario (Zed vermelho, Leblanc roxo, Renekton verde...)
- verde so para o elo, azul para vitoria, rosa para derrota
- menos caixas: linhas e divisorias; cartoes so onde agrupam algo
- menu no topo
Fontes servidas pelo proprio app (/static/fonts), licenca SIL OFL.
"""
import hashlib
import html

e = lambda x: html.escape("" if x is None else str(x))

FONTS = "".join(
    f"@font-face{{font-family:'{fam}';src:url('/static/fonts/{f}') format('woff2');font-weight:{w};font-style:normal;font-display:swap}}"
    for fam, f, w in [("BSD", "bigshoulders-500.woff2", 500), ("BSD", "bigshoulders-700.woff2", 700), ("BSD", "bigshoulders-900.woff2", 900),
                      ("Hanken", "hanken-400.woff2", 400), ("Hanken", "hanken-500.woff2", 500), ("Hanken", "hanken-600.woff2", 600),
                      ("Hanken", "hanken-700.woff2", 700), ("CP", "chakra-700.woff2", 700)])

# cor de destaque por campeao (o resto cai numa paleta fixa, sempre a mesma para o mesmo campeao)
ACCENT = {
    "Zed": "#d7263d", "Leblanc": "#b14aed", "Ryze": "#3a86ff", "Renekton": "#3fae5a", "Ahri": "#e0559a", "Yasuo": "#4fa3d9", "Yone": "#c23a4b",
    "Akali": "#2fbf8f", "Katarina": "#d33a3a", "Talon": "#8a6fd6", "Qiyana": "#e2a33c", "Fizz": "#2ba3c9", "Syndra": "#8c4fe0", "Sylas": "#5c7cff",
    "Viktor": "#e08a2e", "Orianna": "#d9a441", "Lux": "#f0c24a", "Veigar": "#7a4fe0", "Kassadin": "#7a5cff", "Diana": "#9aa8ff", "Ekko": "#3fd0b5",
    "LeeSin": "#e0742e", "Kayn": "#c23a4b", "Nocturne": "#5b63d6", "Galio": "#c9b27a", "Darius": "#c0392b", "Garen": "#d4a63a", "Riven": "#7fbf5a",
    "Irelia": "#d94f8a", "Jinx": "#4fa3ff", "Ezreal": "#e0b13c", "Kaisa": "#b14aed", "Vayne": "#a04fd6", "Thresh": "#3fbf8f", "Lulu": "#b46ee0",
    "Malphite": "#a78b5a", "Annie": "#e0503a", "Vladimir": "#c0263d", "Aatrox": "#c0263d", "Sett": "#e07a3a", "Camille": "#5fa8d9", "Pyke": "#2fae9a",
}
PALETTE = ["#d7263d", "#3a86ff", "#b14aed", "#2fbf8f", "#e0742e", "#e0559a", "#d9a441", "#4fa3d9"]


def accent(champ):
    if not champ:
        return "#d7263d"
    if champ in ACCENT:
        return ACCENT[champ]
    return PALETTE[int(hashlib.md5(champ.encode()).hexdigest(), 16) % len(PALETTE)]


def accent_style(champ):
    c = "#C1121F"      # sistema de design Noxus: o destaque do site e sempre o vermelho-sangue (o overlay pode usar a cor do campeao)
    r, g, b = int(c[1:3], 16), int(c[3:5], 16), int(c[5:7], 16)
    return f"<style>:root{{--ac:{c};--acs:rgba({r},{g},{b},.14);--acm:rgba({r},{g},{b},.35)}}</style>"


BRAND = "Carry"
BRAND_SUB = "Analytics"
TAGLINE = "Quem treina, carrega."


SHUR_A = "M24,24L20.11,20.11L24.00,5.00ZM24,24L27.89,20.11L43.00,24.00ZM24,24L27.89,27.89L24.00,43.00ZM24,24L20.11,27.89L5.00,24.00Z"
SHUR_B = "M24,24L24.00,5.00L27.89,20.11ZM24,24L43.00,24.00L27.89,27.89ZM24,24L24.00,43.00L20.11,27.89ZM24,24L5.00,24.00L20.11,20.11Z"


def mark(size=34, uid="m", ac="var(--ac,#d7263d)"):
    """Simbolo do Carry: shuriken de aco com o clone de sombra atras, na cor do main do usuario (--ac)."""
    return (f"<svg class='cmark' viewBox='0 0 48 48' width='{size}' height='{size}' aria-hidden='true'>"
            f"<defs><linearGradient id='cs{uid}' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#eef0f4'/><stop offset='1' stop-color='#5c6373'/></linearGradient>"
            f"<linearGradient id='cd{uid}' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#8a91a0'/><stop offset='1' stop-color='#262a33'/></linearGradient></defs>"
            f"<g transform='translate(5 -4) rotate(22 24 24)' opacity='.8'><path d='{SHUR_A}' fill='{ac}'/><path d='{SHUR_B}' fill='{ac}' style='filter:brightness(.45)'/></g>"
            f"<g transform='rotate(8 24 24)'><path d='{SHUR_A}' fill='url(#cs{uid})'/><path d='{SHUR_B}' fill='url(#cd{uid})'/></g>"
            f"<circle cx='24' cy='24' r='2.6' fill='#0b0b0e'/><circle cx='24' cy='24' r='1.2' fill='{ac}'/></svg>")


def logo(size=34, uid="m"):
    return f"<span class='clogo'>{mark(size, uid)}<span class='cl-t'><b>{BRAND.upper()}</b></span></span>"


FAVICON = "data:image/svg+xml," + "%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 48 48'%3E%3Cg transform='translate%285 -4%29 rotate%2822 24 24%29'%3E%3Cpath d='M24,24L20.11,20.11L24.00,5.00ZM24,24L27.89,20.11L43.00,24.00ZM24,24L27.89,27.89L24.00,43.00ZM24,24L20.11,27.89L5.00,24.00ZM24,24L24.00,5.00L27.89,20.11ZM24,24L43.00,24.00L27.89,27.89ZM24,24L24.00,43.00L20.11,27.89ZM24,24L5.00,24.00L20.11,20.11Z' fill='%23d7263d' opacity='.85'/%3E%3C/g%3E%3Cg transform='rotate%288 24 24%29'%3E%3Cpath d='M24,24L20.11,20.11L24.00,5.00ZM24,24L27.89,20.11L43.00,24.00ZM24,24L27.89,27.89L24.00,43.00ZM24,24L20.11,27.89L5.00,24.00Z' fill='%23e6e9ef'/%3E%3Cpath d='M24,24L24.00,5.00L27.89,20.11ZM24,24L43.00,24.00L27.89,27.89ZM24,24L24.00,43.00L20.11,27.89ZM24,24L5.00,24.00L20.11,20.11Z' fill='%235c6373'/%3E%3C/g%3E%3Ccircle cx='24' cy='24' r='2.6' fill='%230b0b0e'/%3E%3C/svg%3E"


GRAIN = ("url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='n'%3E%3CfeTurbulence "
         "type='fractalNoise' baseFrequency='.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")")

CSS = FONTS + """
/* ================= PREMIUM ================= */
:root{--night:#120E0E;--raised:#1A1414;--raised2:#221A19;--line:#2E2523;--bone:#F1E9DF;--steel:#8D99AE;--emerald:#6BBF8A;
--ac:#C1121F;--acs:rgba(193,18,31,.14);--acm:rgba(193,18,31,.35);
--bg:var(--night);--panel:var(--raised);--panel2:var(--raised2);--ink:var(--bone);--mute:var(--steel);--rule:var(--line);
--gold:#E9C46A;--purple:#8DA2C0;--purple2:#B5C2D6;--peach:#B5C2D6;--btn:var(--bone);--btnfg:var(--night);
--dado:#6BBF8A;--regra:#E9C46A;--hip:#8D99AE;--win:#6BBF8A;--loss:#D9534F;
--d:'BSD',Impact,'Arial Narrow',sans-serif;--head:'Hanken',system-ui,sans-serif;--body:'Hanken',system-ui,sans-serif;--mono:'Hanken',system-ui,sans-serif;--title:var(--d);
--line-soft:var(--line);--line-hover:#4A3A36;--panel-a:var(--raised);--panel-b:var(--raised);--r-card:14px;--r-btn:10px;
--hx-line:var(--line);--hx-gold2:var(--bone);--hx-glow:var(--acs)}
html{background:var(--night);color-scheme:dark}
body{background:var(--night);color:var(--bone);font:400 15px/1.55 var(--body);-webkit-font-smoothing:antialiased}
body::before{content:'';position:fixed;inset:0;z-index:9000;pointer-events:none;opacity:.045;background-image:""" + GRAIN + """}
a{color:var(--bone)}
:focus-visible{outline:2px solid var(--ac);outline-offset:3px}
::selection{background:var(--acm)}
/* ---------- menu lateral (com toques do Hextech) ---------- */
.shell{display:grid !important;grid-template-columns:252px minmax(0,1fr);min-height:100vh}
.side{position:sticky;top:0;height:100vh;overflow-y:auto;scrollbar-width:thin;display:flex;flex-direction:column;gap:4px;padding:22px 14px 16px;
background:linear-gradient(180deg,#0f1118,#0c0e14);border-right:1px solid transparent;border-image:linear-gradient(180deg,rgba(200,170,110,.45),rgba(200,170,110,.08) 60%,rgba(200,170,110,.25)) 1}
.side .logo{text-decoration:none;padding:0 8px 16px;color:var(--bone)}
.clogo{display:inline-flex;align-items:center;gap:10px}.cl-t{display:flex;flex-direction:column;line-height:1}.clogo b{font:700 26px/.9 'CP',var(--d);letter-spacing:.07em;color:var(--bone)}.clogo small{font:600 10.5px/1 var(--body);letter-spacing:.32em;color:#c8aa6e;margin-top:4px;text-transform:uppercase}
.cmark{flex:none;filter:drop-shadow(0 6px 16px rgba(0,0,0,.55))}
.side-me{display:flex;align-items:center;gap:11px;padding:10px;margin:0 0 6px;border-radius:12px;background:var(--raised);border:1px solid rgba(200,170,110,.18);text-decoration:none;color:var(--bone);position:relative}
.side-me::before{content:'';position:absolute;left:12px;right:12px;top:-1px;height:1px;background:linear-gradient(90deg,transparent,#c8aa6e,transparent)}
.side-me b{display:block;font:600 13.5px/1.25 var(--body)}.side-me small{display:block;color:var(--steel);font-size:12px}
.sg{display:flex;flex-direction:column;gap:1px;margin-top:10px}
.sg>summary{list-style:none;cursor:pointer;display:flex;align-items:center}.sg>summary::-webkit-details-marker{display:none}
.sg>summary:after{content:'';margin-left:auto;margin-right:12px;width:6px;height:6px;border-right:1.5px solid var(--steel);border-bottom:1.5px solid var(--steel);transform:rotate(45deg);transition:transform .2s;opacity:.6}
.sg:not([open])>summary:after{transform:rotate(-45deg)}
.sg small{display:flex;align-items:center;gap:8px;padding:4px 12px 6px;color:#c8aa6e;font:600 12px var(--body);opacity:.85}
.sg small::before{content:'';width:5px;height:5px;transform:rotate(45deg);background:#c8aa6e}
.sg a{display:flex;align-items:center;gap:11px;padding:9px 12px;border-radius:10px;color:var(--steel);text-decoration:none;font:500 14.5px var(--body);position:relative;transition:color .15s,background .15s}
.sg a:hover{color:var(--bone);background:rgba(255,255,255,.03)}
.sg a[aria-current]{color:var(--bone);background:linear-gradient(90deg,rgba(200,170,110,.14),rgba(200,170,110,.02))}
.sg a[aria-current]::before{content:'';position:absolute;left:0;top:8px;bottom:8px;width:3px;border-radius:2px;background:var(--ac)}
.sg a[aria-current] .ni{color:#c8aa6e}
.side-f{margin-top:auto;padding-top:14px;border-top:1px solid var(--line);display:flex;flex-direction:column;gap:8px}
.side-f form{margin:0}.side-f button{width:100%}
.side .pst{padding:0 4px}
.ptop{display:none !important}
/* blocos com a linha dourada do Hextech no topo */
.card,.hp-mission,.cnt,.bx-left,.bx-t,.bx-sk,.bx-items,.mh-box,.rtrack,.otp,.kpi{position:relative}
.card::after,.hp-mission::before,.hp-panel::before,.hp-quick a::before{content:'';position:absolute;left:18px;right:18px;top:-1px;height:1px;background:linear-gradient(90deg,transparent,rgba(200,170,110,.7),transparent);pointer-events:none}
h2{display:flex;align-items:center;gap:12px}
h2::before{display:block !important;content:'' !important;width:8px !important;height:8px !important;flex:none;transform:rotate(45deg);background:#c8aa6e !important;box-shadow:0 0 10px rgba(200,170,110,.5);opacity:1 !important;border:0 !important}
h2::after{content:'';flex:1;height:1px;background:linear-gradient(90deg,rgba(200,170,110,.35),transparent)}
/* ---------- menu no topo (antigo) ---------- */
.shell{display:block;min-height:100vh}
.ptop{position:sticky;top:0;z-index:100;display:flex;align-items:center;gap:34px;padding:16px 56px;background:rgba(18,20,27,.82);backdrop-filter:blur(14px);border-bottom:1px solid transparent;transition:border-color .2s}
.ptop.sc{border-bottom-color:var(--line)}
.ptop .logo{font:900 26px/1 var(--d);color:var(--bone);text-decoration:none;white-space:nowrap}.ptop .logo span{color:var(--ac)}
.pnav{display:flex;gap:26px;align-items:center;min-width:0}
.pnav>a,.pmore>button{color:var(--steel);text-decoration:none;font:500 15px var(--body);padding:8px 0;border:0;border-bottom:2px solid transparent;background:none;cursor:pointer;white-space:nowrap}
.pnav>a:hover,.pmore>button:hover{color:var(--bone)}
.pnav>a[aria-current],.pmore.cur>button{color:var(--bone);border-bottom-color:var(--ac)}
.pmore>button,.pme>button{border:0 !important;border-bottom:2px solid transparent !important;border-radius:0 !important;padding:8px 0 !important;background:none !important;font:500 15px var(--body) !important;color:var(--steel) !important}
.pme>button{border-bottom:0 !important;color:var(--bone) !important}
.pmore.cur>button{border-bottom-color:var(--ac) !important;color:var(--bone) !important}.pmore>button:hover{color:var(--bone) !important}
.hp-filt{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin:0 0 10px}.hp-filt select{width:auto;min-width:200px;padding:8px 12px}.hp-pg{padding-top:34px}
.pmore{position:relative}.pmore>button::after{content:'';display:inline-block;width:6px;height:6px;margin-left:8px;border-right:1.5px solid currentColor;border-bottom:1.5px solid currentColor;transform:rotate(45deg) translateY(-3px)}
.pmenu{position:absolute;top:calc(100% + 10px);left:-14px;min-width:220px;padding:8px;border-radius:14px;background:var(--raised);border:1px solid var(--line);box-shadow:0 24px 60px rgba(0,0,0,.5);display:none}
.pmore.open .pmenu{display:block}
.pmenu a{display:block;padding:9px 12px;border-radius:9px;color:var(--bone);text-decoration:none;font-size:14.5px}.pmenu a:hover,.pmenu a[aria-current]{background:var(--raised2)}
.pright{margin-left:auto;display:flex;align-items:center;gap:18px}
.pst{font-size:13px;color:var(--steel);text-decoration:none;white-space:nowrap}.pst i{display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--emerald);margin-right:7px;vertical-align:1px}
.pst.run i{background:var(--ac);animation:pulse 1.2s infinite}.pst.warn i{background:#d9b26b}
@keyframes pulse{50%{opacity:.3}}
.pme{position:relative}.pme>button{display:flex;align-items:center;gap:10px;background:none;border:0;cursor:pointer;color:var(--bone);padding:0;text-align:left}
.pme>button b{display:block;font:600 14px/1.2 var(--body)}.pme>button small{display:block;color:var(--steel);font-size:12.5px}
.pme .pmenu{left:auto;right:0}.pme.open .pmenu{display:block}.pme .pmenu form{margin:0}
.pme .pmenu button{all:unset;display:block;width:100%;box-sizing:border-box;padding:9px 12px;border-radius:9px;cursor:pointer;font-size:14.5px;color:var(--bone)}
.pme .pmenu button:hover{background:var(--raised2)}
.pav{position:relative;width:38px;height:38px;border-radius:50%;box-shadow:0 0 0 2px var(--night),0 0 0 4px var(--tc,var(--emerald));overflow:hidden;flex:none}
.pav img{width:100%;height:100%;object-fit:cover}
main{max-width:1480px;width:100%;margin:0 auto;padding:26px 40px 100px;min-width:0}
.topbar{display:none}
#jobarea{position:relative}
/* ---------- titulo da pagina ---------- */
.banner{position:relative;overflow:hidden;border:0 !important;border-radius:0;margin:0 0 30px;min-height:0;padding:22px 0 8px;background:none !important;box-shadow:none !important}
.banner::before,.banner::after{display:none !important}
.bn-art{position:absolute;inset:0;opacity:.32;border-radius:16px;background-size:cover;background-position:right 20%;-webkit-mask-image:linear-gradient(90deg,transparent 30%,#000 85%);mask-image:linear-gradient(90deg,transparent 30%,#000 85%);animation:none}
.bn-fade{position:absolute;inset:0;background:linear-gradient(0deg,var(--night),transparent 70%)}
.bn-in{position:relative;padding:0}
.bn-k,.bn-line{display:none !important}
.banner h1{font:900 clamp(52px,6vw,88px)/.85 var(--d) !important;letter-spacing:-.015em;margin:0;text-shadow:none;color:var(--bone)}
.banner h1::after{content:'';display:block;width:56px;height:5px;background:var(--ac);margin:18px 0 0 4px}
.bn-sub{margin:16px 0 0;color:#c9c3b8;font-size:17px;max-width:60ch}
/* ---------- topo do campeao ---------- */
.chero{border:1px solid rgba(200,170,110,.22) !important;border-radius:18px !important;background:var(--night) !important;margin:0 0 26px !important;padding:40px 40px 28px;min-height:380px;overflow:hidden;isolation:isolate}
.chero .sp{inset:0;z-index:-2;background-position:70% 18%;animation:none}
.chero::after{z-index:-1;background:linear-gradient(90deg,var(--night) 22%,rgba(18,20,27,.5) 55%,rgba(18,20,27,.1) 85%),linear-gradient(0deg,var(--night) 3%,transparent 50%) !important}
.ch-in{padding:0 !important;max-width:760px}.ch-in>small{color:#c9c3b8 !important;font:500 16px var(--body) !important;letter-spacing:0 !important}
.ch-n{font:900 clamp(80px,9vw,150px)/.8 var(--d) !important;margin:6px 0 18px !important;color:var(--bone)}
.ch-n::after{content:'';display:block;width:64px;height:6px;background:var(--ac);margin:22px 0 0 4px}
.ch-b{color:#c9c3b8;max-width:60ch}
.hsts{padding:0 0 6px !important}.hst{background:rgba(18,20,27,.6) !important;backdrop-filter:blur(8px);min-width:180px}.hst b{font-size:34px !important}
.bx-seq i.k4{background:var(--ac) !important;color:#fff !important;border-color:var(--ac) !important}
.cm i.on{background:var(--ac) !important}.cm i{border-radius:2px}
@media (max-width:1100px){.chero{padding:30px 22px 22px}}
/* ---------- tipografia ---------- */
h1{font:900 56px/.9 var(--d);letter-spacing:-.01em;color:var(--bone)}
h2{font:700 30px/1.1 var(--d) !important;letter-spacing:.005em !important;text-transform:none !important;color:var(--bone) !important;margin:44px 0 12px}
h2::before{display:none !important}
h3{font:700 22px/1.15 var(--d);color:var(--bone)}
.gl,b.gl{font:600 14.5px var(--body) !important;letter-spacing:0 !important;text-transform:none !important;color:var(--bone) !important}
.kl,.kpi small.kl{font:500 13px var(--body) !important;letter-spacing:0 !important;text-transform:none !important;color:var(--steel) !important}
.kv,.kpi b,.trend b,.hst b,.cscore,.gapn,.lv-clock b,.dh-gap,.m-streak>b,.num-b{font-family:var(--d) !important;font-weight:700 !important;letter-spacing:0 !important}
.kpi b.kv,.kpi>b{font-size:46px !important;line-height:1}
.n,.mut{color:var(--steel)}
.tag{font:600 11.5px var(--body) !important;letter-spacing:.01em !important;text-transform:none !important;opacity:1}
.tag::before{width:7px !important;height:7px !important;border-radius:50%}
.tip{display:block !important;padding:12px 16px !important;background:transparent !important;border:0 !important;border-left:2px solid var(--line) !important;border-radius:0 !important}
.tip .tag{display:inline-flex !important;margin:0 8px 0 0;padding:0 !important}.tip>div{display:inline}
.ch-n,.pname b,.m-t,.dh-t,.big2,.hero .big{font-family:var(--d) !important;letter-spacing:-.01em !important}
/* ---------- superficies ---------- */
.card,.kpi,.trend,.lv-card,.ccol,.gp-card,.dcard2,.drawer,.lchip,.urow,.pchamp,.mst,.thr,.vsc,.tile,.gcard,.dcard,.mcard,.sstat,.eloh,.coach,.gplan,
.lv-top,.arena,.dmore,.rankbox,.ab2,.combo,.tline,.aian,.chc,.itrow,.empty,.jobbar,.gp-mini,.lv-step,.lv-now,.cidea,.tl-c,.pico,.exr,
.mrow,.step,.pcard,.met,.slot,.hst,.mhero,.dhero,.phero2,.maincard,.hero,.cnt,.bx-left,.bx-t,.bx-sk,.bx-items,.mh-box,.rtrack,.otp,.ovl,.alert,.aiban{
border-radius:14px !important;border:1px solid var(--line) !important;background:var(--raised) !important;box-shadow:none !important}
.card:hover{border-color:var(--line) !important}
a.card:hover,a.mcard:hover,a.dcard:hover,a.pchamp:hover,a.tile:hover,a.gcard:hover,.chc:hover{border-color:var(--line-hover) !important}
.mhero,.dhero,.phero2{background:linear-gradient(90deg,var(--raised) 30%,rgba(26,30,40,.6)) !important}
.tl-c,.pico{background:var(--night) !important}
.pill,.badge,.chip,.gstep,.mchk{border-radius:999px !important}
.badge{background:transparent !important;border:1px solid var(--line) !important;color:var(--bone) !important;font:500 12.5px var(--body) !important;text-transform:none !important;letter-spacing:0 !important}
.dcard.go{display:flex;align-items:center;justify-content:center;font:600 15px var(--body) !important;letter-spacing:0 !important;text-transform:none !important;color:var(--bone) !important;text-decoration:none}
.dcard .kl{display:block}
.pname small,.maincard small,.pill small,.rt small,.m-k,.mh-l,.lead{text-transform:none !important;letter-spacing:0 !important;font-family:var(--body) !important}
.pname small{font:500 14px var(--body) !important;color:var(--steel) !important}.pname b{font:900 64px/.9 var(--d) !important}
.chatlog{border-radius:16px !important;border:1px solid var(--line) !important;background:var(--night) !important}.msg{border-radius:16px !important}.msg.bot{background:var(--raised) !important;border:1px solid var(--line) !important;border-left:1px solid var(--line) !important}
.msg.me{background:var(--bone) !important;color:var(--night) !important;border:0 !important}.msg.typing span{background:var(--ac) !important}
.dh-k{font:500 14px var(--body) !important;letter-spacing:0 !important;text-transform:none !important;color:var(--steel) !important}.dh-k i{display:none}
/* ---------- botoes e campos ---------- */
button,.btn{font:600 14px var(--body) !important;letter-spacing:0 !important;text-transform:none !important;border-radius:10px !important;padding:10px 18px !important;
background:transparent !important;color:var(--bone) !important;border:1px solid var(--line) !important;box-shadow:none !important;filter:none !important;transform:none !important;cursor:pointer}
button:hover,.btn:hover{border-color:var(--steel) !important;box-shadow:none !important}
button::after,button::before,.btn::after,.btn::before{display:none}
.btn.gold,button.gold,form button.wide,.btn.primary,button[type=submit].primary{background:var(--bone) !important;color:var(--night) !important;border-color:var(--bone) !important}
.btn.gold:hover,button.gold:hover{background:#fff !important}
.btn.alt{border-color:var(--acm) !important;color:var(--bone) !important}.btn.alt:hover{border-color:var(--ac) !important}
.btn.ghost{background:transparent !important}
button.danger{border-color:rgba(196,106,120,.6) !important;color:#f0b9c1 !important}button.okb{border-color:rgba(61,190,139,.6) !important;color:#bdf0db !important}
.syncbtn{border-radius:10px !important}
/* escolha de fundo: miniaturas de skin (o estilo geral de botao apagava a imagem) */
.skins{grid-template-columns:repeat(auto-fill,minmax(120px,1fr)) !important;gap:14px !important}
.skin button{box-sizing:border-box !important;display:block !important;width:100% !important;height:auto !important;padding:0 !important;margin:0 !important;aspect-ratio:308/560 !important;cursor:pointer;
border-radius:12px !important;border:1px solid var(--line) !important;background-color:#0b1520 !important;background-image:var(--img) !important;background-size:cover !important;background-position:center !important;background-repeat:no-repeat !important;
transition:transform .25s,border-color .25s,box-shadow .25s !important}
.skin button:hover{transform:translateY(-3px) !important;border-color:#c8aa6e !important;box-shadow:0 10px 26px rgba(0,0,0,.5),0 0 18px rgba(200,170,110,.25) !important}
.skin.on button{border-color:#c8aa6e !important;box-shadow:0 0 0 2px #c8aa6e !important}
.skin small{color:var(--steel) !important;font:500 12.5px/1.3 var(--body) !important}
.bgprev{height:200px !important;border-radius:14px !important;border:1px solid var(--line) !important;background:#0b1520}
.bgprev>div{position:absolute !important;inset:0 !important;background-size:cover !important;background-position:center 20% !important;background-repeat:no-repeat !important}
input,select,textarea{background:#151821 !important;border:1px solid var(--line) !important;border-radius:10px !important;color:var(--bone) !important;font:400 15px var(--body) !important;box-shadow:none !important}
input:focus,select:focus,textarea:focus{border-color:var(--steel) !important;outline:0}
label{color:var(--steel)}
/* ---------- tabelas ---------- */
table{border-collapse:collapse}th{font:500 13px var(--body) !important;color:var(--steel) !important;text-transform:none !important;letter-spacing:0 !important}
td{border-color:var(--line) !important}
/* ---------- faixas ---------- */
.jobbar{display:flex;align-items:center;gap:14px;padding:12px 16px !important;margin:0 0 18px}
.jobbar .spin{border-color:var(--line);border-top-color:var(--ac)}.jb-bar i{background:var(--ac) !important}
.alert{padding:12px 16px}.alert.ok{border-color:rgba(61,190,139,.4) !important}
/* ---------- dica flutuante ---------- */
.tipbox{position:fixed;z-index:9999;max-width:320px;padding:12px 14px;border-radius:12px;background:#0e1016;border:1px solid var(--line);
box-shadow:0 18px 44px rgba(0,0,0,.55);color:var(--bone);font:13.5px/1.5 var(--body);pointer-events:none;opacity:0;transform:translateY(4px);transition:opacity .12s,transform .12s}
.tipbox.on{opacity:1;transform:none}.tipbox b{display:block;color:#fff;font-size:14px;margin-bottom:2px}.tipbox em{display:block;font-style:normal;color:var(--steel);font-size:12.5px;margin-bottom:6px}
[data-tip]{cursor:help}
/* ---------- abas e segmentos ---------- */
.ctab.on{border-bottom-color:var(--ac) !important}
.seg{border-radius:999px !important;border:0 !important;background:none !important;gap:6px;overflow:visible !important}
.seg button{border:1px solid var(--line) !important;border-radius:999px !important;padding:7px 16px !important;color:var(--steel) !important;font:500 14px var(--body) !important}
.seg button.on,.seg button[aria-pressed=true]{background:var(--bone) !important;color:var(--night) !important;border-color:var(--bone) !important}
.bx-core.on{background:var(--acs) !important;border-left-color:var(--ac) !important}.bx-tb.on{border-bottom-color:var(--ac) !important;background:var(--acs) !important}
.tl-fill{background:linear-gradient(90deg,var(--acm),var(--ac)) !important}.tl-dot.on i{background:var(--ac) !important;border-color:var(--bone) !important;box-shadow:0 0 0 6px var(--acs) !important}
.tl-dot.on b{color:var(--bone) !important}.tl-dot b{font:600 14px var(--body) !important}
.sgc i.on{background:var(--ac) !important;border-color:var(--ac) !important;color:#fff}
.hi{color:var(--win) !important}.lo{color:var(--loss) !important}
@media (max-width:1100px){.shell{grid-template-columns:1fr !important}.side{position:static;height:auto;flex-direction:row;flex-wrap:wrap;overflow-x:auto}.sg{flex-direction:row;margin:0}.sg small,.side-f{display:none}main{padding:22px 18px 80px}}
@media (max-width:700px){.pme>button div{display:none}.pnav{gap:18px}.ptop .logo{font-size:22px}}
@media (prefers-reduced-motion:reduce){*{animation:none !important;transition:none !important}}
"""

JS = """<script>(function(){var t=document.querySelector('.ptop');if(t){var f=function(){t.classList.toggle('sc',scrollY>8)};addEventListener('scroll',f,{passive:true});f()}
document.addEventListener('click',function(e){var b=e.target.closest('.pmore>button,.pme>button');document.querySelectorAll('.pmore.open,.pme.open').forEach(function(m){if(!b||m!==b.parentNode)m.classList.remove('open')});
if(b){var m=b.parentNode;var o=m.classList.toggle('open');b.setAttribute('aria-expanded',o)}});
document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.pmore.open,.pme.open').forEach(function(m){m.classList.remove('open')})})})();</script>"""

SECTIONS = {
    "/desempenho": ("Meu desempenho", [("/desempenho", "Visão geral"), ("/hoje", "Resumo do dia"), ("/semana", "Semana"), ("/graficos", "Gráficos"), ("/partidas", "Partidas"), ("/estatisticas", "Por campeão"),
                                       ("/matchups", "Matchups"), ("/matchups?ver=grade", "Confrontos"), ("/diagnostico", "Diagnóstico e erros"), ("/derrotas", "Derrotas"),
                                       ("/habitos", "Hábitos"), ("/treino", "Treino"), ("/exercicios", "Exercícios"), ("/pdl", "PDL"), ("/calendario", "Calendário"), ("/topo", "Comparar")],
                    ("/partida/", "/revisao/")),
    "/campeoes": ("Guia do jogo", [("/campeoes", "Campeões"), ("/duelos", "Duelos"), ("/tierlist", "Tier list"), ("/patch", "Patch"),
                                   ("/rotas", "Rotas"), ("/iniciante", "Para iniciantes")],
                  ("/campeao/", "/selva")),
    "/perfil": ("Minha conta", [("/perfil", "Perfil"), ("/conta", "Conta e senha")], ("/vincular",)),
}


def section_of(here):
    """(link da barra lateral, [abas]) da secao em que a pagina esta, ou (None, None)."""
    for root, (_, tabs, extra) in SECTIONS.items():
        if any(here == h or here.startswith(h + "/") or here.startswith(h + "?") for h, _ in tabs) or here.startswith(extra):
            return root, tabs
    return None, None


def subnav(here):
    """Abas no topo das paginas de Meu desempenho e Aprender (cada aba e uma pagina)."""
    root, tabs = section_of(here)
    if not tabs:
        return ""
    alias = {"/partida/": "/partidas", "/revisao/": "/partidas", "/campeao/": "/campeoes", "/selva": "/rotas", "/vincular": "/perfil"}
    cur = next((h for h, _ in tabs if here == h or here.startswith(h + "/")), None) or next((v for k, v in alias.items() if here.startswith(k)), None)
    if root in GROUPED:
        grp = next((g for g in GROUPED[root] if any(h == cur for h, _ in g[1])), GROUPED[root][0])
        top = "".join(f"<a href='{g[1][0][0]}'{' aria-current=page' if g is grp else ''}>{e(g[0])}</a>" for g in GROUPED[root])
        sub = ("<nav class='subnav2' aria-label='" + e(grp[0]) + "'>" + "".join(
            f"<a href='{h}'{' aria-current=page' if h == cur else ''}>{e(t)}</a>" for h, t in grp[1]) + "</nav>") if len(grp[1]) > 1 else ""
        return "<nav class='subnav' aria-label='" + e(SECTIONS[root][0]) + "'>" + top + "</nav>" + sub
    return ("<nav class='subnav' aria-label='" + e(SECTIONS[root][0]) + "'>" + "".join(
        f"<a href='{h}'{' aria-current=page' if h == cur else ''}>{e(t)}</a>" for h, t in tabs) + "</nav>")


# Meu desempenho: 16 paginas em 7 abas; dentro de cada aba, uma segunda linha troca entre as partes
GROUPED = {"/desempenho": [
    ("Visão geral", [("/desempenho", "Resumo"), ("/estatisticas", "Por campeão")]),
    ("Dia e semana", [("/hoje", "Hoje"), ("/semana", "Semana"), ("/calendario", "Calendário")]),
    ("Partidas", [("/partidas", "Partidas")]),
    ("Gráficos e PDL", [("/graficos", "Gráficos"), ("/pdl", "PDL")]),
    ("Confrontos", [("/matchups", "Matchups"), ("/matchups?ver=grade", "Grade de confrontos")]),
    ("Diagnóstico", [("/diagnostico", "O que pesa"), ("/derrotas", "Derrotas"), ("/habitos", "Hábitos")]),
    ("Treino", [("/treino", "Treino de decisão"), ("/exercicios", "Exercícios"), ("/topo", "Comparar com Mestre")]),
]}


SUBNAV_CSS = """.subnav{display:flex;gap:4px;overflow-x:auto;scrollbar-width:thin;margin:0 0 14px;padding:4px;border:1px solid var(--rule);border-radius:14px;
background:rgba(16,11,11,.55);position:sticky;top:0;z-index:20;backdrop-filter:blur(8px)}
.subnav a{flex:0 0 auto;padding:8px 14px;border-radius:10px;color:#D6CCC0;text-decoration:none;font:600 13px var(--body);white-space:nowrap}
.subnav a:hover{background:rgba(255,255,255,.05);color:#fff}.subnav a[aria-current]{background:var(--gold);color:#1a1405}
@media (max-width:700px){.subnav{margin:0 0 10px}}"""

GROUPS = [("Jogar", [("/", "Início"), ("/jogo", "Partida ao vivo"), ("/overlay", "Editar overlay"), ("/coach", "Coach IA")]),
          ("Evoluir", [("/desempenho", "Meu desempenho"), ("/campeoes", "Guia do jogo")])]


def sidebar(here, is_admin, status_html, me_html, sync_html, icon):
    root, _ = section_of(here)
    cur = lambda h: (h == root) if h in SECTIONS else (here == h or (h != "/" and here.startswith(h)))
    groups = GROUPS + ([("Conta", [("/perfil", "Minha conta"), ("/admin", "Administração"), ("/guia", "Como usar")])] if is_admin
                       else [("Conta", [("/perfil", "Minha conta"), ("/guia", "Como usar")])])
    nav = "".join(f"<details class='sg' data-g='{e(g)}' open><summary><small>{e(g)}</small></summary>" + "".join(
        f"<a href='{h}'{' aria-current=page' if cur(h) else ''}>{icon(h)}<span>{e(t)}</span></a>" for h, t in items) + "</details>" for g, items in groups)
    nav += ("<script>(function(){try{var c=JSON.parse(localStorage.getItem('sg_closed')||'[]');document.querySelectorAll('details.sg').forEach(function(d){"
            "if(c.indexOf(d.dataset.g)>=0&&!d.querySelector('[aria-current]'))d.open=false;d.addEventListener('toggle',function(){var x=[];"
            "document.querySelectorAll('details.sg').forEach(function(k){if(!k.open)x.push(k.dataset.g)});localStorage.setItem('sg_closed',JSON.stringify(x))})})}catch(e){}})();</script>")
    return (f"<nav class='side' aria-label='Principal'><a class='logo' href='/' aria-label='Carry, início'>{logo(42, 'sb')}</a>{me_html}{nav}"
            f"<div class='side-f'>{status_html}{sync_html}</div></nav>")


PRIMARY = [("/", "Início"), ("/partidas", "Partidas"), ("/campeoes", "Campeões"), ("/jogo", "Partida ao vivo"), ("/coach", "Coach IA"), ("/diagnostico", "Diagnóstico")]
MORE = [("/perfil", "Meu perfil"), ("/erros", "Meus erros"), ("/duelos", "Duelos"), ("/tierlist", "Tier list"), ("/patch", "Patch"), ("/calendario", "Calendário"), ("/pdl", "PDL"), ("/padroes", "Padrões"), ("/matchups", "Matchups"), ("/topo", "Comparar"), ("/habitos", "Hábitos"), ("/sincronizar", "Sincronizar")]


def topnav(here, is_admin, status_html, me_html):
    cur = lambda h: here == h or (h != "/" and here.startswith(h))
    prim = "".join(f"<a href='{h}'{' aria-current=page' if cur(h) else ''}>{e(t)}</a>" for h, t in PRIMARY)
    more_items = MORE + ([("/admin", "Administração")] if is_admin else [])
    mcur = any(cur(h) for h, _ in more_items)
    more = (f"<div class='pmore{' cur' if mcur else ''}'><button type='button' aria-expanded='false' aria-haspopup='true'>Mais</button><div class='pmenu'>"
            + "".join(f"<a href='{h}'{' aria-current=page' if cur(h) else ''}>{e(t)}</a>" for h, t in more_items) + "</div></div>")
    return (f"<header class='ptop'><a class='logo' href='/'>{logo(30, 'tp')}</a><nav class='pnav' aria-label='Principal'>{prim}{more}</nav>"
            f"<div class='pright'>{status_html}{me_html}</div></header>")


def tabbar(tabs, key):
    """Abas no estilo do Inicio. tabs = [(id, titulo, html, detalhe_opcional)]. Lembra a ultima aba (por pagina) e aceita #id na URL."""
    tabs = [t for t in tabs if t[2]]
    if not tabs:
        return ""
    nav = (f"<div class='hp-tabs' role='tablist' data-key='{e(key)}'>" + "".join(
        f"<button type='button' role='tab' id='tab-{e(k)}' aria-controls='tp-{e(k)}' aria-selected='{'true' if n == 0 else 'false'}' "
        f"tabindex='{0 if n == 0 else -1}' data-t='{e(k)}'>{e(t)}" + (f"<small class='tbx'>{e(x[0])}</small>" if x else "") + "</button>"
        for n, (k, t, _, *x) in enumerate(tabs)) + "</div>")
    panes = "".join(f"<div class='hp-tp' role='tabpanel' id='tp-{e(k)}' aria-labelledby='tab-{e(k)}'{'' if n == 0 else ' hidden'}>{h}</div>"
                    for n, (k, _, h, *__) in enumerate(tabs))
    return nav + panes


TABS_JS = """<script>(function(){document.querySelectorAll('.hp-tabs[data-key]').forEach(function(T){var key='tab-'+T.dataset.key;
function tab(k,focus){var b=T.querySelector('[data-t=\"'+k+'\"]');if(!b)return;T.querySelectorAll('[role=tab]').forEach(function(x){var on=x===b;x.setAttribute('aria-selected',on);x.tabIndex=on?0:-1;
var p=document.getElementById(x.getAttribute('aria-controls'));if(p)p.hidden=!on});if(focus)b.focus();try{sessionStorage.setItem(key,k)}catch(_){}
document.querySelectorAll('#'+b.getAttribute('aria-controls')+' .rv').forEach(function(r){r.classList.add('in')})}
T.ptab=tab;T.addEventListener('click',function(e){var b=e.target.closest('[role=tab]');if(b)tab(b.dataset.t)});
T.addEventListener('keydown',function(e){var l=[].slice.call(T.querySelectorAll('[role=tab]')),i=l.indexOf(document.activeElement);if(i<0)return;var d={ArrowRight:1,ArrowLeft:-1}[e.key];if(!d)return;e.preventDefault();tab(l[(i+d+l.length)%l.length].dataset.t,true)});
var h=(location.hash||'').slice(1),s=null;try{s=sessionStorage.getItem(key)}catch(_){}if(h&&T.querySelector('[data-t=\"'+h+'\"]'))tab(h);else if(s)tab(s);
document.addEventListener('click',function(e){var g=e.target.closest('[data-go]');if(g&&T.querySelector('[data-t=\"'+g.dataset.go+'\"]')){e.preventDefault();tab(g.dataset.go);T.scrollIntoView({behavior:'smooth',block:'start'})}})})})();</script>"""
