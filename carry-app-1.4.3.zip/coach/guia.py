"""Como usar o Carry: o passo a passo completo (instalar, chaves, conta, partida, overlay, voz, paginas e problemas)."""
import html

e = lambda x: html.escape("" if x is None else str(x))

CSS = """
.gd{display:grid;grid-template-columns:240px minmax(0,1fr);gap:26px;align-items:start}
@media (max-width:1000px){.gd{grid-template-columns:1fr}.gd-toc{position:static !important}}
.gd-toc{position:sticky;top:70px;border:1px solid var(--rule);border-radius:16px;padding:14px;background:var(--panel)}
.gd-toc b{display:block;font:700 11px var(--head);letter-spacing:.08em;text-transform:uppercase;color:var(--mute);margin:0 0 8px}
.gd-toc a{display:flex;gap:8px;align-items:center;padding:7px 8px;border-radius:9px;color:#D6CCC0;text-decoration:none;font-size:13.5px}
.gd-toc a:hover{background:rgba(255,255,255,.05);color:#fff}.gd-toc a i{font-style:normal;width:22px;height:22px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;
background:rgba(233,196,106,.15);color:var(--gold);font:700 11px var(--head);flex:none}
.gd-main{display:flex;flex-direction:column;gap:18px;min-width:0}
.gd-hero{border:1px solid rgba(233,196,106,.4);border-radius:18px;padding:20px 22px;background:radial-gradient(800px 240px at 0 0,rgba(233,196,106,.1),transparent 70%),var(--panel)}
.gd-hero h2{margin:0 0 6px;font:800 26px var(--head);color:#fff}.gd-hero p{margin:4px 0;color:#E8DCCB;font-size:14.5px;line-height:1.55}
.gd-sec{border:1px solid var(--rule);border-radius:18px;padding:18px 22px;background:var(--panel);scroll-margin-top:80px}
.gd-sec h2{margin:0 0 4px;font:700 21px var(--head);color:#fff;display:flex;align-items:center;gap:10px}
.gd-sec h2 i{font-style:normal;width:30px;height:30px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;background:var(--gold);color:#1a1405;font:800 14px var(--head)}
.gd-sec>p.s{margin:0 0 12px;color:#9A8F86;font-size:13.5px}
.gd-sec h3{margin:16px 0 6px;font:700 15px var(--head);color:var(--gold)}
.gd-sec ol,.gd-sec ul{margin:6px 0;padding-left:22px;color:#E8DCCB;font-size:14.5px;line-height:1.6}.gd-sec li{margin:4px 0}
.gd-sec p{color:#E8DCCB;font-size:14.5px;line-height:1.6;margin:6px 0}
.gd kbd{display:inline-block;padding:1px 7px;border-radius:6px;border:1px solid rgba(255,255,255,.18);background:#231B1A;font:600 12.5px var(--mono,monospace);color:#fff}
.gd-tip{border-left:3px solid var(--gold);background:rgba(233,196,106,.07);padding:9px 12px;border-radius:8px;margin:10px 0;color:#F0E4CC;font-size:13.5px}
.gd-warn{border-left:3px solid #E5564E;background:rgba(229,86,78,.08);padding:9px 12px;border-radius:8px;margin:10px 0;color:#F0E4CC;font-size:13.5px}
.gd a.go{color:var(--gold)}
.gd-faq details{border:1px solid rgba(255,255,255,.07);border-radius:10px;padding:10px 12px;margin:8px 0;background:rgba(255,255,255,.02)}
.gd-faq summary{cursor:pointer;font-weight:600;color:#fff}.gd-faq details p{margin:8px 0 2px}
"""

SECS = [
    ("comecar", "Primeiros passos", "O que fazer logo depois de instalar (10 minutos, uma vez só).", """
<ol>
<li><b>Abra o Carry</b> pelo atalho <b>Carry</b> na área de trabalho. Ele abre no navegador, em <code>127.0.0.1:8765</code> (roda só no seu PC).</li>
<li><b>Crie a sua conta</b> com nome, e-mail e senha. A primeira conta do PC vira a de administrador.</li>
<li><b>Coloque a chave da Riot</b> em <a class='go' href='/admin'>Administração &gt; Chaves</a> (passo 2 deste guia).</li>
<li><b>Coloque a chave do Gemini</b> (grátis) no mesmo lugar: liga a análise automática das partidas, o Coach IA e as perguntas por voz.</li>
<li><b>Vincule a sua conta do LoL</b> com o seu Riot ID (Nome#TAG). O app pede para trocar o ícone de perfil por alguns segundos, para provar que a conta é sua.</li>
<li><b>Espere a primeira sincronização</b>: o app baixa as suas últimas partidas sozinho (alguns minutos).</li>
<li><b>Escolha o seu main</b> no cartão que aparece no Início (o app já sugere pela sua maestria).</li>
<li><b>Ligue o overlay e teste a voz</b> em <a class='go' href='/overlay'>Editar overlay</a> (passo 5).</li>
</ol>
<div class='gd-tip'>Depois disso é só jogar: deixe o Carry aberto (ele pode abrir sozinho com o Windows) e o resto acontece no automático.</div>"""),
    ("chaves", "As chaves (Riot, Gemini e voz)", "As chaves ficam só no seu PC, em Administração. Nunca mande para ninguém.", """
<h3>Chave da Riot (obrigatória)</h3>
<ol>
<li>Entre em <b>developer.riotgames.com</b> e faça login com a sua conta do LoL.</li>
<li>Clique em <b>Regenerate API Key</b> e copie a chave (começa com <code>RGAPI-</code>).</li>
<li>Cole em <a class='go' href='/admin'>Administração &gt; Chaves &gt; Riot</a> e clique em <b>Salvar</b>. O app testa na hora.</li>
</ol>
<div class='gd-warn'>A chave de desenvolvimento vence a cada 24 horas. Quando o app avisar "chave vencida", gere outra e cole de novo. Para não vencer, peça uma <b>Personal API Key</b> no mesmo site (aprovação da Riot, demora alguns dias).</div>
<h3>Chave do Gemini (grátis, recomendada)</h3>
<ol><li>Entre em <b>aistudio.google.com/app/apikey</b> com uma conta Google.</li><li>Clique em <b>Create API key</b>, copie e cole em <a class='go' href='/admin'>Administração &gt; Chaves &gt; Gemini</a>.</li></ol>
<p>Liga: análise automática de cada partida, Coach IA, perguntas por voz no jogo e uma das vozes grátis.</p>
<h3>Voz (escolha uma)</h3>
<ul><li><b>Microsoft (grátis, sem chave)</b>: a voz padrão. Ligue "Voz grátis" em Administração.</li>
<li><b>Gemini (grátis)</b>: usa a mesma chave do Gemini.</li>
<li><b>ElevenLabs</b>: vozes mais naturais, precisa da chave e de créditos da ElevenLabs.</li></ul>
<p>A voz escolhida fica em <a class='go' href='/jogo'>Partida ao vivo &gt; Voz dos avisos</a>, com filtro por empresa e botão <b>Ouvir exemplo</b>.</p>"""),
    ("partida", "Uma partida do começo ao fim", "O que o Carry faz em cada momento, sem você clicar em nada.", """
<h3>No lobby e na fila</h3>
<p>O app lembra a regra das 2 derrotas, a missão do dia e quanto você já jogou hoje.</p>
<h3>Na seleção de campeões</h3>
<ul><li>A tela <a class='go' href='/jogo'>Partida ao vivo</a> troca sozinha para a seleção.</li>
<li><b>Banir</b>: sugere bans pelo seu histórico e pela rota.</li>
<li><b>Escolher</b>: sugere campeões do seu pool contra o oponente (e avisa quando um campeão te faz perder PDL).</li>
<li><b>Sua configuração</b>: runas, feitiços, itens iniciais e build dos melhores do servidor, ajustada contra a composição inimiga. Os botões <b>Importar</b> mandam runas e itens para o cliente.</li>
<li><b>Ver todas as opções</b>: abre a tela completa da build (núcleos runa + item, runas, sequências de itens, ordem de habilidades).</li>
<li><b>Runas sozinho</b>: quando você locka o campeão, o app grava a página dos melhores no cliente, coloca o conjunto de itens na loja e fala qual página montou. Se o oponente de rota pedir outra página, troca e avisa. Dá para desligar em Editar overlay &gt; Seleção de campeões.</li></ul>
<h3>Na tela de carregamento</h3>
<p>O app busca o elo, o winrate, a maestria e quem está de duo no time inimigo, e a voz fala o mais importante ("Seu oponente é especialista: jogue seguro até o 6").</p>
<h3>Durante a partida</h3>
<ul><li><b>Overlay</b>: o próximo item, as recargas do seu oponente e o balão com o que a voz fala.</li>
<li><b>Balão de aviso</b>: a frase que a voz fala aparece curta na tela por alguns segundos e some. O clique passa direto para o jogo.</li>
<li><b>Voz</b>: só o necessário, na hora certa:
<ul><li><b>Jungler</b>: "Cuidado, jungler deles perto" quando ele aparece perto da sua rota (longe, fica quieto), "bom momento pro Dragão" quando ele está do outro lado e "olha o minimapa" quando ele some.</li>
<li><b>Build</b>: "Já dá pra comprar Lorde Dominik" quando o ouro fecha o próximo item, e "seu próximo item precisa ser…" quando o time inimigo pede outro.</li>
<li><b>Seu campeão</b>: uma dica no começo, como usar a ult no nível 6, o erro comum na primeira morte e dicas novas aos 14 e 28 minutos (vale para todos os campeões).</li>
<li><b>Macro</b>: objetivo chegando, voltar para a base antes do objetivo, torre caída na sua rota, jungler deles morto, gente a mais ou a menos, ace, Barão, Ancião e inibidor.</li></ul></li>
<li><b>Página Partida ao vivo</b> (num segundo monitor): placar, sua build, ouro por rota e o que fazer agora.</li></ul>
<h3>Quando a partida acaba</h3>
<p>A voz faz um resumo de 20 segundos, o app baixa a partida da Riot e a IA analisa sozinha. Abra o pós-jogo em <a class='go' href='/partidas'>Partidas</a>: nota, linha do tempo, onde você morreu e o que treinar.</p>"""),
    ("overlay", "Overlay e atalhos no jogo", "O que aparece por cima do LoL e como ajustar.", """
<ol><li>Deixe o LoL em <b>Sem bordas (Borderless)</b>: Configurações do jogo &gt; Vídeo &gt; Modo de janela. Em Tela cheia o overlay não aparece.</li>
<li>Em <a class='go' href='/overlay'>Editar overlay</a>, clique em <b>Ligar overlay</b>. Ele liga sozinho nas próximas vezes.</li>
<li>Arraste a faixa, o painel e o balão na prévia para onde quiser. Os botões <b>Modo limpo</b> e <b>Tudo ligado</b> mudam o que aparece de uma vez.</li></ol>
<h3>Atalhos</h3>
<ul><li>Fale com o coach: "o Zed usou Flash". Ele conta o tempo e avisa quando o Flash voltar (só feitiços: a Riot não permite acompanhar a ultimate dos inimigos).</li>
<li><kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>A</kbd> ou o botão de falar escolhido: pergunta por voz ao coach.</li>
<li><kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>O</kbd>: mostra ou esconde tudo.</li>
<li><kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>M</kbd>: modo de ajuste dentro do jogo (arraste as caixas; a roda do mouse muda o tamanho do minimapa). Aperte de novo para prender.</li>
<li><kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>J</kbd> com o mouse num acampamento do minimapa: começa o timer dele.</li></ul>"""),
    ("voz", "Falar com o coach no jogo", "Perguntas e marcações por voz, sem tirar a mão do mouse.", """
<ol><li>Em <a class='go' href='/overlay'>Editar overlay &gt; Falar com o coach</a>, escolha o <b>botão de falar</b> (ex.: botão do meio do mouse) e o <b>microfone</b>.</li>
<li>Clique em <b>Testar microfone</b> e fale algo: tem que aparecer "Funcionou".</li>
<li>No jogo: <b>clique</b> no botão, fale e clique de novo (ou <b>segure</b>, fale e solte).</li></ol>
<h3>O que dá para falar</h3>
<ul><li>Perguntas: "o que eu compro agora?", "o que maximizar na Vex?", "como jogo contra esse Yasuo?".</li>
<li>Marcações: "Zed usou flash", "o mid sem ult", "Sett queimou ignite": o app conta o tempo e avisa quando volta.</li></ul>
<div class='gd-tip'>Se aparecer "não chegou som do microfone", troque o microfone na lista ou libere em Configurações do Windows &gt; Privacidade &gt; Microfone &gt; "Permitir que apps da área de trabalho acessem o microfone".</div>"""),
    ("paginas", "As páginas do app", "Onde está cada coisa.", """
<h3>Jogar</h3>
<ul><li><b>Início</b>: missão do dia, o que mais pesa nas suas derrotas e as últimas partidas.</li>
<li><b>Partida ao vivo</b>: seleção, carregamento, partida e pós-jogo numa tela só; também a voz dos avisos.</li>
<li><b>Editar overlay</b>: o que aparece no jogo, posição, botão de falar e microfone.</li>
<li><b>Coach IA</b>: converse sobre o seu jogo; ele olha as suas partidas antes de responder.</li></ul>
<h3>Meu desempenho</h3>
<ul><li><b>Visão geral</b>: elo, campeões (onde você perde PDL), lado do mapa, horários, tilt, recordes e duos.</li>
<li><b>Resumo do dia</b>: quantas ganhou e perdeu, PDL do dia e os maiores erros.</li>
<li><b>Gráficos</b>: calendário, sessões, PDL por campeão, horários, você contra o seu elo e os primeiros 15 minutos.</li>
<li><b>Partidas</b>, <b>Por campeão</b>, <b>Matchups</b>, <b>Diagnóstico e erros</b>, <b>Hábitos</b>, <b>PDL</b> (com zoom), <b>Calendário</b> e <b>Comparar</b>.</li></ul>
<h3>Guia do jogo</h3>
<ul><li><b>Campeões</b>: build, runas, combos, counters e os melhores jogadores de cada campeão.</li>
<li><b>Duelos</b>, <b>Tier list</b>, <b>Patch</b> (buffs e nerfs), <b>Rotas</b> (com o Modo caçador na Selva) e <b>Para iniciantes</b>.</li></ul>
<h3>Minha conta</h3>
<p>Perfil, seu main, conta do LoL, senha e Administração (chaves, usuários e fila de tarefas).</p>"""),
    ("iniciante", "Se você está começando no LoL", "O app ensina do zero.", """
<ol><li>Abra <a class='go' href='/iniciante'>Guia do jogo &gt; Para iniciantes</a> e responda as 8 perguntas.</li>
<li>O app escolhe as aulas do seu nível: mapa, rotas, farm, visão, objetivos e lutas.</li>
<li>Para iniciantes, a voz ensina durante a partida ("olhe o minimapa", "compre sentinela", "volte para a base com esse ouro").</li></ol>"""),
    ("problemas", "Problemas comuns", "Se algo não funcionar.", """
<div class='gd-faq'>
<details><summary>"Chave da Riot recusada" ou erro 401</summary><p>A chave venceu (24 h) ou foi colada com espaço. Gere outra em developer.riotgames.com e salve de novo em Administração.</p></details>
<details><summary>O overlay não aparece no jogo</summary><p>Coloque o LoL em <b>Sem bordas</b>. Confira se o overlay está ligado em Editar overlay e aperte <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>O</kbd> caso esteja escondido.</p></details>
<details><summary>A voz não fala</summary><p>Em Partida ao vivo, confira "falar os avisos" e use <b>Testar a voz pelo overlay</b>. A voz Microsoft grátis precisa de internet.</p></details>
<details><summary>O coach não responde às perguntas por voz</summary><p>Teste o microfone em Editar overlay. Se aparecer "limite grátis do Gemini", a cota do dia acabou; volta no dia seguinte.</p></details>
<details><summary>As partidas não aparecem</summary><p>O app sincroniza sozinho a cada 15 minutos e depois de cada partida. Para forçar, use <b>Sincronizar agora</b> no rodapé da barra lateral.</p></details>
<details><summary>O app não abre</summary><p>Use o atalho Carry. Se ainda assim não abrir, reinicie o PC ou reinstale por cima: os seus dados ficam.</p></details>
</div>"""),
    ("regras", "Regras da Riot e seus dados", "Leia uma vez.", """
<ul><li>O Carry usa só as portas oficiais da Riot (cliente e API da partida). Não lê a memória do jogo nem aperta teclas por você.</li>
<li><b>Atenção:</b> o aviso "jungler inimigo visto" lê o minimapa na tela, o que fica numa área cinzenta das regras de apps da Riot. Use por sua conta e risco; para desligar, vá em Editar overlay.</li>
<li>Seus dados, partidas e chaves ficam só no seu PC. Ao desinstalar, o app pergunta se você quer apagar tudo.</li></ul>"""),
]


def page_html():
    toc = "".join(f"<a href='#{k}'><i>{i}</i>{e(t)}</a>" for i, (k, t, _, _) in enumerate(SECS, 1))
    secs = "".join(f"<section class='gd-sec' id='{k}'><h2><i>{i}</i>{e(t)}</h2><p class='s'>{e(s)}</p>{body}</section>"
                   for i, (k, t, s, body) in enumerate(SECS, 1))
    hero = ("<p style='margin:0 0 10px'><a class='btn' style='width:auto' href='/?tour=1'>Ver o tour de 5 passos</a></p>"
            "<div class='gd-hero'><h2>Bem-vindo ao Carry</h2><p>O Carry é o seu coach de League of Legends: ele prepara a seleção de campeões, "
            "fala com você durante a partida, analisa cada jogo e mostra onde você ganha e onde perde PDL. Este guia mostra como usar tudo, passo a passo.</p></div>")
    return f"<style>{CSS}</style><div class='gd'><nav class='gd-toc' aria-label='Seções do guia'><b>Neste guia</b>{toc}</nav><div class='gd-main'>{hero}{secs}</div></div>"
