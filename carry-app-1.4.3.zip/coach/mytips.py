"""Dicas do SEU campeao durante a partida (vale para todos os campeoes).

Fonte: o guia do campeao por IA (rotas / meio / fim / erros comuns / picos), quando ja existe;
senao as dicas oficiais da Riot para quem joga com o campeao (Data Dragon, "allytips"), que existem para todos.

Quando fala (poucas vezes, nos momentos em que da para ouvir):
- logo no comeco (na base ou indo para a rota): 1 dica da fase de rotas;
- ao chegar no nivel 6: como usar a ultimate;
- primeira morte antes dos 14 min: o erro comum do campeao;
- aos 14 e aos 28 min: 1 dica da fase nova;
- morto com tempo de volta grande (15 s ou mais): mais uma dica da fase, no maximo a cada 3 min e meio.
"""
import os
import re
import time

_MEM = {}          # cid -> dicas
_ST = {}           # chave da partida -> estado


def _clean(t):
    from .ddragon import clean
    t = clean(t or "")
    t = re.sub(r"\s*\[(P|Q|W|E|R)\]", lambda m: f" ({m.group(1)})" if m.group(1) != "P" else "", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t if not t or t.endswith((".", "!", "?")) else t + "."


def short(t, n=150):
    """Primeira frase (o que cabe numa fala curta)."""
    t = _clean(t)
    m = re.match(r"(.+?[.!?])(\s|$)", t)
    s = m.group(1) if m else t
    if len(s) > n:
        cut = s[:n].rsplit(" ", 1)[0].rstrip(",;:")
        s = cut + "."
    return s


def tips_for(cid, ddir=None):
    """{"rotas": [...], "meio": [...], "fim": [...], "erros": [...], "r": "dica da ult" ou "", "name": nome, "rname": nome da ult}."""
    if not cid:
        return {}
    hit = _MEM.get(cid)
    if hit and (hit.get("_guide") or time.time() - hit.get("_at", 0) < 600):
        return hit
    out = {"rotas": [], "meio": [], "fim": [], "erros": [], "r": "", "name": cid, "rname": "", "_at": time.time(), "_guide": False}
    data = {}
    try:
        from .ddragon import DataDragon
        data = DataDragon(cache_dir=os.path.join(ddir, "cache") if ddir else "cache").champion(cid) or {}
    except Exception:
        data = {}
    out["name"] = data.get("name") or cid
    spells = data.get("spells") or []
    if len(spells) >= 4:
        out["rname"] = spells[3].get("name") or ""
    g = None
    if ddir:
        try:
            from . import guides
            g = guides.get(ddir, cid, None)
        except Exception:
            g = None
    if g:
        out["_guide"] = True
        out["rotas"] = [_clean(t) for t in g.get("rotas") or [] if t]
        out["meio"] = [_clean(t) for t in g.get("meio") or [] if t]
        out["fim"] = [_clean(t) for t in g.get("fim") or [] if t]
        out["erros"] = [_clean(t) for t in g.get("erros_comuns") or [] if t]
        for t in (g.get("rotas") or []) + (g.get("meio") or []) + [c.get("quando", "") for c in g.get("combos") or []]:
            if "[R]" in (t or ""):
                out["r"] = _clean(t)
                break
        if not out["r"]:
            for pk in g.get("picos") or []:
                if "6" in str(pk.get("quando") or ""):
                    out["r"] = _clean(pk.get("porque"))
                    break
    ally = [_clean(t) for t in data.get("allytips") or [] if t]
    if ally:                                   # oficiais: completam o que faltar (servem para qualquer fase)
        for ph in ("rotas", "meio", "fim"):
            if not out[ph]:
                out[ph] = list(ally)
        if not out["r"] and out["rname"]:
            low = out["rname"].lower()
            out["r"] = next((t for t in ally if low in t.lower()), "")
    if not out["r"] and out["rname"]:
        out["r"] = f"Sua ultimate, {out['rname']}, está pronta. Use quando o oponente gastar a fuga ou o Flash."
    if data or g:                 # sem a ficha ainda (baixa no aquecimento da partida): tenta de novo no proximo pedido
        _MEM[cid] = out
    return out


def _phase(gt):
    return "rotas" if gt < 840 else "meio" if gt < 1680 else "fim"


def live_cues(ddir, cid, me, gt, game_key):
    """Falas {"k","t","v"} para o overlay. me = jogador ativo (allPlayers)."""
    tp = tips_for(cid, ddir)
    if not tp:
        return []
    st = _ST.setdefault(game_key, {"used": {tp.get("r")}, "last_dead": -1e9, "deaths_seen": 0})
    if len(_ST) > 4:
        for k in list(_ST)[:-4]:
            _ST.pop(k, None)
    nm = tp["name"]
    al = []

    def add(k, t, prefix):
        if not t:
            return
        al.append({"k": f"mytip_{k}", "t": f"{prefix}: {t}", "v": f"{prefix}: {short(t)}"})

    def pick(ph):
        for t in tp.get(ph) or []:
            if t not in st["used"]:
                st["used"].add(t)
                return t
        return ""

    lvl = int(me.get("level") or 1)
    dead = bool(me.get("isDead"))
    resp = int(me.get("respawnTimer") or 0)
    deaths = int((me.get("scores") or {}).get("deaths") or 0)
    if 15 <= gt < 100 and not dead and "start" not in st:
        st["start"] = pick("rotas")
    if st.get("start") and gt < 130:
        add("start", st["start"], f"Dica de {nm}")
    if lvl >= 6 and tp.get("r"):
        if "r6" not in st:
            st["r6"] = gt
        if gt - st["r6"] < 60:
            add("r6", tp["r"], "Nível 6")
    if dead and deaths >= 1 and gt < 840 and "err" not in st and tp.get("erros"):
        st["err"] = (tp["erros"][0], gt)
    if st.get("err") and gt - st["err"][1] < 40:
        add("err", st["err"][0], f"Erro comum de {nm}")
    for ph, t0 in (("meio", 840), ("fim", 1680)):
        if t0 <= gt < t0 + 120 and ph not in st:
            st[ph] = (pick(ph), gt)
        if st.get(ph) and gt - st[ph][1] < 60:
            add(ph, st[ph][0], f"{nm} no {'meio' if ph == 'meio' else 'fim'} de jogo")
    if dead and resp >= 15 and deaths > st["deaths_seen"] and gt - st["last_dead"] >= 210:
        st["deaths_seen"] = deaths
        if not (st.get("err") and gt - st["err"][1] < 5):
            t = pick(_phase(gt))
            if t:
                st["last_dead"] = gt
                st["dead_tip"] = (t, gt, deaths)
    dt = st.get("dead_tip")
    if dt and gt - dt[1] < 30:
        add(f"d{dt[2]}", dt[0], f"Dica de {nm}")
    return al
