"""Voz de controle de onda, controle de mapa e leitura do caçador inimigo (regra geral + dados dos melhores).

O jogo nao mostra a posicao das ondas nem dos inimigos para apps; o que da para usar:
- os tempos fixos (ondas a cada 30 s desde 0:30, canhao a cada 3 ondas, acampamentos 0:55, caranguejos 2:55);
- o nivel e o farm do caçador inimigo (o placar mostra);
- como os MELHORES jogam com aquele caçador (inicio, onde estao aos 3 min, primeiro abate), das partidas guardadas pelo app.
"""
from . import gametimes as GT

MY_SIDE = {"TOP": "cima", "BOTTOM": "baixo", "UTILITY": "baixo"}


def _flip(label, team):
    """Rotulo do resumo (visto do lado do proprio cacador) -> lado real do mapa."""
    if not label:
        return label
    lab = (label.replace("seu lado de cima (Azul)", "selva dele, lado de cima")
                .replace("seu lado de baixo (Vermelho)", "selva dele, lado de baixo")
                .replace("selva inimiga", "invadindo a sua selva"))
    if team == "CHAOS":            # o resumo espelha o lado vermelho: desfaz
        lab = lab.replace("cima", "#").replace("baixo", "cima").replace("#", "baixo")
    return lab


def _side_of(label):
    return "cima" if "cima" in (label or "") else "baixo" if "baixo" in (label or "") else None


def enemy_jungle_read(con, live_data, me, foes, pos, gt):
    """No comeco: por onde o cacador inimigo deve comecar e aparecer (dados dos melhores com ele)."""
    from . import jungle, liveview
    al = []
    ejg = next((p for p in foes if (p.get("position") or "").upper() == "JUNGLE"), None)
    if not ejg or pos == "JUNGLE" or not (15 <= gt < 75):
        return al
    sm = jungle.summary_cached(liveview.champ_id(ejg))      # calculado em segundo plano (overlay.warm_game)
    if not sm or not sm.get("start"):
        return al
    team = ejg.get("team")
    start = sm["start"][0][0]
    start_side = ("cima" if start == "Azul" else "baixo") if team == "ORDER" else ("baixo" if start == "Azul" else "cima")
    pct = round(100 * sm["start"][0][1] / sm["n"])
    at3 = _flip(sm["at3"][0][0], team) if sm.get("at3") else None
    g_where = _flip(sm["gank_where"][0][0], team) if sm.get("gank_where") else None
    nm = ejg.get("championName") or "O caçador inimigo"
    txt = f"{nm} costuma começar no lado de {start_side} ({pct}% dos melhores)"
    if at3:
        txt += f" e aos 3 minutos está {'no' if at3.startswith(('rio', 'meio')) else 'na'} {at3}"
    txt += "."
    danger = _side_of(at3) or _side_of(g_where)
    mine = MY_SIDE.get(pos)
    if pos == "MIDDLE":
        txt += f" Entre 2:45 e 3:30, cuidado com o rio de {danger}." if danger else ""
    elif mine and danger == mine:
        txt += " Ele deve vir para o seu lado por volta dos 3 minutos: sentinela no rio e não estenda."
    elif mine and danger:
        txt += " O seu lado deve estar seguro no começo: pode jogar agressivo até uns 3:30."
    al.append({"k": "jgread_start", "t": txt})
    return al


def jungler_tempo(foes, pos, gt):
    """Nivel do cacador inimigo: 3 campos cedo = gank chegando; nivel 4 = terminou a volta."""
    al = []
    ejg = next((p for p in foes if (p.get("position") or "").upper() == "JUNGLE"), None)
    if not ejg or pos == "JUNGLE":
        return al
    lv = int(ejg.get("level") or 1)
    nm = ejg.get("championName") or "O caçador inimigo"
    if lv >= 3 and gt < 140:
        al.append({"k": "jgtempo_3", "t": f"{nm} já está nível 3: fez 3 acampamentos e pode gankar agora. Jogue perto da sua torre."})
    if lv >= 4 and gt < 230:
        al.append({"k": "jgtempo_4", "t": f"{nm} chegou ao nível 4: terminou a primeira volta. Ele vai gankar ou disputar o caranguejo."})
    return al


def wave_cues(me, pos, gt, gold, nxt=None):
    """Controle de onda pelos tempos fixos das ondas (ensina a hora certa de empurrar, congelar e voltar)."""
    al = []
    add = lambda k, t: al.append({"k": "wave_" + k, "t": t})
    if pos in ("JUNGLE",):
        return al
    if 50 <= gt < 70:
        add("lv2", "Nível 2 vem com a primeira onda inteira e mais 3 minions da segunda. Quem chegar antes troca de graça: bata nos minions agora.")
    if 115 <= gt < 125 and pos != "UTILITY":
        add("ward", "Coloque sentinela no rio agora: o caçador inimigo pode aparecer a partir de 2:15.")
    if pos == "UTILITY" and 115 <= gt < 125:
        add("ward_sup", "Sentinela no mato do rio de baixo agora: o caçador inimigo pode chegar a partir de 2:15.")
    # ondas: a n-esima nasce em 30 + 30*(n-1) s; canhao a cada 3 ondas na fase de rotas
    if 180 <= gt < 840:
        n = int((gt - GT.FIRST_WAVE) // 30) + 1
        for c in (3 * (n // 3), 3 * (n // 3) + 3):
            arrive = GT.FIRST_WAVE + 30 * (c - 1) + 28       # chega no meio uns 28 s depois de nascer
            if c >= 6 and c % 6 == 0 and 0 < arrive - gt <= 10 and gold >= 1300:      # no maximo a cada 3 min
                add(f"cannon_{c}", "Onda com canhão chegando: empurre ela inteira para a torre inimiga e volte para a base. "
                                           "Assim você não perde minions enquanto compra.")
    if pos == "UTILITY" and 360 <= gt < 380:
        add("lens", "Hora de trocar o amuleto pela Lente do Oráculo: limpar visão do inimigo antes dos objetivos ganha jogo.")
    return al


def freeze_hint(pos, d_items, gt):
    """Quando congelar a onda (atras ou com vantagem grande)."""
    if pos in ("JUNGLE", "UTILITY") or not (240 <= gt < 840):
        return []
    slot = int(gt // 240)
    if d_items <= -900:
        return [{"k": f"wave_freeze_bad_{slot}", "t": "Atrás na rota: deixe a onda vir para perto da sua torre e só dê o último golpe. "
                                                       "Empurrar agora te deixa exposto para gank."}]
    if d_items >= 1200:
        return [{"k": f"wave_freeze_good_{slot}", "t": "Com vantagem: segure a onda perto da sua torre (congelar) para o oponente ter que vir farmar perto de você."}]
    return []
