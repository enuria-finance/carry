"""Coach da selecao: quem banir, o que escolher e o que falta no time — com o motivo de cada sugestao.

Fontes: o SEU historico (dado, com n), o mapa de posicoes tirado das partidas salvas (para adivinhar o oponente
de rota, que a ranqueada esconde) e as classes/dano do Data Dragon (hipotese). Tudo e de ANTES da partida.
"""
from collections import Counter

PRIOR_N, PRIOR_WR = 8, 0.5   # suaviza winrate com poucos jogos (8 jogos "imaginarios" a 50%)


def smooth(w, n):
    return (w + PRIOR_WR * PRIOR_N) / (n + PRIOR_N)


_RM = {}


def _db_key(con):
    """Arquivo do banco (None para banco em memoria: nao guarda nada, o id da conexao pode repetir)."""
    try:
        return con.execute("PRAGMA database_list").fetchone()[2] or None
    except Exception:
        return None


def role_map(con):
    """{campeao: {posicao: fracao}} de todas as partidas salvas. Guardado por 15 min: varre o banco inteiro e a tela
    da selecao pedia isso varias vezes por segundo (era o que deixava a selecao e o overlay lentos)."""
    import time as _t
    k = _db_key(con)
    hit = _RM.get(k) if k else None
    if hit and _t.time() - hit[0] < 900:
        return hit[1]
    out = _role_map(con)
    try:
        from . import profile
        profile.ROLE_OF = out          # rota do campeao, para quando o cliente nao diz a sua
    except Exception:
        pass
    if k:
        _RM[k] = (_t.time(), out)
    return out


def _role_map(con):
    c = {}
    for ch, pos, n in con.execute(
            "SELECT champion, position, COUNT(*) FROM participants WHERE COALESCE(position,'')<>'' GROUP BY champion, position"):
        c.setdefault(ch, Counter())[pos] += n
    return {ch: {p: k / sum(cnt.values()) for p, k in cnt.items()} for ch, cnt in c.items()}


def enemy_laner(snap, position, roles):
    """Oponente de rota: posicao dada pelo cliente; senao, o inimigo que mais joga na sua posicao."""
    foes = [p for p in snap["enemy_team"] if p["champion"]]
    exact = next((p["champion"] for p in foes if p["position"] == position), None)
    if exact:
        return exact, False
    best = max(foes, key=lambda p: roles.get(p["champion"], {}).get(position, 0), default=None)
    if best and roles.get(best["champion"], {}).get(position, 0) >= 0.3:
        return best["champion"], True
    return None, False


def damage_type(info, tags):
    """'AP', 'AD' ou 'MIX' pelas notas de ataque/magia do Data Dragon."""
    a, m = (info or {}).get("attack", 0), (info or {}).get("magic", 0)
    if m >= a + 2:
        return "AP"
    if a >= m + 2:
        return "AD"
    return "AP" if "Mage" in tags else "AD" if "Marksman" in tags else "MIX"


def comp(snap, champs):
    """Perfil do seu time (sem voce) e do inimigo: dano AP/AD, frente (tanque/lutador)."""
    def prof(team, skip=None):
        out = {"AP": 0, "AD": 0, "MIX": 0, "front": 0, "n": 0, "names": []}
        for p in team:
            nm = p["champion"]
            if not nm or p is skip:
                continue
            c = champs.get(nm, {})
            out[damage_type(c.get("info"), c.get("tags", []))] += 1
            out["front"] += 1 if set(c.get("tags", [])) & {"Tank", "Fighter"} else 0
            out["n"] += 1
            out["names"].append(nm)
        return out
    return prof(snap["my_team"], snap["me"]), prof(snap["enemy_team"])


def _taken(snap):
    s = set(snap["my_bans"]) | set(snap["their_bans"])
    s |= {p["champion"] for p in snap["my_team"] + snap["enemy_team"] if p["champion"] and p is not snap["me"]}
    return s


def pool_for(saved, games, roles, position, size=4):
    """Pool que faz sentido NESTA rota: do seu pool salvo, so quem joga a rota; completa com os seus mais jogados nela."""
    played = {}
    for g in games:
        if g.get("position") in (None, "", position):
            played[g["champion"]] = played.get(g["champion"], 0) + 1
    fits = lambda ch: played.get(ch) or roles.get(ch, {}).get(position, 0) >= 0.25
    out = [c for c in (saved or []) if fits(c)]
    for ch, k in sorted(played.items(), key=lambda kv: -kv[1]):
        if len(out) >= max(size, len(out)):
            break
        if k >= 5 and ch not in out:          # 1 ou 2 jogos soltos nao fazem do campeao parte do seu pool
            out.append(ch)
    return out


def ban_ideas(games, snap, roles, position, limit=3):
    """Quem mais te venceu na rota (seu historico) e ainda esta livre."""
    taken = _taken(snap) if snap else set()
    opp = {}
    for g in games:
        if g.get("opp_champion"):
            opp.setdefault(g["opp_champion"], []).append(g["win"])
    out = []
    for name, ws in opp.items():
        n, w = len(ws), sum(ws)
        if n < 2 or name in taken:
            continue
        sw = smooth(w, n)
        if sw > 0.47:
            continue
        common = roles.get(name, {}).get(position, 0)
        out.append({"champion": name, "n": n, "w": w, "score": (0.5 - sw) * (0.6 + common),
                    "why": f"você venceu {w} de {n} contra ele", "kind": "dado"})
    out.sort(key=lambda x: -x["score"])
    return out[:limit]


def pick_ideas(games, pool, snap, laner, champs, limit=3, mu=None):
    """Pontua o seu pool: seu winrate com o campeao, contra o oponente provavel (seu e do alto elo) e o que o time precisa.
    mu: {campeao: (jogos, winrate%)} do confronto na amostra do alto elo."""
    taken = _taken(snap) if snap else set()
    mine_p, foe_p = comp(snap, champs) if snap else ({"AP": 0, "AD": 0, "MIX": 0, "front": 0, "n": 0}, {"front": 0, "n": 0, "names": []})
    need_ap = mine_p["n"] >= 2 and mine_p["AP"] == 0
    need_ad = mine_p["n"] >= 2 and mine_p["AD"] == 0
    need_front = mine_p["n"] >= 3 and mine_p["front"] == 0
    out = []
    for name in pool:
        if name in taken:
            continue
        gs = [g for g in games if g["champion"] == name]
        n, w = len(gs), sum(1 for g in gs if g["win"])
        score = smooth(w, n)
        why = [(f"{round(100 * w / n)}% em {n} jogo{'s' if n != 1 else ''} seus" if n else "sem jogos seus ainda", "dado")]
        if laner:
            vs = [g for g in gs if (g.get("opp_champion") or "").lower() == laner.lower()]
            if vs:
                vw = sum(1 for g in vs if g["win"])
                wv = min(0.45, 0.1 * len(vs))     # 1 jogo contra ele pesa pouco; 5+ jogos pesam bastante
                score = (1 - wv) * score + wv * smooth(vw, len(vs))
                why.append((f"contra {laner}: {vw}V {len(vs) - vw}D", "dado"))
            m_ = (mu or {}).get(name)
            if m_:                          # confronto no alto elo, encolhido para 50% (amostra pequena nao manda)
                shr = (m_[1] * m_[0] + 50 * 40) / (m_[0] + 40)
                score += (shr - 50) / 100 * 1.2
                why.insert(0, (f"{m_[1]}% contra {laner} no alto elo ({m_[0]} jogos)", "dado"))
        if n >= 20:      # experiencia com o campeao: quem joga muito com ele sobe mais rapido
            score += 0.04
            why.append((f"você tem experiência com ele ({n} jogos)", "regra"))
        elif n >= 8:
            score += 0.02
        elif n < 3:
            score -= 0.08
            why.append(("poucos jogos: o número ainda pode mudar muito", "regra"))
        c = champs.get(name, {})
        dt = damage_type(c.get("info"), c.get("tags", []))
        tags = set(c.get("tags", []))
        if need_ap and dt == "AP":
            score += 0.04
            why.append(("o time está sem dano mágico", "hipotese"))
        if need_ad and dt == "AD":
            score += 0.04
            why.append(("o time está sem dano físico", "hipotese"))
        if need_front and tags & {"Tank", "Fighter"}:
            score += 0.03
            why.append(("o time está sem linha de frente", "hipotese"))
        squishy = sum(1 for f in foe_p.get("names", []) if not set(champs.get(f, {}).get("tags", [])) & {"Tank", "Fighter"})
        if "Assassin" in tags and squishy >= 3:
            score += 0.02
            why.append((f"{squishy} alvos frágeis no time inimigo", "hipotese"))
        out.append({"champion": name, "score": score, "n": n, "why": why, "damage": dt})
    out.sort(key=lambda x: -x["score"])
    return out[:limit], out[-1] if len(out) > limit and out[-1]["score"] < 0.46 else None


def comp_notes(snap, champs):
    mine, foe = comp(snap, champs)
    notes = []
    if mine["n"] >= 2:
        if mine["AP"] == 0:
            notes.append(("Seu time ainda não tem dano mágico: se puder, escolha AP.", "regra"))
        elif mine["AD"] == 0:
            notes.append(("Seu time ainda não tem dano físico: se puder, escolha AD.", "regra"))
    if mine["n"] >= 3 and mine["front"] == 0:
        notes.append(("Ninguém da linha de frente no seu time (tanque ou lutador).", "hipotese"))
    if foe["n"] >= 3 and foe["front"] >= 3:
        notes.append(("O inimigo tem muita linha de frente: dano contínuo e itens de perfuração rendem mais.", "regra"))
    return notes, mine, foe
