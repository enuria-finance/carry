"""Decisao do meio e do fim de jogo, pela situacao da partida (o que o placar e os eventos do jogo mostram para todos).

Le: ouro em itens dos dois times, torres e inibidores derrubados, dragoes de cada lado (ponto de alma), Barao e Anciao ativos,
quem esta morto, quem esta muito forte e o proximo objetivo. Fala UMA decisao clara a cada ~75 s e na hora em que algo grande muda.
E regra geral de coach (nao enxerga o mapa): o app nao sabe onde os inimigos estao.
"""
from . import gametimes as GT

BUFF_BARON, BUFF_ELDER = 180, 150


def _val(p, items):
    tot = 0
    for it in p.get("items") or []:
        info = (items or {}).get(str(it.get("itemID"))) or {}
        tot += ((info.get("gold") or {}).get("total") or it.get("price") or 0) * max(1, int(it.get("count") or 1))
    return tot


def state(live_data, me, items, gt):
    from . import live
    players = live_data.get("allPlayers") or []
    mine_t = me.get("team")
    allies = [p for p in players if p.get("team") == mine_t]
    foes = [p for p in players if p.get("team") != mine_t]
    team_of = {live._name(p): p.get("team") for p in players}
    ev = (live_data.get("events") or {}).get("Events") or []
    s = {"tv": sum(_val(p, items) for p in allies) - sum(_val(p, items) for p in foes),
         "drag": {"us": 0, "them": 0}, "towers": {"us": 0, "them": 0}, "inhib_down": {"us": 0, "them": 0},
         "baron": None, "elder": None, "allies": allies, "foes": foes}
    for x in ev:
        nm, t = x.get("EventName"), x.get("EventTime") or 0
        side = "us" if team_of.get(x.get("KillerName")) == mine_t else "them"
        if nm == "DragonKill" and (x.get("DragonType") or "").lower() != "elder":
            s["drag"][side] += 1
        elif nm == "DragonKill":
            if gt - t < BUFF_ELDER:
                s["elder"] = (side, int(BUFF_ELDER - (gt - t)))
        elif nm == "BaronKill" and gt - t < BUFF_BARON:
            s["baron"] = (side, int(BUFF_BARON - (gt - t)))
        elif nm == "TurretKilled":
            tid = x.get("TurretKilled") or ""
            # Turret_T1_... = torre do time azul (ORDER); T2 = vermelho (CHAOS)
            owner = "ORDER" if "_T1_" in tid else "CHAOS" if "_T2_" in tid else None
            if owner:
                s["towers"]["them" if owner == mine_t else "us"] += 1      # torre do inimigo caida conta para nos
        elif nm == "InhibKilled":
            iid = x.get("InhibKilled") or ""
            owner = "ORDER" if "_T1_" in iid else "CHAOS" if "_T2_" in iid else None
            if owner and gt - t < GT.INHIB_RESPAWN:
                s["inhib_down"]["us" if owner == mine_t else "them"] += 1  # inibidor NOSSO caido = 'us'
    return s


def decide(live_data, me, pos, gt, items, tmr):
    """(chave, frase) ou None."""
    if gt < 840:
        return None
    s = state(live_data, me, items, gt)
    allies, foes = s["allies"], s["foes"]
    edead = [p for p in foes if p.get("isDead") and int(p.get("respawnTimer") or 0) >= 12]
    adead = [p for p in allies if p.get("isDead") and int(p.get("respawnTimer") or 0) >= 12]
    mmss = lambda v: f"{max(0, int(v)) // 60}:{max(0, int(v)) % 60:02d}"
    drag_at, baron_at = tmr.get("dragon"), tmr.get("baron")
    nxt = []
    if drag_at:
        nxt.append(("o dragão", drag_at, "rio de baixo"))
    if baron_at and gt >= GT.BARON_FIRST - 120:
        nxt.append(("o Barão", baron_at, "rio de cima"))
    if gt < GT.HERALD_GONE and gt >= GT.HERALD_AT - 60 and not tmr.get("hk"):
        nxt.append(("o Arauto", GT.HERALD_AT, "rio de cima"))
    nxt.sort(key=lambda o: o[1])
    up = [o for o in nxt if o[1] <= gt]
    soon = next((o for o in nxt if o[1] > gt), None)
    slot = int(gt // 75)

    # 1) Barao / Anciao ativos: muda tudo
    if s["baron"]:
        side, left = s["baron"]
        if side == "them":
            return (f"baronthem_{slot}", f"Inimigo com Barão por {left} segundos: defenda perto das torres, limpe as ondas de longe e não lute em campo aberto até acabar.")
        return (f"baronus_{slot}", f"Vocês têm Barão por {left} segundos: agrupem com a onda forte e empurrem uma rota para derrubar torre ou inibidor.")
    if s["elder"]:
        side, left = s["elder"]
        if side == "them":
            return (f"elderthem_{slot}", f"Inimigo com Ancião por {left} segundos: não lute, quem tomar dano baixo morre. Recuem e esperem acabar.")
        return (f"elderus_{slot}", f"Vocês têm Ancião por {left} segundos: forcem a luta agora, é a melhor chance de ganhar.")
    # 2) inibidor caido
    if s["inhib_down"]["us"]:
        return (f"inhibus_{slot}", "Seu inibidor está caído: os supertropas pressionam. Defenda a base e limpe as ondas antes de pensar em objetivo.")
    if s["inhib_down"]["them"]:
        return (f"inhibthem_{slot}", "Inibidor deles caído: deixem a onda de supertropas pressionar e joguem no lado oposto, "
                                     "no Barão ou em outra torre. Não entrem na base deles sem vantagem de número.")
    # 3) vantagem numerica
    if len(edead) >= 2 and len(edead) > len(adead):
        what = up[0][0] if up else ("o inibidor" if s["towers"]["us"] >= 5 else "uma torre")
        m = min(int(p.get("respawnTimer") or 0) for p in edead)
        return (f"num_{slot}", f"{len(edead)} inimigos mortos por {m} segundos: peguem {what} agora, sem perseguir ninguém.")
    if len(adead) >= 2 and len(adead) > len(edead):
        m = max(int(p.get("respawnTimer") or 0) for p in adead)
        return (f"numbad_{slot}", f"Vocês estão com {len(adead)} a menos por até {m} segundos: não lute, recue para as torres e entregue o objetivo se precisar.")
    # 4) ponto de alma
    for side in ("us", "them"):
        if s["drag"][side] == 3 and soon and soon[0] == "o dragão" and soon[1] - gt <= 90:
            who = "Vocês estão" if side == "us" else "O inimigo está"
            return (f"soul_{side}_{int(soon[1])}", f"{who} no ponto de alma. O próximo dragão em {mmss(soon[1] - gt)} decide: todos no rio de baixo 1 minuto antes, com visão e ondas empurradas.")
    # 5) alguem muito forte do outro lado
    fed = max(foes, key=lambda p: int((p.get("scores") or {}).get("kills") or 0) - int((p.get("scores") or {}).get("deaths") or 0), default=None)
    if fed:
        sc = fed.get("scores") or {}
        k, d = int(sc.get("kills") or 0), int(sc.get("deaths") or 0)
        if k - d >= 6 and slot % 3 == 0:
            return (f"fed_{slot}", f"{fed.get('championName')} está {k} e {d}: a luta gira em torno dele. Não entrem sem ele aparecer e guardem o controle para ele.")
    # 6) pelo ouro
    tv = s["tv"]
    obj = up[0] if up else soon
    objtxt = (f"{obj[0]} está vivo" if obj and obj[1] <= gt else f"{obj[0]} nasce em {mmss(obj[1] - gt)}") if obj else ""
    if tv >= 2500:
        tip = f"Vocês estão {tv // 100 / 10:.1f} mil na frente em itens: agrupem e forcem objetivo."
        if obj:
            tip += f" {objtxt[0].upper() + objtxt[1:]}: visão no {obj[2]} e ondas laterais empurradas antes."
        elif pos == "TOP":
            tip += " Ou empurre a rota de cima para puxar 2 inimigos."
        return (f"ahead_{slot}", tip)
    if tv <= -2500:
        tip = f"Vocês estão {(-tv) // 100 / 10:.1f} mil atrás em itens: jogue seguro e farme nas rotas perto da sua selva."
        if obj:
            tip += f" Se eles forem para {obj[0]}, troquem: peguem torre ou acampamentos do outro lado."
        return (f"behind_{slot}", tip)
    if obj and 0 < obj[1] - gt <= 90:
        return None            # objetivo em menos de 1 min e meio: o aviso com o que fazer vem do macrocues
    if obj:
        return (f"even_{slot}", f"Partida equilibrada. {objtxt[0].upper() + objtxt[1:]}: preparem visão no {obj[2]} um minuto antes e cheguem primeiro.")
    return (f"even2_{slot}", "Partida equilibrada: empurrem as rotas laterais e só lutem com vantagem de número.")


# ---------------- agrupar x farmar (pelo que o placar e os abates mostram) ----------------
_CS = {}          # chave da partida -> [(tempo de jogo, farm)]
CSPM_GOAL = {"TOP": 6.5, "MIDDLE": 7.0, "BOTTOM": 7.0, "JUNGLE": 5.5, "UTILITY": 0}


def _fights(live_data, gt, window=180):
    """Lutas recentes: 2+ abates em ate 15 s. [{t, names}] com todos que mataram, ajudaram ou morreram."""
    ev = [x for x in ((live_data.get("events") or {}).get("Events") or []) if x.get("EventName") == "ChampionKill"
          and gt - (x.get("EventTime") or 0) <= window]
    out, cur = [], None
    for x in sorted(ev, key=lambda x: x.get("EventTime") or 0):
        t = x.get("EventTime") or 0
        names = {x.get("KillerName"), x.get("VictimName")} | set(x.get("Assisters") or [])
        if cur and t - cur["last"] <= 15:
            cur["n"] += 1
            cur["names"] |= names
            cur["last"] = t
        else:
            cur = {"t": t, "last": t, "n": 1, "names": names}
            out.append(cur)
    return [f for f in out if f["n"] >= 2]


def tempo_cues(live_data, me, pos, gt, tmr):
    """'Junte com o time' quando voce fica fora das lutas; 'vá farmar no lado' quando esta atras de farm/nivel e nao ha objetivo."""
    from . import live
    if gt < 840 or pos == "UTILITY":
        return []
    gk = "|".join(sorted((p.get("championName") or "") for p in live_data.get("allPlayers") or []))
    sc = me.get("scores") or {}
    cs = int(sc.get("creepScore") or 0)
    hist = _CS.setdefault(gk, [])
    if not hist or gt - hist[-1][0] >= 10:
        hist.append((gt, cs))
        del hist[:-40]
    if len(_CS) > 5:
        for k in list(_CS)[:-5]:
            _CS.pop(k, None)
    ago = next((c for t, c in hist if gt - t <= 130), cs)
    cs_recent = cs - ago
    me_name = live._name(me)
    players = live_data.get("allPlayers") or []
    allies = [p for p in players if p.get("team") == me.get("team")]
    team_k = sum(int((p.get("scores") or {}).get("kills") or 0) for p in allies)
    kp = (int(sc.get("kills") or 0) + int(sc.get("assists") or 0)) / team_k if team_k else 1
    fights = _fights(live_data, gt)
    missed = [f for f in fights if me_name not in f["names"]]
    nxt = [at for at in (tmr.get("dragon"), tmr.get("baron") if gt >= GT.BARON_FIRST - 120 else None) if at]
    obj_soon = any(0 < at - gt <= 90 or at <= gt for at in nxt)
    lvl = int(me.get("level") or 1)
    avg_lvl = sum(int(p.get("level") or 1) for p in allies) / max(1, len(allies))
    cspm = cs / (gt / 60) if gt else 0
    slot = int(gt // 90)
    al = []
    # 1) ficou fora das lutas
    if len(missed) >= 2 or (missed and kp < 0.3 and team_k >= 8):
        if obj_soon:
            al.append({"k": f"macro_group_{slot}", "t": "Você ficou de fora das últimas lutas e tem objetivo chegando: pare de farmar no lado e junte com o time agora."})
        else:
            al.append({"k": f"macro_group_{slot}", "t": "Você ficou de fora das últimas lutas. Termine a onda do lado e junte com o time para a próxima luta."})
    # 2) atras de farm/nivel, sem objetivo: farme no lado
    elif not obj_soon and not fights and (lvl <= avg_lvl - 1.5 or (CSPM_GOAL.get(pos) and cspm < CSPM_GOAL[pos] - 1.2)) and pos != "JUNGLE":
        al.append({"k": f"macro_farm_{slot}", "t": f"Você está atrás em {'nível' if lvl <= avg_lvl - 1.5 else 'farm'} ({lvl} contra média {avg_lvl:.0f} do time). "
                                                   "Sem objetivo agora: fique numa rota lateral pegando ondas e XP, com visão, e junte só para o próximo objetivo."})
    elif not obj_soon and not fights and pos == "JUNGLE" and cspm < CSPM_GOAL["JUNGLE"] - 1:
        al.append({"k": f"macro_farm_{slot}", "t": "Seu farm de selva está baixo: limpe os acampamentos do seu lado antes de gankar de novo."})
    # 3) parado sem farmar (grupado sem fazer nada)
    elif not obj_soon and not fights and cs_recent < 5 and len(hist) >= 12 and pos in ("BOTTOM", "MIDDLE", "TOP"):
        al.append({"k": f"macro_idle_{slot}", "t": "Faz 2 minutos que você quase não farma. Sem objetivo agora: pegue as ondas das rotas laterais e volte para o time 1 minuto antes do próximo objetivo."})
    return al
