"""Tarefas em segundo plano (sincronizar, amostra do topo, testar chave) numa FILA unica.

Com varios usuarios e uma chave so (a do admin), as chamadas a Riot precisam ir uma de cada vez:
cada pessoa ve a propria tarefa e a posicao dela na fila.
"""
import itertools
import os
import threading
import time

from . import accounts, db, profile, userdata
from .riot import RiotClient, RiotError
from .sync import sync_player

KEEP_DONE = 200


class JobQueue:
    def __init__(self):
        self._lock = threading.Lock()
        self._cv = threading.Condition(self._lock)
        self._jobs = []
        self._ids = itertools.count(1)
        self._worker = None

    def _ensure_worker(self):
        if not self._worker or not self._worker.is_alive():
            self._worker = threading.Thread(target=self._loop, daemon=True)
            self._worker.start()

    def submit(self, uid, name, fn):
        """Coloca na fila. Devolve False se a pessoa ja tem essa tarefa esperando ou rodando."""
        with self._cv:
            for j in self._jobs:
                if j["uid"] == uid and j["state"] in ("queued", "running") and (j["name"] == name or name == "auto"):
                    return False
            self._jobs.append({"id": next(self._ids), "uid": uid, "name": name, "fn": fn, "state": "queued",
                               "log": [], "error": None, "created_ms": int(time.time() * 1000), "finished_ms": None})
            done = [j for j in self._jobs if j["state"] in ("done", "error")]
            for j in done[:-KEEP_DONE]:
                self._jobs.remove(j)
            self._ensure_worker()
            self._cv.notify()
            return True

    def _loop(self):
        while True:
            with self._cv:
                job = self._next()
                while job is None:
                    self._cv.wait(30)
                    job = self._next()
                job["state"] = "running"

            def log(text, job=job):
                with self._lock:
                    job["log"].append(str(text))
                    del job["log"][:-40]
            try:
                job["fn"](log)
                state, err = "done", None
            except RiotError as ex:
                state, err = "error", str(ex)
            except Exception as ex:  # rede, disco, formato novo
                state, err = "error", f"{type(ex).__name__}: {ex}"
            with self._lock:
                job["state"], job["error"] = state, err
                job["finished_ms"] = int(time.time() * 1000)
                job["fn"] = None

    def _next(self):
        """Tarefas das pessoas primeiro; a base geral (segundo plano) so quando ninguem esta esperando."""
        q = [j for j in self._jobs if j["state"] == "queued"]
        return next((j for j in q if j["name"] != "geral"), None) or (q[0] if q else None)

    def user_waiting(self):
        with self._lock:
            return any(j["state"] == "queued" and j["name"] != "geral" for j in self._jobs)

    def only_background(self):
        """Nada da pessoa rodando ou na fila (a coleta geral pode parar no meio sem problema)."""
        with self._lock:
            return not any(j["state"] in ("queued", "running") and j["name"] != "geral" for j in self._jobs)

    def idle(self):
        with self._lock:
            return not any(j["state"] in ("queued", "running") for j in self._jobs)

    def snapshot(self, uid):
        """Ultima tarefa desta pessoa, no formato que as telas usam (a automatica so aparece se der erro)."""
        with self._lock:
            mine = [j for j in self._jobs if j["uid"] == uid and (j["name"] != "auto" or j["state"] == "error")]
            if not mine:
                return {"name": None, "running": False, "queued": False, "pos": 0, "log": [], "error": None, "finished_ms": None}
            active = [j for j in mine if j["state"] in ("queued", "running")]
            j = active[0] if active else mine[-1]
            pos = 0
            if j["state"] == "queued":
                queue = [x for x in self._jobs if x["state"] == "queued"]
                pos = queue.index(j) + 1 + (1 if any(x["state"] == "running" for x in self._jobs) else 0)
            log = list(j["log"])
            if j["state"] == "queued":
                log = [f"Na fila: posição {pos}. Começa sozinho, pode sair da tela."]
            return {"name": j["name"], "running": j["state"] in ("queued", "running"), "queued": j["state"] == "queued",
                    "pos": pos, "log": log, "error": j["error"], "finished_ms": j["finished_ms"]}

    def clear_last(self, uid):
        """Apaga as tarefas ja terminadas com erro desta pessoa (ex.: teste com a chave velha), para o aviso nao ficar na tela."""
        with self._lock:
            self._jobs = [j for j in self._jobs if not (j["uid"] == uid and j["state"] == "error")]

    def overview(self):
        with self._lock:
            out = []
            for j in self._jobs[-40:]:
                d = {k: j[k] for k in ("id", "uid", "name", "state", "error", "created_ms", "finished_ms")}
                d["last"] = (j["log"] or [""])[-1]
                out.append(d)
            return out


MANAGER = JobQueue()


# ---- o que cada tarefa faz ------------------------------------------------
def client_for(key, region):
    if not key:
        raise RiotError("O administrador ainda não configurou a chave da Riot.")
    return RiotClient(key, region=region or "br1")


def save_mastery(con, client, puuid):
    con.execute("CREATE TABLE IF NOT EXISTS mastery_me (champion_id INTEGER PRIMARY KEY, level INTEGER, points INTEGER, last_play_ms INTEGER)")
    rows = client.mastery_all(puuid) or []
    for m in rows:
        con.execute("INSERT OR REPLACE INTO mastery_me VALUES (?,?,?,?)",
                    (m.get("championId"), m.get("championLevel"), m.get("championPoints"), m.get("lastPlayTime")))
    con.commit()
    return rows


def player_stats(con, puuid):
    """Resumo do jogador tirado dos jogos dele: campeao/posicao principais, pool, jogos e winrate."""
    pos, champ = profile.compute(con, puuid)
    rows = con.execute(
        """SELECT p.champion, p.win FROM participants p JOIN matches m USING(match_id)
           WHERE p.puuid=? AND COALESCE(m.duration_s,0)>=300""", (puuid,)).fetchall()
    by = {}
    for c, w in rows:
        by.setdefault(c, []).append(w)
    pool = [c for c, _ in sorted(by.items(), key=lambda kv: -len(kv[1]))[:5]]
    n = len(rows)
    wr = round(100 * sum(1 for _, w in rows if w) / n, 1) if n else None
    return {"main_champ": champ, "main_role": pos if n else None, "pool": ",".join(pool), "games": n, "winrate": wr}


def refresh_profile(acc, uid, client, con, puuid, log=None):
    """Atualiza nivel, icone, elo e o resumo dos jogos no cadastro do usuario."""
    stats = player_stats(con, puuid)
    try:
        s = client.summoner_by_puuid(puuid) or {}
        stats.update(icon=s.get("profileIconId"), level=s.get("summonerLevel"))
    except RiotError as ex:
        log and log(f"Perfil não atualizado: {ex}")
    try:
        solo = next((x for x in client.league_by_puuid(puuid) if x.get("queueType") == "RANKED_SOLO_5x5"), None)
        if solo:
            stats.update(tier=solo.get("tier"), division=solo.get("rank"), lp=solo.get("leaguePoints"),
                         wins=solo.get("wins"), losses=solo.get("losses"))
            from . import ranks
            ranks.record(con, solo.get("tier"), solo.get("rank"), solo.get("leaguePoints"), solo.get("wins"), solo.get("losses"))
        else:
            stats.update(tier="UNRANKED", division=None, lp=None)
    except RiotError as ex:
        log and log(f"Elo não atualizado: {ex}")
    try:
        a = client.account_by_puuid(puuid) or {}
        if a.get("gameName"):
            stats["riot_id"] = f"{a['gameName']}#{a.get('tagLine', '')}"
    except RiotError:
        pass
    try:          # main escolhido pela pessoa vale mais que o calculado
        mf, rf = accounts.pref(acc, uid, "main_fixo"), accounts.pref(acc, uid, "role_fixo")
        if mf:
            stats["main_champ"] = mf
        if rf:
            stats["main_role"] = rf
    except Exception:
        pass
    accounts.update_link_stats(acc, uid, **stats)


def run_sync(ddir, user_db, key, region, uid, puuid, count, log):
    client = client_for(key, region)
    con = db.connect(user_db)
    acc = accounts.connect(ddir)
    try:
        n = sync_player(client, con, puuid, count=count, queue=420, log=log)
        try:
            save_mastery(con, client, puuid)
        except RiotError as ex:
            log(f"Maestria não atualizada: {ex}")
        refresh_profile(acc, uid, client, con, puuid, log)
        from . import missions
        note = missions.sync_note(con, puuid)
        if note:
            log(note)
        log(f"Pronto: {n} partidas novas." + (" " + note if note and n else ""))
    finally:
        con.close()
        acc.close()


def run_sync_year(ddir, user_db, key, region, uid, puuid, log):
    """Todas as ranqueadas do ano (sem a linha do tempo nas mais antigas, para ser rapido). Serve para o historico de PDL."""
    import time as _t
    client = client_for(key, region)
    con = db.connect(user_db)
    try:
        y0 = _t.mktime((_t.localtime().tm_year, 1, 1, 0, 0, 0, 0, 0, -1))
        ids, start = [], 0
        while True:
            page = client.match_ids(puuid, count=100, start=start, queue=420, start_time=y0)
            ids += page
            log(f"{len(ids)} ranqueadas encontradas no ano...")
            if len(page) < 100 or start > 1500:
                break
            start += 100
        known = db.known_match_ids(con)
        new = [m for m in ids if m not in known]
        log(f"{len(new)} novas para baixar.")
        for i, mid in enumerate(new, 1):
            if MANAGER.user_waiting() and i % 20 == 0:
                log("Pausa curta: outra tarefa sua está na fila.")
            m = client.match(mid)
            if m:
                tl = client.timeline(mid) if i <= 30 else None
                db.save_match(con, m, tl)
            if i % 10 == 0 or i == len(new):
                log(f"  [{i}/{len(new)}] baixadas")
        log(f"Pronto: {len(new)} partidas do ano adicionadas.")
    finally:
        con.close()


def run_top(ddir, user_db, key, region, champion, games, log, puuid=None):
    from . import top
    from .ddragon import DataDragon
    champs = DataDragon(cache_dir=os.path.join(ddir, "cache")).champions()
    by_lower = {k.lower(): k for k in champs}
    name = by_lower.get((champion or "").strip().lower())
    if not name:
        raise RiotError("Campeão não encontrado (use o nome em inglês, ex.: Zed, Ahri, MonkeyKing).")
    ucon = db.connect(user_db)
    try:
        pos = profile.compute(ucon, puuid)[0] if puuid else "MIDDLE"
    finally:
        ucon.close()
    tcon = db.connect(userdata.top_path(ddir))
    try:
        top.sample(client_for(key, region), tcon, name, champs[name]["key"], position=pos,
                   target_games=games, max_players=300, log=log)
    finally:
        tcon.close()
    ucon = db.connect(user_db)
    try:
        userdata.import_top(ddir, ucon)
    finally:
        ucon.close()


def run_key_watch(key, region, log, tries=8, gap=30):
    """Chave recem-gerada as vezes demora 1 a 3 minutos para a Riot aceitar: testa de novo sozinho por ate 4 minutos."""
    from .riot import quick_test
    for i in range(tries):
        ok, code, msg = quick_test(key, region)
        if ok:
            log("Chave funcionando: a Riot aceitou a chave nova.")
            return
        log(f"Tentativa {i + 1}: a Riot ainda recusa (código {code}{': ' + msg if msg else ''}). Testando de novo em {gap} s…")
        time.sleep(gap)
    raise RiotError("A Riot continua recusando esta chave depois de 4 minutos. Gere outra em developer.riotgames.com "
                    "(botão Regenerate API Key), clique em Copy e cole de novo.")


def run_test(key, region, log):
    client = client_for(key, region)
    data = client._get("/lol/status/v4/platform-data", host=client.platform_host)
    if data is None:
        raise RiotError("A Riot não respondeu ao teste.")
    log("Chave funcionando: a Riot respondeu.")


ACTIVE = {"t": 0.0}       # ultima pagina aberta pelo usuario (o app fica leve enquanto ele navega)


def busy_user(window=45):
    return time.time() - ACTIVE["t"] < window


def in_game():
    """True durante uma partida (a API da partida ao vivo do jogo responde na porta 2999). Em partida o app nao faz
    trabalho pesado em segundo plano: era isso que travava o overlay (o banco ficava ocupado e a resposta passava de 6 s)."""
    import socket
    try:
        with socket.create_connection(("127.0.0.1", 2999), timeout=0.3):
            return True
    except OSError:
        return False


def auto_sync_loop(ddir, cfg, stop, every_s=900, first_s=20):
    """Enquanto o servidor esta no ar, sincroniza quem usou o app nos ultimos 14 dias (fila unica)."""
    stop.wait(first_s)
    while not stop.is_set():
        try:
            key = cfg.riot_key()
            if key and not in_game():
                acc = accounts.connect(ddir)
                try:
                    links = accounts.verified_links(acc, active_days=14)
                    users = {r["user_id"]: accounts.get_user(acc, r["user_id"]) for r in links}
                finally:
                    acc.close()
                for l in links:
                    u = users.get(l["user_id"])
                    if not u:
                        continue
                    path, _ = userdata.user_db(ddir, u)
                    MANAGER.submit(l["user_id"], "auto", lambda log, l=l, path=path:
                                   run_sync(ddir, path, key, l["region"], l["user_id"], l["puuid"], 20, log))
        except Exception:
            pass
        stop.wait(every_s)


def run_general(ddir, key, region, log, max_new=30):
    """Um pedaco da base geral (uns 60 pedidos a Riot). Para no meio se alguem pedir algo."""
    from . import top
    tcon = db.connect(userdata.top_path(ddir))
    try:
        top.collect_general(client_for(key, region), tcon, max_new=max_new,
                            should_stop=lambda: MANAGER.user_waiting() or in_game() or busy_user(), log=log)
    finally:
        tcon.close()


def general_status(ddir):
    """(partidas de alto elo na base, campeoes cobertos com 10+ jogos)."""
    p = userdata.top_path(ddir)
    if not os.path.exists(p):
        return 0, 0
    try:
        c = db.connect(p)
    except Exception:
        return 0, 0
    try:
        n = c.execute("SELECT COUNT(*) FROM match_source WHERE source='top'").fetchone()[0]
        k = c.execute("""SELECT COUNT(*) FROM (SELECT p.champion FROM participants p JOIN match_source s USING(match_id)
                         WHERE s.source='top' GROUP BY p.champion HAVING COUNT(*)>=10)""").fetchone()[0]
        return n, k
    except Exception:
        return 0, 0
    finally:
        c.close()


def auto_collect_loop(ddir, cfg, stop, first_s=45, gap_s=15):
    """Enquanto o app esta aberto e a fila esta parada, vai montando a base geral de alto elo.
    Com a chave de desenvolvimento rende umas 1.500 partidas por hora (15 mil linhas de campeao)."""
    stop.wait(first_s)
    while not stop.is_set():
        try:
            key = cfg.riot_key()
            if key and MANAGER.idle() and not in_game() and not busy_user():
                acc = accounts.connect(ddir)
                try:
                    admin = acc.execute("SELECT r.region FROM users u JOIN riot_links r ON r.user_id=u.id WHERE u.role='admin' LIMIT 1").fetchone()
                finally:
                    acc.close()
                region = admin[0] if admin else cfg.region()
                MANAGER.submit(0, "geral", lambda log, key=key, region=region: run_general(ddir, key, region, log))
        except Exception:
            pass
        stop.wait(gap_s)


def run_tier(ddir, key, region, tier, position, games, log):
    from . import tiers
    tiers.sample(client_for(key, region), ddir, tier, position, region, target=games, log=log)


def run_top_many(ddir, user_db, key, region, champions, games, log, puuid=None):
    """Amostra do topo para varios campeoes (o seu pool), um depois do outro."""
    for i, ch in enumerate(champions, 1):
        log(f"[{i}/{len(champions)}] {ch}: começando…")
        try:
            run_top(ddir, user_db, key, region, ch, games, lambda t, ch=ch, i=i: log(f"[{i}/{len(champions)}] {ch}: {t}"), puuid)
        except RiotError as ex:
            log(f"[{i}/{len(champions)}] {ch}: pulado ({ex})")
    log(f"Pronto: amostra de {len(champions)} campeões atualizada.")


def run_experts(ddir, key, region, log, max_players=300):
    """Especialistas: maestria dos melhores do servidor (1 chamada por jogador) e o Riot ID atual de cada um."""
    from . import top
    client = client_for(key, region)
    con = db.connect(userdata.top_path(ddir))
    try:
        con.execute("CREATE TABLE IF NOT EXISTS top_mastery (puuid TEXT, champion_id INTEGER, points INTEGER, level INTEGER, fetched_ms INTEGER, PRIMARY KEY (puuid, champion_id))")
        con.execute("CREATE TABLE IF NOT EXISTS top_names (puuid TEXT PRIMARY KEY, riot_id TEXT, fetched_ms INTEGER)")
        players = top.collect_players(client, con, max_players, log)
        for i, puuid in enumerate(players, 1):
            try:
                ms = (client.mastery_all(puuid) or [])[:15]
                con.execute("DELETE FROM top_mastery WHERE puuid=?", (puuid,))
                for m in ms:
                    con.execute("INSERT OR REPLACE INTO top_mastery VALUES (?,?,?,?,?)",
                                (puuid, m.get("championId"), m.get("championPoints"), m.get("championLevel"), db.now_ms()))
                a = client.account_by_puuid(puuid) or {}
                if a.get("gameName"):
                    con.execute("INSERT OR REPLACE INTO top_names VALUES (?,?,?)", (puuid, f"{a['gameName']}#{a.get('tagLine', '')}", db.now_ms()))
                con.commit()
            except RiotError as ex:
                log(f"Jogador {i}: pulado ({ex})")
            if i % 10 == 0:
                log(f"Especialistas: {i}/{len(players)} jogadores lidos…")
        log(f"Pronto: {len(players)} jogadores do topo com maestria atualizada.")
    finally:
        con.close()


# ---- pos-jogo: assim que a partida acaba, busca ESSA partida na Riot (ela leva de 1 a varios minutos para liberar) ----
POSTGAME = {}   # match_id -> {"state": "buscando"|"pronto"|"desistiu"|"erro", "tries": n, "started": t, "msg": str}


def fetch_postgame(ddir, user_db, key, region, uid, puuid, match_id):
    """Thread propria (nao trava a fila): tenta a cada 20 s nos primeiros 5 min, depois a cada 60 s, ate 20 min."""
    st = POSTGAME.get(match_id)
    if st and st["state"] in ("buscando", "pronto"):
        return st
    st = POSTGAME[match_id] = {"state": "buscando", "tries": 0, "started": time.time(), "msg": ""}

    def go():
        try:
            client = client_for(key, region)
            while time.time() - st["started"] < 1200:
                st["tries"] += 1
                try:
                    m = client.match(match_id)
                except RiotError as ex:
                    m, st["msg"] = None, str(ex)
                if m:
                    tl = None
                    for _ in range(6):        # a timeline as vezes sai um pouco depois
                        try:
                            tl = client.timeline(match_id)
                        except RiotError:
                            tl = None
                        if tl:
                            break
                        time.sleep(15)
                    con = db.connect(user_db)
                    acc = accounts.connect(ddir)
                    try:
                        db.save_match(con, m, tl)
                        try:
                            refresh_profile(acc, uid, client, con, puuid)
                        except Exception:
                            pass
                        try:          # a IA ja analisa a partida sozinha (voce nao precisa responder nada)
                            from . import ai, analysis, config as _cfg
                            k_, m_ = ai.pick(_cfg.Config(os.path.join(ddir, "coach.sqlite")).load())
                            if k_ and not analysis.get(con, match_id):
                                analysis.generate(con, puuid, match_id, k_, m_)
                        except Exception as ex:
                            st["msg"] = f"análise automática: {ex}"
                    finally:
                        con.close()
                        acc.close()
                    st["state"] = "pronto"
                    return
                time.sleep(20 if time.time() - st["started"] < 300 else 60)
            st["state"] = "desistiu"
        except Exception as ex:
            st.update(state="erro", msg=str(ex)[:200])
    threading.Thread(target=go, daemon=True).start()
    return st
