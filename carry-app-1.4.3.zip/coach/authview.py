"""Telas de conta: entrar, criar conta, vincular a conta da Riot, Meu perfil, Minha conta e o painel do admin."""
import html

from . import premium
import time

from . import accounts, icons

e = lambda x: html.escape("" if x is None else str(x))

TIERS = ["IRON", "BRONZE", "SILVER", "GOLD", "PLATINUM", "EMERALD", "DIAMOND", "MASTER", "GRANDMASTER", "CHALLENGER"]
TIER_PT = {"IRON": "Ferro", "BRONZE": "Bronze", "SILVER": "Prata", "GOLD": "Ouro", "PLATINUM": "Platina", "EMERALD": "Esmeralda",
           "DIAMOND": "Diamante", "MASTER": "Mestre", "GRANDMASTER": "Grão-Mestre", "CHALLENGER": "Desafiante", "UNRANKED": "Sem elo"}
TIER_COLOR = {"IRON": "#8a7d78", "BRONZE": "#b5774a", "SILVER": "#a9bac6", "GOLD": "#e6b450", "PLATINUM": "#46c2b2",
              "EMERALD": "#34cf74", "DIAMOND": "#7d97ff", "MASTER": "#b968e0", "GRANDMASTER": "#ec5560", "CHALLENGER": "#f6d982",
              "UNRANKED": "#6D625C"}
ROLE_PT = {"TOP": "Topo", "JUNGLE": "Selva", "MIDDLE": "Meio", "BOTTOM": "Atirador", "UTILITY": "Suporte"}
SPLASHES = ["Zed", "Ahri", "Yasuo", "Jhin", "Kayn", "Akali", "LeeSin", "Viego", "Sylas", "Irelia"]
GOALS = ["", "Sair do Ferro", "Bronze", "Prata", "Ouro", "Platina", "Esmeralda", "Diamante", "Mestre+", "Só melhorar"]


def ago(ms):
    if not ms:
        return "nunca"
    d = time.time() - ms / 1000
    if d < 90:
        return "agora"
    if d < 3600:
        return f"há {int(d // 60)} min"
    if d < 86400:
        return f"há {int(d // 3600)} h"
    return f"há {int(d // 86400)} d"


def profile_icon(icon_id, size=64, cls=""):
    ver = icons.version()
    if icon_id is None or not ver:
        return f"<span class='picon ph {cls}' style='width:{size}px;height:{size}px'>?</span>"
    return (f"<img class='picon {cls}' src='{icons.CDN}/cdn/{e(ver)}/img/profileicon/{int(icon_id)}.png' width='{size}' height='{size}' "
            f"alt='Ícone {int(icon_id)}' loading='lazy'>")


def crest(tier, size=96):
    """Emblema oficial do elo (se ja baixado); senao, o brasao desenhado pelo app."""
    t = (tier or "UNRANKED").upper()
    from . import ranksimg
    if ranksimg.available(t):
        c = TIER_COLOR.get(t, TIER_COLOR["UNRANKED"])
        return (f"<img class='crest emb' src='/static/ranks/{t.lower()}.png' width='{round(size * 1.25)}' height='{round(size * 1.25)}' "
                f"alt='{e(TIER_PT.get(t, t))}' style='--tc:{c};object-fit:contain'>")
    c = TIER_COLOR.get(t, TIER_COLOR["UNRANKED"])
    lvl = TIERS.index(t) if t in TIERS else -1
    gems = "".join(f"<circle cx='{50 + (i - (min(lvl, 4)) / 2) * 9:.1f}' cy='86' r='2.6' fill='{c}'/>" for i in range(min(lvl, 4) + 1)) if lvl >= 0 else ""
    wings = ("<path d='M18 40 L4 30 L10 52 Z M82 40 L96 30 L90 52 Z' fill='{c}' opacity='.75'/>".format(c=c)) if lvl >= 7 else ""
    return (f"<svg class='crest' width='{size}' height='{size}' viewBox='0 0 100 100' style='--tc:{c}'>"
            f"<defs><linearGradient id='cg{t}' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='{c}'/><stop offset='1' stop-color='#141922'/></linearGradient></defs>"
            f"{wings}<path class='cr-out' d='M50 6 L84 20 L80 62 L50 92 L20 62 L16 20 Z' fill='url(#cg{t})' stroke='{c}' stroke-width='2'/>"
            f"<path d='M50 18 L72 27 L69 58 L50 78 L31 58 L28 27 Z' fill='#150F0F' stroke='{c}' stroke-opacity='.6'/>"
            f"<path class='cr-gem' d='M50 32 L60 46 L50 64 L40 46 Z' fill='{c}'/>{gems}</svg>")


def rank_text(l):
    if not l or not l["tier"]:
        return "Elo ainda não lido"
    t = l["tier"]
    if t == "UNRANKED":
        return "Sem elo no solo/duo"
    div = "" if t in ("MASTER", "GRANDMASTER", "CHALLENGER") else f" {l['division'] or ''}"
    return f"{TIER_PT.get(t, t)}{div} · {l['lp'] or 0} PDL"


CSS = """
/* ---------- telas de conta ---------- */
.auth{min-height:100vh;display:grid;grid-template-columns:minmax(0,1.1fr) minmax(380px,520px);background:#090c11}
.auth-art{position:relative;overflow:hidden}
.auth-art .sp{position:absolute;inset:0;background-size:cover;background-position:center 20%;animation:kb 30s ease-in-out infinite alternate;opacity:.9}
.auth-art::after{content:"";position:absolute;inset:0;background:linear-gradient(90deg,rgba(16,11,11,.2),rgba(16,11,11,.55) 70%,#090c11),linear-gradient(0deg,rgba(16,11,11,.9),transparent 45%)}
.auth-copy{position:absolute;left:48px;bottom:48px;right:48px;z-index:2;max-width:560px}
.auth-copy .bn-k{margin-bottom:12px}
.auth-copy .auth-h{font:700 clamp(30px,3.4vw,48px)/1.06 var(--head);color:#fff;letter-spacing:-.02em;text-transform:none;margin:0 0 14px}
.auth-copy p{color:#c6cfe0;font-size:16px;max-width:46ch}
.auth-feats{display:flex;flex-wrap:wrap;gap:8px;margin-top:18px}
.auth-feats span{padding:7px 12px;border:1px solid rgba(255,255,255,.14);border-radius:999px;background:rgba(16,11,11,.55);backdrop-filter:blur(6px);font:600 12px var(--head);letter-spacing:.06em;color:#dfe6f5}
.auth-side{display:flex;align-items:center;justify-content:center;padding:40px 32px;position:relative}
.auth-box{width:100%;max-width:420px;position:relative}
.auth-box .brand{margin:0 0 4px;font-size:28px}
.auth-box .tagl{color:#c9c3b8;font:500 15px var(--body);letter-spacing:0;margin:2px 0 28px}
.auth-box h3{font:700 22px var(--head);margin:0 0 6px;color:#fff}
.auth-box .sub{color:var(--mute);margin:0 0 22px}
.fld{display:flex;flex-direction:column;gap:6px;margin:0 0 14px}
.fld label{font:600 11.5px var(--mono);letter-spacing:.1em;text-transform:uppercase;color:#aab4cc}
.fld small{color:var(--mute);font-size:12.5px}
.auth input:not([type=checkbox]):not([type=hidden]),.fld input,.fld select,input[type=email],input:not([type]){width:100%;padding:12px 14px;border-radius:10px;border:1px solid var(--rule);background:#0f141b;color:var(--ink);font:15px var(--body);transition:border-color .2s,box-shadow .2s}
.fld input:focus,.fld select:focus{outline:0;border-color:var(--purple);box-shadow:0 0 0 3px rgba(59,158,255,.18)}
.fld2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.chk{display:flex;gap:10px;align-items:flex-start;font-size:13.5px;color:#c3cbe0;margin:6px 0 18px}
.chk input{margin-top:3px;accent-color:var(--purple)}
.wide{width:100%;padding:13px 18px;font:700 14px var(--head);letter-spacing:.08em;text-transform:uppercase}
.alt{margin-top:18px;color:var(--mute);font-size:14px;text-align:center}
.alert{display:block;padding:12px 14px;border-radius:10px;margin:0 0 16px;font-size:14px;border:1px solid}
.alert.err{border-color:rgba(255,122,133,.45);background:rgba(255,122,133,.08);color:#ffc2c8}
.alert.ok{border-color:rgba(94,224,192,.45);background:rgba(94,224,192,.08);color:#b9f3e3}
.alert.info{border-color:rgba(59,158,255,.45);background:rgba(59,158,255,.08);color:#cfe5ff}
@media (max-width:900px){.auth{grid-template-columns:1fr}.auth-side{order:-1;padding:28px 16px}.auth-art{min-height:0}.auth-art .sp{opacity:.35}.auth-copy{position:relative;left:auto;right:auto;bottom:auto;padding:28px 16px 36px}.auth-copy .auth-h{font-size:26px}}

/* ---------- perfil ---------- */
.picon{border-radius:50%;object-fit:cover;display:inline-flex;align-items:center;justify-content:center;background:#1a2030;color:var(--mute);font:700 14px var(--head)}
.phero2{position:relative;overflow:hidden;border:1px solid var(--rule);border-radius:18px;display:grid;grid-template-columns:auto minmax(0,1fr) auto;gap:28px;align-items:center;padding:30px 34px;background:#11161e;margin:0 0 22px}
.phero2 .sp{position:absolute;inset:0;background-size:cover;background-position:right 18%;opacity:.42;-webkit-mask-image:linear-gradient(90deg,transparent 25%,#000 85%);mask-image:linear-gradient(90deg,transparent 25%,#000 85%);animation:kb 24s ease-in-out infinite alternate}
.phero2>*{position:relative}
.avatar{position:relative;width:118px;height:118px}
.avatar .picon{width:118px;height:118px;border:3px solid var(--tc,#3b9eff);box-shadow:0 0 0 6px rgba(0,0,0,.35),0 0 34px var(--tc,#3b9eff)}
.avatar .lvl{position:absolute;left:50%;bottom:-10px;transform:translateX(-50%);padding:3px 10px;border-radius:999px;background:#0b0e13;border:1px solid var(--tc,#3b9eff);font:700 12px var(--mono);color:#fff}
.avatar::before{content:"";position:absolute;inset:-10px;border-radius:50%;border:1px dashed var(--tc,#3b9eff);opacity:.5;animation:spin 18s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.pname small{display:block;color:var(--gold);font:600 12px var(--mono);letter-spacing:.18em;text-transform:uppercase;margin-bottom:6px}
.pname b{display:block;font:700 clamp(28px,3.4vw,44px)/1.05 var(--head);color:#fff;letter-spacing:-.02em;text-shadow:0 2px 20px rgba(0,0,0,.6)}
.pname .tagline{color:var(--mute);font:600 16px var(--head)}
.badges{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}
.badge{display:inline-flex;align-items:center;gap:6px;padding:5px 11px;border-radius:999px;border:1px solid var(--rule);background:rgba(16,11,11,.6);font:600 12px var(--head);letter-spacing:.04em}
.badge.ver{border-color:rgba(94,224,192,.5);color:var(--win)}.badge.warn{border-color:rgba(233,196,106,.5);color:var(--gold)}
.badge.adm{border-color:rgba(233,196,106,.6);color:#1a1405;background:linear-gradient(135deg,#E9C46A,#b8923f)}
.rankbox{display:flex;align-items:center;gap:16px;padding:14px 18px;border-radius:14px;background:rgba(16,11,11,.66);border:1px solid rgba(255,255,255,.08);backdrop-filter:blur(6px)}
.rankbox .rt{display:flex;flex-direction:column}
.rankbox .rt b{font:700 22px var(--head);color:#fff}.rankbox .rt small{color:var(--mute);font:12px var(--mono)}
.crest{filter:drop-shadow(0 0 14px var(--tc));animation:float 5s ease-in-out infinite}
.crest .cr-gem{animation:glow 2.6s ease-in-out infinite}
@keyframes float{50%{transform:translateY(-4px)}}
@keyframes glow{50%{opacity:.55}}
.pgrid2{display:grid;grid-template-columns:minmax(0,1.2fr) minmax(0,1fr);gap:16px}
.maincard{position:relative;overflow:hidden;border-radius:16px;border:1px solid var(--rule);min-height:260px;display:flex;align-items:flex-end;padding:22px;background:#11161e}
.maincard .sp{position:absolute;inset:0;background-size:cover;background-position:center 15%;transition:transform .8s}
.maincard:hover .sp{transform:scale(1.05)}
.maincard::after{content:"";position:absolute;inset:0;background:linear-gradient(0deg,rgba(16,11,11,.95),rgba(16,11,11,.1) 65%)}
.maincard>div{position:relative;z-index:2}
.maincard small{color:var(--gold);font:600 11.5px var(--mono);letter-spacing:.18em;text-transform:uppercase}
.maincard b{display:block;font:700 36px var(--head);color:#fff}
.poolrow{display:grid;grid-template-columns:repeat(auto-fill,minmax(178px,1fr));gap:10px}
.pchamp{display:flex;align-items:center;gap:10px;padding:10px 12px;border:1px solid var(--rule);border-radius:12px;background:var(--panel)}
.pchamp small{white-space:nowrap}.pchamp b{display:block;font:700 14px var(--head)}.pchamp small{color:var(--mute);font:12px var(--mono)}
.rolebars{display:flex;flex-direction:column;gap:10px}
.rb{display:grid;grid-template-columns:90px minmax(0,1fr) 48px;gap:10px;align-items:center;font:600 13px var(--head)}
.rb .tr{height:10px;border-radius:99px;background:#261C1B;overflow:hidden}
.rb .tr i{display:block;height:100%;border-radius:inherit;background:linear-gradient(90deg,#3b9eff,#8cc4ff);transform-origin:left;animation:grow 1.1s cubic-bezier(.2,.8,.2,1) both}
@keyframes grow{from{transform:scaleX(0)}}
.form10{display:flex;gap:6px;flex-wrap:wrap}
.form10 i{width:26px;height:26px;border-radius:7px;display:inline-flex;align-items:center;justify-content:center;font:700 11px var(--mono);font-style:normal}
.form10 i.v{background:rgba(94,224,192,.16);color:var(--win);border:1px solid rgba(94,224,192,.4)}
.form10 i.d{background:rgba(255,122,133,.12);color:var(--loss);border:1px solid rgba(255,122,133,.35)}
.mast{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:10px}
.mst{text-align:center;padding:14px 10px;border:1px solid var(--rule);border-radius:12px;background:var(--panel)}
.mst .cic{border-radius:50%;border:2px solid var(--gold);box-shadow:0 0 16px rgba(233,196,106,.35)}
.mst b{display:block;margin-top:8px;font:700 14px var(--head)}.mst small{color:var(--gold);font:12px var(--mono)}
@media (max-width:900px){.phero2{grid-template-columns:1fr;text-align:center;justify-items:center}.pgrid2{grid-template-columns:1fr}}

/* ---------- vincular ---------- */
.linkwrap{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:18px}
.chal{display:flex;align-items:center;justify-content:center;gap:26px;padding:26px;border:1px solid var(--rule);border-radius:16px;background:radial-gradient(circle at 50% 40%,rgba(59,158,255,.18),transparent 60%),#11161e}
.chal .arrow{font:700 28px var(--head);color:var(--gold);animation:nudge 1.4s ease-in-out infinite}
@keyframes nudge{50%{transform:translateX(6px)}}
.chal figure{margin:0;text-align:center}.chal figcaption{margin-top:10px;font:600 11.5px var(--mono);letter-spacing:.1em;text-transform:uppercase;color:var(--mute)}
.chal .target .picon{border:3px solid var(--gold);box-shadow:0 0 30px rgba(233,196,106,.55);animation:pulse 2s ease-in-out infinite}
@keyframes pulse{50%{box-shadow:0 0 50px rgba(233,196,106,.8)}}
.howto{counter-reset:s;list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:10px}
.howto li{counter-increment:s;display:grid;grid-template-columns:34px minmax(0,1fr);gap:12px;align-items:start;padding:12px 14px;border:1px solid var(--rule);border-radius:12px;background:var(--panel)}
.howto li::before{content:counter(s);width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:rgba(59,158,255,.18);border:1px solid rgba(59,158,255,.5);font:700 14px var(--head);color:#cfe5ff}
@media (max-width:900px){.linkwrap{grid-template-columns:1fr}}

/* ---------- admin ---------- */
.utable{display:flex;flex-direction:column;gap:10px}
.urow{display:grid;grid-template-columns:52px minmax(170px,1.3fr) minmax(150px,1fr) minmax(140px,1fr) minmax(110px,.8fr) minmax(220px,1.4fr);gap:14px;align-items:center;
padding:12px 16px;border:1px solid var(--rule);border-radius:14px;background:var(--panel);position:relative}
.urow.pending{border-color:rgba(233,196,106,.5);box-shadow:inset 3px 0 0 var(--gold)}
.urow.blocked{opacity:.6;box-shadow:inset 3px 0 0 var(--loss)}
.urow .nm b{display:block;font:700 15px var(--head)}.urow .nm small,.urow .mt small{display:block;color:var(--mute);font:12px var(--mono);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.urow .mt{display:flex;align-items:center;gap:8px;min-width:0}.urow .mt>div{min-width:0}
.urow .mt b{font:700 13.5px var(--head)}
.uact{display:flex;flex-wrap:wrap;gap:6px;justify-content:flex-end}
.uact form{margin:0}.uact button{padding:6px 10px;font-size:11.5px}
.uact .del{display:flex;gap:4px}.uact .del input{width:84px;padding:6px 8px;font-size:12px}
button.danger{background:linear-gradient(135deg,#ff6b7a,#c73a4c)}
button.okb{background:linear-gradient(135deg,#43d3ae,#1f9c7d)}
.audit{font:12.5px var(--mono);color:#b7c0d6;display:flex;flex-direction:column;gap:4px;max-height:380px;overflow:auto}
.audit div{display:grid;grid-template-columns:90px 150px minmax(0,1fr);gap:10px;padding:6px 10px;border-radius:8px;background:rgba(255,255,255,.02)}
.audit b{color:var(--gold);font-weight:600}
.audit div.qrow{grid-template-columns:50px 140px 170px minmax(0,1fr)}
.secret{font:700 20px var(--mono);letter-spacing:.06em;padding:14px 18px;border-radius:12px;border:1px dashed var(--gold);background:rgba(233,196,106,.06);color:#fff;user-select:all;display:inline-block}
.qrow{display:grid;grid-template-columns:70px 140px 110px minmax(0,1fr);gap:10px;padding:8px 12px;border-radius:8px;background:rgba(255,255,255,.02);font:12.5px var(--mono);color:#b7c0d6}
.st-running{color:var(--purple2)}.st-queued{color:var(--gold)}.st-error{color:var(--loss)}.st-done{color:var(--win)}
@media (max-width:1100px){.urow{grid-template-columns:44px minmax(0,1fr)}.urow>*:nth-child(n+3){grid-column:2}.uact{justify-content:flex-start}}
.usermenu{margin-top:auto;display:flex;flex-direction:column;gap:2px;padding-top:14px;border-top:1px solid var(--rule)}
.usermenu .me{display:flex;align-items:center;gap:10px;padding:8px 10px;color:var(--ink);text-decoration:none}
.usermenu .me .picon{width:34px;height:34px;border:2px solid var(--tc,#3b9eff)}
.usermenu .me b{display:block;font:700 13px var(--head)}.usermenu .me small{color:var(--mute);font:11px var(--mono)}
.usermenu form{margin:0}.usermenu button{width:100%;background:none;border:1px solid transparent;color:var(--mute);text-align:left;padding:9px 12px;font:600 12.5px var(--head);letter-spacing:.08em;text-transform:uppercase;box-shadow:none}
.usermenu button:hover{color:var(--loss);background:rgba(255,122,133,.08);transform:none}
"""


# ---- telas sem menu (entrar / criar conta / aguardando) --------------------
def shell(title, inner, base_css, js="", splash=None):
    import random
    sp = icons.splash(splash or random.choice(SPLASHES))
    art = (f"<div class='auth-art'><div class='sp' style=\"background-image:url('{sp}')\"></div>"
           "<div class='auth-copy'><p class='bn-k'><i></i>Coach de League of Legends</p>"
           "<p class='auth-h'>Suba de elo com os seus próprios dados.</p>"
           "<p>Diagnóstico das suas partidas, seus piores matchups, hábitos que custam PDL e o que os melhores do servidor fazem diferente.</p>"
           "<div class='auth-feats'><span>Diagnóstico</span><span>Matchups</span><span>Comparar com o topo</span><span>Hábitos</span><span>Seleção de campeões</span></div></div></div>")
    from . import rotk
    return rotk.apply(f"<!doctype html><html lang='pt-BR'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
            f"<title>{e(title)} · Carry</title><link rel='icon' href=\"{premium.FAVICON}\"><style>{base_css}{rotk.CSS}</style>"
            f"<div class='auth'>{art}<div class='auth-side'><div class='auth-box'>"
            f"<p class='brand'>{premium.logo(40, 'au')}</p><p class='tagl'>{premium.TAGLINE}</p>{inner}</div></div></div>{js}</html>")


def _alert(msg, kind="err"):
    return f"<div class='alert {kind}'>{e(msg)}</div>" if msg else ""


def login_form(err="", info="", email="", pre=""):
    return (f"<h3>Entrar</h3><p class='sub'>Bem-vindo de volta. Entre para ver o seu diagnóstico.</p>{_alert(err)}{_alert(info, 'ok')}"
            f"<form method='post' action='/entrar'><input type='hidden' name='pre' value='{e(pre)}'>"
            f"<div class='fld'><label for='em'>E-mail</label><input id='em' type='email' name='email' value='{e(email)}' autocomplete='username' required autofocus></div>"
            "<div class='fld'><label for='pw'>Senha</label><input id='pw' type='password' name='password' autocomplete='current-password' required></div>"
            "<button class='wide'>Entrar</button></form>")


def signup_form(mode, err="", v=None, pre="", first=False):
    v = v or {}
    if mode == "fechado" and not first:
        return ("<h3>Cadastro fechado</h3><p class='sub'>No momento só o administrador cria contas. Peça um convite a ele.</p>"
                "<p class='alt'><a href='/entrar'>Voltar para entrar</a></p>")
    roles = "".join(f"<option value='{k}'{' selected' if v.get('pref_role') == k else ''}>{t}</option>" for k, t in [("", "Escolha…")] + list(ROLE_PT.items()))
    goals = "".join(f"<option{' selected' if v.get('goal') == g else ''} value='{e(g)}'>{e(g or 'Escolha…')}</option>" for g in GOALS)
    note = ("<div class='alert info'>Você é a primeira pessoa aqui: esta conta vira a do <b>administrador</b>.</div>" if first else
            "<div class='alert info'>Depois do cadastro, o administrador aprova a sua conta.</div>" if mode == "aprovacao" else "")
    return (f"<h3>Criar conta</h3><p class='sub'>Leva 1 minuto. Depois você vincula a sua conta do LoL.</p>{note}{_alert(err)}"
            f"<form method='post' action='/cadastro'><input type='hidden' name='pre' value='{e(pre)}'>"
            f"<div class='fld'><label for='nm'>Nome ou apelido</label><input id='nm' name='name' value='{e(v.get('name'))}' maxlength='40' required></div>"
            f"<div class='fld'><label for='em'>E-mail</label><input id='em' type='email' name='email' value='{e(v.get('email'))}' autocomplete='email' required></div>"
            "<div class='fld2'><div class='fld'><label for='pw'>Senha</label><input id='pw' type='password' name='password' minlength='8' autocomplete='new-password' required></div>"
            "<div class='fld'><label for='pw2'>Repita a senha</label><input id='pw2' type='password' name='password2' minlength='8' autocomplete='new-password' required></div></div>"
            f"<div class='fld2'><div class='fld'><label for='rl'>Posição favorita</label><select id='rl' name='pref_role'>{roles}</select></div>"
            f"<div class='fld'><label for='gl'>Meta de elo</label><select id='gl' name='goal'>{goals}</select></div></div>"
            f"<div class='fld'><label for='dc'>Discord <span class='n'>(opcional)</span></label><input id='dc' name='discord' value='{e(v.get('discord'))}' maxlength='40'></div>"
            f"<div class='fld'><label for='sc'>Como conheceu o app? <span class='n'>(opcional)</span></label><input id='sc' name='source' value='{e(v.get('source'))}' maxlength='60'></div>"
            "<label class='chk'><input type='checkbox' name='consent' value='1' required><span>Concordo que o app guarde meus dados de conta e as partidas "
            "da minha conta do LoL para gerar as análises. Posso baixar ou apagar tudo em Minha conta. <a href='/privacidade' target='_blank'>Privacidade</a></span></label>"
            "<button class='wide'>Criar conta</button></form><p class='alt'>Já tem conta? <a href='/entrar'>Entrar</a></p>")


def pending_box(name):
    return (f"<h3>Quase lá, {e(name)}!</h3><div class='alert info'>Sua conta foi criada e está aguardando a aprovação do administrador.</div>"
            "<p class='sub'>Assim que ele aprovar, é só entrar de novo. Enquanto isso, deixe o seu Riot ID à mão.</p>"
            "<form method='post' action='/sair'><button class='wide btn ghost'>Sair</button></form>")


def privacy_body():
    items = [("O que guardamos", "Nome, e-mail, a senha (só em forma embaralhada, nunca o texto), suas preferências e, depois do vínculo, o seu Riot ID e as partidas ranqueadas da sua conta, tiradas da API oficial da Riot."),
             ("Para que", "Só para montar as suas análises dentro do app. Não vendemos nem passamos dados para ninguém."),
             ("Quem vê", "Só você vê as suas análises. O administrador vê o seu cadastro (nome, e-mail, Riot ID, elo) para gerenciar contas."),
             ("Seus direitos", "Em Minha conta você baixa todos os seus dados ou apaga a sua conta e as suas partidas de vez.")]
    return ("<div class='steps'>" + "".join(f"<div class='step'><div class='stn'><span>{i}</span>{e(t)}</div><p class='n'>{e(d)}</p></div>"
                                            for i, (t, d) in enumerate(items, 1)) + "</div>"
            "<p class='n'>Carry não é endossado pela Riot Games e não reflete as opiniões da Riot Games nem de ninguém envolvido "
            "na produção ou gestão de propriedades da Riot Games. Riot Games e todas as propriedades associadas são marcas registradas da Riot Games, Inc.</p>")


# ---- vincular a conta da Riot ----------------------------------------------
def link_body(link, has_key, region_select, err="", info=""):
    head = _alert(err) + _alert(info, "ok")
    if not has_key:
        return head + ("<div class='empty'><span class='em'>🔑</span><b>Aguardando o administrador</b>"
                       "<span>O app ainda não tem a chave da Riot configurada. Assim que o admin configurar, você vincula a sua conta aqui.</span></div>")
    if link and link["verified_ms"]:
        return head + (f"<div class='card ok'><b class='gl'>Conta vinculada: {e(link['riot_id'])}</b>"
                       f"<p class='n'>Verificada {e(ago(link['verified_ms']))}. Quer usar outra conta do LoL? Vincule de novo abaixo "
                       "(a conta atual sai e as análises passam a ser da nova).</p></div>" + _riot_form(link, region_select))
    if link and link["challenge_icon"] is not None:
        return head + (
            "<div class='linkwrap'><div>"
            f"<div class='chal'><figure>{profile_icon(link['icon'], 92)}<figcaption>Seu ícone agora</figcaption></figure>"
            f"<span class='arrow'>→</span><figure class='target'>{profile_icon(link['challenge_icon'], 110)}<figcaption>Troque para este</figcaption></figure></div>"
            "<form method='post' action='/vincular/verificar' class='row' style='justify-content:center;margin-top:16px'>"
            "<button class='btn gold'>Já troquei, verificar</button></form>"
            "<p class='n' style='text-align:center'>Depois de verificar, você pode voltar para o seu ícone de sempre.</p></div>"
            f"<div><b class='gl'>Prove que {e(link['riot_id'])} é sua</b><ol class='howto' style='margin-top:12px'>"
            "<li><span>Abra o cliente do League of Legends.</span></li>"
            "<li><span>Clique no seu ícone de perfil (canto superior direito).</span></li>"
            "<li><span>Escolha o ícone da direita (é um dos ícones que toda conta tem) e salve.</span></li>"
            "<li><span>Volte aqui e clique em <b>Já troquei, verificar</b>. Pode levar até 1 minuto para a Riot atualizar.</span></li></ol>"
            "<p class='n'>Por que isso? Para ninguém vincular a conta de outra pessoa.</p></div></div>"
            + _riot_form(link, region_select, "Errou o Riot ID? Corrija aqui"))
    return head + ("<div class='linkwrap'><div>" + _riot_form(link, region_select, "Qual é a sua conta do LoL?", big=True) + "</div>"
                   "<div><ol class='howto'><li><span>Digite o seu Riot ID no formato <b>Nome#TAG</b> (aparece no cliente, no seu perfil).</span></li>"
                   "<li><span>Troque o ícone de perfil para o que o app pedir. É a prova de que a conta é sua.</span></li>"
                   "<li><span>Pronto: o app baixa as suas partidas ranqueadas, descobre seu campeão, sua posição e seu elo.</span></li></ol></div></div>")


def _riot_form(link, region_select, title="Vincular outra conta", big=False):
    rid = link["riot_id"] if link else ""
    reg = link["region"] if link else "br1"
    return (f"<div class='card'><b class='gl'>{e(title)}</b><form method='post' action='/vincular' class='row' style='flex-wrap:wrap'>"
            f"<input name='riot_id' value='{e(rid)}' placeholder='Nome#TAG' maxlength='24' required style='max-width:260px'>"
            f"{region_select(reg)}<button{' class=btn' if big else ''}>Continuar</button></form></div>")


# ---- Meu perfil -------------------------------------------------------------
def profile_body(user, link, games, mastery_rows, champ_names, sample_note, syncing=True):
    tier = (link["tier"] if link else None) or "UNRANKED"
    tc = TIER_COLOR.get(tier, TIER_COLOR["UNRANKED"])
    rid = (link["riot_id"] if link else "") or ""
    name, _, tag = rid.partition("#")
    main = link["main_champ"] if link else None
    from . import bg
    sp = bg.art("sp", icons.splash(main) if main else "")
    badges = []
    if link and link["verified_ms"]:
        badges.append("<span class='badge ver'>✓ Conta verificada</span>")
    if user["role"] == "admin":
        badges.append("<span class='badge adm'>Administrador</span>")
    if link and link["main_role"]:
        badges.append(f"<span class='badge'>{e(ROLE_PT.get(link['main_role'], link['main_role']))}</span>")
    if user["goal"]:
        badges.append(f"<span class='badge warn'>Meta: {e(user['goal'])}</span>")
    from .riot import REGIONS
    if link:
        badges.append(f"<span class='badge'>{e(REGIONS.get(link['region'], (link['region'],))[0])}</span>")
    w, l_ = (link["wins"] or 0, link["losses"] or 0) if link else (0, 0)
    season = f"{w}V {l_}D · {round(100 * w / (w + l_))}% na temporada" if (w + l_) else "sem jogos ranqueados lidos"
    lvl = f"<span class='lvl'>{link['level']}</span>" if link and link["level"] else ""
    body = (f"<section class='phero2' style='--tc:{tc}'>{sp}<div class='avatar'>{profile_icon(link['icon'] if link else None, 118)}{lvl}</div>"
            f"<div class='pname'><small>Invocador</small><b>{e(name or user['name'])}</b><span class='tagline'>#{e(tag)}</span>"
            f"<div class='badges'>{''.join(badges)}</div></div>"
            f"<div class='rankbox'>{crest(tier, 92)}<div class='rt'><small>Solo/Duo</small><b>{e(rank_text(link))}</b><small>{e(season)}</small></div></div></section>")
    if not games and syncing:
        return body + ("<div class='empty'><span class='em'>⏳</span><b>Baixando as suas partidas…</b>"
                       "<span>A primeira sincronização começa sozinha depois do vínculo. Esta página se completa quando ela terminar.</span></div>")
    if not games:
        return body + ("<div class='empty'><span class='em'>🎮</span><b>Nenhuma partida ranqueada solo/duo encontrada</b>"
                       "<span>O app analisa as ranqueadas solo/duo. Jogue algumas e clique em Sincronizar agora.</span></div>")
    n = len(games)
    wins = sum(1 for g in games if g["win"])
    k = sum(g["kills"] for g in games) / n
    d = sum(g["deaths"] for g in games) / n
    a = sum(g["assists"] for g in games) / n
    cs = [g.get("cs_per_min") for g in games if g.get("cs_per_min")]
    kpis = [("Partidas analisadas", f"{n}", sample_note(n)), ("Winrate", f"{round(100 * wins / n)}%", f"{wins}V {n - wins}D"),
            ("KDA médio", f"{(k + a) / max(d, 1):.2f}", f"{k:.1f} / {d:.1f} / {a:.1f}"),
            ("CS por minuto", f"{sum(cs) / len(cs):.1f}" if cs else "–", "média das partidas")]
    from . import statsui as _su
    body += _su.rank_track(link["tier"], link["division"], link["lp"]) if link else ""
    body += "<div class='kpis'>" + "".join(f"<div class='kpi'><small class='kl'>{e(t)}</small><b class='kv'>{e(v)}</b><small class='n'>{e(s)}</small></div>" for t, v, s in kpis) + "</div>"
    # campeao principal + forma recente / posicoes
    by = {}
    for g in games:
        by.setdefault(g["champion"], []).append(g)
    mg = by.get(main, [])
    mwr = round(100 * sum(1 for g in mg if g["win"]) / len(mg)) if mg else 0
    maincard = (f"<div class='maincard'><div class='sp' style=\"background-image:url('{icons.splash(main)}')\"></div><div>"
                f"<small>Campeão principal</small><b>{e(main)}</b><span class='pill'><small>Jogos</small>{len(mg)}</span> "
                f"<span class='pill {'okp' if mwr >= 52 else 'badp' if mwr <= 45 else ''}'><small>Winrate</small>{mwr}%</span></div></div>") if main else ""
    roles = {}
    for g in games:
        if g.get("position"):
            roles[g["position"]] = roles.get(g["position"], 0) + 1
    tot = sum(roles.values()) or 1
    rb = "".join(f"<div class='rb'><span>{e(ROLE_PT.get(r, r))}</span><span class='tr'><i style='width:{100 * c / tot:.0f}%'></i></span><span class='n'>{round(100 * c / tot)}%</span></div>"
                 for r, c in sorted(roles.items(), key=lambda kv: -kv[1]))
    form = "".join(f"<i class='{'v' if g['win'] else 'd'}' title='{e(g['champion'])}'>{'V' if g['win'] else 'D'}</i>" for g in games[:15])
    side = (f"<div class='card'><b class='gl'>Forma recente</b><div class='form10' style='margin-top:10px'>{form}</div></div>"
            f"<div class='card'><b class='gl'>Posições</b><div class='rolebars' style='margin-top:12px'>{rb}</div></div>")
    body += f"<h2>Seu jogo</h2><div class='pgrid2'>{maincard}<div>{side}</div></div>"
    from . import statsui
    body += "<h2>Seus campeões</h2>" + statsui.champ_table(games)
    if mastery_rows:
        body += "<h2>Maestria</h2><div class='mast'>" + "".join(
            f"<div class='mst'>{icons.champ(champ_names.get(str(m['champion_id']), '?'), 64)}<b>{e(champ_names.get(str(m['champion_id']), '?'))}</b>"
            f"<small>{m['points']:,} pts · nível {m['level']}</small></div>".replace(",", ".") for m in mastery_rows[:6]) + "</div>"
    return body


# ---- Minha conta ------------------------------------------------------------
def account_body(user, link, err="", info=""):
    roles = "".join(f"<option value='{k}'{' selected' if (user['pref_role'] or '') == k else ''}>{t}</option>" for k, t in [("", "—")] + list(ROLE_PT.items()))
    goals = "".join(f"<option{' selected' if (user['goal'] or '') == g else ''} value='{e(g)}'>{e(g or '—')}</option>" for g in GOALS)
    lk = (f"{e(link['riot_id'])} · {'verificada' if link['verified_ms'] else 'não verificada'}" if link else "nenhuma")
    return (_alert(err) + _alert(info, "ok") +
            "<div class='grid2'>"
            "<div class='card'><b class='gl'>Seus dados</b><form method='post' action='/conta' style='margin-top:12px'>"
            f"<div class='fld'><label>Nome ou apelido</label><input name='name' value='{e(user['name'])}' maxlength='40'></div>"
            f"<div class='fld'><label>E-mail</label><input value='{e(user['email'])}' disabled></div>"
            f"<div class='fld2'><div class='fld'><label>Posição favorita</label><select name='pref_role'>{roles}</select></div>"
            f"<div class='fld'><label>Meta de elo</label><select name='goal'>{goals}</select></div></div>"
            f"<div class='fld'><label>Discord</label><input name='discord' value='{e(user['discord'])}' maxlength='40'></div>"
            "<button>Salvar</button></form></div>"
            "<div class='card'><b class='gl'>Trocar a senha</b><form method='post' action='/conta/senha' style='margin-top:12px'>"
            "<div class='fld'><label>Senha atual</label><input type='password' name='current' autocomplete='current-password' required></div>"
            "<div class='fld'><label>Nova senha</label><input type='password' name='new' minlength='8' autocomplete='new-password' required></div>"
            "<button>Trocar senha</button><p class='n'>Trocar a senha desconecta os outros aparelhos.</p></form></div></div>"
            f"<div class='card'><b class='gl'>Conta do LoL</b><p class='n'>Vinculada: {lk}.</p><a class='btn ghost' href='/vincular'>Gerenciar vínculo</a></div>"
            "<div class='grid2'><div class='card'><b class='gl'>Seus dados (LGPD)</b><p class='n'>Baixe tudo o que o app guarda sobre você (cadastro e vínculo).</p>"
            "<a class='btn ghost' href='/conta/exportar'>Baixar meus dados</a></div>"
            "<div class='card warn'><b class='gl'>Apagar minha conta</b><p class='n'>Apaga o seu cadastro e todas as suas partidas e análises. Não dá para desfazer.</p>"
            "<form method='post' action='/conta/apagar' class='row' style='flex-wrap:wrap'><input type='password' name='password' placeholder='Sua senha' required style='max-width:180px'>"
            "<input name='confirm' placeholder='Digite APAGAR' required style='max-width:150px'><button class='danger'>Apagar tudo</button></form></div></div>")


# ---- Painel do admin --------------------------------------------------------
def admin_body(con, me, users, key_status, has_key, queue, audit_rows, mode, notice="", secret=None, user_db_games=None):
    user_db_games = user_db_games or {}
    now = time.time() * 1000
    total = len(users)
    active7 = sum(1 for u in users if (u["last_seen_ms"] or u["last_login_ms"] or 0) > now - 7 * 86400000)
    pend = sum(1 for u in users if u["status"] == "pending")
    ver = sum(1 for u in users if u["verified_ms"])
    qn = sum(1 for j in queue if j["state"] in ("queued", "running"))
    out = _alert(notice, "ok")
    if secret:
        out += (f"<div class='card warn'><b class='gl'>Senha temporária de {e(secret[0])}</b><p class='n'>Mostrada só agora. Passe para a pessoa; "
                f"ela troca em Minha conta.</p><span class='secret'>{e(secret[1])}</span></div>")
    kp = [("Usuários", total, "contas criadas"), ("Ativos (7 dias)", active7, "entraram na semana"), ("Aguardando", pend, "aprovação"),
          ("Verificados", ver, "conta do LoL vinculada"), ("Na fila", qn, "tarefas rodando/esperando")]
    out += "<div class='kpis'>" + "".join(f"<div class='kpi'><small class='kl'>{e(t)}</small><b class='kv'>{v}</b><small class='n'>{e(s)}</small></div>" for t, v, s in kp) + "</div>"
    # configuracoes
    modes = "".join(f"<option value='{k}'{' selected' if k == mode else ''}>{e(t)}</option>" for k, t in accounts.SIGNUP_MODES.items())
    out += ("<!--CHAVES--><h2>Contas e servidor</h2><div class='grid2'>"
            "<div class='card'><b class='gl'>Cadastro de novas contas</b>"
            f"<form method='post' action='/admin/modo' class='row'><select name='mode'>{modes}</select><button>Salvar</button></form>"
            "<b class='gl' style='display:block;margin-top:18px'>Criar conta para alguém</b>"
            "<form method='post' action='/admin/criar' class='row' style='flex-wrap:wrap'><input name='name' placeholder='Nome' required style='max-width:150px'>"
            "<input type='email' name='email' placeholder='E-mail' required style='max-width:220px'><button>Criar</button></form>"
            "<p class='n'>A conta nasce aprovada, com uma senha temporária mostrada uma vez.</p>"
            "<b class='gl' style='display:block;margin-top:18px'>Servidor</b>"
            "<form method='post' action='/reiniciar' class='row'><button class='btn ghost'>↻ Reiniciar o app</button></form></div></div>")
    # usuarios
    rows = ""
    for u in users:
        st = u["status"]
        tier = u["tier"] or None
        rk = (f"<div class='mt'>{crest(tier, 34)}<div><b>{e(TIER_PT.get(tier, tier) if tier else '—')}"
              f"{'' if not tier or tier in ('UNRANKED', 'MASTER', 'GRANDMASTER', 'CHALLENGER') else ' ' + e(u['division'] or '')}</b>"
              f"<small>{(str(u['lp']) + ' PDL') if u['lp'] is not None else ''}</small></div></div>")
        mc = (f"<div class='mt'>{icons.champ(u['main_champ'], 34, 'me')}<div><b>{e(u['main_champ'])}</b>"
              f"<small>{e(ROLE_PT.get(u['main_role'], u['main_role'] or ''))} · {u['games'] or 0} jogos · {u['winrate'] if u['winrate'] is not None else '–'}%</small></div></div>"
              if u["main_champ"] else "<div class='mt'><small>sem partidas ainda</small></div>")
        riot = (f"<small>{e(u['riot_id'])} {'✓' if u['verified_ms'] else '(não verificada)'}</small>" if u["riot_id"] else "<small>sem conta do LoL</small>")
        pill = {"active": "", "pending": "<span class='badge warn'>Aguardando</span>", "blocked": "<span class='badge' style='color:var(--loss)'>Bloqueado</span>"}[st]
        role = "<span class='badge adm'>Admin</span>" if u["role"] == "admin" else ""
        acts = ""
        is_me = u["id"] == me["id"]

        def act(path, label, cls="btn ghost", extra=""):
            return (f"<form method='post' action='/admin/u/{u['id']}/{path}'>{extra}<button class='{cls}'>{label}</button></form>")
        if st == "pending":
            acts += act("aprovar", "Aprovar", "okb")
        if not is_me:
            acts += act("desbloquear", "Desbloquear") if st == "blocked" else act("bloquear", "Bloquear")
            acts += act("rebaixar", "Tirar admin") if u["role"] == "admin" else act("promover", "Tornar admin")
        if u["riot_id"] and not u["verified_ms"]:
            acts += act("verificar", "Verificar conta")
        if u["verified_ms"]:
            acts += act("sincronizar", "Sincronizar")
        acts += act("senha", "Nova senha")
        if not is_me:
            acts += (f"<form method='post' action='/admin/u/{u['id']}/excluir' class='del'><input name='confirm' placeholder='EXCLUIR' aria-label='Digite EXCLUIR'>"
                     "<button class='danger'>Excluir</button></form>")
        rows += (f"<div class='urow {st}' style='--tc:{TIER_COLOR.get(tier or 'UNRANKED')}'>{profile_icon(u['icon'], 44)}"
                 f"<div class='nm'><b>{e(u['name'])} {role}{pill}</b><small>{e(u['email'])}</small>{riot}</div>"
                 f"{rk}{mc}<div class='nm'><small>Criada {e(ago(u['created_ms']))}</small><small>Visto {e(ago(u['last_seen_ms'] or u['last_login_ms']))}</small>"
                 f"<small>{e(u['goal'] or '')}{' · ' + e(u['discord']) if u['discord'] else ''}</small></div><div class='uact'>{acts}</div></div>")
    out += f"<h2>Usuários</h2><div class='utable'>{rows}</div>"
    # fila
    names = {u["id"]: u["name"] for u in users}
    qhtml = "".join(f"<div class='qrow'><span>#{j['id']}</span><span>{e(names.get(j['uid'], '—'))}</span><span class='st-{j['state']}'>{e(j['name'])} · {e(j['state'])}</span>"
                    f"<span>{e(j['error'] or j['last'])}</span></div>" for j in reversed(queue[-15:]))
    out += "<h2>Fila de tarefas</h2>" + (f"<div class='audit'>{qhtml}</div>" if qhtml else "<p class='n'>Nada na fila.</p>")
    au = "".join(f"<div><span>{e(time.strftime('%d/%m %H:%M', time.localtime(r['at_ms'] / 1000)))}</span><b>{e(r['action'])}</b>"
                 f"<span>{e(names.get(r['user_id'], ''))} {e(r['detail'])} {e(r['ip'])}</span></div>" for r in audit_rows)
    out += "<h2>Auditoria</h2>" + (f"<div class='audit'>{au}</div>" if au else "<p class='n'>Sem registros.</p>")
    return out


def companion_body():
    return ("<div class='empty'><span class='em'>🖥</span><b>Esta tela lê o cliente do LoL do seu computador</b>"
            "<span>Seleção de campeões e Ao vivo precisam do app rodando no mesmo PC do jogo (o cliente do LoL só conversa com o próprio computador). "
            "Pelo site você tem diagnóstico, partidas, matchups, hábitos e a comparação com o topo.</span></div>")

CSS += """
input[type=email],input:not([type]){width:100%;padding:10px 12px;border-radius:8px;border:1px solid var(--rule);background:#0f141b;color:var(--ink);font:15px var(--body)}
.row input:not([type]),.row input[type=email]{max-width:320px}
.rail{overflow-y:auto}
"""
