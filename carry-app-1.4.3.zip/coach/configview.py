"""Runas, feiticos e itens com icones (imagens oficiais do Data Dragon da Riot)."""
import json

from . import builds
from .tags import DADO, tip

CDN = "https://ddragon.leagueoflegends.com/cdn"


def _img(url, name, e, cls="ic"):
    return f"<img class='{cls}' src='{e(url)}' alt='{e(name)}' title='{e(name)}' width='36' height='36' loading='lazy'>"


def item_icons(ids, items, ver, e):
    out = ""
    for i in ids:
        if not i:
            continue
        nm = (items.get(str(i)) or {}).get("name", str(i))
        out += _img(f"{CDN}/{ver}/img/item/{i}.png", nm, e) if ver else f"<span class='chip'>{e(nm)}</span>"
    return out or "<span class='n'>–</span>"


def rune_block(page, info, e):
    """page = (estilo1, estilo2, [9 ids]). Mostra arvore principal, secundaria e fragmentos."""
    prim, sub, sel = page

    def r(i, big=False):
        d = info.get(i) or {"name": str(i), "icon": None}
        img = _img(f"{CDN}/img/{d['icon']}", d["name"], e, "ic big" if big else "ic") if d.get("icon") else ""
        return (f"<div class='rune'>{img}<span><b>{e(d['name'])}</b>"
                f"<small>{e(d.get('desc') or '')}</small></span></div>")
    out = f"<p class='gl'>{e((info.get(prim) or {}).get('name', prim))}</p>" + "".join(
        r(i, k == 0) for k, i in enumerate(sel[:4]))
    out += f"<p class='gl'>{e((info.get(sub) or {}).get('name', sub))}</p>" + "".join(r(i) for i in sel[4:6])
    return out


def spell_block(pair, spells, ver, e):
    out = ""
    for k, sid in enumerate(pair):
        d = spells.get(sid) or {"id": "", "name": str(sid)}
        img = _img(f"{CDN}/{ver}/img/spell/{d['id']}.png", d["name"], e) if ver and d["id"] else ""
        out += f"<span class='spell'>{img}<small>{e(d['name'])}</small></span>"
    return out


def _wr(n, w):
    return f"{round(100 * w / n)}% de vitória · {n} jogo(s)" if n else ""


def top_panel(con, champion, dd, e, tips_html, rank=0, form=True, position=None):
    """'Sua configuração' com o que os melhores mais usam no campeao (amostra do topo)."""
    rows = builds.top_rows(con, champion, position)
    if not rows:
        return ("<div class='card'><b class='gl'>Runas, feitiços e itens do topo</b>" + tips_html([
            tip(DADO, f"Sem partidas do topo para {champion}. Clique em Baixar amostra do topo (em Sincronizar ou na página do campeão).", 0)]) + "</div>")
    try:
        ver = dd.version()
        info = dd.rune_info()
        items = dd.items()
        spells = dd.spells()
    except Exception:
        ver, info, items, spells = None, {}, {}, {}
    st = builds.item_stats(con, rows, items)
    runes = builds.rune_stats(rows)
    sp = builds.spell_stats(rows)
    cols = "<div class='cfg'>"
    cols += "<div class='card'><b class='gl'>Runas</b>"
    if runes and rank < len(runes):
        (prim, sub, sel), n, w = runes[rank]
        cols += rune_block((prim, sub, list(sel)), info, e) + f"<p class='n'><span class='tag dado'>dado</span> {e(_wr(n, w))}</p>"
    else:
        cols += "<p class='n'>Nenhuma página completa na amostra.</p>"
    cols += "</div><div class='card'><b class='gl'>Feitiços de invocador</b>"
    if sp and rank < len(sp):
        pair, n, w = sp[rank]
        cols += spell_block(pair, spells, ver, e) + f"<p class='n'><span class='tag dado'>dado</span> {e(_wr(n, w))}</p>"
    cols += "<b class='gl' style='margin-top:14px'>Itens</b>"
    if st["n"]:
        from . import profile as _pf
        cb = builds.clean_build(st, items, champion, position or _pf.position())      # a mesma build conferida do resto do app
        if cb["start"]:
            cols += "<p class='n'>Inicial</p><div class='ics'>" + item_icons(cb["start"], items, ver, e) + "</div>"
        order = cb["order"][:3]
        if order:
            cols += "<p class='n'>Ordem dos primeiros itens</p><div class='ics'>" + item_icons(order, items, ver, e) + "</div>"
        if cb["boots"]:
            cols += "<p class='n'>Botas</p><div class='ics'>" + item_icons([cb["boots"]], items, ver, e) + "</div>"
        extra = [i for i in cb["order"][3:] + cb["extra"] if i not in order][:5]
        if extra:
            cols += "<p class='n'>Situacionais frequentes</p><div class='ics'>" + item_icons(extra, items, ver, e) + "</div>"
        cols += f"<p class='n'><span class='tag dado'>dado</span> {st['n']} jogo(s) do topo no {e(champion)}"
        cols += " (amostra pequena: não é conclusivo)" if st["n"] < 30 else ""
        cols += "</p>"
    cols += "</div></div>"
    if not form:
        return cols
    cols += ("<form method='post' action='/selecao/importar' class='row'><input type='hidden' name='champion' value='" + e(champion) + "'>"
             "<button name='what' value='runas'>Importar runas no cliente</button> "
             "<button name='what' value='itens'>Importar itens no cliente</button></form>")
    return cols


def my_panel(con, mid, pid, dd, e):
    """O que VOCE usou nesta partida (runas, feiticos, itens finais) com icones."""
    r = con.execute("SELECT items, perks, spells FROM participant_extra WHERE match_id=? AND participant_id=?",
                    (mid, pid)).fetchone()
    if not r:
        return ""
    try:
        ver, info, items, spells = dd.version(), dd.rune_info(), dd.items(), dd.spells()
    except Exception:
        return "<p class='n'>Sem internet para buscar os ícones do Data Dragon.</p>"
    page = builds.page_from_perks(json.loads(r["perks"] or "{}"))
    out = "<div class='cfg'><div class='card'><b class='gl'>Suas runas</b>"
    out += rune_block(page, info, e) if page else "<p class='n'>Sem runas salvas.</p>"
    out += "</div><div class='card'><b class='gl'>Seus feitiços</b>"
    try:
        out += spell_block([x for x in json.loads(r["spells"] or "[]") if x], spells, ver, e)
    except ValueError:
        pass
    out += "<b class='gl' style='margin-top:14px'>Seus itens finais</b><div class='ics'>"
    out += item_icons(json.loads(r["items"] or "[]")[:6], items, ver, e) + "</div></div></div>"
    return out
