"""Avisos de rota em tom serio: guardar a fuga, jungler deles voltando, hora de jogar agressivo e ganks (para quem e jungler).
Cada fala tem chave unica (o overlay fala uma vez cada)."""
import time

_ST = {}
LN = {"TOP": "topo", "MIDDLE": "meio", "BOTTOM": "rota de baixo", "UTILITY": "rota de baixo"}


def _gk(live_data):
    return "|".join(sorted((p.get("championName") or "") for p in live_data.get("allPlayers") or []))


def cues(live_data, me, foes, pos, gt, ddir=None):
    from . import escapes, live, liveview, spelltimers
    al = []
    add = lambda k, t, v=None: al.append({"k": k, "t": t, **({"v": v} if v else {})})
    st = _ST.setdefault(_gk(live_data), {"jg_dead": False, "seen6": False})
    if len(_ST) > 4:
        for k in list(_ST)[:-4]:
            _ST.pop(k, None)
    my_cid = liveview.champ_id(me)
    esc = escapes.escape_of(my_cid, ddir)
    esc_txt = f"Guarde o {esc[0]} pra fugir" if esc else ""
    lp = next((p for p in foes if pos and p.get("position") == pos and pos != "JUNGLE"), None)
    ejg = next((p for p in foes if (p.get("position") or "").upper() == "JUNGLE"), None)
    me_name = live._name(me)
    lv = int(me.get("level") or 1)

    # 1) por que voce morreu, na hora (uma frase com a causa provavel, pelo placar do jogo)
    evs = (live_data.get("events") or {}).get("Events") or []
    by_name = {live._name(p): p for p in live_data.get("allPlayers") or []}
    for x in evs:
        if x.get("EventName") != "ChampionKill" or x.get("VictimName") != me_name or not (6 <= gt - (x.get("EventTime") or 0) <= 25):
            continue            # espera 6 s: a luta pode continuar depois da sua morte e muda a leitura
        t0 = x.get("EventTime") or 0
        kp = by_name.get(x.get("KillerName"))
        ass = [by_name.get(a) for a in x.get("Assisters") or [] if by_name.get(a)]
        who = [p for p in [kp] + ass if p and p.get("team") != me.get("team")]
        if not who:
            add(f"morte_{int(t0)}", "Morreu para torre ou monstro: só entre sob a torre com a onda segurando os tiros.")
            break
        # quem estava na luta: todo mundo que matou, ajudou ou morreu entre 12 s antes e 6 s depois da sua morte
        my_team = me.get("team")
        ally_in, foe_in, ours, theirs = set(), set(), 0, 0
        for y in evs:
            if y.get("EventName") != "ChampionKill" or not (t0 - 12 <= (y.get("EventTime") or 0) <= t0 + 6):
                continue
            ppl = [by_name.get(n) for n in [y.get("KillerName"), y.get("VictimName")] + list(y.get("Assisters") or [])]
            for pp in ppl:
                if not pp or pp is me:
                    continue
                (ally_in if pp.get("team") == my_team else foe_in).add(live._name(pp))
            vic = by_name.get(y.get("VictimName"))
            if vic:
                if vic.get("team") == my_team:
                    theirs += 1
                else:
                    ours += 1
        n_a, n_e = len(ally_in) + 1, max(len(foe_in), len(who))
        names = [p.get("championName") for p in who]
        txt = f"Por que você morreu: {names[0]}" + (f" com {', '.join(names[1:])}" if len(names) > 1 else "") + "."
        if n_a >= 2:                                   # luta de time: nao foi "jungler sumido"
            placar = f" ({ours} a {theirs} em abates)" if ours or theirs else ""
            if n_e > n_a:
                txt += f" Luta {n_a} contra {n_e}{placar}: em desvantagem de número, recue até o time chegar."
            elif ours > theirs:
                txt += f" Luta {n_a} contra {n_e}{placar}: a troca foi boa para o time."
            elif ours == theirs:
                txt += f" Luta {n_a} contra {n_e}{placar}: troca empatada. Agora vale objetivo ou voltar para a base."
            else:
                txt += f" Luta {n_a} contra {n_e}{placar}, perdida em número igual: no replay, veja quem entrou primeiro e quais habilidades faltaram."
        elif ejg and ejg in who and pos != "JUNGLE" and len(who) >= 2:
            txt = f"Por que você morreu: gank do caçador, {ejg.get('championName')}, {len(who)} contra 1."
            if gt < 900:
                txt += " Antes de trocar, confira onde ele foi visto por último e se a sua onda está empurrada."
                if esc:
                    txt += f" {esc_txt} até ele aparecer."
        elif len(who) >= 3:
            txt += f" {len(who)} contra 1: antes de entrar, conte quem está à vista."
        elif len(who) == 2:
            txt += " Dois contra um: com mais de um inimigo perto, não fique na rota sem fuga."
        elif kp and lp and kp is lp and int(lp.get("level") or 1) > lv:
            dl_ = int(lp.get("level") or 1) - lv
            txt += f" Ele estava {dl_} níve{'is' if dl_ > 1 else 'l'} na frente: com nível atrás, não troque."
        elif kp and lp and kp is lp:
            txt += " Duelo perdido na rota: troque só quando ele gastar a habilidade principal."
        elif kp and kp is not lp:
            txt += f" O {kp.get('championName')} veio de outra rota: quando o oponente dele sumir, jogue mais perto da torre."
        gold = int(((live_data.get("activePlayer") or {}).get("currentGold")) or 0)
        if gold >= 1300:
            txt += f" E você morreu com {gold} de ouro sem gastar: volte antes."
        add(f"morte_{int(t0)}", txt)
        break

    # 1b) resumo da luta grande que acabou de terminar
    kills = sorted((x for x in evs if x.get("EventName") == "ChampionKill"), key=lambda x: x.get("EventTime") or 0)
    if kills:
        tl = kills[-1].get("EventTime") or 0
        if 8 <= gt - tl <= 25:
            cl = [kills[-1]]
            for x in reversed(kills[:-1]):
                if (cl[-1].get("EventTime") or 0) - (x.get("EventTime") or 0) <= 10:
                    cl.append(x)
                else:
                    break
            if len(cl) >= 3:
                t_ini = min(x.get("EventTime") or 0 for x in cl)
                ours = sum(1 for x in cl if (by_name.get(x.get("VictimName")) or {}).get("team") == me.get("team"))
                theirs = len(cl) - ours
                objs = [x.get("EventName") for x in evs if x.get("EventName") in ("DragonKill", "BaronKill", "HeraldKill")
                        and t_ini - 20 <= (x.get("EventTime") or 0) <= tl + 5]
                onde = {"DragonKill": " no Dragão", "BaronKill": " no Barão", "HeraldKill": " no Arauto"}.get(objs[0], "") if objs else ""
                vivos_deles = sum(1 for p in foes if not p.get("isDead"))
                if ours > theirs:
                    add(f"luta_{int(t_ini)}", f"Luta perdida{onde}: {ours} dos seus contra {theirs} deles. Antes de entrar na próxima, contem quem está vivo "
                        "e à vista; sem o número, recuem e defendam perto da torre.", f"Luta perdida{onde}, {ours} a {theirs}. Contem antes de entrar.")
                elif theirs > ours and vivos_deles <= 2:
                    add(f"luta_{int(t_ini)}", f"Luta ganha{onde}: {theirs} deles contra {ours} seus. Com {5 - vivos_deles} deles mortos, peguem torre ou objetivo agora.",
                        f"Luta ganha, {theirs} a {ours}: peguem objetivo agora.")

    # 2) oponente de rota chegou no 6
    if lp and esc and int(lp.get("level") or 1) >= 6 and gt < 1200:
        if not st["seen6"]:
            st["seen6"] = gt
        if gt - st["seen6"] < 30:
            add("esc_6", f"{lp.get('championName')} chegou no nível 6. {esc_txt} da ultimate dele, não use pra trocar.",
                f"{lp.get('championName')} tem ult agora. {esc_txt}.")

    # 3) jungler deles voltou a vida
    if ejg:
        dead = bool(ejg.get("isDead"))
        if st["jg_dead"] and not dead and pos != "JUNGLE":
            st["jg_back"] = gt
            st["jg_back_n"] = st.get("jg_back_n", 0) + 1
        st["jg_dead"] = dead
        if st.get("jg_back") and gt - st["jg_back"] < 25 and gt < 1500:
            add(f"jgback_{st['jg_back_n']}", f"{ejg.get('championName')} voltou: o jungler deles pode gankar de novo. Jogue com cuidado.",
                "O jungler deles voltou: pode gankar de novo.")

    # 4) jogar agressivo (frase seria)
    if lp and gt < 840 and pos != "JUNGLE" and not me.get("isDead"):
        d = lv - int(lp.get("level") or 1)
        if d >= 2:
            add(f"agg_lvl_{lv}", f"Você está {d} níveis na frente do {lp.get('championName')}: jogue agressivo e force troca.",
                f"{d} níveis na frente do {lp.get('championName')}: jogue agressivo.")
    flash_down = {}
    try:
        gkey = spelltimers.game_key(live_data)
        for m in spelltimers.MARKS:
            if m["game"] == gkey and m["what"] == "Flash" and m["ready"] > gt:
                flash_down[m["champ"]] = m
    except Exception:
        pass
    if lp and lp.get("championName") in flash_down:
        m = flash_down[lp.get("championName")]
        add(f"agg_nf_{m['id']}", f"{lp.get('championName')} está sem Flash: jogue agressivo e chame o jungler.",
            f"{lp.get('championName')} sem Flash: jogue agressivo.")

    # 5) para quem joga de selva: gank na rota sem Flash
    if pos == "JUNGLE" and gt < 1500:
        for p in foes:
            nm = p.get("championName")
            if nm in flash_down and p.get("position") in LN and not p.get("isDead"):
                m = flash_down[nm]
                add(f"jg_gank_nf_{m['id']}", f"Bom gank no {LN[p.get('position')]}: {nm} está sem Flash.",
                    f"Bom gank no {LN[p.get('position')]}: {nm} sem Flash.")
    return al
