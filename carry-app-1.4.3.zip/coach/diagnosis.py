"""Diagnostico: o que mais separa as SUAS vitorias das SUAS derrotas.

Para cada fator compara a taxa de vitoria dos grupos (ex.: 0 mortes antes dos 10 min x 2 ou mais).
Mostra sempre quantos jogos tem em cada grupo. E correlacao, nao prova de causa: a leitura do
motivo e hipotese; o numero e dado; o treino sugerido e regra geral.
"""
import statistics
import time

MIN_GROUP = 8      # jogos minimos por grupo para entrar no ranking
MIN_GAP = 10       # diferenca (pontos percentuais) para considerar que pesa


def _wr(xs):
    return round(100 * sum(1 for x in xs if x["win"]) / len(xs)) if xs else None


def _groups(label_fn_pairs):
    out = []
    for label, xs in label_fn_pairs:
        if xs:
            out.append({"label": label, "n": len(xs), "wr": _wr(xs)})
    return out


def _lever(key, title, groups, why, training, caveat=None):
    ok = [g for g in groups if g["n"] >= MIN_GROUP]
    if len(ok) < 2:
        return None
    gap = max(g["wr"] for g in ok) - min(g["wr"] for g in ok)
    total = sum(g["n"] for g in groups)
    return {"key": key, "title": title, "groups": groups, "gap": gap, "weight": gap * min(1.0, sum(g["n"] for g in ok) / max(total, 1)),
            "why": why, "training": training, "caveat": caveat, "pesa": gap >= MIN_GAP}


def levers(games):
    """games: suas partidas (qualquer ordem). Devolve [{...}] do que mais pesa para o que menos pesa."""
    tl = [g for g in games if g.get("deaths_before_10") is not None]
    out = []

    d10 = [("0 mortes", [g for g in tl if g["deaths_before_10"] == 0]),
           ("1 morte", [g for g in tl if g["deaths_before_10"] == 1]),
           ("2 ou mais", [g for g in tl if g["deaths_before_10"] >= 2])]
    out.append(_lever("deaths10", "Mortes antes dos 10 minutos", _groups(d10),
                      "Morrer cedo entrega ouro, experiência e a prioridade da rota.",
                      "Nos 10 primeiros minutos, jogue para não morrer: recue quando a onda empurrar contra você, "
                      "avise-se do jungler inimigo antes de trocar e aceite perder um pouco de farm para continuar vivo."))

    cs = [("CS igual ou melhor que o oponente aos 10", [g for g in tl if g.get("csdiff10") is not None and g["csdiff10"] >= 0]),
          ("CS pior que o oponente aos 10", [g for g in tl if g.get("csdiff10") is not None and g["csdiff10"] < 0])]
    from collections import Counter as _C
    main_pos = (_C(g.get("position") for g in games).most_common(1) or [(None, 0)])[0][0]
    if main_pos == "UTILITY":   # suporte: farm nao e o trabalho; participacao em abates e
        cs = [("Participação em abates 55% ou mais", [g for g in tl if g.get("kp") is not None and g["kp"] >= 0.55]),
              ("Participação abaixo de 55%", [g for g in tl if g.get("kp") is not None and g["kp"] < 0.55])]
        out.append(_lever("kp", "Participação em abates (suporte)", _groups(cs),
                          "O suporte ganha jogo estando nas lutas e nos objetivos certos.",
                          "Depois de colocar visão, ande com quem vai lutar: siga o caçador nos objetivos e o meio quando ele rotacionar."))
        cs = []
    out.append(_lever("csdiff10", "CS contra o oponente aos 10 minutos", _groups(cs),
                      "Perder a disputa de farm na rota costuma virar vantagem de ouro e de itens para o inimigo.",
                      "Antes de jogar, 10 minutos de treino de last hit. Na partida, priorize o abate do minion sobre a troca de dano "
                      "quando o oponente ainda tem as habilidades prontas."))

    gd = [("Ouro à frente do oponente aos 15", [g for g in tl if g.get("golddiff15") is not None and g["golddiff15"] > 0]),
          ("Ouro atrás ou igual aos 15", [g for g in tl if g.get("golddiff15") is not None and g["golddiff15"] <= 0])]
    out.append(_lever("gold15", "Ouro contra o oponente aos 15 minutos", _groups(gd),
                      "Resume farm, abates e mortes da fase de rotas em um número só.",
                      "Se você costuma estar atrás aos 15, o trabalho está antes: mortes cedo e CS aos 10 (veja os fatores acima)."))

    short, mid_, long_ = ([g for g in games if g["duration_s"] < 1500], [g for g in games if 1500 <= g["duration_s"] < 1920],
                          [g for g in games if g["duration_s"] >= 1920])
    out.append(_lever("duration", "Duração da partida", _groups([("até 25 min", short), ("25 a 32 min", mid_), ("mais de 32 min", long_)]),
                      "Se você vence mais as longas, talvez esteja perdendo o jogo cedo e se recuperando depois (ou o contrário).",
                      "Se vence mais tarde: jogue a fase de rotas para não perder (farm seguro) e use o poder do fim de jogo. "
                      "Se vence mais cedo: converta vantagem em objetivos antes de o jogo esfriar."))

    vis = [g for g in games if g.get("vision_per_min")]
    if len(vis) >= 2 * MIN_GROUP:
        med = statistics.median(g["vision_per_min"] for g in vis)
        out.append(_lever("vision", "Visão por minuto", _groups([("acima da sua mediana", [g for g in vis if g["vision_per_min"] >= med]),
                                                                  ("abaixo da sua mediana", [g for g in vis if g["vision_per_min"] < med])]),
                          "Compara só os seus jogos; não é a meta oficial de ninguém.",
                          "Só vale priorizar se os números abaixo mostrarem diferença entre os grupos."))

    champs = {}
    for g in games:
        champs.setdefault(g["champion"], []).append(g)
    big = sorted(champs.items(), key=lambda kv: -len(kv[1]))[:4]
    out.append(_lever("pool", "Campeão", _groups([(n, xs) for n, xs in big]),
                      "Quem tem mais jogos tem número mais confiável.",
                      "Concentre as partidas nos campeões com boa taxa e jogos suficientes; teste novos campeões fora da ranqueada."))

    pos = {}
    for g in games:
        pos.setdefault(g["position"] or "?", []).append(g)
    names = {"MIDDLE": "Meio", "JUNGLE": "Selva", "TOP": "Topo", "BOTTOM": "Atirador", "UTILITY": "Suporte"}
    out.append(_lever("role", "Rota", _groups([(names.get(p, p), xs) for p, xs in sorted(pos.items(), key=lambda kv: -len(kv[1]))[:3]]),
                      "Mostra onde seus resultados são melhores.",
                      "Se uma rota rende bem menos, pense em jogar só a mais forte enquanto sobe de elo."))

    bands = {}
    for g in games:
        h = time.localtime((g["started_ms"] or 0) / 1000).tm_hour
        bands.setdefault(h // 6, []).append(g)
    nm = {0: "madrugada (0-6h)", 1: "manhã (6-12h)", 2: "tarde (12-18h)", 3: "noite (18-24h)"}
    out.append(_lever("hour", "Horário em que joga", _groups([(nm[k], bands[k]) for k in sorted(bands)]),
                      "Cansaço, horário de fila e distração podem pesar; os números podem ser só amostra.",
                      "Se um horário rende muito pior, teste não jogar ranqueada nele por um tempo e compare."))

    chron = sorted(games, key=lambda g: g["started_ms"] or 0)
    after_l, after_w = [], []
    for a, b in zip(chron, chron[1:]):
        if (b["started_ms"] or 0) - (a["started_ms"] or 0) < 4 * 3600 * 1000:
            (after_l if not a["win"] else after_w).append(b)
    out.append(_lever("tilt", "Jogo logo depois de uma derrota", _groups([("depois de derrota", after_l), ("depois de vitória", after_w)]),
                      "Mostra se jogar em sequência depois de perder piora o resultado.",
                      "Se cair muito depois de derrota, use a regra das 2 derrotas: parar depois de perder duas seguidas."))
    out = [x for x in out if x]
    actionable = {"deaths10", "csdiff10", "gold15"}
    for x in out:
        x["actionable"] = x["key"] in actionable
    out.sort(key=lambda x: (not x["pesa"], not x["actionable"], -x["weight"]))
    return out


def reading(lv):
    """Linhas marcadas (dado / hipotese / regra geral) para um fator."""
    from .tags import DADO, HIPOTESE, REGRA, tip
    ok = sorted([g for g in lv["groups"] if g["n"] >= MIN_GROUP], key=lambda g: -g["wr"])
    hi, lo = ok[0], ok[-1]
    n = sum(g["n"] for g in lv["groups"])
    if lv["pesa"]:
        out = [tip(DADO, f"{hi['label']}: {hi['wr']}% de vitória ({hi['n']} jogos). {lo['label']}: {lo['wr']}% ({lo['n']} jogos). "
                         f"Diferença de {lv['gap']} pontos.", n)]
        out.append(tip(HIPOTESE, lv["why"] + " É correlação nos seus jogos, não prova de causa."))
        out.append(tip(REGRA, lv["training"]))
    else:
        out = [tip(DADO, f"{hi['label']}: {hi['wr']}% ({hi['n']} jogos). {lo['label']}: {lo['wr']}% ({lo['n']} jogos). "
                         "Quase sem diferença: nos seus jogos isto não separa vitória de derrota.", n)]
    return out
