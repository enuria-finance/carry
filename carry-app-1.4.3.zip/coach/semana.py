"""Resumo da semana: estes 7 dias contra os 7 anteriores. O que melhorou, o que piorou e se o combinado foi cumprido
(jogar de main, parar depois de 2 derrotas, nada depois das 23h)."""
import html
import time

e = lambda x: html.escape("" if x is None else str(x))
DAY = 86400000


def _avg(gs, k):
    v = [g[k] for g in gs if g.get(k) is not None]
    return sum(v) / len(v) if v else None


def _discipline(gs, main):
    """(partidas com o main, partidas depois das 23h, partidas jogadas depois de 2 derrotas seguidas no mesmo dia)."""
    on_main = sum(1 for g in gs if g["champion"] == main)
    late = sum(1 for g in gs if g.get("started_ms") and (time.localtime(g["started_ms"] / 1000).tm_hour >= 23
                                                          or time.localtime(g["started_ms"] / 1000).tm_hour < 5))
    tilt, streak, day = 0, 0, None
    for g in sorted(gs, key=lambda x: x.get("started_ms") or 0):
        d = time.strftime("%Y%m%d", time.localtime((g.get("started_ms") or 0) / 1000))
        if d != day:
            day, streak = d, 0
        if streak >= 2:
            tilt += 1
        streak = 0 if g["win"] else streak + 1
    return on_main, late, tilt


def build(con, puuid):
    from . import report
    gs = report.my_games(con, puuid, "")
    now = int(time.time() * 1000)
    a = [g for g in gs if (g.get("started_ms") or 0) >= now - 7 * DAY]
    b = [g for g in gs if now - 14 * DAY <= (g.get("started_ms") or 0) < now - 7 * DAY]
    cnt = {}
    for g in gs[:100]:
        cnt[g["champion"]] = cnt.get(g["champion"], 0) + 1
    main = max(cnt, key=cnt.get) if cnt else None
    return {"a": a, "b": b, "main": main}


def html_page(R):
    a, b, main = R["a"], R["b"], R["main"]
    if not a:
        return "<div class='card'><p class='n'>Nenhuma partida nos últimos 7 dias.</p></div>"
    wr = lambda gs: round(100 * sum(1 for g in gs if g["win"]) / len(gs)) if gs else None
    rows = [("Partidas", len(a), len(b), None, "{:.0f}"),
            ("Vitórias", wr(a), wr(b), True, "{:.0f}%"),
            ("Farm aos 10", _avg(a, "cs10"), _avg(b, "cs10"), True, "{:.0f}"),
            ("Farm contra o oponente aos 10", _avg(a, "csdiff10"), _avg(b, "csdiff10"), True, "{:+.0f}"),
            ("Mortes antes dos 10", _avg(a, "deaths_before_10"), _avg(b, "deaths_before_10"), False, "{:.1f}"),
            ("Participação em abates", _avg(a, "kp"), _avg(b, "kp"), True, "{:.0%}"),
            ("Visão por minuto", _avg(a, "vision_per_min"), _avg(b, "vision_per_min"), True, "{:.2f}")]
    better, worse, body = [], [], ""
    for lb, x, y, hi, fm in rows:
        cls = ""
        if hi is not None and x is not None and y is not None and x != y:
            good = (x > y) == hi
            cls = "up" if good else "dn"
            (better if good else worse).append(lb.lower())
        body += (f"<div style='display:grid;grid-template-columns:1fr 100px 100px;gap:8px;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.05)'>"
                 f"<span>{e(lb)}</span><b class='{cls}' style='text-align:right'>{e(fm.format(x)) if x is not None else '-'}</b>"
                 f"<span style='text-align:right;color:var(--mute)'>{e(fm.format(y)) if y is not None else '-'}</span></div>")
    head = ("<div style='display:grid;grid-template-columns:1fr 100px 100px;gap:8px;font-size:12px;color:var(--mute)'><span></span>"
            "<span style='text-align:right'>esta semana</span><span style='text-align:right'>semana passada</span></div>")
    out = "<div class='card'><b class='gl'>Esta semana contra a passada</b>" + head + body + "</div>"
    sm = []
    if better:
        sm.append("Melhorou: " + ", ".join(better) + ".")
    if worse:
        sm.append("Piorou: " + ", ".join(worse) + ".")
    if sm:
        out += "<div class='card verdict'><b class='gl'>Resumo</b>" + "".join(f"<p>{e(x)}</p>" for x in sm) + "</div>"
    if main:
        on_main, late, tilt = _discipline(a, main)
        out += ("<div class='card'><b class='gl'>O combinado</b>"
                f"<p>Partidas com {e(main)}: <b>{on_main} de {len(a)}</b> ({round(100 * on_main / len(a))}%).</p>"
                f"<p>Partidas depois das 23h: <b>{late}</b>.</p>"
                f"<p>Partidas jogadas depois de 2 derrotas seguidas no mesmo dia: <b>{tilt}</b>.</p>"
                + ("<p class='n'>Combinado cumprido. É assim que o PDL fica.</p>" if on_main >= len(a) * 0.8 and late == 0 and tilt == 0 else
                   "<p class='n'>Cada uma dessas partidas fora do combinado é onde o PDL costuma ir embora.</p>") + "</div>")
    return out
