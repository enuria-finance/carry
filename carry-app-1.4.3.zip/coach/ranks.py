"""Historico de elo: guarda o PDL a cada sincronizacao e desenha a subida com as faixas de elo ao fundo."""
import html
import time

TIERS = ["IRON", "BRONZE", "SILVER", "GOLD", "PLATINUM", "EMERALD", "DIAMOND", "MASTER", "GRANDMASTER", "CHALLENGER"]
DIVS = {"IV": 0, "III": 1, "II": 2, "I": 3}
APEX = 2800  # Mestre comeca aqui (7 elos x 400)
e = lambda x: html.escape("" if x is None else str(x))


def _ensure(con):
    con.execute("""CREATE TABLE IF NOT EXISTS rank_history (
        at_ms INTEGER PRIMARY KEY, tier TEXT, division TEXT, lp INTEGER, wins INTEGER, losses INTEGER)""")


def ladder(tier, division, lp):
    """Numero unico para o grafico: Ferro IV 0 PDL = 0; cada divisao 100; Mestre+ = 2800 + PDL."""
    t = (tier or "").upper()
    if t not in TIERS:
        return None
    i = TIERS.index(t)
    if i >= 7:
        return APEX + (lp or 0)
    return i * 400 + DIVS.get(division or "IV", 0) * 100 + (lp or 0)


def record(con, tier, division, lp, wins, losses, now_ms=None):
    """Salva um ponto se algo mudou (ou se passou 1 dia)."""
    _ensure(con)
    now_ms = now_ms or int(time.time() * 1000)
    last = con.execute("SELECT * FROM rank_history ORDER BY at_ms DESC LIMIT 1").fetchone()
    if last and (last["tier"], last["division"], last["lp"], last["wins"], last["losses"]) == (tier, division, lp, wins, losses) \
            and now_ms - last["at_ms"] < 86400000:
        return False
    con.execute("INSERT OR REPLACE INTO rank_history VALUES (?,?,?,?,?,?)", (now_ms, tier, division, lp, wins, losses))
    con.commit()
    return True


def history(con):
    _ensure(con)
    out = []
    for r in con.execute("SELECT * FROM rank_history ORDER BY at_ms"):
        v = ladder(r["tier"], r["division"], r["lp"])
        if v is not None:
            out.append({**dict(r), "v": v})
    return out


def delta_days(hist, days=14):
    if len(hist) < 2:
        return None
    cut = hist[-1]["at_ms"] - days * 86400000
    base = next((h for h in hist if h["at_ms"] >= cut), hist[0])
    return hist[-1]["v"] - base["v"]


TIER_PT = {"IRON": "Ferro", "BRONZE": "Bronze", "SILVER": "Prata", "GOLD": "Ouro", "PLATINUM": "Platina", "EMERALD": "Esmeralda",
           "DIAMOND": "Diamante", "MASTER": "Mestre", "GRANDMASTER": "Grão-Mestre", "CHALLENGER": "Desafiante"}


def chart(hist, colors, w=640, h=210):
    """SVG da subida. Faixas coloridas por elo; linha que se desenha ao abrir."""
    if len(hist) < 2:
        return ("<div class='empty'><span class='em'>📈</span><b>Sua subida começa hoje</b>"
                "<span>A cada sincronização o app guarda o seu PDL. Em poucos dias aparece aqui a linha da sua evolução.</span></div>")
    vs = [p["v"] for p in hist]
    lo = max(0, (min(vs) // 100) * 100 - 50)
    hi = (max(vs) // 100 + 1) * 100 + 50
    if hi - lo < 300:
        hi = lo + 300
    t0, t1 = hist[0]["at_ms"], hist[-1]["at_ms"]
    X = lambda t: 34 + (w - 44) * ((t - t0) / max(t1 - t0, 1))
    Y = lambda v: 10 + (h - 30) * (1 - (v - lo) / (hi - lo))
    bands = ""
    for i, t in enumerate(TIERS[:7]):
        b0, b1 = i * 400, (i + 1) * 400
        if b1 <= lo or b0 >= hi:
            continue
        y0, y1 = Y(min(b1, hi)), Y(max(b0, lo))
        c = colors.get(t, "#888")
        bands += (f"<rect x='34' y='{y0:.1f}' width='{w - 44}' height='{y1 - y0:.1f}' fill='{c}' opacity='.09'/>"
                  f"<line x1='34' x2='{w - 10}' y1='{y0:.1f}' y2='{y0:.1f}' stroke='{c}' stroke-opacity='.35' stroke-dasharray='3 5'/>"
                  f"<text x='40' y='{y0 + 14:.1f}' class='lb' fill='{c}'>{e(TIER_PT[t])}</text>")
        for d in range(1, 4):
            yv = b0 + d * 100
            if lo < yv < hi:
                bands += f"<line x1='34' x2='{w - 10}' y1='{Y(yv):.1f}' y2='{Y(yv):.1f}' stroke='{c}' stroke-opacity='.12'/>"
    if hi > APEX:
        y0 = Y(hi)
        bands += f"<rect x='34' y='{y0:.1f}' width='{w - 44}' height='{Y(max(APEX, lo)) - y0:.1f}' fill='{colors.get('MASTER', '#b968e0')}' opacity='.1'/>"
    pts = " ".join(f"{X(p['at_ms']):.1f},{Y(p['v']):.1f}" for p in hist)
    area = f"M34,{h - 20} L" + " L".join(f"{X(p['at_ms']):.1f},{Y(p['v']):.1f}" for p in hist) + f" L{X(t1):.1f},{h - 20} Z"
    last = hist[-1]
    dots = "".join(f"<circle cx='{X(p['at_ms']):.1f}' cy='{Y(p['v']):.1f}' r='3' class='pt'><title>{e(TIER_PT.get(p['tier'], p['tier']))} "
                   f"{e(p['division'] or '')} {p['lp']} PDL · {time.strftime('%d/%m', time.localtime(p['at_ms'] / 1000))}</title></circle>" for p in hist)
    d0 = time.strftime('%d/%m', time.localtime(t0 / 1000))
    d1 = time.strftime('%d/%m', time.localtime(t1 / 1000))
    return (f"<svg class='ladder' viewBox='0 0 {w} {h}' role='img' aria-label='Evolução do PDL'>"
            f"<defs><linearGradient id='lad' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='var(--gold)' stop-opacity='.35'/>"
            f"<stop offset='1' stop-color='var(--gold)' stop-opacity='0'/></linearGradient></defs>{bands}"
            f"<path d='{area}' class='ar' fill='url(#lad)'/><polyline points='{pts}' class='ln' pathLength='1'/>{dots}"
            f"<circle cx='{X(last['at_ms']):.1f}' cy='{Y(last['v']):.1f}' r='6' class='now'/>"
            f"<text x='34' y='{h - 4}' class='lb'>{d0}</text><text x='{w - 10}' y='{h - 4}' class='lb' text-anchor='end'>{d1}</text></svg>")


def trends(games, window=10):
    """Ultimos `window` jogos contra os `window` anteriores, nas medidas que mais importam."""
    defs = [("deaths_before_10", "Mortes antes dos 10", False, 1), ("cs_per_min", "CS por minuto", True, 1),
            ("csdiff10", "CS contra o oponente aos 10", True, 1), ("golddiff15", "Ouro contra o oponente aos 15", True, 0),
            ("vision_per_min", "Visão por minuto", True, 2), ("kp", "Participação em abates", True, 0)]
    if len(games) < window + 5:
        return []
    rec, prev = games[:window], games[window:2 * window]
    out = []
    for key, label, higher, nd in defs:
        a = [g[key] for g in rec if g.get(key) is not None]
        b = [g[key] for g in prev if g.get(key) is not None]
        if len(a) < 5 or len(b) < 5:
            continue
        ma, mb = sum(a) / len(a), sum(b) / len(b)
        if key == "kp":
            ma, mb = ma * 100, mb * 100
        diff = ma - mb
        better = (diff > 0) == higher
        series = [g[key] * (100 if key == "kp" else 1) for g in reversed(games[:30]) if g.get(key) is not None]
        out.append({"label": label, "now": ma, "before": mb, "diff": diff, "better": better, "nd": nd,
                    "flat": abs(diff) < (0.05 * max(abs(mb), 1)), "series": series, "n": len(a)})
    return out
