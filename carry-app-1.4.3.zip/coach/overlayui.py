"""Pagina "Editar overlay": escolher o que aparece no jogo, tamanho, transparencia, cor e posicao, com previa ao vivo.

A previa e uma tela de jogo generica (desenho proprio, sem arte da Riot). Arrastar a faixa na previa muda a posicao
no jogo (guardada em fracao da tela, entao vale para qualquer resolucao). Cada mudanca salva sozinha e o overlay
aberto aplica em ate 2 segundos.
"""
import html
import json

from . import overlay

e = lambda s: html.escape(str(s), quote=True)

SHOW = [("plan", "Plano do momento", "No topo da faixa: o que fazer agora, pela fase e pelo placar (objetivo chegando, inimigos mortos, vantagem ou desvantagem)."),
        ("lanes", "Ouro por rota", "Diferença de itens do seu time contra o inimigo, no total e rota por rota (a sua fica destacada)."),
        ("item", "Próximo item", "Ícone e nome do item que vem a seguir na sua build."),
        ("gold", "Barra de ouro", "Quanto falta para comprar o próximo item."),
        ("after", "Itens seguintes", "Os dois itens depois do próximo, pequenos."),
        ("cdstrip", "Recargas do oponente", "Sempre na faixa: recarga das habilidades do seu oponente de rota (e da ultimate depois do nível 6)."),
        ("note", "Linha de informação", "Inimigos mortos e o tempo de volta, objetivo chegando, dica contra o seu oponente."),
        ("toasts", "Avisos na tela", "Mensagens curtas que aparecem por alguns segundos.")]
MM = [("mm_obj", "Dragão, Barão, Larvas e Arauto", "Contagem no fosso do minimapa."),
      ("mm_camps", "Nascimento dos acampamentos", "0:55 dos acampamentos (Gromp e Krugs 1:07) e 2:55 dos caranguejos, no começo da partida."),
      ("mm_jungle", "Timers da selva (Ctrl+Shift+J)", "O tempo de volta do acampamento que você marcar.")]
ALERTS = [("a_obj", "Objetivo nascendo"), ("a_gold", "Ouro para o item"), ("a_lane", "Oponente de rota morto"),
          ("a_lvl6", "Nível 6 (seu e do oponente)"), ("a_edead", "Vários inimigos mortos"), ("a_mission", "Missão do dia (no começo e se ela estourar)")]
ALERTS2 = [("voz_essencial", "Voz: só o necessário", "Ligado: fala só o que muda a jogada (Flash e ult marcados voltando, vantagem ou desvantagem de gente, Barão, Ancião, inibidor, objetivo chegando, caçador inimigo perto de você) e espaça o resto. Desligado: fala todos os avisos marcados abaixo."),
           ("a_select", "Seleção de campeões", "Sua vez de banir ou escolher, seu histórico contra o oponente, o perfil do time inimigo. Só voz (o overlay precisa estar ligado)."),
           ("a_map", "Lembretes de olhar o mapa", "No fim da primeira volta do caçador inimigo (perto de 3:00) e quando o caçador ou o suporte deles volta à vida."),
           ("a_mapnudge", "Olhar o mapa a cada minuto", "Um lembrete curto por minuto, dos 3 aos 15 minutos. Bom para criar o hábito."),
           ("a_enemyitem", "Itens do inimigo", "Quando o seu oponente completa um item grande, ou alguém fecha Zhonya, Anjo, Véu e parecidos."),
           ("a_farm", "Farm e visão aos 10 minutos", "Comparado com a sua própria média."),
           ("a_habit", "Seus hábitos", "Avisa na janela de tempo em que você mais morre, pelo seu histórico."),
           ("a_cd", "Recargas do oponente", "No começo: a recarga das habilidades e os feitiços dele. Depois, a recarga da ultimate nos níveis 6, 11 e 16 (dado do jogo, sem rastrear quando ele usa)."),
           ("a_threat", "Inimigo forte", "Quando alguém do outro time está com muitos abates."),
           ("a_self", "Sobre você", "Quando você morre (tempo de volta, ouro, sem sentinela), item completo e os picos de poder do seu campeão."),
           ("quiet_fight", "Silêncio nas lutas", "Segura as falas por alguns segundos quando morrem 2 ou mais campeões ao mesmo tempo, e fala depois."),
           ("a_events", "Lances da partida", "Primeiro abate, abates triplos ou mais, ace, torres e Arauto."),
           ("a_jgvis", "Jungler inimigo visto (beta)", "Lê só o seu minimapa na tela. Na fase de rotas, fala \"Cuidado, jungler deles perto\" só quando ele aparece perto da sua rota (longe, fica quieto) e, a qualquer momento, \"bom momento pro Dragão\" quando ele está do outro lado. Precisa da caixa do overlay alinhada com o minimapa (Ctrl+Shift+M)."),
           ("a_mmlook", "Lembrete de olhar o minimapa", "Na fase de rotas, quando o jungler deles some por quase 1 minuto. No máximo 6 vezes por partida. Precisa do aviso de jungler visto ligado."),
           ("auto_aceitar", "Aceitar a fila sozinho", "Quando a partida for encontrada, o Carry aceita por você (desligado por padrão)."),
           ("a_det", "Detalhes da partida", "Runa, feitiços e item inicial do oponente, farm aos 5/10/15/20 min, item que muda a sua jogada (Zhonya, Anjo, Mercúrio), pico de item, jungler deles aparecendo em outra rota, recompensa, quem mais te mata e alvo do combo para assassinos."),
           ("a_mytips", "Dicas do seu campeão", "Para qualquer campeão: uma dica no começo, como usar a ult no nível 6, o erro comum na primeira morte e uma dica nova aos 14 e aos 28 minutos ou quando você está morto esperando."),
           ("a_role", "Dicas da sua rota", "Modo por rota: rota de acampamentos e ganks (selva), visão e Sentinela de Controle (suporte), Teleporte e Arauto (topo), caranguejo (meio), picos de item (atirador)."),
           ("a_matchup", "Como jogar contra", "Dicas oficiais contra o seu oponente no começo e quando ele te mata, e item de defesa se ele ficar forte."),
           ("a_timers", "Buffs e inibidores", "Quando o buff do Barão ou do Ancião está acabando e quando um inibidor vai voltar.")]
PANEL_ROWS = [("p_plan", "Dicas da fase", "Fase de rotas, meio ou fim de jogo: 2 ou 3 dicas com os nomes dos campeões da partida."),
              ("p_cs", "Seu farm", "Farm e farm por minuto, comparado com a sua média."),
              ("p_lane", "Oponente de rota", "Nível dele contra o seu."),
              ("p_gold", "Itens: você contra ele", "Valor dos itens de cada um (o que o placar mostra)."),
              ("p_team", "Times", "Diferença de itens entre os times e os abates."),
              ("p_obj", "Objetivos", "Tempo do próximo dragão e Barão."),
              ("p_cd", "Recargas do oponente", "Recarga de cada habilidade dele (a ultimate muda nos níveis 11 e 16)."),
              ("p_tm", "Buffs e inibidores", "Quanto falta para o buff do Barão ou do Ancião acabar e para um inibidor voltar.")]
ACCENTS = [("main", "Cor do main"), ("game", "Campeão da partida"), ("gold", "Dourado"), ("green", "Verde"), ("blue", "Azul")]
PRESETS = [("Canto de cima, esquerda", 0.008, 0.013), ("Topo, centro", 0.44, 0.013), ("Canto de cima, direita", 0.80, 0.013),
           ("Esquerda, meio", 0.008, 0.40)]

CSS = """
.oe [hidden],.oe-zoom [hidden]{display:none !important}
.oe{display:grid;grid-template-columns:minmax(0,1fr) 360px;gap:22px;align-items:start}
@media (max-width:1180px){.oe{grid-template-columns:1fr}}
.oe-stage{position:sticky;top:18px}
.oe-scr{position:relative;aspect-ratio:16/9;border-radius:16px;overflow:hidden;border:1px solid var(--line);user-select:none;
background:radial-gradient(120% 90% at 30% 30%,#2a3a2e 0,#1b2620 45%,#111814 100%)}
.oe-scr::before{content:'';position:absolute;inset:0;background:
radial-gradient(circle at 62% 58%,rgba(120,150,110,.25) 0 8%,transparent 9%),
linear-gradient(115deg,transparent 46%,rgba(70,110,140,.35) 47% 53%,transparent 54%),
repeating-linear-gradient(0deg,rgba(255,255,255,.02) 0 2px,transparent 2px 40px);opacity:.9}
.oe-hud{position:absolute;left:50%;bottom:1.5%;transform:translateX(-50%);width:34%;height:11%;border-radius:10px 10px 4px 4px;
background:linear-gradient(#20242c,#14171d);border:1px solid #333a46}
.oe-hud::before{content:'';position:absolute;left:24%;right:24%;top:22%;height:34%;border-radius:4px;
background:repeating-linear-gradient(90deg,#2b313c 0 15%,transparent 15% 17%)}
.oe-top{position:absolute;right:0;top:0;width:15%;height:4%;background:#14171d;border-bottom-left-radius:6px;border:1px solid #2a2f39;border-top:0;border-right:0}
.oe-mm{position:absolute;right:.6%;bottom:1%;width:15.5%;aspect-ratio:1;border:1px solid #3a4250;border-radius:3px;overflow:hidden;
background:linear-gradient(135deg,#25331f 0,#1f2b1b 100%)}
.oe-mm::before{content:'';position:absolute;inset:0;background:linear-gradient(135deg,transparent 47%,rgba(80,130,160,.55) 48% 52%,transparent 53%)}
.oe-mm::after{content:'';position:absolute;inset:0;background:
linear-gradient(45deg,transparent 48.5%,rgba(200,190,150,.25) 49% 51%,transparent 51.5%),
linear-gradient(0deg,transparent 0 6%,rgba(200,190,150,.22) 6% 8%,transparent 8%),
linear-gradient(90deg,transparent 0 6%,rgba(200,190,150,.22) 6% 8%,transparent 8%)}
.oe-mm i{position:absolute;transform:translate(-50%,-50%);font:900 var(--mmf,11px)/1 var(--body);color:#ede7dc;
text-shadow:0 0 2px #000,0 0 3px #000,1px 1px 0 #000;font-style:normal;z-index:1;white-space:nowrap}
.oe-mm i.c{color:#DDD3C7;font-weight:700;font-size:calc(var(--mmf,11px)*.8)}
.oe-mm i.y{color:#E9C46A}
.oe-strip{position:absolute;left:var(--x,1%);top:var(--y,1.5%);transform-origin:top left;cursor:grab;touch-action:none;z-index:3}
.oe-strip.drag{cursor:grabbing}
.oe-eb .in{background:#0D0E16;padding:5px;border-radius:8px;display:grid;grid-template-columns:repeat(4,26px);gap:3px;box-shadow:0 2px 10px rgba(0,0,0,.4)}
.oe-eb .in i{width:26px;height:26px;border-radius:4px;background:#2A1F1E;display:flex;align-items:center;justify-content:center;font:600 10px 'Segoe UI';color:#ede7dc;font-style:normal;background-size:cover}
.oe-eb .in i.c{border:1px solid #3a2d2b}.oe-eb .in i.m{background:#000;color:#fff}
.oe-bb .in{display:flex;align-items:center;gap:8px;background:#1B1112 !important;border:2px solid var(--oac,var(--ac)) !important;border-radius:12px !important;padding:8px 12px 8px 9px;max-width:300px;box-shadow:0 2px 10px rgba(0,0,0,.4)}
.oe-bb .in::before{display:none}.oe-bb .in i{flex:none;width:26px;height:26px;border-radius:50%;background:var(--oac,var(--ac));color:#fff;font:700 12px 'Segoe UI';display:flex;align-items:center;justify-content:center;font-style:normal}
.oe-bb .in span{color:#fff;font:600 13px 'Segoe UI'}
.oe-preset{display:flex;gap:8px;flex-wrap:wrap;margin:6px 0 10px}
.oe-scr.rift{background:linear-gradient(180deg,rgba(6,10,8,.12),rgba(6,10,8,.3)),var(--rift) center/cover no-repeat,#0d1410}
.oe-scr.rift::before{display:none}
.oe-scr.rift .oe-mm{background:var(--map) center/cover no-repeat,#0d1410}.oe-scr.rift .oe-mm::before,.oe-scr.rift .oe-mm::after{display:none}
.oe-scr.shot{background:var(--rift) center/100% 100% no-repeat,#000}.oe-scr.shot .oe-hud,.oe-scr.shot .oe-top{display:none}
.oe-scr.shot .oe-mm{background:transparent;border:1px dashed rgba(255,211,107,.7)}
.oe-bgup{display:flex;gap:8px;align-items:center}.oe-bgup .btn{padding:6px 12px !important;font-size:13px !important;cursor:pointer}
.oe-strip .in,.oe-strip2 .in{border-radius:3px !important;border:1px solid #2A2B3B;position:relative}
.oe-strip .in::before,.oe-strip2 .in::before{content:'';position:absolute;left:-1px;width:46%;top:-1px;height:2px;background:#D9B45A}
.oe-mid b::before{content:'PRÓXIMO ITEM';display:block;font:600 8px/1.3 'Segoe UI',var(--body);color:#8e9ab0;letter-spacing:.02em}
.oe-pb .in{width:272px !important}
.oe-pb .in{width:236px;background:#0D0E16;padding:7px 9px;font:400 10.5px/1.45 'Segoe UI',var(--body);color:#8e9ab0;box-shadow:0 2px 10px rgba(0,0,0,.4)}
.oe-pb .in b{display:block;font:600 12px/1.3 'Segoe UI',var(--body);color:#ede7dc;margin-bottom:2px}.oe-pb .g{color:#6BBF8A}.oe-pb .r{color:#D9534F}.oe-pb .y{color:#E9C46A}
.oe-strip .in{width:236px;background:#0D0E16;border-radius:2px;padding:7px 8px;font-family:'Segoe UI',var(--body);box-shadow:0 2px 10px rgba(0,0,0,.4)}
.oe-strip.drag .in{outline:2px solid var(--ac)}
.oe-row{display:flex;align-items:center;gap:8px}.oe-ic{width:36px;height:36px;border-radius:2px;flex:none;
background:linear-gradient(135deg,#5b6577,#2b313c);display:grid;place-items:center}
.oe-ic::after{content:'';width:55%;height:55%;background:linear-gradient(135deg,#d9dde6,#7d8696);clip-path:polygon(50% 0,100% 50%,50% 100%,0 50%)}
.oe-mid{flex:1;min-width:0}.oe-mid b{display:block;font:600 12px/1.25 'Segoe UI',var(--body);color:#ede7dc;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.oe-bar{height:3px;background:#272c39;margin:3px 0 2px}.oe-bar span{display:block;height:100%;width:69%;background:var(--oac,var(--ac))}
.oe-mid small{display:block;font:400 10.5px/1.2 'Segoe UI',var(--body);color:#8e9ab0}
.oe-nx{display:flex;gap:3px}.oe-nx span{width:20px;height:20px;border-radius:2px;background:linear-gradient(135deg,#5a4a7a,#2c2540)}
.oe-nx span+span{background:linear-gradient(135deg,#7a4a4a,#40252a)}
.oe-toast{margin-top:6px;background:#232838;color:#ede7dc;padding:5px 8px;font:600 12px/1.3 'Segoe UI',var(--body)}
.oe-note{margin-top:5px;color:#ede7dc;font:400 10.5px/1.3 'Segoe UI',var(--body)}
.oe-sel{width:100%;padding:8px 10px;border-radius:10px;background:#1a1312;color:#F0E4CC;border:1px solid var(--rule);font:500 13px var(--body)}
.oe-cap{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-top:10px;color:var(--steel);font-size:13.5px}
.oe-cap b{color:var(--bone);font-weight:600}
.oe-p{display:flex;flex-direction:column;gap:14px}
.oe-box{background:var(--raised);border:1px solid var(--line);border-radius:14px;padding:16px 16px 12px;position:relative}
.oe-box::after{content:'';position:absolute;left:18px;right:18px;top:-1px;height:1px;background:linear-gradient(90deg,transparent,#c8aa6e,transparent)}
.oe-box>b{display:block;font:700 19px var(--d);margin-bottom:8px;color:var(--bone)}
.oe-t{display:flex;align-items:flex-start;gap:12px;padding:8px 0;border-top:1px solid rgba(255,255,255,.04);cursor:pointer}
.oe-t:first-of-type{border-top:0}.oe-t span{flex:1}.oe-t strong{display:block;font:600 14px var(--body);color:var(--bone)}
.oe-t small{display:block;color:var(--steel);font-size:12.5px;line-height:1.35;margin-top:1px}
.oe-t input{appearance:none;-webkit-appearance:none;flex:none;width:38px;height:22px;border-radius:999px;background:#2a2f3b;border:1px solid var(--line);
position:relative;cursor:pointer;margin:1px 0 0;transition:background .2s,border-color .2s;padding:0 !important}
.oe-t input::after{content:'';position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background:#8e9ab0;transition:transform .2s,background .2s}
.oe-t input:checked{background:var(--acm);border-color:var(--ac)}.oe-t input:checked::after{transform:translateX(16px);background:#fff}
.oe-t input:focus-visible{outline:2px solid var(--ac);outline-offset:2px}
.oe-al{display:grid;grid-template-columns:1fr;gap:0}
.oe-zoom{position:relative;overflow:hidden;border-radius:10px;padding:14px;background:linear-gradient(rgba(8,12,10,.5),rgba(8,12,10,.5)),var(--rift,radial-gradient(120% 120% at 30% 30%,#2a3a2e,#141c17)) 30% 40%/cover;min-height:90px}
.oe-strip2{transform-origin:top left;display:inline-block}.oe-al .oe-t{border-top:0;padding:6px 0}
.oe-s{display:grid;grid-template-columns:1fr auto;gap:2px 10px;align-items:center;padding:6px 0}
.oe-s label{font:600 14px var(--body);color:var(--bone)}.oe-s output{font:600 13px var(--body);color:#c8aa6e;font-variant-numeric:tabular-nums}
.oe-s input[type=range]{grid-column:1/-1;width:100%;accent-color:var(--ac);padding:0 !important;border:0 !important;background:none !important;height:22px}
.oe-ch{display:flex;gap:8px;flex-wrap:wrap}.oe-ch label{cursor:pointer}.oe-ch input{position:absolute;opacity:0;pointer-events:none}
.oe-ch span{display:inline-flex;align-items:center;gap:7px;padding:7px 12px;border-radius:999px;border:1px solid var(--line);font:500 13.5px var(--body);color:var(--steel)}
.oe-ch span i{width:10px;height:10px;border-radius:50%;background:var(--c)}
.oe-ch input:checked+span{border-color:var(--bone);color:var(--bone);background:rgba(255,255,255,.04)}
.oe-ch input:focus-visible+span{outline:2px solid var(--ac);outline-offset:2px}
.oe-pr{display:grid;grid-template-columns:1fr 1fr;gap:8px}.oe-pr button{padding:8px 10px !important;font-size:13px !important}
.oe-act{display:flex;gap:8px;flex-wrap:wrap}.oe-act button,.oe-act .btn{flex:1;min-width:140px;justify-content:center;text-align:center}
.oe-saved{font-size:13px;color:var(--steel);min-height:18px}.oe-saved.ok{color:#6BBF8A}
.oe-keys{display:grid;grid-template-columns:auto 1fr;gap:6px 12px;font-size:13.5px;color:var(--steel)}
.oe-keys kbd{font:600 12px var(--body);color:var(--bone);background:#232838;border:1px solid var(--line);border-radius:6px;padding:2px 7px;white-space:nowrap}
"""

JS = """<script>(function(){
var f=document.getElementById('oef');if(!f)return;var st=document.getElementById('oes'),scr=document.getElementById('oescr'),sv=document.getElementById('oesaved');
var AC={main:getComputedStyle(document.documentElement).getPropertyValue('--ac').trim()||'#d7263d',game:getComputedStyle(document.documentElement).getPropertyValue('--ac').trim()||'#d7263d',gold:'#c8aa6e',green:'#6BBF8A',blue:'#8DA2C0'};
function v(n){var el=f.elements.namedItem(n);if(!el)return null;if(el.type==='checkbox')return el.checked;if(el.length&&el[0]&&el[0].type==='radio'){for(var i=0;i<el.length;i++)if(el[i].checked)return el[i].value;return null}return el.value}
function show(sel,on){document.querySelectorAll(sel).forEach(function(x){x.hidden=!on})}
function paint(){var W=scr.clientWidth/1920;
 var sc=v('scale')/100;st.style.transform='scale('+(sc*W*1.0)+')';
 var z=document.querySelector('.oe-strip2'),zb=document.getElementById('oez');z.style.transform='scale('+sc+')';
 document.querySelectorAll('.oe-strip .in,.oe-strip2 .in').forEach(function(x){x.style.opacity=v('opacity')/100});
 [st,z].forEach(function(x){x.style.setProperty('--oac',AC[v('accent')]||AC.main)});
 st.style.setProperty('--x',(parseFloat(f.elements.fx.value||0.008)*100)+'%');st.style.setProperty('--y',(parseFloat(f.elements.fy.value||0.013)*100)+'%');
 show('.oe-ic,.oe-mid',v('item'));show('.oe-bar,.oe-mid small',v('item')&&v('gold'));show('.oe-nx',v('after'));show('.oe-row',v('item')||v('after'));
 show('.oe-toast',v('toasts'));show('.oe-note',v('note')&&!v('toasts'));
 var mm=document.getElementById('oemm'),ms=v('mm_size')||26;mm.style.width=(ms*9/16)+'%';
 if(v('mm_side')==='left'){mm.style.left='.6%';mm.style.right='auto'}else{mm.style.right='.6%';mm.style.left='auto'}mm.style.setProperty('--mmf',Math.max(7,(mm.clientWidth/24)*v('mm_text')/100)+'px');
 show('.oe-mm i.o',v('mm_obj'));show('.oe-mm i.c',v('mm_camps'));show('.oe-mm i.j',v('mm_jungle'));
 ['scale','opacity','toast_secs','mm_text','mm_size','bub_size','bub_font','luta_vol'].forEach(function(n){var o=document.getElementById('o_'+n);if(o)o.textContent=v(n)+(n==='toast_secs'?' s':'%')});
 var pb=document.getElementById('oep');pb.style.transform='scale('+(sc*W)+')';pb.querySelector('.in').style.opacity=v('opacity')/100;
 pb.style.setProperty('--x',(parseFloat(f.elements.fx2.value||0.86)*100)+'%');pb.style.setProperty('--y',(parseFloat(f.elements.fy2.value||0.46)*100)+'%');
 pb.hidden=!v('panel');var ebx=document.getElementById('oeb');if(ebx){ebx.style.transform='scale('+(sc*W)+')';ebx.style.setProperty('--x',(parseFloat(f.elements.fx3.value||0.93)*100)+'%');ebx.style.setProperty('--y',(parseFloat(f.elements.fy3.value||0.36)*100)+'%');ebx.hidden=!v('ebar')}var bbx=document.getElementById('obb');if(bbx){bbx.style.transform='scale('+(sc*W)+')';bbx.style.setProperty('--x',(parseFloat(f.elements.fx4.value||0.74)*100)+'%');bbx.style.setProperty('--y',(parseFloat(f.elements.fy4.value||0.62)*100)+'%');bbx.hidden=!v('balao')}['cs','lane','gold','team','obj','cd','tm'].forEach(function(k){show('.pr-'+k,v('p_'+k))});
 var anyStrip=v('item')||v('after')||v('toasts')||v('note');st.hidden=!anyStrip;z.hidden=!anyStrip;
 zb.style.height=(anyStrip?z.querySelector('.in').offsetHeight*sc+28:60)+'px'}
var tmr;function save(){clearTimeout(tmr);sv.textContent='Salvando…';sv.className='oe-saved';tmr=setTimeout(function(){
 fetch(f.action,{method:'POST',body:new URLSearchParams(new FormData(f)),headers:{'X-Auto':'1'}}).then(function(r){sv.textContent=r.ok?'Salvo. O overlay aberto muda em até 2 segundos.':'Não deu para salvar.';sv.className='oe-saved'+(r.ok?' ok':'')}).catch(function(){sv.textContent='Não deu para salvar.'})},350)}
f.addEventListener('input',function(){paint();save()});f.addEventListener('change',function(){paint();save()});
document.querySelectorAll('[data-fx]').forEach(function(b){b.addEventListener('click',function(){f.elements.fx.value=b.dataset.fx;f.elements.fy.value=b.dataset.fy;paint();save()})});
function drag(el,nx,ny){var dr=null;el.addEventListener('pointerdown',function(ev){var r=scr.getBoundingClientRect(),b=el.getBoundingClientRect();dr={dx:ev.clientX-b.left,dy:ev.clientY-b.top,r:r};el.setPointerCapture(ev.pointerId);el.classList.add('drag')});
el.addEventListener('pointermove',function(ev){if(!dr)return;var b=el.getBoundingClientRect(),x=(ev.clientX-dr.dx-dr.r.left)/dr.r.width,y=(ev.clientY-dr.dy-dr.r.top)/dr.r.height;
 x=Math.max(0,Math.min(1-b.width/dr.r.width,x));y=Math.max(0,Math.min(1-b.height/dr.r.height,y));f.elements[nx].value=x.toFixed(4);f.elements[ny].value=y.toFixed(4);paint()});
el.addEventListener('pointerup',function(){if(!dr)return;dr=null;el.classList.remove('drag');save()});
el.addEventListener('keydown',function(ev){var k={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[ev.key];if(!k)return;ev.preventDefault();
 var s=ev.shiftKey?0.02:0.004;f.elements[nx].value=Math.max(0,Math.min(0.95,parseFloat(f.elements[nx].value||0)+k[0]*s)).toFixed(4);f.elements[ny].value=Math.max(0,Math.min(0.95,parseFloat(f.elements[ny].value||0)+k[1]*s)).toFixed(4);paint();save()})}
drag(st,'fx','fy');drag(document.getElementById('oep'),'fx2','fy2');var eb=document.getElementById('oeb');if(eb)drag(eb,'fx3','fy3');var bb=document.getElementById('obb');if(bb)drag(bb,'fx4','fy4');
var PRE={limpo:{plan:0,lanes:0,p_plan:0,item:1,gold:1,after:0,note:0,cdstrip:1,toasts:1,panel:0,ebar:0},tudo:{plan:1,lanes:1,p_plan:1,item:1,gold:1,after:1,note:1,cdstrip:1,toasts:1,panel:1,ebar:0}};
document.querySelectorAll('[data-preset]').forEach(function(b){b.addEventListener('click',function(){var P=PRE[b.dataset.preset];for(var k in P){var el=f.elements.namedItem(k);if(el&&el.type==='checkbox')el.checked=!!P[k]}paint();save()})});
var up=document.getElementById('oebg'),CS=CSRF_TOKEN;if(up)up.addEventListener('change',function(){var fl=up.files[0];if(!fl)return;sv.textContent='Enviando o print…';
 fetch('/overlay/fundo/enviar',{method:'POST',body:fl,headers:{'X-CSRF':CS}}).then(function(r){return r.json()}).then(function(d){if(d.ok)location.reload();else sv.textContent=d.erro||'Não deu para enviar.'})});
var bx=document.getElementById('oebgx');if(bx)bx.addEventListener('click',function(){fetch('/overlay/fundo/enviar',{method:'POST',body:'',headers:{'X-CSRF':CS}}).then(function(){location.reload()})});
addEventListener('resize',paint);paint();
})();</script>"""


def _toggle(k, title, desc, on):
    return (f"<label class='oe-t'><span><strong>{e(title)}</strong>" + (f"<small>{e(desc)}</small>" if desc else "") + "</span>"
            f"<input type='checkbox' name='{k}' value='1'{' checked' if on else ''} role='switch'></label>")


def _slider(k, label, lo, hi, step, val, unit):
    return (f"<div class='oe-s'><label for='r_{k}'>{e(label)}</label><output id='o_{k}'>{val}{unit}</output>"
            f"<input type='range' id='r_{k}' name='{k}' min='{lo}' max='{hi}' step='{step}' value='{val}'></div>")


def _mic_block(ui):
    from . import overlay
    mics = overlay.STATE.get("mics") or []
    cur = ui.get("mic", -1)
    opts = "<option value='-1'" + (" selected" if cur in (-1, None) else "") + ">Padrão do Windows</option>" + "".join(
        f"<option value='{i}'{' selected' if cur == i else ''}>{e(n)}</option>" for i, n in enumerate(mics))
    return ("<div class='oe-s' style='margin-top:12px'><label for='o_mic'>Microfone</label></div>"
            f"<select id='o_mic' name='mic' class='oe-sel'>{opts}</select>"
            + ("" if mics else "<p class='n' style='margin:4px 0 0;font-size:12px'>Ligue o overlay para aparecer a lista dos seus microfones.</p>")
            + "<div style='display:flex;gap:8px;align-items:center;margin-top:10px;flex-wrap:wrap'><button type='button' class='btn ghost' id='oemic'>Testar microfone</button>"
            "<span id='oemicr' class='n' style='font-size:12.5px'></span></div>")


MIC_JS = """<script>(function(){var b=document.getElementById('oemic'),r=document.getElementById('oemicr');if(!b)return;var CS=CSRF_TOKEN;
function post(u){return fetch(u,{method:'POST',headers:{'X-CSRF':CS}}).then(function(x){return x.json()})}
b.addEventListener('click',function(){r.textContent='Pedindo ao overlay…';post('/overlay/microfone/testar').then(function(d){if(d.erro){r.textContent=d.erro;return}
 r.textContent='Fale qualquer coisa agora (3 segundos)…';var n=0,t=setInterval(function(){n++;post('/overlay/microfone/estado').then(function(s){
  if(s.state==='pronto'){clearInterval(t);if(s.level<0.3)r.innerHTML='<b style="color:#E8817C">Sem som ('+s.level+'%).</b> O microfone escolhido não está captando: troque acima ou confira Configurações do Windows > Privacidade > Microfone (deixe apps da área de trabalho usarem o microfone).';
   else r.innerHTML='<b style="color:#8FD4A8">Funcionou ('+s.level+'%).</b> '+(s.text?'Entendi: “'+s.text.replace(/</g,'')+'”':'Ouvi som, mas não deu para transcrever.')}
  else if(s.state==='sem_resposta'||n>20){clearInterval(t);r.textContent='O overlay não respondeu. Ele está ligado?'}})},1000)})})})();</script>"""


def body(ui, running, ac, ver=None, shot=None, csrf=None):
    from . import icons
    mapimg = f"{icons.CDN}/cdn/{ver}/img/map/map11.png" if ver else ""
    bgimg = f"/overlay/fundo.img?v={shot}" if shot else "/static/img/rift_hd.jpg"
    fx = ui.get("fx") if ui.get("fx") is not None else 0.008
    fy = ui.get("fy") if ui.get("fy") is not None else 0.013
    strip_in = ("<div class='in'><div class='oe-row'><div class='oe-ic'></div><div class='oe-mid'><b>Lâmina Fantasma de Youmuu</b><div class='oe-bar'><span></span></div><small>faltam 850 de ouro</small></div>"
                "<div class='oe-nx'><span></span><span></span></div></div>"
                "<div class='oe-toast'>Dragão nasce em 42s</div><div class='oe-note'>Mortos: Ahri 22s</div></div>")
    mapvar = f" style=\"--map:url('{mapimg}');--rift:url('{bgimg}')\""
    _cdn = f"{icons.CDN}/cdn/{ver}/img" if ver else ""
    stage = (f"<div class='oe-stage'><div class='oe-scr rift{' shot' if shot else ''}' id='oescr' aria-label='Prévia da tela do jogo'{mapvar}><div class='oe-top'></div><div class='oe-hud'></div>"
             "<div class='oe-mm' id='oemm'>"
             "<i class='o y' style='left:66.5%;top:70.5%'>0:42</i><i class='o' style='left:33.5%;top:29.5%'>2:58</i>"
             "<i class='c' style='left:29%;top:36%'>3:30</i><i class='c' style='left:71%;top:64%'>3:30</i>"
             "<i class='j c' style='left:25%;top:46%'>4:12</i><i class='j c' style='left:52%;top:74%'>1:05</i></div>"
             "<div class='oe-strip' id='oes' tabindex='0' role='button' aria-label='Faixa do overlay: arraste ou use as setas para mudar a posição'>" + strip_in + "</div>"
             "<div class='oe-strip oe-pb' id='oep' tabindex='0' role='button' aria-label='Painel da partida: arraste para mudar a posição'><div class='in'>"
             "<b>14:32 · Zed · nível 11</b><div class='pr-cs g'>142 de farm · 9.7/min (sua média 6.9)</div><div class='pr-lane r'>Ahri nível 12 · 1 nível atrás</div>"
             "<div class='pr-gold g'>Itens: você 8.2k · Ahri 7.1k</div><div class='pr-cd'>Recargas: Ahri Q 7s · W 9s · E 14s · R 100s</div><div class='pr-team'>Times: +2.4k em itens · abates 12 x 9</div><div class='pr-tm y'>Inibidor deles 3:20</div><div class='pr-obj y'>Dragão 1:20 · Barão 6:40</div></div></div>"
             f""
             "<div class='oe-strip oe-bb' id='obb' tabindex='0' role='button' aria-label='Balão de aviso: arraste para mudar a posição'><div class='in'><i>C</i><span>Cuidado, jungler inimigo visível: Lee Sin no rio de cima.</span></div></div></div>"
             "<div class='oe-cap'><span><b>Arraste a faixa e o painel</b> para escolher onde ficam no jogo (vale para qualquer resolução).</span>"
             "<span class='oe-bgup'><label class='btn ghost'>Usar um print do meu jogo<input type='file' id='oebg' accept='image/png,image/jpeg' hidden></label>"
             + ("<button type='button' class='btn ghost' id='oebgx'>Fundo padrão</button>" if shot else "") + "</span>"
             f"<span>Overlay: <b>{'ligado' if running else 'desligado'}</b></span></div>"
             "<div class='oe-box oe-zb' style='margin-top:14px'><b>De perto</b><p class='n' style='margin:0 0 10px;font-size:12.5px'>Tamanho real numa tela Full HD (1920 x 1080).</p>"
             f"<div class='oe-zoom' id='oez'{mapvar}><div class='oe-strip2'>" + strip_in + "</div></div></div>"
             "<div class='oe-box' style='margin-top:14px'><b>Atalhos no jogo</b><div class='oe-keys'>"
             "<kbd>Ctrl+Shift+O</kbd><span>Mostrar ou esconder tudo</span>"
             "<kbd>Ctrl+Shift+M</kbd><span>Ajustar no próprio jogo: arraste a faixa e alinhe a caixa com o minimapa (a roda do mouse muda o tamanho). Aperte de novo para prender.</span>"
             "<kbd>Ctrl+Shift+J</kbd><span>Com o mouse em cima de um acampamento no minimapa, começa (ou cancela) o timer dele.</span>"
             "<kbd>Ctrl+Shift+A</kbd><span>Perguntar ao coach por voz: aperte, fale a pergunta e aperte de novo (ou espere 10 segundos). A resposta é falada e aparece na faixa. Também serve para marcar tempo: fale “Zed usou flash” ou “o mid sem ult” e a voz avisa quando volta.</span></div></div></div>")
    acc = "".join(f"<label><input type='radio' name='accent' value='{k}'{' checked' if ui['accent'] == k else ''}><span style='--c:{ac if k == 'main' else {'gold': '#c8aa6e', 'green': '#6BBF8A', 'blue': '#8DA2C0', 'game': 'conic-gradient(#d7263d,#E9C46A,#6BBF8A,#8DA2C0,#b98cff,#d7263d)'}[k]}'><i></i>{e(n)}</span></label>"
                  for k, n in ACCENTS)
    pres = "".join(f"<button type='button' class='btn ghost' data-fx='{x}' data-fy='{y}'>{e(n)}</button>" for n, x, y in PRESETS)
    panel = ("<div class='oe-p'>"
             "<div class='oe-box'><b>Modo</b><div class='oe-preset'><button type='button' class='btn ghost' data-preset='limpo'>Modo limpo</button>"
             "<button type='button' class='btn ghost' data-preset='tudo'>Tudo ligado</button></div>"
             "<p class='n' style='margin:0;font-size:12.5px'>Modo limpo: só o próximo item, as recargas do seu oponente, os avisos curtos e a barra dos inimigos. O resto fica na voz.</p></div>"
             "<div class='oe-box'><b>Balão de aviso</b>" + _toggle("balao", "Balão com a frase da voz", "Uma frase curta (a mesma que a voz fala) aparece por 4 a 6 segundos e some. O clique passa direto para o jogo. Arraste o balão na prévia ou com Ctrl+Shift+M no jogo. Ligado, ele substitui os avisos na faixa.", ui.get("balao", 1))
             + _slider("bub_size", "Tamanho do balão", 70, 170, 5, ui.get("bub_size", 100), "%")
             + _slider("bub_font", "Tamanho da letra do balão", 70, 170, 5, ui.get("bub_font", 100), "%") + "</div>"
             "<div class='oe-box'><b>Seleção de campeões</b>" + _toggle("runas_auto", "Montar as runas sozinho", "Quando você locka o campeão, o app grava a página dos melhores no cliente e fala qual montou. Se o oponente de rota pedir outra página, troca e avisa.", ui.get("runas_auto", 1)) + "</div>"
             "<div class='oe-box'><b>Na faixa</b>" + "".join(_toggle(k, t, d, ui[k]) for k, t, d in SHOW) + "</div>"
             "<div class='oe-box'><b>Falar com o coach</b><p class='n' style='margin:0 0 8px;font-size:12.5px'>Faça uma pergunta por voz durante a partida. O Ctrl+Shift+A sempre funciona; escolha também um botão do mouse ou uma tecla.</p>"
             "<div class='oe-s'><label>Botão de falar</label></div><div class='oe-ch'>"
             + "".join(f"<label><input type='radio' name='ptt' value='{k}'{' checked' if ui.get('ptt', 'none') == k else ''}><span>{e(n)}</span></label>" for k, n in overlay.PTT_NAMES)
             + "</div><div class='oe-s' style='margin-top:6px'><label>Como funciona</label></div><div class='oe-ch'>"
             + "".join(f"<label><input type='radio' name='ptt_mode' value='{k}'{' checked' if ui.get('ptt_mode', 'hold') == k else ''}><span>{e(n)}</span></label>"
                       for k, n in (("hold", "Segurar para falar"), ("toggle", "Apertar para começar e de novo para enviar")))
             + "</div><p class='n' style='margin:8px 0 0;font-size:12.5px'>O clique continua indo para o jogo normalmente. Um clique rápido (menos de meio segundo) não conta como pergunta.</p>"
             + _mic_block(ui) + "</div>"
             "<div class='oe-box'><b>Painel da partida</b>" + _toggle("panel", "Mostrar o painel quando você morrer", "Um segundo overlay, separado da faixa: plano da fase, farm, timers e placar. Aparece só enquanto você está morto, para não tapar o jogo.", ui.get("panel", 1))
             + "".join(_toggle(k, t, d, ui.get(k, 1)) for k, t, d in PANEL_ROWS) + "</div>"
             "<div class='oe-box'><b>Avisos da partida</b><div class='oe-al'>" + "".join(_toggle(k, t, "", ui[k]) for k, t in ALERTS) + "</div></div>"
             "<div class='oe-box'><b>Mais avisos e voz</b>" + "".join(_toggle(k, t, d, ui[k]) for k, t, d in ALERTS2)
             + _slider("luta_vol", "Volume da voz nas lutas grandes", 20, 100, 5, ui.get("luta_vol", 100), "%")
             + "<p class='n' style='margin:0 0 4px;font-size:12.5px'>Em 100%, a voz espera a luta acabar (Silêncio nas lutas). Abaixo disso, ela fala na hora, mais baixo.</p>"
             + "<p class='n' style='margin:6px 0 0;font-size:12.5px'>Tudo isso também é falado, se a voz estiver ligada (Partida ao vivo). Só o aviso de jungler visto lê a sua tela (apenas o minimapa).</p></div>"
             "<div class='oe-box'><b>No minimapa</b>" + "".join(_toggle(k, t, d, ui[k]) for k, t, d in MM)
             + "<div class='oe-s'><label>Lado do minimapa no seu jogo</label></div><div class='oe-ch'>"
             + "".join(f"<label><input type='radio' name='mm_side' value='{k}'{' checked' if ui.get('mm_side', 'right') == k else ''}><span>{n}</span></label>" for k, n in (("left", "Esquerda"), ("right", "Direita")))
             + "</div>"
             + _slider("mm_size", "Tamanho do minimapa no jogo", 12, 45, 1, ui.get("mm_size", 26), "%")
             + "<p class='n' style='margin:0 0 4px;font-size:12.5px'>Igual à escala do minimapa nas opções do jogo. Para o ajuste fino, aperte Ctrl+Shift+M no jogo.</p>"
             + _slider("mm_text", "Tamanho dos números", 70, 170, 5, ui["mm_text"], "%") + "</div>"
             "<div class='oe-box'><b>Aparência</b>"
             + _slider("scale", "Tamanho da faixa", 70, 170, 5, ui["scale"], "%")
             + _slider("opacity", "Opacidade", 40, 100, 2, ui["opacity"], "%")
             + _slider("toast_secs", "Tempo de cada aviso", 3, 15, 1, ui["toast_secs"], " s")
             + f"<div class='oe-s'><label>Cor da barra</label></div><div class='oe-ch'>{acc}</div>"
             f"<div class='oe-s' style='margin-top:6px'><label>Posição rápida</label></div><div class='oe-pr'>{pres}</div></div>"
             f"<input type='hidden' name='fx' value='{fx}'><input type='hidden' name='fy' value='{fy}'>"
             f"<input type='hidden' name='fx2' value='{ui.get('fx2') if ui.get('fx2') is not None else 0.86}'><input type='hidden' name='fy2' value='{ui.get('fy2') if ui.get('fy2') is not None else 0.46}'>"
             f"<input type='hidden' name='fx3' value='{ui.get('fx3') if ui.get('fx3') is not None else 0.93}'><input type='hidden' name='fy3' value='{ui.get('fy3') if ui.get('fy3') is not None else 0.36}'>"
             f"<input type='hidden' name='fx4' value='{ui.get('fx4') if ui.get('fx4') is not None else 0.74}'><input type='hidden' name='fy4' value='{ui.get('fy4') if ui.get('fy4') is not None else 0.62}'>"
             "<div class='oe-saved' id='oesaved' aria-live='polite'></div></div>")
    acts = ("<div class='oe-act' style='margin:6px 0 18px'>"
            + ("<form method='post' action='/overlay/previa'><button class='btn gold' style='width:100%'>Mostrar no jogo agora (30 s)</button></form>"
               "<form method='post' action='/overlay/teste'><button class='btn ghost' style='width:100%'>Testar com partida simulada e voz (60 s)</button></form>" if running else
               "<form method='post' action='/overlay/abrir'><input type='hidden' name='volta' value='/overlay'><button class='btn gold' style='width:100%'>Ligar overlay</button></form>")
            + "<form method='post' action='/overlay/padrao'><button class='btn ghost' style='width:100%'>Voltar ao padrão</button></form></div>")
    intro = ("<p class='n'>Escolha o que aparece por cima do jogo e onde. Tudo salva sozinho. Com o overlay ligado, "
             "<b>Mostrar no jogo agora</b> exibe uma prévia na sua tela por 30 segundos, mesmo fora da partida, para você ver o tamanho de verdade.</p>")
    try:
        from . import extras
        intro += extras.profiles_html(ui.get("perfil"))
    except Exception:
        pass
    return (f"<style>{CSS}</style>{intro}{acts}<form id='oef' method='post' action='/overlay/salvar' class='oe' onsubmit='return false'>"
            f"{stage}{panel}</form>{JS.replace('CSRF_TOKEN', json.dumps(csrf or ''))}{MIC_JS.replace('CSRF_TOKEN', json.dumps(csrf or ''))}")
