"""Lembrete do Flash e da ultimate do inimigo que VOCE marcou (atalho no jogo ou botao na Partida ao vivo).

O jogo nao conta para apps quando o inimigo usa Flash ou ult; por isso voce FALA no jogo (botao de falar com o coach):
"Zed usou flash", "Ahri sem ult", "o mid queimou ignite". O app marca, conta o tempo e avisa: "Flash do Zed volta em 1 minuto", "voltou".
O tempo e aproximado: conta as Botas Jonias (aceleracao de feitico); runas e aceleracao de habilidade do inimigo o jogo nao mostra.
"""
import threading
import time

ORDER = ["TOP", "JUNGLE", "MIDDLE", "BOTTOM", "UTILITY"]
SPELL_CD = {"flash": 300, "ignite": 180, "incendiar": 180, "exhaust": 240, "exaustão": 240, "exaustao": 240, "heal": 240, "curar": 240,
            "barrier": 180, "barreira": 180, "cleanse": 240, "purificar": 240, "ghost": 240, "fantasma": 240,
            "teleport": 360, "teleporte": 360, "smite": 90, "golpear": 90}
SPELL_PT = {"flash": "Flash", "ignite": "Incendiar", "exhaust": "Exaustão", "heal": "Curar", "barrier": "Barreira", "cleanse": "Purificar",
            "ghost": "Fantasma", "teleport": "Teleporte", "smite": "Golpear"}
IONIAN = 3158        # Botas Jonias da Lucidez: +10 de aceleracao de feitico de invocador
_LOCK = threading.Lock()
MARKS = []           # [{"id", "game", "champ", "who", "what", "ready", "cd"}]


def game_key(live_data):
    names = sorted((p.get("championName") or "") for p in (live_data or {}).get("allPlayers") or [])
    return "|".join(names)


def enemies(live_data, me):
    foes = [p for p in (live_data or {}).get("allPlayers") or [] if p.get("team") != (me or {}).get("team")]
    pos = {(p.get("position") or "").upper(): p for p in foes}
    ordered = [pos[r] for r in ORDER if r in pos]
    return ordered + [p for p in foes if p not in ordered]


ALIAS = {"incendiar": "ignite", "exaustão": "exhaust", "exaustao": "exhaust", "curar": "heal", "barreira": "barrier",
         "purificar": "cleanse", "fantasma": "ghost", "teleporte": "teleport", "golpear": "smite"}
ICON = {"flash": "SummonerFlash", "ignite": "SummonerDot", "exhaust": "SummonerExhaust", "heal": "SummonerHeal", "barrier": "SummonerBarrier",
        "cleanse": "SummonerBoost", "ghost": "SummonerHaste", "teleport": "SummonerTeleport", "smite": "SummonerSmite"}
RAW = {"SummonerDot": "ignite", "SummonerBoost": "cleanse", "SummonerHaste": "ghost", "SummonerFlash": "flash", "SummonerExhaust": "exhaust",
       "SummonerHeal": "heal", "SummonerBarrier": "barrier", "SummonerTeleport": "teleport", "SummonerSmite": "smite"}


def _spell_key(name):
    low = (name or "").lower()
    for raw, k in RAW.items():
        if raw.lower() in low:
            return k
    for k in SPELL_CD:
        if k in low:
            return ALIAS.get(k, k)
    return None


def mark(live_data, me, slot, kind, ddir=None, spell=None):
    """slot 1..5 (ordem das rotas); kind 'f' (Flash ou o outro feitico) ou 'r' (ultimate). Devolve o texto do aviso ou None."""
    from . import live, liveview, voicecues
    gt = (live_data.get("gameData") or {}).get("gameTime") or 0
    foes = enemies(live_data, me)
    if not (1 <= slot <= len(foes)):
        return None
    p = foes[slot - 1]
    nm = p.get("championName") or "Inimigo"
    if kind == "r":       # a Riot proibe acompanhar a ultimate dos inimigos (2025), mesmo marcando na mao
        return "A Riot não permite acompanhar a ultimate dos inimigos. Eu marco só Flash e feitiços: diga, por exemplo, \"o Zed usou Flash\"."
    if False:
        cds = voicecues.champ_cds(ddir or "", liveview.champ_id(p)) or {}
        lv = int(p.get("level") or 1)
        if lv < 6:
            return f"{nm} ainda não tem ultimate."
        rr = cds.get("R") or []
        cd = rr[min(len(rr), voicecues.r_rank(lv)) - 1] if rr else 100
        what = "ultimate"
    else:
        ss = p.get("summonerSpells") or {}
        spells = [(ss.get(k) or {}).get("displayName") or "" for k in ("summonerSpellOne", "summonerSpellTwo")]
        keys = [_spell_key(s) for s in spells]
        key = spell if spell else ("flash" if "flash" in keys else next((k for k in keys if k and k not in ("smite", "golpear")), "flash"))
        haste = 10 if any(it.get("itemID") == IONIAN for it in p.get("items") or []) else 0
        cd = SPELL_CD.get(key, 300) * 100 / (100 + haste)
        what = SPELL_PT.get(key, "Flash")
    gk = game_key(live_data)
    with _LOCK:
        for m in [m for m in MARKS if m["game"] == gk and m["champ"] == nm and m["what"] == what]:
            MARKS.remove(m)        # marcou de novo: recomeca
        MARKS[:] = [m for m in MARKS if m["game"] == gk][-20:]
        MARKS.append({"id": f"{nm}_{what}_{int(gt)}", "game": gk, "champ": nm, "what": what, "ready": gt + cd, "cd": cd})
    left = int(cd)
    lab = "Ult" if what == "ultimate" else what
    return f"{lab} do {nm} {'marcada' if what == 'ultimate' else 'marcado'}: volta em {left // 60}:{left % 60:02d}."


def tip_for(live_data, me, slot, kind, spell=None):
    """Frase curta e util para falar quando voce marca: o que fazer com o inimigo sem Flash ou sem ult."""
    from . import profile
    foes = enemies(live_data, me)
    if not (1 <= slot <= len(foes)):
        return None
    p = foes[slot - 1]
    nm = p.get("championName") or "Inimigo"
    try:
        mine = profile.game_pos(me)
    except Exception:
        mine = (me or {}).get("position")
    lane = (p.get("position") or "").upper() == (mine or "").upper() and mine
    jg = (p.get("position") or "").upper() == "JUNGLE"
    if kind == "r":
        return None
    sp = SPELL_PT.get(spell or "flash", "Flash")
    if sp == "Flash":
        if lane:
            return f"{nm} sem Flash por 5 minutos: jogue agressivo e chame o caçador."
        if jg:
            return f"Caçador sem Flash: ganks dele ficam mais fracos."
        return f"{nm} sem Flash: foquem ele na próxima luta."
    if sp == "Teleporte" and lane:
        return f"{nm} sem Teleporte: se ele voltar para a base, perde a rota."
    return f"{sp} do {nm} marcado."


def clear(live_data, slot, kind, spell=None):
    """Desmarca (clicou de novo no que ja estava contando)."""
    from . import live
    foes = enemies(live_data, live._find_me(live_data))
    if not (1 <= slot <= len(foes)):
        return None
    nm = foes[slot - 1].get("championName")
    what = "ultimate" if kind == "r" else SPELL_PT.get(spell or "flash", "Flash")
    gk = game_key(live_data)
    with _LOCK:
        MARKS[:] = [m for m in MARKS if not (m["game"] == gk and m["champ"] == nm and m["what"] == what)]
    return f"{'Ult' if what == 'ultimate' else what} do {nm} desmarcado."


def spell_icon(sp):
    """'SummonerFlash' a partir do rawDisplayName do jogo (para o icone do Data Dragon)."""
    raw = (sp or {}).get("rawDisplayName") or ""
    import re
    m = re.search(r"(Summoner[A-Za-z]+?)(?:_|Upgrade|$)", raw)
    return m.group(1) if m else None


def bar(live_data, me, gt):
    """Os 5 inimigos com os 2 feiticos e a ult: o que voce marcou e quanto falta."""
    marks = {(m["champ"], m["what"]): m for m in current(live_data)}
    out = []
    from . import liveview
    for i, p in enumerate(enemies(live_data, me), 1):
        nm = p.get("championName") or ""
        ss = p.get("summonerSpells") or {}
        cells = []
        for k in ("summonerSpellOne", "summonerSpellTwo"):
            sp = ss.get(k) or {}
            key = _spell_key(sp.get("rawDisplayName")) or _spell_key(sp.get("displayName"))
            label = SPELL_PT.get(key, sp.get("displayName") or "?")
            m = marks.get((nm, label))
            cells.append({"t": "s", "key": key or "", "label": label, "icon": ICON.get(key) or spell_icon(sp),
                          "left": int(m["ready"] - gt) if m and m["ready"] - gt > -12 else None})
        m = marks.get((nm, "ultimate"))
        cells.append({"t": "r", "key": "r", "label": "Ult", "icon": None, "has": int(p.get("level") or 1) >= 6,
                      "left": int(m["ready"] - gt) if m and m["ready"] - gt > -12 else None})
        out.append({"slot": i, "name": nm, "champ": liveview.champ_id(p), "lvl": int(p.get("level") or 1),
                    "dead": bool(p.get("isDead")), "cells": cells})
    return out


def current(live_data):
    gk = game_key(live_data)
    with _LOCK:
        return [dict(m) for m in MARKS if m["game"] == gk]


def alerts(live_data, gt):
    """Avisos de voz: falta 1 minuto (ou 30 s nos curtos) e 'voltou'."""
    al = []
    for m in current(live_data):
        left = m["ready"] - gt
        nm, what = m["champ"], m["what"]
        art = "do"
        what = "Ult" if what == "ultimate" else what
        if m["cd"] > 100 and 50 <= left <= 62:
            al.append({"k": f"spell60_{m['id']}", "t": f"{what} {art} {nm} volta em 1 minuto."})
        elif 22 <= left <= 32:
            al.append({"k": f"spell30_{m['id']}", "t": f"{what} {art} {nm} volta em 30 segundos."})
        if -12 <= left <= 0:
            al.append({"k": f"spellup_{m['id']}", "t": f"{what} {art} {nm} voltou."})
    return al


def line(live_data, gt):
    """Texto curto para a faixa: 'Flash Zed 2:10 · Ult Ahri 0:35'."""
    parts = []
    for m in sorted(current(live_data), key=lambda m: m["ready"]):
        left = int(m["ready"] - gt)
        if left < -12:
            continue
        lab = "Ult" if m["what"] == "ultimate" else m["what"]
        parts.append(f"{lab} {m['champ']} " + ("pronto" if left <= 0 else f"{left // 60}:{left % 60:02d}"))
    return " · ".join(parts)


# ---------------- marcar pela fala: "Zed usou flash", "o suporte sem ult" ----------------
SPOKEN = [("r", ("ult", "ulti", "ultimate", "ultimata", "r dele", "r da", "o r")),
          ("flash", ("flash", "flesh", "flech", "flaxe", "fléxi", "lampejo")),
          ("ignite", ("ignite", "incendiar", "ignaite", "ignai", "igniti")),
          ("teleport", ("teleporte", "teleport", "tp", "tepê", "tê pê")),
          ("exhaust", ("exaust", "exausto", "exaustão", "exhaust")),
          ("heal", ("heal", "curar", "cura", "riu")),
          ("barrier", ("barreira", "barrier")),
          ("cleanse", ("purificar", "cleanse", "clins")),
          ("ghost", ("ghost", "fantasma", "gost"))]
ROLE_WORDS = {"TOP": ("top", "topo"), "JUNGLE": ("jungle", "jg", "caçador", "cacador", "selva", "jungler"),
              "MIDDLE": ("mid", "meio"), "BOTTOM": ("adc", "atirador", "bot", "ad"), "UTILITY": ("sup", "suporte", "support")}
NICK = {"MonkeyKing": ("wukong",), "MasterYi": ("yi", "master yi", "mestre yi"), "MissFortune": ("mf", "miss fortune"),
        "TwistedFate": ("tf", "twisted fate"), "JarvanIV": ("j4", "jarvan"), "AurelionSol": ("asol", "aurelion"), "KogMaw": ("kog", "kog maw"),
        "Cassiopeia": ("cass", "cassio"), "Morgana": ("morg",), "Nautilus": ("naut", "nautilus"), "Evelynn": ("eve",), "Kassadin": ("kass", "kassadin"),
        "Katarina": ("kat", "katarina"), "Leblanc": ("lb", "leblanc", "le blanc"), "Warwick": ("ww",), "DrMundo": ("mundo",), "Volibear": ("voli",),
        "Hecarim": ("heca", "hecarim"), "TahmKench": ("tahm", "kench"), "KSante": ("ksante", "k sante"), "Khazix": ("kha", "khazix", "kazix"),
        "Chogath": ("cho", "chogath"), "Velkoz": ("velkoz", "vel koz"), "RekSai": ("reksai", "rek sai"), "Belveth": ("belveth", "bel veth"),
        "Kaisa": ("kaisa", "kai sa"), "Nidalee": ("nida",), "Blitzcrank": ("blitz",), "Tristana": ("trist", "tris"), "Ezreal": ("ez",),
        "Caitlyn": ("cait",), "Seraphine": ("sera",), "Mordekaiser": ("morde",), "Malphite": ("malph",), "Gangplank": ("gp",), "Fiddlesticks": ("fiddle",)}


def _norm(t):
    import unicodedata
    t = unicodedata.normalize("NFD", (t or "").lower())
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")
    return " " + "".join(c if c.isalnum() else " " for c in t) + " "


def parse_spoken(text, live_data, me):
    """('slot', 'f' ou 'r', chave do feitico) se a frase fala de um inimigo que usou feitico/ult; senao None."""
    t = _norm(text)
    kind = None
    for k, words in SPOKEN:
        if any(f" {_norm(w).strip()} " in t for w in words):
            kind = k
            break
    if not kind:
        return None
    foes = enemies(live_data, me)
    from . import liveview
    best = None
    for i, p in enumerate(foes, 1):
        cid = liveview.champ_id(p)
        names = {p.get("championName") or "", cid} | set(NICK.get(cid, ()))
        for nm in names:
            n = _norm(nm).strip()
            if n and f" {n} " in t:
                best = i
        role = (p.get("position") or "").upper()
        if not best and any(f" {w} " in t for w in ROLE_WORDS.get(role, ())):
            best = i
    if not best:
        import difflib
        words = t.split()
        for i, p in enumerate(foes, 1):
            n = _norm(p.get("championName")).strip().replace(" ", "")
            if any(difflib.SequenceMatcher(None, w, n).ratio() >= 0.75 for w in words if len(w) >= 3):
                best = i
                break
    if not best:
        return None
    return best, ("r" if kind == "r" else "f"), (None if kind == "r" else kind)
