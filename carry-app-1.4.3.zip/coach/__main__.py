"""Uso:
    python -m coach sync [--count 100] [--queue 420]
    python -m coach report [--champion Zed] [--position MIDDLE]
    python -m coach vs Cassiopeia
    python -m coach app                      (abre a tela no navegador)
    python -m coach postgame [match_id]      (pos-jogo da ultima partida)
    python -m coach topo --champion Zed --games 30   (amostra dos melhores do BR)
"""
import argparse
import os
import sys

from . import db, report
from .riot import RiotClient, RiotError
from .sync import sync_player

DB_PATH = os.environ.get("COACH_DB", "coach.sqlite")
RIOT_ID = os.environ.get("RIOT_ID", "")  # se vazio, vale o Riot ID salvo no site (Dados e chave)


def _riot_id():
    from . import config as config_mod
    rid = RIOT_ID or config_mod.Config(DB_PATH).riot_id()
    if "#" not in rid:
        sys.exit("Falta o Riot ID. Abra o app e preencha em Dados e chave (ou defina RIOT_ID=Nome#TAG).")
    return rid


def _puuid(con, client):
    """Guarda o puuid no banco para nao consultar a conta toda vez."""
    RIOT_ID_ = _riot_id()
    con.execute("CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)")
    row = con.execute("SELECT v FROM meta WHERE k='puuid:'||?", (RIOT_ID_,)).fetchone()
    if row:
        return row[0]
    name, tag = RIOT_ID_.split("#", 1)
    puuid = client.puuid_by_riot_id(name, tag)
    con.execute("INSERT OR REPLACE INTO meta VALUES ('puuid:'||?, ?)", (RIOT_ID_, puuid))
    con.commit()
    return puuid


def _saved_puuid(con):
    con.execute("CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)")
    row = con.execute("SELECT v FROM meta WHERE k='puuid:'||?", (_riot_id(),)).fetchone()
    if not row:
        sys.exit("Rode primeiro: python -m coach sync")
    return row[0]


def main(argv=None):
    ap = argparse.ArgumentParser(prog="coach")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("sync", help="baixa suas partidas")
    s.add_argument("--count", type=int, default=100)
    s.add_argument("--queue", type=int, default=420, help="420 = solo/duo; 0 = todas")
    r = sub.add_parser("report", help="relatorio das suas partidas")
    r.add_argument("--champion")
    r.add_argument("--position", default="MIDDLE")
    v = sub.add_parser("vs", help="seus jogos contra um campeão")
    v.add_argument("opponent")
    v.add_argument("--position", default="MIDDLE")
    a = sub.add_parser("app", help="abre a tela no navegador")
    a.add_argument("--port", type=int, default=8765)
    a.add_argument("--no-browser", action="store_true")
    pg = sub.add_parser("postgame", help="pós-jogo no terminal")
    pg.add_argument("match_id", nargs="?")
    o = sub.add_parser("overlay", help="janela por cima do jogo (aberta pelo app)")
    o.add_argument("--port", type=int, default=8765)
    o.add_argument("--token", required=True)
    t = sub.add_parser("topo", help="baixa partidas dos melhores jogadores do BR")
    t.add_argument("--champion", default="Zed")
    t.add_argument("--games", type=int, default=30)
    t.add_argument("--players", type=int, default=60)
    args = ap.parse_args(argv)
    if args.cmd == "overlay":
        from . import overlay
        try:
            return overlay.run(args.port, args.token)
        except Exception:
            import traceback
            overlay.log("overlay fechou com erro: " + traceback.format_exc()[-600:])
            raise

    con = db.connect(DB_PATH)
    try:
        if args.cmd == "sync":
            from . import config as config_mod
            client = RiotClient(config_mod.Config(DB_PATH).riot_key(), region=config_mod.Config(DB_PATH).region())
            puuid = _puuid(con, client)
            n = sync_player(client, con, puuid, count=args.count, queue=args.queue or None)
            print(f"Pronto: {n} partidas novas salvas em {DB_PATH}.")
        elif args.cmd == "app":
            from . import web
            web.serve(DB_PATH, None, args.port, not args.no_browser)
        elif args.cmd == "postgame":
            from . import postgame
            from .tags import as_text
            puuid = _saved_puuid(con)
            mid = args.match_id or postgame.latest_match_id(con, puuid)
            pg = postgame.build(con, puuid, mid) if mid else None
            if not pg:
                sys.exit("Nenhuma partida encontrada. Rode o sync.")
            print(f"== Pós-jogo {mid} ==")
            for title, items in (("Resumo", pg["summary"]), ("Foi bem", pg["well"])):
                print(f"\n{title}:")
                for t in items:
                    print("  " + as_text(t))
            print("\nAs 3 decisões que mais custaram:")
            for c in pg["costly"]:
                print(f"  * {c['title']}")
                for t in c["facts"]:
                    print("      " + as_text(t))
            print("\n  " + as_text(pg["focus"]))
        elif args.cmd == "topo":
            from . import top
            from .ddragon import DataDragon
            client = RiotClient(os.environ.get("RIOT_API_KEY"))
            champs = DataDragon(cache_dir=os.path.join(os.path.dirname(os.path.abspath(DB_PATH)), "cache")).champions()
            if args.champion not in champs:
                sys.exit("Campeão não encontrado (use o nome em inglês, ex.: Zed, Ahri, MonkeyKing).")
            top.sample(client, con, args.champion, champs[args.champion]["key"],
                       target_games=args.games, max_players=args.players)
        elif args.cmd == "report":
            games = report.my_games(con, _saved_puuid(con), args.position)
            if args.champion:
                games = [g for g in games if g["champion"].lower() == args.champion.lower()]
            print(report.render(games, f"Suas partidas ({args.champion or 'todos os campeões'})"))
        elif args.cmd == "vs":
            games = report.my_games(con, _saved_puuid(con), args.position)
            print(report.matchup(games, args.opponent))
    except RiotError as e:
        sys.exit(f"Erro: {e}")


if __name__ == "__main__":
    main()
