"""Quanto esta na sua mao: separa as derrotas em "o time perdeu com voce jogando bem", "todo mundo errou" e "voce foi o problema",
e conta os jogadores que 'alimentaram' (muitas mortes e quase nenhum abate) no SEU time e no time DELES.
So com os dados oficiais das suas partidas (placar final de cada jogador)."""
import html

e = lambda x: html.escape("" if x is None else str(x))


def _impact(p, team_kills):
    k, d, a = int(p["kills"] or 0), int(p["deaths"] or 0), int(p["assists"] or 0)
    kp = (k + a) / team_kills if team_kills else 0
    return (k + a) / max(1, d) + 2 * kp - 0.15 * d


def _feeder(p):
    return int(p["deaths"] or 0) >= 8 and int(p["kills"] or 0) + int(p["assists"] or 0) <= int(p["deaths"] or 0) * 0.6


def breakdown(con, puuid, limit=60):
    rows = con.execute(
        """SELECT p.match_id, p.team_id, p.win, p.champion FROM participants p JOIN match_source s USING (match_id)
           JOIN matches m USING (match_id) WHERE p.puuid=? AND s.source='me' AND COALESCE(m.duration_s,0) >= 900
           ORDER BY m.started_ms DESC LIMIT ?""", (puuid, limit)).fetchall()
    res = {"n": 0, "loss": 0, "carried_loss": 0, "mixed_loss": 0, "me_loss": 0, "feed_mine": 0, "feed_theirs": 0,
           "win": 0, "me_win": 0, "bad_win": 0, "examples": []}
    for mid, team, win, champ in rows:
        ps = con.execute("SELECT puuid, team_id, kills, deaths, assists, champion FROM participants WHERE match_id=?", (mid,)).fetchall()
        if len(ps) != 10:
            continue
        mine = [p for p in ps if p[1] == team]
        theirs = [p for p in ps if p[1] != team]
        tk = sum(int(p[2] or 0) for p in mine)
        d = lambda p: {"kills": p[2], "deaths": p[3], "assists": p[4]}
        imp = sorted(((_impact(d(p), tk), p[0]) for p in mine), reverse=True)
        rank = next(i for i, (_, pu) in enumerate(imp, 1) if pu == puuid)
        me = next(p for p in mine if p[0] == puuid)
        res["n"] += 1
        if any(_feeder(d(p)) for p in mine if p[0] != puuid):
            res["feed_mine"] += 1
        if any(_feeder(d(p)) for p in theirs):
            res["feed_theirs"] += 1
        if win:
            res["win"] += 1
            if rank <= 2:
                res["me_win"] += 1
            elif rank >= 4 or _feeder(d(me)):
                res["bad_win"] += 1
            continue
        res["loss"] += 1
        my_bad = rank >= 4 or _feeder(d(me))
        if rank <= 2 and not my_bad:
            res["carried_loss"] += 1
        elif my_bad:
            res["me_loss"] += 1
            if len(res["examples"]) < 3:
                res["examples"].append((mid, champ, f"{me[2]}/{me[3]}/{me[4]}"))
        else:
            res["mixed_loss"] += 1
    return res


def html_card(r):
    if not r or not r["loss"]:
        return "<div class='card'><p class='n'>Ainda sem derrotas suficientes para separar (partidas de 15 min ou mais).</p></div>"
    L = r["loss"]
    pct = lambda x: round(100 * x / L)
    bar = lambda lb, v, col: (f"<div style='margin:8px 0'><div style='display:flex;justify-content:space-between;font-size:14px'><span>{e(lb)}</span>"
                              f"<b>{v} ({pct(v)}%)</b></div><div style='height:10px;border-radius:6px;background:#241B1A'>"
                              f"<div style='height:10px;border-radius:6px;width:{pct(v)}%;background:{col}'></div></div></div>")
    body = (f"<div class='card'><b class='gl'>As suas últimas {L} derrotas</b>"
            + bar("O time perdeu com você jogando bem (você foi o 1º ou 2º do time)", r["carried_loss"], "#6BBF8A")
            + bar("Todo mundo errou um pouco (você no meio do time)", r["mixed_loss"], "#8DA2C0")
            + bar("Você foi o problema (4º ou 5º do time, ou muitas mortes)", r["me_loss"], "#D9534F") + "</div>")
    fm, ft, n = r["feed_mine"], r["feed_theirs"], r["n"]
    body += (f"<div class='card'><b class='gl'>Alguém do time 'alimentou'? (8+ mortes, quase sem abate)</b>"
             f"<p>No <b>seu</b> time (sem contar você): <b>{fm}</b> de {n} partidas. No time <b>deles</b>: <b>{ft}</b> de {n}.</p>"
             + ("<p class='n'>Os números são parecidos dos dois lados: não existe fila dos perdedores, o jogo com o 0/10 do outro lado só não fica na memória.</p>"
                if abs(fm - ft) <= max(2, n * 0.08) else
                ("<p class='n'>Mais do seu lado nessa amostra. Acontece em sequências, mas no longo prazo os dois lados se igualam.</p>" if fm > ft else
                 "<p class='n'>Mais do lado deles: você também ganhou jogos assim.</p>")) + "</div>")
    body += (f"<div class='card'><b class='gl'>O que está na sua mão</b><p>Em {r['me_loss']} das {L} derrotas ({pct(r['me_loss'])}%) você foi o problema. "
             "São essas que viram vitória quando você corrige o seu erro principal. As do time você não controla, então não gaste energia com elas.</p>"
             + "".join(f"<p><a href='/revisao/{e(m)}'>Revisar: {e(c)} {e(k)}</a></p>" for m, c, k in r["examples"]) + "</div>")
    if r["win"]:
        body += (f"<div class='card'><b class='gl'>E nas vitórias</b><p>Você foi o 1º ou 2º do time em {r['me_win']} das {r['win']} vitórias "
                 f"({round(100 * r['me_win'] / r['win'])}%).</p>"
                 + (f"<p>E em <b>{r['bad_win']}</b> vitórias ({round(100 * r['bad_win'] / r['win'])}%) você foi o 4º ou 5º do time: o time te carregou. "
                    "Vale revisar essas também, porque o erro estava lá mesmo com a vitória.</p>" if r.get("bad_win") else "") + "</div>")
    return body


_JG = {}


def jungler_stats(con, puuid):
    """{campeao do jungler aliado: (jogos, vitorias)} nas suas partidas (voce fora da selva)."""
    import time as _t
    hit = _JG.get(puuid)
    if hit and _t.time() - hit[0] < 1800:
        return hit[1]
    rows = con.execute(
        """SELECT j.champion, COUNT(*), SUM(me.win) FROM participants me JOIN match_source s USING (match_id)
           JOIN participants j ON j.match_id=me.match_id AND j.team_id=me.team_id AND j.position='JUNGLE' AND j.puuid<>me.puuid
           WHERE me.puuid=? AND s.source='me' AND me.position<>'JUNGLE' GROUP BY j.champion""", (puuid,)).fetchall()
    out = {r[0]: (int(r[1] or 0), int(r[2] or 0)) for r in rows}
    _JG[puuid] = (_t.time(), out)
    return out


def jungler_card(con, puuid, champs=None):
    st = {c: v for c, v in jungler_stats(con, puuid).items() if v[0] >= 5}
    if not st:
        return ""
    nm = lambda c: ((champs or {}).get(c) or {}).get("name") or c
    rows = sorted(st.items(), key=lambda kv: -(kv[1][1] + 10) / (kv[1][0] + 20))
    line = lambda c, v: f"<p>{e(nm(c))}: <b>{round(100 * v[1] / v[0])}%</b> em {v[0]} jogos</p>"
    best, worst = rows[:4], [r for r in rows[-4:] if r not in rows[:4]]
    return ("<div class='card'><b class='gl'>Com que jungler você ganha</b>"
            "<p class='n'>Seu winrate pelo jungler do SEU time (5 jogos ou mais). Com os de cima, jogue junto com ele no começo; "
            "com os de baixo, jogue mais seguro e conte menos com gank.</p>"
            + "".join(line(c, v) for c, v in best) + ("<hr style='opacity:.15'>" + "".join(line(c, v) for c, v in worst) if worst else "") + "</div>")
