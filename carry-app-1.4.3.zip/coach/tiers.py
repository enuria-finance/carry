"""Amostra por elo: partidas de jogadores de um elo (ex.: Platina) na sua posicao, so pela API oficial.

Fica em tiers.sqlite (compartilhado entre os usuarios). Serve para comparar voce com o elo que voce quer alcancar,
que e uma meta mais realista do que o Desafiante.
"""
import os

from . import db, report

TIERS = ["IRON", "BRONZE", "SILVER", "GOLD", "PLATINUM", "EMERALD", "DIAMOND", "MASTER", "GRANDMASTER", "CHALLENGER"]
GOAL_TO_TIER = {"Bronze": "BRONZE", "Prata": "SILVER", "Ouro": "GOLD", "Platina": "PLATINUM", "Esmeralda": "EMERALD",
                "Diamante": "DIAMOND", "Mestre+": "MASTER", "Sair do Ferro": "BRONZE"}
DIVISIONS = ["I", "II", "III", "IV"]


def path(ddir):
    return os.path.join(ddir, "tiers.sqlite")


def connect(ddir):
    con = db.connect(path(ddir))
    con.execute("""CREATE TABLE IF NOT EXISTS tier_players (puuid TEXT PRIMARY KEY, tier TEXT, division TEXT, region TEXT, fetched_ms INTEGER)""")
    con.execute("""CREATE TABLE IF NOT EXISTS tier_games (match_id TEXT, puuid TEXT, tier TEXT, position TEXT, PRIMARY KEY (match_id, puuid))""")
    return con


def next_tier(tier, goal=None):
    """Meta do cadastro se for acima do elo atual; senao, o elo logo acima."""
    cur = TIERS.index(tier) if tier in TIERS else 2  # sem elo: compara com Ouro
    g = GOAL_TO_TIER.get(goal or "")
    if g and TIERS.index(g) > cur:
        return g
    return TIERS[min(cur + 1, len(TIERS) - 1)] if tier in TIERS else "GOLD"


def count(ddir, tier, position):
    if not os.path.exists(path(ddir)):
        return 0
    con = connect(ddir)
    try:
        return con.execute("SELECT COUNT(*) FROM tier_games WHERE tier=? AND position=?", (tier, position)).fetchone()[0]
    finally:
        con.close()


def games(ddir, tier, position):
    if not os.path.exists(path(ddir)):
        return []
    con = connect(ddir)
    try:
        rows = con.execute(
            """SELECT p.*, m.duration_s, m.patch, m.started_ms FROM tier_games t
               JOIN participants p ON p.match_id=t.match_id AND p.puuid=t.puuid
               JOIN matches m ON m.match_id=t.match_id
               WHERE t.tier=? AND t.position=? AND COALESCE(m.duration_s,0)>=300""", (tier, position)).fetchall()
        return report._games_from_rows(con, rows)
    finally:
        con.close()


def sample(client, ddir, tier, position, region, target=40, per_player=4, log=print):
    """Junta ate `target` partidas novas de jogadores do elo na posicao pedida (fila solo/duo)."""
    con = connect(ddir)
    try:
        have = con.execute("SELECT COUNT(*) FROM tier_games WHERE tier=? AND position=?", (tier, position)).fetchone()[0]
        log(f"Já tenho {have} partidas de {tier.title()} nessa posição; buscando mais {target}.")
        known = db.known_match_ids(con)
        saved, looked = 0, 0
        apex = tier in ("MASTER", "GRANDMASTER", "CHALLENGER")
        divs = [None] if apex else DIVISIONS
        for div in divs:
            if saved >= target:
                break
            for page in (1, 2):
                if saved >= target:
                    break
                if apex:
                    entries = client.league_entries(tier.lower()) if page == 1 else []
                else:
                    entries = client._get(f"/lol/league/v4/entries/RANKED_SOLO_5x5/{tier}/{div}", {"page": page},
                                          host=client.platform_host) or []
                for ent in entries[:40]:
                    if saved >= target:
                        break
                    puuid = ent.get("puuid")
                    if not puuid:
                        continue
                    looked += 1
                    con.execute("INSERT OR REPLACE INTO tier_players VALUES (?,?,?,?,?)",
                                (puuid, tier, ent.get("rank"), region, db.now_ms()))
                    got = 0
                    for mid in client.match_ids(puuid, count=per_player, queue=420):
                        if mid in known or got >= 2 or saved >= target:
                            continue
                        m = client.match(mid)
                        known.add(mid)
                        if not m:
                            continue
                        me = next((p for p in m["info"]["participants"] if p["puuid"] == puuid), None)
                        if not me or me.get("teamPosition") != position:
                            continue
                        db.save_match(con, m, client.timeline(mid), source="tier")
                        con.execute("INSERT OR IGNORE INTO tier_games VALUES (?,?,?,?)", (mid, puuid, tier, position))
                        con.commit()
                        saved += 1
                        got += 1
                    if looked % 5 == 0:
                        log(f"Olhando jogador {looked} de {tier.title()} {div or ''} (salvas: {saved}/{target})…")
        con.commit()
        log(f"Pronto: {saved} partidas novas de {tier.title()}.")
        return saved
    finally:
        con.close()
