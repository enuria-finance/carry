"""Onde ficam os dados de cada pessoa.

- accounts.sqlite: contas, sessoes, vinculos (accounts.py)
- users/u<ID>.sqlite: partidas, revisoes, pool e metas de UM usuario (isolado dos outros)
- top.sqlite: amostra dos melhores, baixada uma vez e compartilhada com todos
O banco antigo (coach.sqlite) vira o banco do primeiro admin, sem mover nada.
"""
import os

from . import db

MATCH_TABLES = ("matches", "participants", "frames", "deaths", "wards", "events", "participant_extra", "raw", "match_source")


def data_dir(db_path):
    return os.path.dirname(os.path.abspath(db_path))


def top_path(ddir):
    return os.path.join(ddir, "top.sqlite")


def user_db(ddir, user, legacy_name="coach.sqlite"):
    """Caminho do banco do usuario (cria o nome na primeira vez)."""
    name = user["db_file"]
    if not name:
        name = os.path.join("users", f"u{int(user['id'])}.sqlite")
    path = os.path.join(ddir, name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path, name


def _cols(con, schema, table):
    return [r[1] for r in con.execute(f"PRAGMA {schema}.table_info({table})")]


def copy_matches(src_path, dst_con, match_ids):
    """Copia partidas inteiras (todas as tabelas) de outro banco. So as que ainda nao existem no destino."""
    if not match_ids or not os.path.exists(src_path):
        return 0
    have = {r[0] for r in dst_con.execute("SELECT match_id FROM matches")}
    ids = [m for m in match_ids if m not in have]
    if not ids:
        return 0
    dst_con.commit()
    dst_con.execute("ATTACH DATABASE ? AS src", (src_path,))
    try:
        dst_con.execute("CREATE TEMP TABLE IF NOT EXISTS _ids (m TEXT PRIMARY KEY)")
        dst_con.execute("DELETE FROM _ids")
        dst_con.executemany("INSERT OR IGNORE INTO _ids VALUES (?)", [(m,) for m in ids])
        for t in MATCH_TABLES:
            src_cols = set(_cols(dst_con, "src", t))
            cols = [c for c in _cols(dst_con, "main", t) if c in src_cols]
            if not cols:
                continue
            cl = ",".join(cols)
            dst_con.execute(f"INSERT OR IGNORE INTO main.{t} ({cl}) SELECT {cl} FROM src.{t} WHERE match_id IN (SELECT m FROM _ids)")
        if "top_players" in {r[0] for r in dst_con.execute("SELECT name FROM src.sqlite_master WHERE type='table'")}:
            dst_con.execute("INSERT OR REPLACE INTO main.top_players SELECT * FROM src.top_players")
        dst_con.commit()
    finally:
        dst_con.execute("DETACH DATABASE src")
    return len(ids)


def top_ids(path):
    if not os.path.exists(path):
        return []
    c = db.connect(path)
    try:
        return [r[0] for r in c.execute("SELECT match_id FROM match_source WHERE source='top'")]
    finally:
        c.close()


_IMPORTED = {}


def import_top(ddir, user_con):
    """Traz para o banco do usuario as partidas do topo que ele ainda nao tem (copia local, sem chamar a Riot).
    So refaz quando a base geral mudou ou a cada 10 min: antes rodava inteiro em toda pagina e deixava o app lento."""
    import time as _time
    tp = top_path(ddir)
    try:
        upath = user_con.execute("PRAGMA database_list").fetchone()[2]
        stamp = os.path.getmtime(tp) if os.path.exists(tp) else 0
    except Exception:
        upath, stamp = None, 0
    last = _IMPORTED.get(upath)
    if upath and last and _time.time() - last[1] < 600:
        return 0
    if upath:
        _IMPORTED[upath] = (stamp, _time.time())
    ids = top_ids(tp)
    n = copy_matches(tp, user_con, ids)
    # o que saiu da base geral (partidas antigas) sai da copia do usuario tambem
    try:
        have = {r[0] for r in user_con.execute("SELECT match_id FROM match_source WHERE source='top'")}
        mine = {r[0] for r in user_con.execute("SELECT DISTINCT match_id FROM raw")}   # partidas do proprio usuario nunca saem
        gone = list(have - set(ids) - mine)
        for i in range(0, len(gone), 400):
            chunk = gone[i:i + 400]
            q = ",".join("?" * len(chunk))
            for t in ("participants", "participant_extra", "frames", "deaths", "wards", "events", "match_source", "matches"):
                user_con.execute(f"DELETE FROM {t} WHERE match_id IN ({q})", chunk)
        if gone:
            user_con.commit()
    except Exception:
        pass
    return n


def seed_top_from(ddir, legacy_path):
    """Primeira vez: o que ja estava baixado no banco antigo vai para a amostra compartilhada."""
    tp = top_path(ddir)
    if not os.path.exists(legacy_path) or os.path.abspath(tp) == os.path.abspath(legacy_path):
        return 0
    ids = top_ids(legacy_path)
    if not ids:
        return 0
    c = db.connect(tp)
    try:
        n = copy_matches(legacy_path, c, ids)
        c.execute("INSERT OR IGNORE INTO seen_matches SELECT match_id FROM match_source")
        c.commit()
        return n
    finally:
        c.close()
