"""Missao do dia: UMA meta tirada do seu Diagnostico, conferida sozinha em cada partida do dia.

- Dia cumprido: cumpriu a meta em pelo menos metade das partidas do dia (minimo 1 partida).
- Sequencia: dias JOGADOS seguidos cumprindo (dia sem jogar nao quebra; dia jogado sem cumprir quebra).
- Formatura: cumpriu 3 dias jogados seguidos com a mesma meta -> a meta fica mais exigente ou passa para a proxima.
"""
import math
import time

from . import diagnosis, report

BADGES = [(3, "Constante", "3 dias seguidos"), (7, "Disciplina", "1 semana"), (14, "Mentalidade", "2 semanas"),
          (30, "Lenda", "30 dias")]

# meta por fator do Diagnostico: (metrica, operador, alvo facil, alvo dificil, texto facil, texto dificil)
MISSIONS = {
    "deaths10": ("deaths_before_10", "<=", 1, 0, "No máximo 1 morte antes dos 10 minutos", "Zero mortes antes dos 10 minutos"),
    "csdiff10": ("csdiff10", ">=", 0, 8, "CS aos 10 igual ou melhor que o oponente", "8 CS à frente do oponente aos 10"),
    "gold15": ("golddiff15", ">=", 0, 500, "Ouro igual ou à frente do oponente aos 15", "500 de ouro à frente aos 15"),
}
FALLBACK = ("cs_per_min", ">=", 6.5, 7.5, "6,5 de CS por minuto ou mais", "7,5 de CS por minuto ou mais")


def _ensure(con):
    con.execute("""CREATE TABLE IF NOT EXISTS missions (
        day TEXT PRIMARY KEY, lever TEXT, level INTEGER, metric TEXT, op TEXT, target REAL, text TEXT, created_ms INTEGER)""")


def today(now=None):
    return time.strftime("%Y-%m-%d", time.localtime(now or time.time()))


def _day_of(ms):
    return time.strftime("%Y-%m-%d", time.localtime((ms or 0) / 1000))


def _met(v, op, target):
    return (v <= target) if op == "<=" else (v >= target)


def day_result(games, m):
    """(partidas com a medida, cumpridas, status) para o dia da missao."""
    gs = [g for g in games if _day_of(g["started_ms"]) == m["day"] and g.get(m["metric"]) is not None]
    met = sum(1 for g in gs if _met(g[m["metric"]], m["op"], m["target"]))
    if not gs:
        return 0, 0, "pending"
    return len(gs), met, "done" if met >= math.ceil(len(gs) / 2) else "failed"


def history(con, games, limit=60):
    _ensure(con)
    rows = [dict(r) for r in con.execute("SELECT * FROM missions ORDER BY day DESC LIMIT ?", (limit,))]
    for r in rows:
        r["n"], r["met"], r["status"] = day_result(games, r)
    return rows


def streak(hist):
    """(atual, melhor). Dias sem jogo (pending) nao contam nem quebram, exceto hoje que ainda pode virar."""
    cur, best, run, broken = 0, 0, 0, False
    for r in hist:  # do mais novo para o mais velho
        if r["status"] == "pending":
            continue
        if r["status"] == "done":
            run += 1
            if not broken:
                cur = run
        else:
            broken = True
            best = max(best, run)
            run = 0
    return cur, max(best, run, cur)


def _choose(games, hist):
    lvs = [l for l in diagnosis.levers(games) if l["pesa"] and l["actionable"]] if len(games) >= 20 else []
    order = [l["key"] for l in lvs] or ["deaths10"]
    played = [h for h in hist if h["status"] != "pending"]
    last = played[0] if played else None
    if last:
        same = []
        for h in played:
            if h["lever"] == last["lever"] and h["level"] == last["level"]:
                same.append(h)
            else:
                break
        grad = len(same) >= 3 and all(h["status"] == "done" for h in same[:3])
        if not grad:
            return last["lever"], last["level"]
        if last["level"] == 0 and last["lever"] in MISSIONS:
            return last["lever"], 1                       # mesma meta, mais exigente
        nxt = [k for k in order if k != last["lever"]]
        return (nxt[0] if nxt else last["lever"]), 0      # proxima fraqueza
    return order[0], 0


def ensure_today(con, games):
    """Cria a missao de hoje (se ainda nao existe) e devolve tudo o que a tela precisa."""
    _ensure(con)
    day = today()
    row = con.execute("SELECT * FROM missions WHERE day=?", (day,)).fetchone()
    if not row:
        hist = history(con, games)
        lever, level = _choose(games, hist)
        metric, op, easy, hard, t_easy, t_hard = MISSIONS.get(lever, FALLBACK)
        target, text = (hard, t_hard) if level else (easy, t_easy)
        con.execute("INSERT INTO missions VALUES (?,?,?,?,?,?,?,?)", (day, lever, level, metric, op, target, text, int(time.time() * 1000)))
        con.commit()
    hist = history(con, games)
    m = hist[0]
    cur, best = streak(hist)
    today_games = sorted([g for g in games if _day_of(g["started_ms"]) == day], key=lambda g: g["started_ms"] or 0)
    checks = [{"champion": g["champion"], "win": g["win"], "match_id": g["match_id"], "value": g.get(m["metric"]),
               "ok": (g.get(m["metric"]) is not None and _met(g[m["metric"]], m["op"], m["target"]))} for g in today_games]
    why = None
    lv = next((l for l in diagnosis.levers(games) if l["key"] == m["lever"]), None) if len(games) >= 20 else None
    if lv and lv["pesa"]:
        ok = sorted([g for g in lv["groups"] if g["n"] >= diagnosis.MIN_GROUP], key=lambda g: -g["wr"])
        why = (ok[0], ok[-1], lv["gap"])
    done_days = sum(1 for h in hist if h["status"] == "done")
    return {"mission": m, "streak": cur, "best": best, "checks": checks, "hist": hist, "why": why,
            "badges": [(d, n, s, best >= d) for d, n, s in BADGES], "done_days": done_days}


def sync_note(con, puuid):
    """Linha para o fim da sincronizacao: como esta a missao de hoje."""
    try:
        games = report.my_games(con, puuid, "")
        st = ensure_today(con, games)
    except Exception:
        return None
    m = st["mission"]
    if not st["checks"]:
        return None
    ok = sum(1 for c in st["checks"] if c["ok"])
    flag = "✓ cumprida" if m["status"] == "done" else "ainda não"
    return f"Missão de hoje ({m['text']}): {ok}/{len(st['checks'])} partidas · {flag} · sequência {st['streak']} dia(s)."
