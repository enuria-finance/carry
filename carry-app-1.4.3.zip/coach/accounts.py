"""Contas do app: usuarios, sessoes, papeis (admin/usuario), vinculo com a conta da Riot e auditoria.

Tudo fica em accounts.sqlite, ao lado do banco. Senhas: PBKDF2-SHA256 com sal (nunca em texto).
Sessao: token aleatorio no cookie (HttpOnly); no banco fica so o hash do token.
"""
import hashlib
import hmac
import os
import re
import secrets
import sqlite3
import time

ITER = 240_000
SESSION_DAYS = 30
MAX_FAILS = 5          # tentativas erradas...
FAIL_WINDOW_S = 900    # ...em 15 minutos bloqueiam o login por 15 minutos
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,190}\.[^@\s]{2,24}$")
RIOT_ID_RE = re.compile(r"^.{3,16}#[^#\s]{2,5}$")
# Icones que toda conta tem desde o inicio: usados para provar que a conta e sua.
STARTER_ICONS = list(range(0, 29))

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    pass_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',          -- 'admin' | 'user'
    status TEXT NOT NULL DEFAULT 'active',      -- 'active' | 'pending' | 'blocked'
    db_file TEXT,                               -- banco de partidas deste usuario
    discord TEXT, goal TEXT, pref_role TEXT, source TEXT,
    consent_ms INTEGER,
    created_ms INTEGER, last_login_ms INTEGER, last_seen_ms INTEGER
);
CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL, csrf TEXT NOT NULL,
    created_ms INTEGER, expires_ms INTEGER, ip TEXT, ua TEXT
);
CREATE TABLE IF NOT EXISTS riot_links (
    user_id INTEGER PRIMARY KEY,
    riot_id TEXT NOT NULL, region TEXT NOT NULL, puuid TEXT,
    verified_ms INTEGER, challenge_icon INTEGER, challenge_ms INTEGER,
    icon INTEGER, level INTEGER,
    tier TEXT, division TEXT, lp INTEGER, wins INTEGER, losses INTEGER,
    main_champ TEXT, main_role TEXT, pool TEXT, games INTEGER, winrate REAL,
    updated_ms INTEGER
);
CREATE TABLE IF NOT EXISTS login_fails (key TEXT, at_ms INTEGER);
CREATE TABLE IF NOT EXISTS audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT, at_ms INTEGER, user_id INTEGER, actor_id INTEGER,
    action TEXT, detail TEXT, ip TEXT
);
CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS prefs (user_id INTEGER, k TEXT, v TEXT, PRIMARY KEY (user_id, k));
"""

SIGNUP_MODES = {"aberto": "Aberto (qualquer um cria conta)",
                "aprovacao": "Com aprovação (você aprova cada conta)",
                "fechado": "Fechado (só o admin cria contas)"}


def now_ms():
    return int(time.time() * 1000)


def connect(data_dir):
    con = sqlite3.connect(os.path.join(data_dir, "accounts.sqlite"), timeout=10)
    con.row_factory = sqlite3.Row
    con.executescript(SCHEMA)
    return con


# -- senhas -------------------------------------------------------------
def hash_password(pw):
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), salt, ITER)
    return f"pbkdf2_sha256${ITER}${salt.hex()}${dk.hex()}"


def check_password(pw, stored):
    try:
        _, it, salt, dk = stored.split("$")
        got = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), bytes.fromhex(salt), int(it))
        return hmac.compare_digest(got.hex(), dk)
    except (ValueError, AttributeError):
        return False


def password_problem(pw):
    if len(pw) < 8:
        return "A senha precisa ter pelo menos 8 caracteres."
    if len(pw) > 200:
        return "Senha longa demais."
    if pw.isdigit() or pw.lower() in ("12345678", "password", "senha123", "qwerty123"):
        return "Senha fácil demais. Misture letras e números."
    return None


# -- configuracoes do app (modo de cadastro etc.) ------------------------
def setting(con, k, default=None):
    r = con.execute("SELECT v FROM settings WHERE k=?", (k,)).fetchone()
    return r[0] if r else default


def set_setting(con, k, v):
    con.execute("INSERT OR REPLACE INTO settings VALUES (?,?)", (k, v))
    con.commit()


def signup_mode(con):
    m = setting(con, "signup_mode", "aprovacao")
    return m if m in SIGNUP_MODES else "aprovacao"


# -- auditoria ------------------------------------------------------------
def audit(con, action, user_id=None, actor_id=None, detail="", ip=""):
    con.execute("INSERT INTO audit (at_ms,user_id,actor_id,action,detail,ip) VALUES (?,?,?,?,?,?)",
                (now_ms(), user_id, actor_id, action, (detail or "")[:300], ip or ""))
    con.execute("DELETE FROM audit WHERE id < (SELECT MAX(id) - 5000 FROM audit)")
    con.commit()


# -- usuarios -------------------------------------------------------------
def user_count(con):
    return con.execute("SELECT COUNT(*) FROM users").fetchone()[0]


def get_user(con, uid):
    return con.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()


def by_email(con, email):
    return con.execute("SELECT * FROM users WHERE email=?", ((email or "").strip().lower(),)).fetchone()


def create_user(con, email, name, password, role=None, status=None, **extra):
    """Cria a conta. A primeira conta do app vira admin (o dono). Devolve (id, erro)."""
    email = (email or "").strip().lower()
    name = (name or "").strip()[:40]
    if not EMAIL_RE.match(email):
        return None, "E-mail inválido."
    if len(name) < 2:
        return None, "Digite seu nome ou apelido."
    p = password_problem(password or "")
    if p:
        return None, p
    if by_email(con, email):
        return None, "Já existe uma conta com esse e-mail."
    first = user_count(con) == 0
    role = role or ("admin" if first else "user")
    if status is None:
        status = "active" if first or signup_mode(con) == "aberto" else "pending"
    fields = {k: (str(v).strip()[:80] if v else None) for k, v in extra.items()
              if k in ("discord", "goal", "pref_role", "source")}
    cur = con.execute(
        "INSERT INTO users (email,name,pass_hash,role,status,created_ms,consent_ms,discord,goal,pref_role,source)"
        " VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (email, name, hash_password(password), role, status, now_ms(), now_ms(),
         fields.get("discord"), fields.get("goal"), fields.get("pref_role"), fields.get("source")))
    con.commit()
    return cur.lastrowid, None


def update_profile(con, uid, **kw):
    allowed = {k: (str(v).strip()[:80] or None) for k, v in kw.items()
               if k in ("name", "discord", "goal", "pref_role") and v is not None}
    if "name" in allowed and (not allowed["name"] or len(allowed["name"]) < 2):
        allowed.pop("name")
    if allowed:
        con.execute("UPDATE users SET " + ",".join(f"{k}=?" for k in allowed) + " WHERE id=?", (*allowed.values(), uid))
        con.commit()


def set_password(con, uid, pw):
    con.execute("UPDATE users SET pass_hash=? WHERE id=?", (hash_password(pw), uid))
    con.execute("DELETE FROM sessions WHERE user_id=?", (uid,))  # derruba sessoes antigas
    con.commit()


def set_user_field(con, uid, field, value):
    assert field in ("role", "status", "db_file")
    con.execute(f"UPDATE users SET {field}=? WHERE id=?", (value, uid))
    if field == "status" and value != "active":
        con.execute("DELETE FROM sessions WHERE user_id=?", (uid,))
    con.commit()


def admins(con):
    return con.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND status='active'").fetchone()[0]


def delete_user(con, uid):
    con.execute("DELETE FROM prefs WHERE user_id=?", (uid,))
    con.execute("DELETE FROM sessions WHERE user_id=?", (uid,))
    con.execute("DELETE FROM riot_links WHERE user_id=?", (uid,))
    con.execute("DELETE FROM users WHERE id=?", (uid,))
    con.commit()


def list_users(con):
    return con.execute(
        """SELECT u.*, l.riot_id, l.region, l.puuid, l.verified_ms, l.icon, l.level, l.tier, l.division, l.lp,
                  l.wins, l.losses, l.main_champ, l.main_role, l.pool, l.games, l.winrate
           FROM users u LEFT JOIN riot_links l ON l.user_id=u.id ORDER BY u.created_ms""").fetchall()


# -- login com limite de tentativas ---------------------------------------
def _fail_key(email, ip):
    return f"{(email or '').strip().lower()}|{ip}"


def locked(con, email, ip):
    since = now_ms() - FAIL_WINDOW_S * 1000
    n = con.execute("SELECT COUNT(*) FROM login_fails WHERE key=? AND at_ms>?", (_fail_key(email, ip), since)).fetchone()[0]
    n_ip = con.execute("SELECT COUNT(*) FROM login_fails WHERE key LIKE ? AND at_ms>?", ("%|" + ip, since)).fetchone()[0]
    return n >= MAX_FAILS or n_ip >= MAX_FAILS * 4


def authenticate(con, email, pw, ip):
    """Devolve (user, erro)."""
    if locked(con, email, ip):
        return None, "Muitas tentativas erradas. Espere 15 minutos e tente de novo."
    u = by_email(con, email)
    ok = check_password(pw or "", u["pass_hash"]) if u else check_password(pw or "", hash_password("x"))  # tempo parecido
    if not u or not ok:
        con.execute("INSERT INTO login_fails VALUES (?,?)", (_fail_key(email, ip), now_ms()))
        con.execute("DELETE FROM login_fails WHERE at_ms<?", (now_ms() - 86400000,))
        con.commit()
        audit(con, "login_falhou", u["id"] if u else None, detail=(email or "")[:80], ip=ip)
        return None, "E-mail ou senha incorretos."
    if u["status"] == "blocked":
        return None, "Esta conta está bloqueada. Fale com o administrador."
    con.execute("DELETE FROM login_fails WHERE key=?", (_fail_key(email, ip),))
    con.execute("UPDATE users SET last_login_ms=? WHERE id=?", (now_ms(), u["id"]))
    con.commit()
    return u, None


# -- sessoes --------------------------------------------------------------
def _h(token):
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def new_session(con, uid, ip="", ua=""):
    token = secrets.token_urlsafe(32)
    con.execute("INSERT INTO sessions VALUES (?,?,?,?,?,?,?)",
                (_h(token), uid, secrets.token_urlsafe(24), now_ms(), now_ms() + SESSION_DAYS * 86400000, ip, (ua or "")[:200]))
    con.execute("DELETE FROM sessions WHERE expires_ms<?", (now_ms(),))
    con.commit()
    return token


def session_user(con, token):
    """(user, sessao) ou (None, None). Renova o prazo a cada uso (no maximo 1x por hora)."""
    if not token or len(token) > 100:
        return None, None
    s = con.execute("SELECT * FROM sessions WHERE token_hash=?", (_h(token),)).fetchone()
    if not s or s["expires_ms"] < now_ms():
        return None, None
    u = get_user(con, s["user_id"])
    if not u or u["status"] == "blocked":
        return None, None
    if s["expires_ms"] - now_ms() < (SESSION_DAYS * 86400000 - 3600000):
        con.execute("UPDATE sessions SET expires_ms=? WHERE token_hash=?", (now_ms() + SESSION_DAYS * 86400000, s["token_hash"]))
        con.execute("UPDATE users SET last_seen_ms=? WHERE id=?", (now_ms(), u["id"]))
        con.commit()
    return u, s


def end_session(con, token):
    if token:
        con.execute("DELETE FROM sessions WHERE token_hash=?", (_h(token),))
        con.commit()


def check_csrf(sess, value):
    return bool(sess) and bool(value) and hmac.compare_digest(sess["csrf"], value)


# -- vinculo com a conta da Riot -------------------------------------------
def link(con, uid):
    return con.execute("SELECT * FROM riot_links WHERE user_id=?", (uid,)).fetchone()


def set_link(con, uid, riot_id, region, puuid):
    """Novo vinculo (ou troca de conta): zera a verificacao e os dados antigos."""
    con.execute("DELETE FROM riot_links WHERE user_id=?", (uid,))
    con.execute("INSERT INTO riot_links (user_id,riot_id,region,puuid,updated_ms) VALUES (?,?,?,?,?)",
                (uid, riot_id, region, puuid, now_ms()))
    con.commit()


def puuid_taken(con, puuid, uid):
    r = con.execute("SELECT user_id FROM riot_links WHERE puuid=? AND verified_ms IS NOT NULL AND user_id<>?", (puuid, uid)).fetchone()
    return bool(r)


def new_challenge(con, uid, current_icon):
    choices = [i for i in STARTER_ICONS if i != current_icon]
    icon = secrets.choice(choices)
    con.execute("UPDATE riot_links SET challenge_icon=?, challenge_ms=?, icon=? WHERE user_id=?",
                (icon, now_ms(), current_icon, uid))
    con.commit()
    return icon


def mark_verified(con, uid):
    con.execute("UPDATE riot_links SET verified_ms=?, challenge_icon=NULL WHERE user_id=?", (now_ms(), uid))
    con.commit()


def update_link_stats(con, uid, **kw):
    allowed = {k: v for k, v in kw.items() if k in (
        "icon", "level", "tier", "division", "lp", "wins", "losses", "main_champ", "main_role", "pool", "games", "winrate", "riot_id")}
    if allowed:
        allowed["updated_ms"] = now_ms()
        con.execute("UPDATE riot_links SET " + ",".join(f"{k}=?" for k in allowed) + " WHERE user_id=?", (*allowed.values(), uid))
        con.commit()


def verified_links(con, active_days=None):
    q = """SELECT l.*, u.db_file, u.last_seen_ms FROM riot_links l JOIN users u ON u.id=l.user_id
           WHERE l.verified_ms IS NOT NULL AND u.status='active'"""
    args = ()
    if active_days:
        q += " AND COALESCE(u.last_seen_ms, u.last_login_ms, 0) > ?"
        args = (now_ms() - active_days * 86400000,)
    return con.execute(q, args).fetchall()


def pref(con, uid, k, default=None):
    r = con.execute("SELECT v FROM prefs WHERE user_id=? AND k=?", (uid, k)).fetchone()
    return r[0] if r else default


def set_pref(con, uid, k, v):
    if v is None:
        con.execute("DELETE FROM prefs WHERE user_id=? AND k=?", (uid, k))
    else:
        con.execute("INSERT OR REPLACE INTO prefs VALUES (?,?,?)", (uid, k, v))
    con.commit()
