"""Diagnostico em camadas: primeiro o gancho (o numero que mais pesa), depois o detalhe so para quem quiser abrir.

Cada fator vira um cartao com manchete curta, as barras e tres gavetas fechadas
(o numero / por que acontece / treino de hoje). Assim a pessoa le uma coisa de cada vez.
"""
import html

from . import diagnosis, premium

e = lambda x: html.escape("" if x is None else str(x))
ICON = {"dado": "📊", "hipotese": "🤔", "regra geral": "🎯"}
DRAWER = {"dado": "O número por trás", "hipotese": "Por que isso acontece?", "regra geral": "O treino de hoje"}
TEASE = {"dado": "veja os grupos lado a lado", "hipotese": "a explicação mais provável", "regra geral": "o que fazer na próxima partida"}


def _ends(lv):
    ok = sorted([g for g in lv["groups"] if g["n"] >= diagnosis.MIN_GROUP], key=lambda g: -g["wr"])
    return ok[0], ok[-1]


def headline(lv):
    hi, lo = _ends(lv)
    k = lv["key"]
    if k == "deaths10":
        return f"Morrer cedo está te custando {lv['gap']} pontos de vitória"
    if k == "csdiff10":
        return f"Perder o farm aos 10 derruba a sua vitória para {lo['wr']}%"
    if k == "gold15":
        return f"Aos 15 minutos, o jogo já pende {lv['gap']} pontos"
    if k == "duration":
        return f"Seus jogos de {hi['label']} rendem {lv['gap']} pontos a mais"
    if k == "pool":
        return f"De {hi['label']} você vence {hi['wr']}%; de {lo['label']}, só {lo['wr']}%"
    if k == "tilt":
        return f"Jogo {lo['label']}: só {lo['wr']}% de vitória"
    if k == "hour":
        return f"Você rende {lv['gap']} pontos a mais de {hi['label'].split(' ')[0]}"
    return f"{hi['label']}: {hi['wr']}% contra {lo['wr']}%"


def _ring(pct, cls, size=118):
    r, c = 48, 2 * 3.14159 * 48
    return (f"<svg class='dring {cls}' width='{size}' height='{size}' viewBox='0 0 110 110'><circle cx='55' cy='55' r='{r}' class='bg'/>"
            f"<circle cx='55' cy='55' r='{r}' class='fg' stroke-dasharray='{c:.1f}' stroke-dashoffset='{c * (1 - pct / 100):.1f}' transform='rotate(-90 55 55)'/>"
            f"<text x='55' y='62' text-anchor='middle'>{pct}%</text></svg>")


def _pips(gap):
    on = max(1, min(5, round(gap / 8)))
    return "<span class='pips' title='Quanto pesa'>" + "".join(f"<i class='{'on' if i < on else ''}'></i>" for i in range(5)) + "</span>"


def _bars(lv):
    out = ""
    for g in lv["groups"]:
        low = g["n"] < diagnosis.MIN_GROUP
        out += (f"<div class='pb{' low' if low else ''}'><span class='pn'>{e(g['label'])}</span>"
                f"<span class='pt2'><i style='width:{g['wr']}%'></i><u></u></span>"
                f"<span class='pv'>{g['wr']}% <small>· {g['n']}j</small></span></div>")
    return out


def _drawers(lv, sample_note, open_training=False):
    out = ""
    for t in diagnosis.reading(lv):
        kind = t["kind"]
        cls = kind.split()[0]
        n = f" <span class='n'>({e(sample_note(t['n']))})</span>" if t.get("n") is not None else ""
        op = " open" if (open_training and kind == "regra geral") else ""
        out += (f"<details class='drawer {cls}'{op}><summary><span class='di'>{ICON.get(kind, '•')}</span>"
                f"<span class='dt'><b>{e(DRAWER.get(kind, kind))}</b><small>{e(TEASE.get(kind, ''))}</small></span>"
                f"<span class='tag {cls}'>{e('hipótese' if kind == 'hipotese' else kind)}</span><span class='chev'>›</span></summary>"
                f"<div class='dbody'>{e(t['text'])}{n}</div></details>")
    return out


def build(base, lane_label, wins, sample_note):
    lvs = diagnosis.levers(base)
    heavy = [l for l in lvs if l["pesa"]]
    light = [l for l in lvs if not l["pesa"]]
    wr = round(100 * wins / len(base))
    body = (f"<div class='dmeta'><span class='pill'><small>Base</small>{len(base)} partidas {e(lane_label)}</span>"
            f"<span class='pill'><small>Vitória</small>{wr}%</span>"
            f"<span class='pill' title='Grupos com menos de {diagnosis.MIN_GROUP} jogos aparecem apagados e não entram no ranking.'>"
            "<small>Como ler</small>vitórias × derrotas ⓘ</span></div>")
    top = next((l for l in heavy if l["actionable"]), heavy[0] if heavy else None)
    if top:
        hi, lo = _ends(top)
        body += (f"<section class='dhero rv'><div class='dh-copy'><p class='dh-k'><i></i>Achamos {len(heavy)} coisa{'s' if len(heavy) != 1 else ''} que decide{'m' if len(heavy) != 1 else ''} os seus jogos</p>"
                 f"<p class='dh-t'>{e(headline(top))}</p>"
                 f"<p class='dh-s'>Nos seus jogos com <b>{e(hi['label'].lower())}</b> você vence <b class='win'>{hi['wr']}%</b>. "
                 f"Com <b>{e(lo['label'].lower())}</b>, cai para <b class='loss'>{lo['wr']}%</b>.</p>"
                 f"<a class='btn gold' href='#lv-{e(top['key'])}' data-go='lv-{e(top['key'])}'>Ver o treino para isso ↓</a></div>"
                 f"<div class='dh-duel'><figure>{_ring(hi['wr'], 'good')}<figcaption>{e(hi['label'])}<small>{hi['n']} jogos</small></figcaption></figure>"
                 f"<span class='dh-gap'>−{top['gap']}<small>pontos</small></span>"
                 f"<figure>{_ring(lo['wr'], 'bad')}<figcaption>{e(lo['label'])}<small>{lo['n']} jogos</small></figcaption></figure></div></section>")
    tabs = []
    for i, lv in enumerate(heavy, 1):
        nxt = (f"<a class='dnext' href='#lv-{e(heavy[i]['key'])}' data-go='lv-{e(heavy[i]['key'])}'>Próximo: {e(heavy[i]['title'])} →</a>" if i < len(heavy) else
               "<span class='dnext done'>✓ Você viu tudo o que pesa</span>")
        card = (f"<article class='dcard2 rv in{' first' if i == 1 else ''}' id='lv-{e(lv['key'])}'>"
                f"<header><span class='rank'>#{i}</span><div><small>{e(lv['title'])}</small><b>{e(headline(lv))}</b></div>"
                f"<div class='impact'><span class='gapn'>{lv['gap']}<small>pts</small></span>{_pips(lv['gap'])}</div></header>"
                f"<div class='dbars'>{_bars(lv)}</div><div class='drawers'>{_drawers(lv, sample_note, open_training=(i == 1))}</div>{nxt}</article>")
        short = lv["title"]
        tabs.append((f"lv-{lv['key']}", f"#{i} {short}", card, f"{lv['gap']} pontos"))
    if light:
        lt = ("<p class='n'>Aqui a diferença entre os grupos é pequena: não vale gastar energia agora.</p><div class='dlight'>")
        for lv in light:
            lt += (f"<details class='lchip'><summary><span class='ok'>✓</span><b>{e(lv['title'])}</b>"
                   f"<small>só {lv['gap']} pts de diferença</small><span class='chev'>›</span></summary>"
                   f"<div class='dbars'>{_bars(lv)}</div></details>")
        lt += "</div>"
        tabs.append(("nao-pesa", "O que não pesa", lt, f"{len(light)} item(ns)"))
    if tabs:
        body += "<h2>O que pesa · comece pelo #1</h2>" + premium.tabbar(tabs, "diag")
    body += "<p class='n dfoot'>Tudo aqui é comparação entre os SEUS jogos: mostra o que anda junto com vitória, não prova a causa.</p>"
    body += ("<script>(function(){function op(id){var c=document.getElementById(id);if(!c)return;"
             "var d=c.querySelector('details.drawer.regra');if(d)d.open=true;c.classList.add('flash');setTimeout(function(){c.classList.remove('flash')},1600)}"
             "document.addEventListener('click',function(ev){var a=ev.target.closest&&ev.target.closest('a[href^=\"#lv-\"]');if(a)op(a.getAttribute('href').slice(1))});"
             "})();</script>")
    return body


CSS = """
/* ---------- diagnostico em camadas ---------- */
.dmeta{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 18px}
.dhero{position:relative;overflow:hidden;display:grid;grid-template-columns:minmax(0,1.2fr) auto;gap:30px;align-items:center;padding:30px 34px;border-radius:18px;
border:1px solid rgba(59,158,255,.45);background:radial-gradient(120% 140% at 100% 0%,rgba(59,158,255,.22),transparent 55%),linear-gradient(135deg,#131b29,#0f141c)}
.dhero::before{content:"";position:absolute;inset:0;background:linear-gradient(115deg,transparent 40%,rgba(255,255,255,.05) 50%,transparent 60%);background-size:250% 100%;animation:sheen 6s ease-in-out infinite}
@keyframes sheen{0%{background-position:150% 0}60%,100%{background-position:-100% 0}}
.dh-copy,.dh-duel{position:relative}
.dh-k{display:flex;align-items:center;gap:9px;margin:0 0 10px;color:var(--gold);font:600 12px var(--mono);letter-spacing:.16em;text-transform:uppercase}
.dh-k i{width:9px;height:9px;background:var(--gold);transform:rotate(45deg);box-shadow:0 0 12px var(--gold)}
.dh-t{font:700 clamp(24px,2.6vw,36px)/1.12 var(--head);color:#fff;margin:0 0 12px;letter-spacing:-.01em;max-width:24ch}
.dh-s{color:#c3cce0;font-size:16px;margin:0 0 18px;max-width:52ch}
.dh-duel{display:flex;align-items:center;gap:18px}
.dh-duel figure{margin:0;text-align:center}
.dh-duel figcaption{font:600 13px var(--head);max-width:130px;margin:8px auto 0;color:#dfe6f5}
.dh-duel figcaption small{display:block;color:var(--mute);font:11.5px var(--mono)}
.dh-gap{font:700 30px var(--head);color:var(--loss);text-align:center;text-shadow:0 0 22px rgba(255,122,133,.45);animation:beat 2.4s ease-in-out infinite}
.dh-gap small{display:block;font:600 11px var(--mono);letter-spacing:.12em;text-transform:uppercase;color:var(--mute)}
@keyframes beat{50%{transform:scale(1.08)}}
.dring .bg{fill:none;stroke:#1d2433;stroke-width:9}
.dring .fg{fill:none;stroke-width:9;stroke-linecap:round;transition:stroke-dashoffset 1.4s cubic-bezier(.2,.8,.2,1)}
.dring.good .fg{stroke:var(--win);filter:drop-shadow(0 0 8px rgba(94,224,192,.55))}
.dring.bad .fg{stroke:var(--loss);filter:drop-shadow(0 0 8px rgba(255,122,133,.5))}
.dring text{fill:#fff;font:700 24px var(--head)}
.js .dhero:not(.in) .dring .fg{stroke-dashoffset:302 !important}
.dlist{display:flex;flex-direction:column;gap:14px}
.dcard2{position:relative;border:1px solid var(--rule);border-radius:16px;background:linear-gradient(180deg,var(--panel2),var(--panel));padding:20px 22px;
display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.05fr);grid-template-areas:"h h" "b d" "n n";gap:14px 26px;scroll-margin-top:20px;transition:box-shadow .4s,border-color .4s}
.dcard2.first{border-color:rgba(233,196,106,.45)}
.dcard2.flash{border-color:var(--gold);box-shadow:0 0 0 3px rgba(233,196,106,.25),0 0 40px rgba(233,196,106,.2)}
.dcard2 header{grid-area:h;display:grid;grid-template-columns:auto minmax(0,1fr) auto;gap:16px;align-items:center}
.dcard2 .rank{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;justify-content:center;font:700 18px var(--head);color:#1a1405;
background:linear-gradient(135deg,#E9C46A,#b8923f);box-shadow:0 6px 20px rgba(233,196,106,.3)}
.dcard2:not(.first) .rank{background:#1d2433;color:#cfd7ea;box-shadow:none;border:1px solid var(--rule)}
.dcard2 header small{display:block;color:var(--gold);font:600 11.5px var(--mono);letter-spacing:.14em;text-transform:uppercase}
.dcard2 header b{display:block;font:700 20px/1.25 var(--head);color:#fff}
.impact{display:flex;flex-direction:column;align-items:flex-end;gap:6px}
.gapn{font:700 26px var(--head);color:var(--loss)}.gapn small{font:600 11px var(--mono);color:var(--mute);margin-left:3px}
.pips{display:flex;gap:4px}.pips i{width:16px;height:6px;border-radius:3px;background:#232b3b}
.pips i.on{background:linear-gradient(90deg,#ff9a6b,#ff6b7a);box-shadow:0 0 8px rgba(255,107,122,.45)}
.dbars{grid-area:b;align-self:start}.dbars .pb{grid-template-columns:minmax(110px,1.1fr) minmax(70px,1fr) auto}
.drawers{grid-area:d;display:flex;flex-direction:column;gap:8px}
.drawer{border:1px solid var(--rule);border-radius:12px;background:rgba(16,11,11,.45);overflow:hidden;transition:border-color .25s,background .25s}
.drawer:hover{border-color:#3a4458}
.drawer summary{list-style:none;cursor:pointer;display:grid;grid-template-columns:30px minmax(0,1fr) auto 18px;gap:10px;align-items:center;padding:11px 14px}
.drawer summary::-webkit-details-marker{display:none}
.drawer .di{font-size:18px}
.drawer .dt b{display:block;font:700 14px var(--head)}.drawer .dt small{color:var(--mute);font-size:12.5px}
.drawer .tag{padding:0;font-size:10.5px}
.chev{color:var(--mute);font:700 20px var(--head);transition:transform .25s}
details[open]>summary .chev{transform:rotate(90deg);color:var(--gold)}
.dbody{padding:0 16px 14px 54px;color:#DDD3C7;font-size:14.5px;line-height:1.55;animation:dIn .35s ease both}
@keyframes dIn{from{opacity:0;transform:translateY(-6px)}}
.drawer.dado[open]{border-color:rgba(94,224,192,.45)}.drawer.regra[open]{border-color:rgba(233,196,106,.5);background:rgba(233,196,106,.05)}
.drawer.hipotese[open]{border-color:rgba(140,196,255,.45)}
.dnext{grid-area:n;justify-self:end;font:600 13px var(--head);letter-spacing:.04em;color:var(--purple2);text-decoration:none}
.dnext:hover{color:#fff}.dnext.done{color:var(--win)}
.dlight{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px}
.lchip{border:1px solid var(--rule);border-radius:12px;background:var(--panel)}
.lchip summary{list-style:none;cursor:pointer;display:grid;grid-template-columns:26px minmax(0,1fr) 18px;grid-template-rows:auto auto;column-gap:10px;padding:12px 14px;align-items:center}
.lchip summary::-webkit-details-marker{display:none}
.lchip .ok{grid-row:1/3;width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:rgba(94,224,192,.14);color:var(--win);font-size:13px}
.lchip b{font:700 14px var(--head)}.lchip small{grid-column:2;color:var(--mute);font:12px var(--mono)}.lchip .chev{grid-row:1/3;grid-column:3}
.lchip .dbars{padding:0 14px 12px;animation:dIn .35s ease both}.lchip .pb{grid-template-columns:minmax(0,1fr) 90px auto}
.dhero .btn{display:inline-block;width:auto}
.dmore{border:1px dashed rgba(233,196,106,.45);border-radius:16px;background:rgba(233,196,106,.03)}
.dmore>summary{list-style:none;cursor:pointer;display:grid;grid-template-columns:52px minmax(0,1fr) 20px;gap:14px;align-items:center;padding:16px 20px}
.dmore>summary::-webkit-details-marker{display:none}
.dmore .plus{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;justify-content:center;font:700 18px var(--head);color:var(--gold);border:1px solid rgba(233,196,106,.5);animation:beat 2.4s ease-in-out infinite}
.dmore summary b{display:block;font:700 17px var(--head);color:#fff}.dmore summary small{color:var(--mute);font-size:13px}
.dmore[open]>summary{border-bottom:1px solid var(--rule)}.dmore>.dlist{padding:14px;animation:dIn .35s ease both}
.dfoot{margin-top:22px;text-align:center}
@media (max-width:1000px){.dhero{grid-template-columns:1fr}.dh-duel{justify-content:center}
.dcard2{grid-template-columns:1fr;grid-template-areas:"h" "b" "d" "n"}}
"""
