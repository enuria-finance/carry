"""Telas que eram texto simples: agora com retratos, aneis, barras de comparacao e linha do tempo."""
import html
import time

from . import icons

e = lambda x: html.escape("" if x is None else str(x))


def ring(pct, size=54):
    r = 21
    c = 2 * 3.14159 * r
    off = c * (1 - pct / 100)
    return (f"<svg class='wring' width='{size}' height='{size}' viewBox='0 0 54 54'><circle cx='27' cy='27' r='{r}' class='bg'/>"
            f"<circle cx='27' cy='27' r='{r}' class='fg' stroke-dasharray='{c:.1f}' stroke-dashoffset='{off:.1f}' transform='rotate(-90 27 27)'/>"
            f"<text x='27' y='31' text-anchor='middle'>{pct}%</text></svg>")


def _kda(g):
    return f"{g['kills']}/{g['deaths']}/{g['assists']}"


def matchup_detail(games, op):
    """Detalhe de um confronto: quem e o inimigo, seu resultado total, por campeao seu e ultimos jogos."""
    sel = [g for g in games if (g["opp_champion"] or "").lower() == op.lower()]
    if not sel:
        return (f"<div class='empty'><span class='em'>⚔</span><b>Nenhum jogo contra {e(op)}</b>"
                "<span>Quando você enfrentar esse campeão e sincronizar, ele aparece aqui.</span></div>")
    n = len(sel)
    w = sum(1 for g in sel if g["win"])
    pct = round(100 * w / n)
    kills = sum(g["kills"] for g in sel) / n
    deaths = sum(g["deaths"] for g in sel) / n
    ast = sum(g["assists"] for g in sel) / n
    small = n < 10
    pcls = "okp" if pct >= 55 else "badp" if pct <= 40 else ""
    warn = (f"<span class='pill warnp'>⚠ Amostra pequena · {n} jogo(s) <small>tendência, não conclusão</small></span>" if small else "")
    hero = (f"<div class='vs-hero'>{icons.champ(op, 84, 'foe')}<div class='who2'><small>Seu confronto contra</small><b>{e(op)}</b></div>"
            f"{ring(pct, 84)}<div class='stats'>"
            f"<span class='pill {pcls}'><small>Resultado</small>{w}V {n - w}D</span>"
            f"<span class='pill'><small>KDA médio</small>{kills:.1f} / {deaths:.1f} / {ast:.1f}</span>{warn}</div></div>")
    by = {}
    for g in sel:
        by.setdefault(g["champion"], []).append(g)
    cards = ""
    for name, gs in sorted(by.items(), key=lambda kv: (-len(kv[1]), kv[0])):
        k = len(gs)
        ww = sum(1 for g in gs if g["win"])
        p = round(100 * ww / k)
        cls = "good" if (k >= 3 and p >= 55) else "bad" if (k >= 3 and p <= 40) else ""
        cards += (f"<div class='vsc {cls}'>{icons.champ(name, 56, 'me')}<div><b>{e(name)}</b>"
                  f"<small>{k} jogo(s) · {ww}V {k - ww}D</small></div>{ring(p)}</div>")
    body = hero + "<h2>Com qual campeão você enfrenta</h2><div class='vsgrid'>" + cards + "</div>"
    rows = ""
    for g in sel[:8]:
        when = time.strftime("%d/%m", time.localtime((g["started_ms"] or 0) / 1000))
        rows += (f"<a class='gcard {'v' if g['win'] else 'd'}' style='text-decoration:none;color:inherit' href='/partida/{e(g['match_id'])}'>"
                 f"<span class='gres'>{'VITÓRIA' if g['win'] else 'DERROTA'}<small>{when} · {(g['duration_s'] or 0) // 60} min</small></span>"
                 f"<div class='gvs'>{icons.champ(g['champion'], 46, 'me')}<span class='vs'>vs</span>{icons.champ(g['opp_champion'], 46, 'foe')}"
                 f"<span class='gn'><b>{e(g['champion'])}</b></span></div>"
                 f"<div class='gk'><b>{_kda(g)}</b><small>CS {g['cs']}</small></div><span></span><span class='btn'>Pós-jogo</span></a>")
    return body + "<h2>Últimos jogos nesse confronto</h2><div class='glist'>" + rows + "</div>"


def _fmt(v, nd):
    return "–" if v is None else f"{v:.{nd}f}"


def top_compare(champion, rows, notes_html, higher_better=None):
    """Voce x mediana do topo: duas barras por medida, com a diferenca ao lado."""
    higher_better = higher_better or {}
    out = ("<div class='lg'><span><i style='background:#8cc4ff'></i>Você (média)</span>"
           "<span><i style='background:#E9C46A'></i>Mediana do topo do BR</span></div>")
    for r in rows:
        m, t = r["mine"], r["top"]
        mx = max([abs(v) for v in (m, t) if v is not None] + [0.0001])
        wm = 0 if m is None else max(3, 100 * abs(m) / mx)
        wt = 0 if t is None else max(3, 100 * abs(t) / mx)
        if m is None or t is None:
            d, dc = "–", "eq"
        else:
            diff = m - t
            hb = higher_better.get(r["label"], True)
            good = (diff > 0) == hb
            dc = "eq" if abs(diff) < 10 ** (-r["nd"]) else ("up" if good else "dn")
            d = f"{'+' if diff > 0 else ''}{diff:.{r['nd']}f}"
        out += (f"<div class='duel rv'><div class='dl'>{e(r['label'])}<small>você {r['n_mine']} jogos · topo {r['n_top']} jogos</small></div>"
                f"<div class='dtrack'><div class='dbar me'><i style='width:{wm:.0f}%'></i><b>{_fmt(m, r['nd'])}</b></div>"
                f"<div class='dbar top'><i style='width:{wt:.0f}%'></i><b>{_fmt(t, r['nd'])}</b></div></div>"
                f"<div class='dd {dc}'>{d}</div></div>")
    return (f"<div class='vs-hero'>{icons.champ(champion, 84, 'me')}<div class='who2'><small>Comparando</small><b>{e(champion)}</b></div>"
            f"<div class='stats'><span class='pill'><small>Você</small>azul</span><span class='pill'><small>Topo</small>dourado</span></div></div>"
            f"<div class='card'>{out}</div>{notes_html}")


def habits_view(periods, hist, sample_note):
    if not periods:
        return "<div class='empty'><span class='em'>🕒</span><b>Sem partidas ainda</b><span>Sincronize para ver seu rendimento por horário.</span></div>"
    emo = {"madrugada": "🌙", "manha": "🌅", "tarde": "☀", "noite": "🌆"}
    best = max((p for p in periods if p["n"] >= 8), key=lambda p: p["wr"], default=None)
    cards = ""
    for p in periods:
        key = p["period"].split(" ")[0]
        cls = ("best" if best is p else "") + (" dim" if p["n"] < 8 else "")
        cards += (f"<div class='pcard {cls}'><span class='em'>{emo.get(key, '🕒')}</span><b>{e(p['period'])}</b>"
                  f"{ring(round(p['wr']), 76)}<small>{p['wins']}V {p['n'] - p['wins']}D · {e(sample_note(p['n']))}</small></div>")
    body = ("<h2>Rendimento por horário</h2><div class='pgrid'>" + cards + "</div>"
            "<p class='n'>Horário do seu PC. Cartões apagados = menos de 8 jogos (pode ser só amostra). "
            "O destaque verde marca o melhor período com amostra razoável.</p>")
    if hist:
        ms = ""
        for h in hist:
            ok = h["met"]
            ms += (f"<div class='meta {'ok' if ok else 'no'}'><span class='ck'>{'✓' if ok else '✕'}</span>"
                   f"<div><b>{e(h['text'])}</b><small>Resultado: {h['value']:.2f} · {'cumprido' if ok else 'não cumprido'}</small></div></div>")
        body += "<h2>Metas por jogo</h2><div class='metas'>" + ms + "</div>"
    return body


def joblog(lines):
    return "<ul class='joblog'>" + "".join(f"<li>{e(l)}</li>" for l in lines) + "</ul>"


def steps_start():
    items = [("Seu Riot ID", "Digite Nome#TAG e escolha o servidor (Brasil, América do Norte…). O app descobre seu campeão e sua posição pelos seus jogos."),
             ("Pegue a chave", "Use o botão dourado (abre o site da Riot), entre com a SUA conta e copie a chave de desenvolvimento (vale 24 horas)."),
             ("Cole e sincronize", "Cole a chave, salve e clique em Sincronizar agora. O resto funciona sozinho.")]
    return ("<div class='steps'>" + "".join(
        f"<div class='step'><div class='stn'><span>{i}</span>{e(t)}</div><p class='n'>{e(d)}</p></div>"
        for i, (t, d) in enumerate(items, 1)) + "</div>")
