"""Fundo do app escolhido por cada pessoa: skin oficial (Data Dragon), video do YouTube (player oficial embutido)
ou um video seu na pasta fundos/. Sem escolha: a arte do seu campeao principal."""
import html
import os
import re

from . import icons
from .localctx import LocalDict

BG = LocalDict(kind=None, value=None)
YT_RE = re.compile(r"(?:youtu\.be/|youtube\.com/(?:watch\?(?:.*&)?v=|embed/|shorts/|live/))([A-Za-z0-9_-]{11})")
VIDEO_EXT = (".mp4", ".webm")
e = lambda x: html.escape("" if x is None else str(x))


def folder(ddir):
    p = os.path.join(ddir, "fundos")
    os.makedirs(p, exist_ok=True)
    return p


def local_videos(ddir):
    try:
        return sorted(f for f in os.listdir(folder(ddir)) if f.lower().endswith(VIDEO_EXT))
    except OSError:
        return []


def youtube_id(text):
    m = YT_RE.search(text or "")
    if m:
        return m.group(1)
    t = (text or "").strip()
    return t if re.fullmatch(r"[A-Za-z0-9_-]{11}", t) else None


def skin_url(champ, num):
    return f"{icons.CDN}/cdn/img/champion/splash/{e(icons.champ_id(champ))}_{int(num)}.jpg"


def art(cls, fallback_url="", style=""):
    """Camada de fundo: imagem, video do YouTube ou video local (sempre sem som, em loop, sem cliques)."""
    kind, val = BG.get("kind"), BG.get("value")
    if kind in ("skin", "auto") and val and ":" in val:
        ch, num = val.split(":", 1)
        if num.isdigit():
            return f"<div class='{cls}' style=\"background-image:url('{skin_url(ch, num)}');{style}\"></div>"
    if kind == "youtube" and val and re.fullmatch(r"[A-Za-z0-9_-]{11}", val):
        src = (f"https://www.youtube-nocookie.com/embed/{val}?autoplay=1&mute=1&controls=0&enablejsapi=1"
               "&modestbranding=1&playsinline=1&rel=0&disablekb=1&iv_load_policy=3&fs=0")
        img = f"background-image:url('{e(fallback_url)}');" if fallback_url else ""
        return (f"<div class='{cls} bgvid' style=\"{img}{style}\"><iframe src='{src}' data-yt='{val}' title='Fundo' tabindex='-1' aria-hidden='true' "
                "allow='autoplay; encrypted-media' referrerpolicy='strict-origin-when-cross-origin'></iframe></div>" + YT_JS)
    if kind == "file" and val and val.lower().endswith(VIDEO_EXT) and "/" not in val and "\\" not in val:
        return (f"<div class='{cls} bgvid' style='{style}'><video src='/fundos/{e(val)}' autoplay muted loop playsinline "
                "aria-hidden='true'></video></div>")
    if fallback_url:
        return f"<div class='{cls}' style=\"background-image:url('{e(fallback_url)}');{style}\"></div>"
    return ""


# O player do YouTube mostra botoes quando pausa/carrega/termina: o video so aparece TOCANDO; no resto fica a arte por baixo.
YT_JS = """<script>(function(){if(window.__ytbg)return;window.__ytbg=1;
function setup(){document.querySelectorAll('iframe[data-yt]:not([data-on])').forEach(function(f){f.setAttribute('data-on','1');
var box=f.closest('.bgvid');new YT.Player(f,{events:{onReady:function(ev){ev.target.mute();ev.target.playVideo()},
onStateChange:function(ev){if(ev.data===1){box.classList.add('playing')}else{box.classList.remove('playing');
if(ev.data===0||ev.data===2||ev.data===5){ev.target.seekTo(0,true);ev.target.playVideo()}}}}})})}
window.onYouTubeIframeAPIReady=setup;var s=document.createElement('script');s.src='https://www.youtube.com/iframe_api';document.head.appendChild(s);
document.addEventListener('liveswap',function(){if(window.YT&&YT.Player)setup()});})();</script>"""


def active():
    return bool(BG.get("kind"))


CSS = """
.bgvid{overflow:hidden;container-type:size;background-color:#010a13;background-size:cover;background-position:center 20%}
.bgvid iframe{opacity:0;transition:opacity .9s ease}.bgvid.playing iframe{opacity:1}
.bgvid iframe,.bgvid video{position:absolute;top:50%;left:50%;border:0;pointer-events:none;object-fit:cover;
width:max(100%,calc(100cqh * 16 / 9));height:max(100%,calc(100cqw * 9 / 16));transform:translate(-50%,-50%)}
.bgvid video{width:100%;height:100%}
.bn-art.bgvid{-webkit-mask-image:linear-gradient(90deg,transparent 10%,#000 60%);mask-image:linear-gradient(90deg,transparent 10%,#000 60%)}
.skins{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:10px;margin-top:12px}
.skin{position:relative;margin:0}.skin button{all:unset;cursor:pointer;display:block;border:1px solid var(--rule);border-radius:2px;overflow:hidden;
aspect-ratio:308/560;background:#0b1520 center/cover no-repeat;transition:transform .25s,border-color .25s,box-shadow .25s;width:100%}
.skin button:hover{transform:translateY(-3px);border-color:var(--gold);box-shadow:0 10px 26px rgba(0,0,0,.5),0 0 18px rgba(200,170,110,.25)}
.skin.on button{border-color:var(--gold);box-shadow:0 0 0 2px var(--gold)}
.skin small{display:block;margin-top:6px;font-size:12px;color:var(--mute);text-align:center;line-height:1.3}
.bgprev{position:relative;height:180px;border:1px solid var(--rule);overflow:hidden;margin:10px 0}
.bgprev>div{position:absolute;inset:0;background-size:cover;background-position:center 20%}
"""
