"""Perfil do jogador: posicao e campeao principais, tirados dos PROPRIOS jogos dele.
Assim o app serve para qualquer pessoa (nao so para quem joga Zed no mid)."""

from .localctx import LocalDict

CURRENT = LocalDict(position="MIDDLE", champion=None)

LANE_NAME = {"TOP": "topo", "JUNGLE": "selva", "MIDDLE": "mid", "BOTTOM": "atirador", "UTILITY": "suporte"}
LANE_IN = {"TOP": "no topo", "JUNGLE": "na selva", "MIDDLE": "no mid", "BOTTOM": "como atirador", "UTILITY": "como suporte"}
LANE_ENEMY = {"TOP": "o topo inimigo", "JUNGLE": "o caçador inimigo", "MIDDLE": "o mid inimigo",
              "BOTTOM": "o atirador inimigo", "UTILITY": "o suporte inimigo"}


def compute(con, puuid):
    """(posicao, campeao) mais jogados. Sem partidas: devolve o padrao anterior."""
    if not puuid:
        return CURRENT["position"], None
    rows = con.execute(
        """SELECT p.position, p.champion, COUNT(*) n FROM participants p JOIN matches m USING(match_id)
           WHERE p.puuid=? AND COALESCE(m.duration_s,0)>=300 AND COALESCE(p.position,'')<>''
           GROUP BY p.position, p.champion""", (puuid,)).fetchall()
    if not rows:
        return CURRENT["position"], None
    by_pos = {}
    for pos, champ, n in rows:
        by_pos.setdefault(pos, []).append((n, champ))
    pos = max(by_pos, key=lambda p: sum(n for n, _ in by_pos[p]))
    champ = max(by_pos[pos])[1]
    return pos, champ


def set_for(con, puuid):
    try:
        pos, champ = compute(con, puuid)
    except Exception:
        return
    CURRENT["position"], CURRENT["champion"] = pos, champ


def position():
    return CURRENT["position"]


# rota da partida ATUAL (a que o cliente deu na selecao). Vale ate 90 min depois da ultima vez que foi vista.
_LIVE = {"pos": None, "at": 0.0}


def set_live(pos):
    import time
    if pos in LANE_NAME:
        _LIVE.update(pos=pos, at=time.time())


def live_pos(max_age=5400):
    import time
    return _LIVE["pos"] if _LIVE["pos"] and time.time() - _LIVE["at"] < max_age else None


SMITE_ID = 11
ROLE_OF = {}          # {campeao: {rota: fracao}} preenchido pelo app (draft.role_map); usado so quando o cliente nao diz a rota


def has_smite(spells):
    """spells: ids da selecao (11 = Golpear) ou os nomes crus da partida (SummonerSmite)."""
    for s in spells or ():
        if s == SMITE_ID or "smite" in str(s).lower():
            return True
    return False


def resolve_pos(given=None, champ=None, spells=(), roles=None):
    """A ROTA PRIMEIRO, sempre pela mesma regra (pedido: "identifique primeiro a rota, depois sugira itens"):
    1) a que o cliente deu (selecao ou partida); 2) Golpear = selva; 3) a da selecao desta partida (ate 90 min);
    4) a rota em que o campeao mais e jogado; 5) a sua rota mais jogada."""
    g = (given or "").upper()
    if g in LANE_NAME:
        return g
    if has_smite(spells):
        return "JUNGLE"
    lp = live_pos()
    if lp:
        return lp
    r = (roles if roles is not None else ROLE_OF).get(champ) if champ else None
    if r:
        best = max(r.items(), key=lambda kv: kv[1])
        if best[1] >= 0.5 and best[0] in LANE_NAME:
            return best[0]
    return CURRENT["position"]


def game_pos(me):
    """Rota do jogador na partida em andamento: a do jogo; se vier vazia, Golpear, a da selecao, a do campeao e por
    ultimo a mais jogada. Ja deixa essa rota como padrao desta requisicao (builds e historico da rota certa)."""
    p = ((me or {}).get("position") or "").upper()
    if p in LANE_NAME:
        set_live(p)
    else:
        sp = me.get("summonerSpells") or {} if me else {}
        raw = [(sp.get(k) or {}).get("rawDisplayName") or "" for k in ("summonerSpellOne", "summonerSpellTwo")]
        cid = None
        try:
            from . import liveview
            cid = liveview.champ_id(me) if me else None
        except Exception:
            cid = None
        p = resolve_pos(None, cid, raw)
        if me is not None:
            me["position"] = p
    CURRENT["position"] = p
    return p


def use_live(pos=None):
    """Nesta requisicao, a rota padrao passa a ser a da partida atual (builds, historico, sugestoes)."""
    p = pos if pos in LANE_NAME else live_pos()
    if p:
        CURRENT["position"] = p
    return CURRENT["position"]


def champion(default=""):
    return CURRENT["champion"] or default


def lane_in():
    return LANE_IN.get(CURRENT["position"], "na sua posição")


def lane_name():
    return LANE_NAME.get(CURRENT["position"], "sua posição")


def lane_enemy():
    return LANE_ENEMY.get(CURRENT["position"], "o oponente de rota")
