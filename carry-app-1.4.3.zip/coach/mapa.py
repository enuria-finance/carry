"""Minimapa desenhado (vetor): fica nítido em qualquer tamanho, no estilo do mapa do jogo.
Coordenadas em 0..100, com (0,0) no canto de cima à esquerda (base azul embaixo à esquerda)."""


def _jungle():
    P = "stroke='#BDB38A' fill='none' stroke-linecap='round' stroke-linejoin='round'"
    j = (f"<g {P} stroke-width='2.6'>"
         "<path d='M8 60 C16 60 20 56 22 50 C24 44 27 40 32 35'/><path d='M14 44 C20 41 25 45 27 51 C29 57 35 60 42 58'/><path d='M22 51 C22 58 19 66 14 73'/>"
         "<path d='M17 76 C24 71 30 71 35 65'/><path d='M8 34 C13 34 16 30 19 26'/><path d='M27 66 C30 72 31 78 30 84'/>"
         "<path d='M40 92 C40 84 44 80 50 78 C56 76 62 72 66 67'/><path d='M54 92 C54 86 58 82 64 82 C70 82 74 80 79 75'/><path d='M45 70 C50 74 56 74 61 70'/>"
         "<path d='M58 82 C58 77 54 73 50 71'/><path d='M66 92 C70 88 73 86 74 82'/><path d='M34 83 C39 82 42 78 45 74'/></g>"
         "<g fill='#BDB38A'><circle cx='22' cy='50' r='2.2'/><circle cx='50' cy='78' r='2.2'/><circle cx='27' cy='66' r='2.4'/><circle cx='58' cy='82' r='2.4'/>"
         "<circle cx='14' cy='44' r='2'/><circle cx='45' cy='70' r='2'/></g>")
    return j


def base(scale=1.0):
    """Fundo do mapa em <g transform='scale(...)'> para um viewBox de 100*scale."""
    P = "stroke='#BDB38A' fill='none' stroke-linecap='round' stroke-linejoin='round'"
    j = _jungle()
    s = (f"<g transform='scale({scale})'><rect width='100' height='100' fill='#1C2232'/>"
         f"<g {P} stroke-width='5.2'><path d='M8 92 V12 Q8 8 12 8 H88'/><path d='M8 92 H88 Q92 92 92 88 V8'/><path d='M12 88 L88 12'/></g>"
         f"{j}<g transform='rotate(180 50 50)'>{j}</g>"
         "<path d='M3 9 C12 14 16 20 22 26 C30 33 34 32 40 38 C46 44 47 50 52 54 C58 60 66 62 72 68 C78 74 82 80 88 86 C92 90 95 93 97 97' stroke='#22A6DE' stroke-width='3.4' fill='none' stroke-linecap='round'/>"
         "<circle cx='31' cy='31' r='4.6' fill='#22A6DE'/><circle cx='69' cy='69' r='4.6' fill='#22A6DE'/>"
         "<path d='M0 100V74c8 0 16 3 20 8s6 12 6 18z' fill='#7E8C9C' stroke='#A9B7C6' stroke-width='.6'/>"
         "<path d='M100 0v26c-8 0-16-3-20-8S74 6 74 0z' fill='#7E8C9C' stroke='#A9B7C6' stroke-width='.6'/>"
         "<circle cx='8' cy='92' r='3' fill='#A9B7C6' stroke='#6FB7FF' stroke-width='.8'/><circle cx='92' cy='8' r='3' fill='#A9B7C6' stroke='#E0384C' stroke-width='.8'/>")
    for i, (x, y) in enumerate([(8, 64), (8, 40), (36, 92), (60, 92), (30, 70), (40, 60), (92, 36), (92, 60), (64, 8), (40, 8), (70, 30), (60, 40)]):
        s += f"<path d='M{x} {y - 2.2}l1.6 1.6v2.6h-3.2v-2.6z' fill='{'#E8F1FA' if i < 6 else '#F6E3E6'}' stroke='#55606E' stroke-width='.35'/>"
    return s + "</g>"
