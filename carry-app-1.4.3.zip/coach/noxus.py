"""Sistema de design "Noxus" (escolhido pelo Lucas): preto quente, vermelho-sangue de destaque, bronze nos detalhes,
verde-musgo para o positivo e aco para o neutro. Titulos em Big Shoulders, texto em Hanken Grotesk, icones Phosphor.

Vem por ultimo no CSS: sobrescreve o que for preciso sem mexer em cada tela.
"""

TOKENS = {"fundo": "#120E0E", "painel": "#1A1414", "painel2": "#221A19", "linha": "#2E2523", "texto": "#F1E9DF",
          "destaque": "#C1121F", "bronze": "#E9C46A", "positivo": "#6BBF8A", "aco": "#8D99AE", "negativo": "#D9534F"}

CARDS = (".card,.hpn,.ln-card,.ll,.cr-s,.kv4,.vm,.mi,.cq,.ccol,.lq,.cr-ai,.lh,.ln-hero,.psum,.dcard,.cs-wrap,.td-row,.pch .it,"
         ".cidea,.sbteam,.gscore,.aian")

CSS = """
/* ================= NOXUS: sistema de design ================= */
:root{--nx-red:#C1121F;--nx-red2:#8E0D17;--nx-bronze:#E9C46A;--nx-moss:#6BBF8A;--nx-steel:#8D99AE;--nx-bad:#D9534F;
--night:#120E0E;--raised:#1A1414;--raised2:#221A19;--line:#2E2523;--bone:#F1E9DF;--steel:#8D99AE;
--bg:#120E0E;--panel:#1A1414;--panel2:#221A19;--rule:#2E2523;--ink:#F1E9DF;--mute:#9A8F86;--gold:#E9C46A;--ac:#C1121F;
--acs:rgba(193,18,31,.14);--acm:rgba(193,18,31,.35)}
html,body{background:#120E0E}
body{background:
  radial-gradient(1100px 620px at 8% -12%,rgba(193,18,31,.13),transparent 62%),
  radial-gradient(900px 520px at 105% -5%,rgba(233,196,106,.06),transparent 60%),
  #120E0E;background-attachment:fixed}
::selection{background:rgba(193,18,31,.45);color:#fff}
::-webkit-scrollbar{width:11px;height:11px}::-webkit-scrollbar-track{background:#140F0F}
::-webkit-scrollbar-thumb{background:#3A2C29;border-radius:99px;border:3px solid #140F0F}::-webkit-scrollbar-thumb:hover{background:#5A3F3A}

/* cartoes: camada de luz no topo, borda quente e luz que segue o mouse */
:where(""" + CARDS + """){position:relative}
:where(.card,.hpn,.ln-card,.ll,.cr-s,.kv4,.vm,.mi,.ccol,.lq,.lh,.psum,.cs-wrap){background-image:linear-gradient(180deg,rgba(255,240,225,.028),rgba(255,240,225,0) 38%) !important;
  border-color:#2E2523 !important;transition:border-color .25s ease,transform .25s ease,box-shadow .25s ease}
:where(.card,.hpn,.ln-card,.ll,.kv4,.vm,.mi,.ccol):hover{border-color:#4A3A36 !important;box-shadow:0 18px 40px -24px rgba(0,0,0,.8),0 0 0 1px rgba(193,18,31,.06)}
.nx-spot{position:absolute;inset:0;border-radius:inherit;pointer-events:none;opacity:0;transition:opacity .3s ease;
  background:radial-gradient(420px circle at var(--mx,50%) var(--my,0%),rgba(193,18,31,.11),transparent 46%)}
:hover>.nx-spot{opacity:1}

/* botoes: primario vermelho-sangue, secundario em bronze fino */
.btn.gold,button.gold,.cr-ai .btn.gold{background:linear-gradient(180deg,#D3202D,#9E0E19) !important;color:#fff !important;border:1px solid #E0303D !important;
  box-shadow:inset 0 1px 0 rgba(255,255,255,.18),0 10px 24px -10px rgba(193,18,31,.55) !important;text-shadow:0 1px 0 rgba(0,0,0,.25)}
.btn.gold:hover,button.gold:hover{filter:brightness(1.08);transform:translateY(-1px)}
.btn,button{transition:transform .15s ease,filter .15s ease,border-color .15s ease,background .15s ease}
.btn:not(.gold):hover{border-color:rgba(233,196,106,.55) !important}

/* abas e selecoes: bronze */
.p4-seg a.on,.vod-f button[aria-pressed=true],.hp-tabs button[aria-selected=true]{background:#E9C46A !important;color:#1A1208 !important;border-color:#E9C46A !important}

/* titulos de secao: tipografia forte, linha bronze e marcador vermelho (quebra o ritmo das caixas) */
main h2{font-family:var(--d) !important;letter-spacing:.02em}
main h2::before{content:'';display:inline-block;width:8px;height:8px;margin-right:12px;vertical-align:middle;background:#C1121F;transform:rotate(45deg) translateY(-2px);
  box-shadow:0 0 12px rgba(193,18,31,.7)}

/* menu lateral */
.side{background:linear-gradient(180deg,#150F0F,#120E0E) !important;border-right:1px solid #2A201E !important}
.sg a[aria-current=page]{background:linear-gradient(90deg,rgba(193,18,31,.18),rgba(193,18,31,0)) !important;color:#fff !important}
.sg a[aria-current=page] svg{color:#E9C46A}
.sg a:hover svg{color:#E9C46A}
.sg small{color:#E9C46A !important}.sg small::before{background:#C1121F !important}
svg.ni.ph{opacity:.92}

/* entrada da pagina: leve, em cascata */
@media (prefers-reduced-motion:no-preference){
  main>*{animation:nxIn .55s cubic-bezier(.2,.7,.2,1) both}
  main>*:nth-child(2){animation-delay:.04s}main>*:nth-child(3){animation-delay:.08s}main>*:nth-child(4){animation-delay:.12s}
  main>*:nth-child(5){animation-delay:.16s}main>*:nth-child(n+6){animation-delay:.2s}
}
@keyframes nxIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}

/* numeros grandes e positivos/negativos coerentes */
.win,.g,b.g,.wv{color:#8FD4A8}.loss,.r,b.r,.lv{color:#E8817C}
.tag.dado{color:#8FD4A8}.tag.regra{color:#E9C46A}.tag.hipotese{color:#8D99AE}
"""

JS = """<script>(function(){var sel='""" + CARDS.replace("'", "") + """';
document.addEventListener('pointermove',function(ev){var c=ev.target.closest&&ev.target.closest(sel);if(!c)return;
if(!c.__nx){c.__nx=1;var s=document.createElement('i');s.className='nx-spot';c.appendChild(s)}
var r=c.getBoundingClientRect();c.style.setProperty('--mx',(ev.clientX-r.left)+'px');c.style.setProperty('--my',(ev.clientY-r.top)+'px')},{passive:true});
})();</script>"""
