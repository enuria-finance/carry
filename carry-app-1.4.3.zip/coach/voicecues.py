"""Falas extras do overlay: da selecao de campeoes ate o fim da partida.

Regra (politica da Riot): so informacao que o jogo ou o cliente ja mostram para todos, mais o seu historico.
Nada de posicao de inimigo, nada de tela lida, nada de ordem. Os lembretes de mapa sao pela hora do jogo
("costuma acontecer agora"), quem olha o mapa e voce.

Cada fala: {"k": chave unica (o overlay fala cada uma uma vez), "t": texto na tela, "v": texto falado (opcional,
mais curto e sem nomes quando da, para a frase ficar em cache e nao gastar a cota da voz de novo)}.
O prefixo da chave diz a categoria (ligar/desligar na pagina Editar overlay).
"""
import time

# itens que mudam a luta (e o jogador quer saber na hora): Zhonya, Anjo, Véu, Limiar da Noite, Mercurial, Ampulheta/Cinto
KEY_ITEMS = {3157, 3026, 3102, 3814, 3139, 2420, 3156, 6673, 3065, 3075, 3143, 3110}
_STATS = {}

# o que muda quando o inimigo fecha o item (informacao do proprio item)
ITEM_FX = {3157: ": pode ficar invulnerável por 2,5 segundos", 2420: ": pode ficar invulnerável uma vez", 3026: ": revive uma vez depois de morrer",
           3102: ": bloqueia a primeira habilidade", 3814: ": bloqueia a primeira habilidade", 3139: ": pode limpar controle de grupo",
           3156: ": ganha escudo contra dano mágico quando fica com pouca vida", 6673: ": ganha escudo contra dano físico quando fica com pouca vida",
           3065: ": recebe mais cura e escudo", 3075: ": devolve dano de ataques e reduz cura", 3143: ": reduz a velocidade de ataque de quem bate nele",
           3110: ": reduz a velocidade de ataque perto dele"}


def item_effect(iid, info):
    if iid in ITEM_FX:
        return ITEM_FX[iid]
    tags = set((info or {}).get("tags") or [])
    if {"Armor", "SpellBlock", "Health"} & tags and not {"SpellDamage", "Damage"} & tags:
        return ": fica mais resistente"
    if "SpellDamage" in tags:
        return ": mais dano mágico"
    if "CriticalStrike" in tags or "Damage" in tags:
        return ": mais dano físico"
    return ""


def _is_jungler(p):
    if (p.get("position") or "").upper() == "JUNGLE":
        return True
    ss = p.get("summonerSpells") or {}
    return any("Smite" in ((ss.get(k) or {}).get("rawDisplayName") or "") for k in ("summonerSpellOne", "summonerSpellTwo"))


def _is_support(p):
    return (p.get("position") or "").upper() == "UTILITY"


def profile_stats(con, puuid):
    """Do seu historico (guardado 10 min): CS aos 10 (mediana) e a janela de 4 min em que voce mais morre."""
    hit = _STATS.get(puuid)
    if hit and time.time() - hit["at"] < 600:
        return hit
    out = {"at": time.time(), "cs10": None, "win": None}
    try:
        from . import insights, report
        games = report.my_games(con, puuid)[:60]
        cs = [g["cs10"] for g in games if g.get("cs10") is not None]
        if len(cs) >= 8:
            out["cs10"] = round(insights._median(cs))
        cpm = [g["cs_per_min"] for g in games if g.get("cs_per_min")]
        if len(cpm) >= 8:
            out["cspm"] = round(insights._median(cpm), 1)
        rows = con.execute("""SELECT d.t_ms FROM deaths d JOIN participants p ON p.match_id=d.match_id AND p.participant_id=d.victim_id
                              WHERE p.puuid=? ORDER BY d.match_id DESC LIMIT 600""", (puuid,)).fetchall()
        mins = [r[0] / 60000 for r in rows if r[0] is not None]
        if len(mins) >= 20:
            best = max(range(3, 22), key=lambda a: sum(1 for m in mins if a <= m < a + 4))
            share = sum(1 for m in mins if best <= m < best + 4) / len(mins)
            if share >= 0.22:
                out["win"] = (best, best + 4, round(share * 100))
    except Exception:
        pass
    try:
        from . import missions, report
        out["mission"] = missions.ensure_today(con, report.my_games(con, puuid, ""))["mission"].get("text")
    except Exception:
        pass
    _STATS[puuid] = out
    return out


def game_cues(con, puuid, live_data, me, foes, pos, gt, items):
    al = []
    add = lambda k, t, v=None: al.append({"k": k, "t": t, **({"v": v} if v else {})})
    # comeco: missao do dia
    if gt < 45:
        txt = profile_stats(con, puuid).get("mission")
        if txt:
            add("mission_start", f"Missão de hoje: {txt}")
    # lembretes de mapa pela hora do jogo
    if 170 <= gt < 200:
        add("map_clear1", "Olhe o minimapa: a primeira volta do caçador inimigo costuma terminar agora.")
    jg = next((p for p in foes if _is_jungler(p)), None)
    if jg:
        d = int((jg.get("scores") or {}).get("deaths") or 0)
        r = int(jg.get("respawnTimer") or 0)
        if jg.get("isDead") and r >= 12 and gt >= 150:
            add(f"map_jgdead_{d}", f"Caçador inimigo ({jg.get('championName')}) morto por {r}s.", "O caçador inimigo morreu.")
        if jg.get("isDead") and r <= 4:
            add(f"map_jgback_{d}", "O caçador inimigo está voltando à vida. Olhe o mapa.")
    sup = next((p for p in foes if _is_support(p)), None)
    if sup and gt >= 180 and pos in ("BOTTOM", "UTILITY"):      # so importa para quem esta no bot
        d = int((sup.get("scores") or {}).get("deaths") or 0)
        if sup.get("isDead") and int(sup.get("respawnTimer") or 0) <= 4:
            add(f"map_supback_{d}", "O suporte inimigo está voltando para a rota.")
    if 180 <= gt < 900:
        add(f"nudge_{int(gt // 60)}", "Olhe o minimapa.")
    # itens que mudam a luta (o placar mostra para todos)
    lp = next((p for p in foes if pos and p.get("position") == pos), None)
    for p in foes:
        for it in p.get("items") or []:
            iid = it.get("itemID")
            info = (items or {}).get(str(iid)) or {}
            cost = (info.get("gold") or {}).get("total") or it.get("price") or 0
            if iid in KEY_ITEMS or (p is lp and cost >= 2600 and "Boots" not in (info.get("tags") or [])):
                nm = info.get("name") or it.get("displayName") or str(iid)
                add(f"eitem_{p.get('championName')}_{iid}", f"{p.get('championName')} completou {nm}{item_effect(iid, info)}.")
    # 10 minutos: farm e visao comparados com voce mesmo
    sc = me.get("scores") or {}
    stt = profile_stats(con, puuid)
    if 600 <= gt < 640:
        cs = int(sc.get("creepScore") or 0)
        ref = stt.get("cs10")
        extra = f" (sua média é {ref})" if ref else ""
        if pos != "UTILITY":
            add("farm_10", f"10 minutos: {cs} de farm{extra}.")
        ws = float(sc.get("wardScore") or 0)
        if ws < {"UTILITY": 15, "JUNGLE": 8}.get(pos, 6) and pos != "UTILITY":
            add("farm_vis10", f"Pontuação de visão baixa aos 10 min: {ws:.0f}.", "Sua visão está baixa para 10 minutos.")
    # habito: a janela em que voce mais morre
    w = stt.get("win")
    if w and w[0] * 60 - 30 <= gt < w[0] * 60 + 30:
        add("habit_win", f"Entre {w[0]} e {w[1]} min é quando você mais morre ({w[2]}% das suas mortes).",
            f"Atenção: entre {w[0]} e {w[1]} minutos é quando você mais morre.")
    return al


def select_cues(con, puuid, snap, champs, items=None, ddir=None):
    """Selecao de campeoes: sua vez, seu historico no duelo, perfil dos times (classes do Data Dragon)."""
    from . import draft, profile, report
    al = []
    add = lambda k, t, v=None: al.append({"k": k, "t": t, **({"v": v} if v else {})})
    if not snap or not snap.get("me"):
        return al
    me = snap["me"]
    turn = snap.get("my_turn")
    hit = _STATS.get(("games", puuid))
    if hit and time.time() - hit[0] < 180:
        games = hit[1]
    else:
        games = report.my_games(con, puuid)
        _STATS[("games", puuid)] = (time.time(), games)
    roles = draft.role_map(con)
    # a rota primeiro: tudo daqui para baixo (picks, itens, runas) e da rota desta partida
    position = profile.resolve_pos(me.get("position"), me.get("champion"), me.get("spells"), roles)
    if me.get("position"):
        profile.set_live(me["position"])
    profile.use_live(position)
    games = report.my_games(con, puuid, position)          # sempre as partidas da rota desta partida
    if turn == "ban":
        idea = draft.ban_ideas(games, snap, roles, position, limit=1)
        if idea:
            i = idea[0]
            add(f"sel_ban_{i['champion']}", f"Sua vez de banir. Quem mais te venceu: {i['champion']}, {i['why']}.",
                f"Sua vez de banir. Pelo seu histórico, {i['champion']} é quem mais te venceu.")
        else:
            try:
                from . import pregame
                cb = pregame.comp_bans(con, snap, champs, position, limit=1)
            except Exception:
                cb = []
            if cb:
                c = cb[0]
                add(f"sel_cban_{c['champion']}", f"Sua vez de banir. Sugestão: {c['champion']} ({'; '.join(c['why'])}).",
                    f"Sua vez de banir. Sugestão pela composição e pelos melhores: {c['champion']}.")
            else:
                add("sel_banturn", "Sua vez de banir.")
    if turn == "pick":
        add("sel_pickturn", "Sua vez de escolher.")
    mine = me.get("champion")
    enemy, _guess = draft.enemy_laner(snap, position, roles)
    dn = lambda c: (champs.get(c) or {}).get("name") or c
    # counters reais (amostra do alto elo, mesma rota)
    try:
        from . import counters
        if enemy and position:
            cl = counters.counters_of(con, enemy, position)
            if cl and not mine:          # so fala counter que voce joga: campeao fora do pool nao e sugestao
                from . import champselect as cs_
                pool_c = set(draft.pool_for(cs_.pool_get(con), games, roles, position))
                cl_p = [x for x in cl if x[0] in pool_c]
                if cl_p:
                    add(f"sel_ctr_{enemy}", f"Do seu pool, quem vence {dn(enemy)} no alto elo: "
                        + ", ".join(f"{dn(c)} {wr}% em {n} jogos" for c, wr, n in cl_p) + ".",
                        f"Contra {dn(enemy)}, do seu pool: " + ", ".join(dn(c) for c, _, _ in cl_p) + ".")
            if mine:
                mu_ = counters.matchup(con, mine, enemy, position)
                if mu_:
                    n_, wr_ = mu_
                    vd = counters.verdict(wr_)
                    tip_ = {"vantagem": "jogue para matar na rota.",
                            "desvantagem": "jogue pela onda e pelo jungler, não force troca; o seu jogo é no meio e no fim da partida.",
                            "equilibrado": "quem errar menos na rota ganha."}[vd]
                    add(f"sel_mu_{mine}_{enemy}", f"{dn(mine)} contra {dn(enemy)} no alto elo: {wr_}% em {n_} jogos. Confronto de {vd}: {tip_}",
                        f"{dn(mine)} contra {dn(enemy)}: {wr_}%, {vd}.")
                    if vd == "desvantagem" and cl:
                        add(f"sel_ctrnote_{mine}_{enemy}", f"Quem vence o {dn(enemy)} de verdade: " + ", ".join(dn(c) for c, _, _ in cl[:2]) + ". Vale ter um deles no pool.")
    except Exception:
        pass
    # plano B quando banem o seu main
    try:
        if not mine:
            allg_ = report.my_games(con, puuid, "")[:200]
            cnt_ = {}
            for g in allg_:
                c_ = cnt_.setdefault(g["champion"], [0, 0])
                c_[0] += 1
                c_[1] += 1 if g["win"] else 0
            if cnt_:
                main_ = max(cnt_, key=lambda k: cnt_[k][0])
                banned_ = set(snap.get("my_bans") or []) | set(snap.get("their_bans") or [])
                taken_ = {p.get("champion") for p in (snap.get("my_team") or []) + (snap.get("enemy_team") or []) if p.get("champion")}
                if main_ in banned_ or main_ in taken_:
                    alts_ = [(k, v) for k, v in cnt_.items() if k != main_ and v[0] >= 5 and k not in banned_ and k not in taken_]
                    alts_.sort(key=lambda kv: -(kv[1][1] + 10) / (kv[1][0] + 20))
                    if alts_:
                        b_, (n_, w_) = alts_[0]
                        add(f"sel_planob_{main_}", f"{dn(main_)} {'banido' if main_ in banned_ else 'já foi escolhido'}. Seu plano B: {dn(b_)}, "
                            f"{round(100 * w_ / n_)}% em {n_} jogos. As runas montam sozinhas quando você lockar.",
                            f"{dn(main_)} fora. Plano B: {dn(b_)}, {round(100 * w_ / n_)}%.")
    except Exception:
        pass
    # a sua propria nota sobre o confronto
    try:
        if mine and enemy:
            from . import ficha
            nt_ = ficha.note_get(con, mine, enemy)
            if nt_:
                add(f"sel_nota_{mine}_{enemy}", f"Sua nota contra {dn(enemy)}: {nt_}")
    except Exception:
        pass
    # dica de especialista do confronto
    try:
        if mine and enemy:
            from . import especialista
            et_ = especialista.sel_text(mine, enemy)
            if et_:
                add(f"sel_esp_{mine}_{enemy}", et_)
    except Exception:
        pass
    # jungler aliado: com quem voce ganha
    try:
        if position != "JUNGLE":
            jg_ = next((p.get("champion") for p in snap.get("my_team") or [] if (p.get("position") or "") == "JUNGLE" and p.get("champion")), None)
            if jg_:
                from . import derrotas
                n_, w_ = derrotas.jungler_stats(con, puuid).get(jg_, (0, 0))
                if n_ >= 5:
                    wr_ = round(100 * w_ / n_)
                    if wr_ >= 56 or wr_ <= 45:
                        add(f"sel_jg_{jg_}", f"Com {dn(jg_)} de jungler no seu time você tem {wr_}% em {n_} jogos. "
                            + ("Jogue junto com ele no começo: empurre e chegue primeiro no rio." if wr_ >= 56 else
                               "Conte menos com gank: jogue seguro e farme até o 6."))
    except Exception:
        pass
    # disciplina de pool: ranqueada com o campeao que ganha (pedido do usuario: parar de pegar mil campeoes)
    if mine:
        try:
            allg = report.my_games(con, puuid, "")
            cnt = {}
            for g in allg:
                c_ = cnt.setdefault(g["champion"], [0, 0])
                c_[0] += 1
                c_[1] += 1 if g["win"] else 0
            main = max(cnt.items(), key=lambda kv: kv[1][0])[0] if cnt else None
            n_, w_ = cnt.get(mine, [0, 0])
            mn, mw = cnt.get(main, [0, 0]) if main else (0, 0)
            if main and mine != main and mn >= 30:
                mwr = round(100 * mw / mn)
                if n_ < 10:
                    add(f"sel_disc_{mine}", f"Você tem só {n_} partida{'s' if n_ != 1 else ''} de {dn(mine)} no histórico. "
                        f"Na ranqueada, o seu campeão é {dn(main)}: {mwr}% em {mn} jogos. Teste {dn(mine)} na normal.",
                        f"Só {n_} jogos de {dn(mine)}. Seu campeão é {dn(main)}, {mwr}%.")
                elif round(100 * w_ / n_) <= mwr - 6:
                    add(f"sel_disc_{mine}", f"Com {dn(mine)} você tem {round(100 * w_ / n_)}% em {n_} jogos. Com {dn(main)}, {mwr}% em {mn}. "
                        "Cada partida fora dele devolve o PDL que ele ganhou.",
                        f"{dn(mine)}: {round(100 * w_ / n_)}%. {dn(main)}: {mwr}%.")
        except Exception:
            pass
    if mine and enemy:
        vs = [g for g in games if g["champion"] == mine and (g.get("opp_champion") or "") == enemy]
        if vs:
            w = sum(1 for g in vs if g["win"])
            add(f"sel_vs_{mine}_{enemy}", f"{mine} contra {enemy}: você venceu {w} de {len(vs)}.")
        else:
            anyvs = [g for g in games if (g.get("opp_champion") or "") == enemy]
            if len(anyvs) >= 3:
                w = sum(1 for g in anyvs if g["win"])
                add(f"sel_vsany_{enemy}", f"Contra {enemy} você venceu {w} de {len(anyvs)} (com qualquer campeão).")
    try:
        notes, mt, ft = draft.comp_notes(snap, champs)
        if ft["n"] >= 4:
            if ft["AP"] >= 3:
                add("sel_ap", "O time inimigo tem muito dano mágico.")
            elif ft["AD"] >= 4:
                add("sel_ad", "O time inimigo é quase todo de dano físico.")
            if ft["front"] >= 3:
                add("sel_front", "O time inimigo tem muita linha de frente.")
        if mt["n"] >= 3 and mt["front"] == 0:
            add("sel_nofront", "Seu time ainda não tem linha de frente.")
    except Exception:
        pass
    # melhor do seu pool contra o oponente revelado (antes de voce escolher)
    if enemy and not mine:
        try:
            from . import champselect as cs
            pool = draft.pool_for(cs.pool_get(con), games, roles, position)
            mu = {}
            try:
                from . import counters
                for c_ in pool:
                    m_ = counters.matchup(con, c_, enemy, position)
                    if m_:
                        mu[c_] = m_
            except Exception:
                mu = {}
            picks, _ = draft.pick_ideas(games, pool, snap, enemy, champs, limit=1, mu=mu)
            saved_ = set(cs.pool_get(con) or [])
            picks = [p for p in picks if p["n"] >= 5 or p["champion"] in saved_]     # nunca sugerir quem voce nao joga
            if picks:
                pk = picks[0]
                why = pk["why"][0][0] if pk["champion"] in mu else (pk["why"][1][0] if len(pk["why"]) > 1 else pk["why"][0][0])
                add(f"sel_pool_{enemy}_{pk['champion']}", f"Contra {dn(enemy)}, o melhor do seu pool é {dn(pk['champion'])} ({why}).")
        except Exception:
            pass
    if snap.get("phase") == "FINALIZATION" and mine:
        try:
            from . import pregame
            pl = pregame.plan_text(con, puuid, games, snap, champs, position, roles, items)
            if pl:
                add(f"sel_plan_{mine}_{enemy}", "Plano · " + pl[0], pl[1])
            foes = [p["champion"] for p in snap.get("enemy_team", []) if p.get("champion")]
            defensive = None
            if ddir:
                defensive = {"AP": defensive_pick(con, mine, position, items, "magico"), "AD": defensive_pick(con, mine, position, items, "fisico")}
            adj = pregame.comp_adjust(foes, champs, pregame.my_dtype(champs, mine), items, defensive, position, mine=mine, con=con, laner=enemy)
            if adj:
                txt = "; ".join(f"{nm} ({why})" for _, nm, why, _ in adj[:3])
                add(f"sel_adj_{mine}", f"Build pela composição inimiga: {txt}.", f"Ajuste de build pela composição inimiga: {txt}.")
        except Exception:
            pass
    try:            # lote das 100 ideias: condicao de vitoria, dupla de baixo, counter revelado, pool contra a composicao
        from . import extras, champselect as cs
        pool_x = draft.pool_for(cs.pool_get(con), games, roles, position)
        for k_, t_, v_ in extras.select_extra(con, puuid, snap, champs, position, pool_x):
            add(k_, t_, v_)
    except Exception:
        pass
    if snap.get("phase") == "FINALIZATION":
        add("sel_final", "Seleção fechada. Confira as runas e os feitiços antes de entrar.")
    return al


# ---------------- informacao extra (pedido: "falar muito mais coisas") ----------------
_CD = {}


def champ_cds(ddir, cid):
    """Recargas base das habilidades (Data Dragon, dado publico): {"Q": [11,10.5,...], ..., "names": {...}}."""
    if cid in _CD:
        return _CD[cid]
    out = None
    try:
        import os
        from .ddragon import DataDragon
        c = DataDragon(cache_dir=os.path.join(ddir, "cache")).champion(cid)
        out = {"names": {}, "tips": [t for t in (c.get("enemytips") or []) if t], "tags": c.get("tags") or [],
               "info": c.get("info") or {}, "name": c.get("name") or cid}
        for k, sp in zip("QWER", c.get("spells") or []):
            out[k] = [float(x) for x in (sp.get("cooldown") or [])]
            out["names"][k] = sp.get("name") or k
    except Exception:
        out = None
    if out:                 # nao guarda falha: a ficha pode chegar daqui a pouco (download em segundo plano)
        _CD[cid] = out
    return out


def _n(v):
    return f"{v:g}"


def r_rank(level):
    return 3 if level >= 16 else 2 if level >= 11 else 1


def cd_line(cds, level):
    """'Q 11s · W 14s · E 10s · R 60s' com a recarga do nivel atual (as basicas no rank 1: o jogo nao mostra o rank do inimigo)."""
    if not cds:
        return ""
    parts = []
    for k in "QWE":
        if cds.get(k):
            parts.append(f"{k} {_n(cds[k][0])}s")
    if cds.get("R") and level >= 6:
        parts.append(f"R {_n(cds['R'][min(len(cds['R']), r_rank(level)) - 1])}s")
    return " · ".join(parts)


# ---------------- como jogar contra quem esta forte (dicas oficiais do Data Dragon + itens da build dos melhores) ----------------
_DEF = {}


def dmg_type(cds):
    """'fisico' ou 'magico' pelo perfil oficial do campeao (info.attack x info.magic)."""
    inf = (cds or {}).get("info") or {}
    return "magico" if (inf.get("magic") or 0) > (inf.get("attack") or 0) else "fisico"


def defensive_pick(con, my_cid, pos, items, kind):
    """Item com armadura (contra dano fisico) ou resistencia magica que os melhores jogadores do seu campeao mais fecham."""
    key = (my_cid, pos, kind)
    if key in _DEF:
        return _DEF[key]
    out = None
    try:
        import json
        from collections import Counter
        from . import builds
        stat = "FlatArmorMod" if kind == "fisico" else "FlatSpellBlockMod"
        cnt = Counter()
        for r in builds.top_rows(con, my_cid, pos):
            for i in json.loads(r["items"] or "[]")[:6]:
                it = (items or {}).get(str(i)) or {}
                if (it.get("stats") or {}).get(stat) and builds.is_complete(items, i) and "Boots" not in (it.get("tags") or []):
                    cnt[i] += 1
        if cnt:
            i, n = cnt.most_common(1)[0]
            out = {"id": i, "name": items[str(i)].get("name", str(i)), "n": n}
    except Exception:
        out = None
    _DEF[key] = out
    return out


def _clean_tip(t):
    t = (t or "").strip()
    return t if t.endswith((".", "!", "?")) else t + "."


def matchup_cues(con, ddir, live_data, me, foes, pos, gt, items=None):
    """Dica para jogar contra o oponente de rota no começo, quando ele te mata e quando alguem do outro time fica forte."""
    from . import live, liveview
    al = []
    add = lambda k, t, v=None: al.append({"k": k, "t": t, **({"v": v} if v else {})})
    my_cid = liveview.champ_id(me)
    me_name = live._name(me)
    lp = next((p for p in foes if pos and p.get("position") == pos), None)
    ev = (live_data.get("events") or {}).get("Events") or []
    if lp:
        nm = lp.get("championName") or "Oponente"
        cds = champ_cds(ddir, liveview.champ_id(lp)) or {}
        tips = cds.get("tips") or []
        if tips and 100 <= gt < 220:
            add(f"mu_tip0_{nm}", f"Contra {nm}: {_clean_tip(tips[0])}")
        lp_name = live._name(lp)
        deaths = [x for x in ev if x.get("EventName") == "ChampionKill" and x.get("VictimName") == me_name and x.get("KillerName") == lp_name]
        n = len(deaths)
        if n and gt - (deaths[-1].get("EventTime") or 0) < 40:
            if n <= 4 and tips:
                add(f"mu_death_{n}", f"{nm} te matou. Dica: {_clean_tip(tips[n % len(tips)])}")
            if n == 2:
                kind = dmg_type(cds)
                pick = defensive_pick(con, my_cid, pos, items, kind)
                if pick:
                    add(f"mu_item_{nm}", f"Regra geral: {nm} causa dano {'mágico' if kind == 'magico' else 'físico'}. "
                        f"Se continuar forte, {pick['name']} ajuda ({'resistência mágica' if kind == 'magico' else 'armadura'}; "
                        f"está em {pick['n']} builds dos melhores com o seu campeão).")
            if n == 3:
                add(f"mu_safe_{nm}", f"Regra geral: {nm} já te matou 3 vezes. Jogue perto da sua torre, farme com segurança e espere o caçador ou o item.")
    if 45 <= gt < 150 and items:
        try:
            import os
            from . import pregame
            from .ddragon import DataDragon
            chs = DataDragon(cache_dir=os.path.join(ddir, "cache")).champions()
            names = [liveview.champ_id(p) for p in foes]
            dfn = {"AP": defensive_pick(con, my_cid, pos, items, "magico"), "AD": defensive_pick(con, my_cid, pos, items, "fisico")}
            adj = pregame.comp_adjust(names, chs, pregame.my_dtype(chs, my_cid), items, dfn, pos, mine=my_cid, con=con, laner=liveview.champ_id(lp) if lp else None)
            if adj:
                txt = "; ".join(f"{nm} ({why})" for _, nm, why, _ in adj[:3])
                add("mu_comp", f"Build pela composição inimiga: {txt}.", f"Pela composição inimiga, considere: {txt}.")
        except Exception:
            pass
    for p in foes:
        sc = p.get("scores") or {}
        k, d = int(sc.get("kills") or 0), int(sc.get("deaths") or 0)
        if k >= 5 and k - d >= 4 and p is not lp:
            nm = p.get("championName") or "Inimigo"
            cds = champ_cds(ddir, liveview.champ_id(p)) or {}
            tips = cds.get("tips") or []
            kind = dmg_type(cds)
            pick = defensive_pick(con, my_cid, pos, items, kind)
            extra = f" Contra esse dano, {pick['name']} ajuda." if pick else ""
            if tips:
                add(f"mu_threat_{nm}", f"Como lidar com {nm}: {_clean_tip(tips[0])}{extra}")
    return al


def matchup_text(ddir, cid):
    """Dicas oficiais de como jogar contra um campeao (para a IA e a selecao)."""
    return (champ_cds(ddir, cid) or {}).get("tips") or []


def extra_cues(con, puuid, ddir, live_data, me, foes, pos, gt, active, items=None):
    """Recargas do oponente, feiticos dele, quem esta forte, sua morte, farm por fase, placas, buffs e inibidores."""
    from . import live, liveview
    al = []
    add = lambda k, t, v=None: al.append({"k": k, "t": t, **({"v": v} if v else {})})
    lp = next((p for p in foes if pos and p.get("position") == pos), None)
    # recargas e feiticos do oponente de rota (dado publico do jogo)
    if lp:
        nm = lp.get("championName") or "Oponente"
        cds = champ_cds(ddir, liveview.champ_id(lp))
        lv = int(lp.get("level") or 1)
        if cds and 15 <= gt < 120:
            basic = ", ".join(f"{k} {_n(cds[k][0])} segundos" for k in "QWE" if cds.get(k))
            add(f"cd_start_{nm}", f"{nm}: recarga no começo · {cd_line(cds, 1)} (ultimate {_n(cds['R'][0])}s)" if cds.get("R") else f"{nm}: {cd_line(cds, 1)}",
                f"{nm}: recarga de {basic}.")
        ss = lp.get("summonerSpells") or {}
        names = [((ss.get(k) or {}).get("displayName") or "").strip() for k in ("summonerSpellOne", "summonerSpellTwo")]
        names = [x for x in names if x]
        if names and 20 <= gt < 120:
            add(f"cd_spells_{nm}", f"{nm} está com {' e '.join(names)}.")
        # lembrete das recargas a cada 3 minutos na fase de rota (falar so no comeco a gente esquece)
        if cds and 180 <= gt < 900 and not lp.get("isDead") and int(gt) % 180 < 40:
            basic = ", ".join(f"{k} {_n(cds[k][0])}" for k in "QWE" if cds.get(k))
            ult = f", ultimate {_n(cds['R'][min(len(cds['R']), r_rank(lv)) - 1])}" if cds.get("R") and lv >= 6 else ""
            add(f"cd_rem_{nm}_{int(gt) // 180}", f"Lembrete · {nm}: {cd_line(cds, lv)}", f"Lembrete das recargas de {nm}: {basic}{ult} segundos.")
        if cds and cds.get("R"):
            for at in [x for x in (16, 11, 6) if lv >= x][:1]:      # so o nivel mais alto ja alcancado
                if gt >= 60:
                    rcd = cds["R"][min(len(cds["R"]), r_rank(at)) - 1]
                    msg = (f"{nm} tem a ultimate: {_n(rcd)} segundos de recarga." if at == 6 else
                           f"{nm} nível {at}: ultimate mais forte, recarga de {_n(rcd)} segundos.")
                    add(f"cd_r{at}_{nm}", msg)
    # inimigo forte (o placar mostra para todos)
    for p in foes:
        sc = p.get("scores") or {}
        k, d = int(sc.get("kills") or 0), int(sc.get("deaths") or 0)
        if k >= 5 and k - d >= 4:
            add(f"threat_{p.get('championName')}_{k // 3}", f"Atenção: {p.get('championName')} está com {k} abates e {d} morte{'s' if d != 1 else ''}.")
    # voce
    if me.get("isDead"):
        d = int((me.get("scores") or {}).get("deaths") or 0)
        r = int(me.get("respawnTimer") or 0)
        gold = int((active or {}).get("currentGold") or 0)
        if r >= 5:
            add(f"self_dead_{d}", f"Você volta em {r} segundos, com {gold} de ouro.", f"Você volta em {r} segundos.")
    sc = me.get("scores") or {}
    cs = int(sc.get("creepScore") or 0)
    for m in ((5, 15, 20, 25) if pos != "UTILITY" else ()):
        if m * 60 <= gt < m * 60 + 40:
            add(f"farm_{m}", f"{m} minutos: {cs} de farm, {cs / m:.1f} por minuto.")
    # (as placas das torres nao caem mais aos 14 min desde a temporada 2026: sem aviso)
    # eventos que o jogo anuncia: buffs de Barao e Ancião, inibidores, ponto de alma, abates marcantes, torres
    ev = (live_data.get("events") or {}).get("Events") or []
    me_name = live._name(me)
    turrets = {"nossa": 0, "deles": 0}
    for x in ev:
        name, eid = x.get("EventName"), x.get("EventID")
        recent = (x.get("EventTime") or 0) >= gt - 25          # overlay aberto no meio da partida: nao fala o passado
        if name == "TurretKilled":
            tid = x.get("TurretKilled") or ""
            lost = "ORDER" if "_T1_" in tid else "CHAOS" if "_T2_" in tid else None
            if lost:
                side = "nossa" if lost == me.get("team") else "deles"
                turrets[side] += 1
                if recent:
                    add(f"ev_tower_{tid}", ("Vocês perderam uma torre" if side == "nossa" else "Torre inimiga destruída") + f": {turrets[side]}ª.")
            continue
        if not recent:
            continue
        if name == "FirstBlood":
            add("ev_fb", "Primeiro abate da partida." if x.get("Recipient") != me_name else "Primeiro abate da partida é seu.")
        elif name == "Ace":
            ours = (x.get("AcingTeam") or "") == me.get("team")
            add(f"ev_ace_{eid}", "Todos os inimigos estão mortos." if ours else "Todo o seu time está morto.")
        elif name == "Multikill" and (x.get("KillStreak") or 0) >= 3:
            who = x.get("KillerName")
            add(f"ev_multi_{eid}", f"{'Você fez' if who == me_name else (who or 'Alguém') + ' fez'} um abate {['', '', 'duplo', 'triplo', 'quádruplo', 'pentakill'][min(5, x.get('KillStreak'))]}.")
        elif name == "HeraldKill":
            add(f"ev_herald_{eid}", "Arauto abatido.")
    # seus itens e seus picos de poder
    try:
        from . import guides
        mine_items = [it.get("itemID") for it in me.get("items") or []]
        for it in me.get("items") or []:
            info = (items or {}).get(str(it.get("itemID"))) or {}
            total = (info.get("gold") or {}).get("total") or 0
            if (total >= 2200 and not info.get("into") and "Boots" not in (info.get("tags") or [])) or it.get("itemID") in KEY_ITEMS:
                add(f"self_item_{it.get('itemID')}", f"Você completou {info.get('name') or it.get('displayName') or 'um item'}.")
        from . import visao
        if me.get("isDead") and gt >= 360 and visao.needs(me, gt):          # nao lembra com uma no inventario ou ativa no mapa
            add(f"self_ward_{int((me.get('scores') or {}).get('deaths') or 0)}", "Você está sem sentinela de controle.")
        g = guides.get(ddir, liveview.champ_id(me), None) if hasattr(guides, "get") else None
        lv = int(me.get("level") or 1)
        for pk in (g or {}).get("picos") or []:
            q = str(pk.get("quando") or "")
            import re as _re
            m = _re.search(r"(\d+)", q)
            if "ível" in q and m and lv >= int(m.group(1)) >= 2 and lv - int(m.group(1)) <= 1:
                add(f"self_spike_{m.group(1)}", f"Nível {m.group(1)}: {pk.get('porque')}")
    except Exception:
        pass
    team_of = {live._name(p): p.get("team") for p in live_data.get("allPlayers") or []}
    mine = me.get("team")
    drags = {}
    for x in ev:
        name, t = x.get("EventName"), x.get("EventTime") or 0
        tm = team_of.get(x.get("KillerName"))
        ours = tm == mine
        if name == "BaronKill" and tm and 0 < t + 180 - gt <= 35:
            add(f"buff_baron_{int(t)}", ("O buff do Barão do seu time" if ours else "O buff do Barão do inimigo") + f" acaba em {int(t + 180 - gt)} segundos.")
        if name == "DragonKill":
            if (x.get("DragonType") or "") == "Elder":
                if 0 < t + 150 - gt <= 30:
                    add(f"buff_elder_{int(t)}", ("O buff do Ancião do seu time" if ours else "O buff do Ancião do inimigo") + f" acaba em {int(t + 150 - gt)} segundos.")
            elif tm:
                drags[tm] = drags.get(tm, 0) + 1
        if name == "InhibKilled":
            inh = x.get("InhibKilled") or ""
            side_lost = "ORDER" if "_T1_" in inh else "CHAOS" if "_T2_" in inh else None
            left = t + 300 - gt
            if side_lost and 0 < left <= 35:
                add(f"inhib_{inh}_{int(t)}", ("O seu inibidor" if side_lost == mine else "O inibidor inimigo") + f" volta em {int(left)} segundos.")
    for tm, n in drags.items():
        if n == 3:
            add(f"obj_soul_{tm}", "Seu time está no ponto de alma: o próximo dragão dá a alma." if tm == mine else
                "O inimigo está no ponto de alma: o próximo dragão dá a alma para eles.")
    return al


def timers_line(live_data, me, gt):
    """Linha de timers para o painel: buffs ativos e inibidores caidos."""
    from . import live
    ev = (live_data.get("events") or {}).get("Events") or []
    team_of = {live._name(p): p.get("team") for p in live_data.get("allPlayers") or []}
    mine = me.get("team")
    parts = []
    mm = lambda v: f"{int(v) // 60}:{int(v) % 60:02d}"
    for x in ev:
        name, t = x.get("EventName"), x.get("EventTime") or 0
        ours = team_of.get(x.get("KillerName")) == mine
        if name == "BaronKill" and t + 180 > gt:
            parts.append(f"Barão {'nosso' if ours else 'deles'} {mm(t + 180 - gt)}")
        if name == "DragonKill" and (x.get("DragonType") or "") == "Elder" and t + 150 > gt:
            parts.append(f"Ancião {'nosso' if ours else 'deles'} {mm(t + 150 - gt)}")
        if name == "InhibKilled" and t + 300 > gt:
            inh = x.get("InhibKilled") or ""
            lost = "ORDER" if "_T1_" in inh else "CHAOS"
            parts.append(f"Inibidor {'nosso' if lost == mine else 'deles'} {mm(t + 300 - gt)}")
    return " · ".join(parts[:3])


# ---------------- narrador divertido (opcao de voz: mesmo conteudo, com humor) ----------------
FUN = {
    "obj_": ["Hora do churrasco! ", "Olha o bichão chegando! ", "Prepara o rio: "],
    "lane_dead": ["Tchau, querido! ", "Foi de base, literalmente. ", "Mandou pro banco de reservas! "],
    "threat_": ["Eita, esse aí tá alimentado. ", "Cuidado, temos um chefão. ", "Alguém deu comida demais pra ele. "],
    "self_dead": ["Acontece nas melhores famílias. ", "Respira, toma uma água. ", "Ninguém viu, fica entre nós. "],
    "eitem_": ["Opa, alguém foi às compras: ", "Saiu do shopping: ", "Novidade na vitrine do inimigo: "],
    "farm_": ["Relatório do agricultor: ", "Hora de contar as galinhas: "],
    "ev_": ["Que lance! ", "Pode isso, Arnaldo? ", "Rolou: "],
    "cd_": ["Anota aí: ", "Cola do professor: "],
    "gold_": ["Dinheiro no bolso! ", "Bora gastar: "],
    "mu_": ["Dica do professor: ", "Segredo do ofício: "],
    "lobby_": ["Bora aquecer! ", "Partiu fila: "],
    "post_": ["Fim de papo! ", "Acabou o show. "],
    "sel_": ["Seleção rolando: ", ""],
}


def fun(text, key):
    """Versao divertida da frase (prefixo escolhido pela chave, sempre igual para a mesma fala)."""
    import zlib as _z
    k = key or ""
    for pre, opts in FUN.items():
        if k.startswith(pre):
            return opts[_z.crc32(k.encode()) % len(opts)] + text
    if _z.crc32(k.encode()) % 3 == 0:
        return ["Olha só: ", "Fica a dica: ", "Escuta essa: "][_z.crc32(k.encode()) % 3] + text
    return text
