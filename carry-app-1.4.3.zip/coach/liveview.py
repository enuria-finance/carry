"""Ao vivo em UMA tela (sem rolar): placar e ouro, duelo de rota, sua build com o proximo item,
o que importa agora e os dois times. Atualiza sozinho a cada poucos segundos.

Tudo vem da API oficial do proprio jogo (Live Client Data) e dos seus dados; o app nao age no jogo.
"""
import html
import os
import time
import json

from . import builds, icons, live

e = lambda x: html.escape("" if x is None else str(x))
DRAGON_RESPAWN, BARON_RESPAWN = 300, 360
LANE = {"TOP": "Topo", "JUNGLE": "Selva", "MIDDLE": "Meio", "BOTTOM": "Atirador", "UTILITY": "Suporte"}


def champ_id(p):
    raw = p.get("rawChampionName") or ""
    if "displayname_" in raw:
        return raw.split("displayname_", 1)[1]
    return icons.champ_id(p.get("championName") or "")


def _mmss(s):
    s = max(int(s), 0)
    return f"{s // 60}:{s % 60:02d}"


def item_img(item_id, size=40, cls=""):
    ver = icons.version()
    if not ver:
        return f"<span class='it ph {cls}' style='width:{size}px;height:{size}px'></span>"
    return (f"<img class='it {cls}' src='{icons.CDN}/cdn/{e(ver)}/img/item/{int(item_id)}.png' width='{size}' height='{size}' alt='' loading='lazy'>")


def my_rows(con, puuid, champion, position=None):
    """As SUAS partidas com o campeao NA ROTA (vitorias primeiro), no mesmo formato da amostra do topo."""
    rows = con.execute(
        """SELECT p.match_id, p.participant_id, p.win, x.items, x.perks, x.spells, m.started_ms
           FROM participants p JOIN participant_extra x USING (match_id, participant_id) JOIN matches m USING (match_id)
           WHERE p.puuid=? AND p.champion=? AND COALESCE(m.duration_s,0)>=300 AND (?='' OR p.position=?)
           ORDER BY p.win DESC, m.started_ms DESC""",
        (puuid, champion, position or "", position or "")).fetchall()
    return [dict(r) for r in rows]


_PLAN = {}


def build_plan(con, puuid, champion, position, items_data, opp=None, foes=()):
    """{'order','boots','extra','start','n','source'} ou None. Primeiro a amostra dos melhores (recortada para o
    oponente de rota ou a composicao inimiga, quando tem amostra); senao, as suas vitorias."""
    key = (champion, position, opp, tuple(sorted(foes or ())), id(con))
    hit = _PLAN.get(key)
    if hit and time.time() - hit[0] < 600:
        return hit[1]
    plan = _build_plan(con, puuid, champion, position, items_data, opp, foes)
    if len(_PLAN) > 30:
        _PLAN.clear()
    _PLAN[key] = (time.time(), plan)
    return plan


def _build_plan(con, puuid, champion, position, items_data, opp=None, foes=()):
    for source, rows in (("os melhores do servidor", builds.top_rows(con, champion, position)),
                         ("as suas partidas com ele", my_rows(con, puuid, champion, position))):
        if not rows:
            continue
        why = None
        if source.startswith("os melhores") and (opp or foes):
            rows, why = builds.matchup_rows(con, rows, opp, foes)
            if why:
                source = f"os melhores {why}"
        if source.startswith("as suas"):
            wins = [r for r in rows if r["win"]]
            rows = wins if len(wins) >= 2 else rows
        if source.startswith("os melhores") and len(rows) < builds.MIN_ROWS:
            continue                                 # amostra pequena: melhor as suas vitorias do que ruido
        st = builds.item_stats(con, rows, items_data)
        b = builds.clean_build(st, items_data, champion, position)
        if not b["order"]:
            continue
        order, boots, extra, start = b["order"], b["boots"], b["extra"][:4], b["start"]
        return {"order": order, "boots": boots, "extra": extra, "start": start, "n": st["n"], "source": source}
    return None


def build_card(plan, me, gold, items_data, champion, queued):
    if not plan:
        msg = ("Baixando agora a amostra dos melhores com " + e(champion) + ": em alguns minutos a build aparece aqui."
               if queued else "Sem partidas suas nem do topo com " + e(champion) + " ainda.")
        return f"<div class='lv-card lv-build'><h3>Sua build</h3><div class='lv-empty'>{msg}</div></div>"
    owned = {i.get("itemID") for i in me.get("items") or []}
    seq = list(plan["order"])
    if plan["boots"]:
        seq.insert(1 if len(seq) > 1 else len(seq), plan["boots"])
    nxt = next((i for i in seq if i not in owned), None)
    steps = ""
    for i in seq:
        it = items_data.get(str(i)) or {}
        cost = (it.get("gold") or {}).get("total") or 0
        state = "own" if i in owned else ("next" if i == nxt else "")
        bar = ""
        if state == "next" and cost:
            pct = min(100, round(100 * gold / cost))
            bar = (f"<span class='lv-gold'><i style='width:{pct}%'></i></span>"
                   f"<small>{'pode comprar' if gold >= cost else f'faltam {cost - gold:,}'.replace(',', '.') + ' de ouro'}</small>")
        from .polish import tip_attr
        from .ddragon import clean
        steps += (f"<div class='lv-step {state}'{tip_attr(it.get('name', str(i)), f'{cost} de ouro' if cost else '', clean(it.get('description') or '')[:380])}>{item_img(i, 44)}<div><b>{e(it.get('name', i))}</b>"
                  f"<small>{cost:,} de ouro</small>{bar}</div>{'<em>✓</em>' if state == 'own' else ''}</div>".replace(",", "."))
    extra = "".join(f"<span title='{e((items_data.get(str(i)) or {}).get('name', i))}'>{item_img(i, 30)}</span>" for i in plan["extra"])
    start = "".join(f"<span title='{e((items_data.get(str(i)) or {}).get('name', i))}'>{item_img(i, 30)}</span>" for i in plan.get("start") or [])
    return (f"<div class='lv-card lv-build'><h3>Sua build <small>{e(plan['source'])} · {plan['n']} partidas</small></h3>"
            + (f"<div class='lv-extra'><small>Começo</small>{start}</div>" if start else "")
            + f"<div class='lv-steps'>{steps}</div>"
            + (f"<div class='lv-extra'><small>Também comuns</small>{extra}</div>" if extra else "") + "</div>")


def _objectives(data, me):
    t = (data.get("gameData") or {}).get("gameTime") or 0
    players = data.get("allPlayers") or []
    team_of = {live._name(p): p.get("team") for p in players}
    ev = (data.get("events") or {}).get("Events") or []
    out = []
    drag = [x for x in ev if x.get("EventName") == "DragonKill"]
    mine_d = sum(1 for x in drag if team_of.get(x.get("KillerName")) == me.get("team"))
    if drag:
        nxt = (drag[-1].get("EventTime") or 0) + DRAGON_RESPAWN
        out.append(("🐉", f"Dragão {'volta em ' + _mmss(nxt - t) if nxt > t else 'disponível'}", f"{mine_d} × {len(drag) - mine_d}"))
    else:
        out.append(("🐉", "Primeiro dragão aos 5:00" if t < 300 else "Dragão disponível", "0 × 0"))
    bar = [x for x in ev if x.get("EventName") == "BaronKill"]
    if bar:
        nxt = (bar[-1].get("EventTime") or 0) + BARON_RESPAWN
        out.append(("👁", f"Barão {'volta em ' + _mmss(nxt - t) if nxt > t else 'disponível'}", ""))
    elif t >= 20 * 60:
        out.append(("👁", "Barão disponível", ""))
    return out


def now_list(data, me, foes, my_cs_avg):
    """No maximo 4 linhas curtas, da mais urgente para a menos."""
    t = (data.get("gameData") or {}).get("gameTime") or 0
    items = []
    dead = [p for p in foes if p.get("isDead")]
    if dead:
        names = ", ".join(f"{p.get('championName')} ({int(p.get('respawnTimer') or 0)}s)" for p in dead[:3])
        items.append(("⚔", f"{len(dead)} inimigo{'s' if len(dead) > 1 else ''} morto{'s' if len(dead) > 1 else ''}: {names}", "dado"))
    if me.get("isDead"):
        items.append(("⏳", f"Você volta em {int(me.get('respawnTimer') or 0)}s", "dado"))
    sc = me.get("scores") or {}
    if sc.get("deaths", 0) >= 3 and sc["deaths"] > sc.get("kills", 0) + sc.get("assists", 0):
        items.append(("🛡", "Muitas mortes: farme perto da torre e só lute com o jungler à vista", "regra"))
    if t >= 300 and sc.get("creepScore") is not None and (me.get("position") or "").upper() not in ("UTILITY", "JUNGLE"):
        cpm = sc["creepScore"] / (t / 60)
        avg = f" · sua média {my_cs_avg[0]:.1f}" if my_cs_avg else ""
        items.append(("🌾", f"CS/min {cpm:.1f}{avg}", "dado"))
    items.append(("🧭", live.tips_for(me.get("position"))[live.phase_now(t)][0], "regra"))
    return items[:4]


ROLES = (("TOP", "Topo"), ("JUNGLE", "Selva"), ("MIDDLE", "Meio"), ("BOTTOM", "Atirador"), ("UTILITY", "Suporte"))


def est_gold(p, t):
    """Ouro total ganho, ESTIMADO pelo placar (o jogo nao mostra o ouro dos inimigos): inicial + passivo + farm + abates
    e assistencias. A mesma conta para os dois lados, entao a diferenca entre eles e o que vale."""
    sc = p.get("scores") or {}
    passive = max(0.0, t - 65) * 2.04
    return int(500 + passive + 20 * int(sc.get("creepScore") or 0) + 300 * int(sc.get("kills") or 0) + 130 * int(sc.get("assists") or 0))


def lanes_card(mine, foes, me, t):
    """Rota a rota: diferenca de itens, de ouro total estimado, de farm e de nivel."""
    sgn = lambda v: ("+" if v > 0 else "") + (f"{v / 1000:.1f}k" if abs(v) >= 1000 else str(v))
    cls = lambda v: "up" if v > 0 else "dn" if v < 0 else ""
    rows = ""
    for r, lb in ROLES:
        a = next((p for p in mine if (p.get("position") or "").upper() == r), None)
        b = next((p for p in foes if (p.get("position") or "").upper() == r), None)
        if not a or not b:
            continue
        iv = live._value(a) - live._value(b)
        gv = est_gold(a, t) - est_gold(b, t)
        cs = int((a.get("scores") or {}).get("creepScore") or 0) - int((b.get("scores") or {}).get("creepScore") or 0)
        lv = int(a.get("level") or 0) - int(b.get("level") or 0)
        rows += (f"<div class='lr{' me' if a is me else ''}'>{icons.champ(champ_id(a), 24)}<b>{e(lb)}</b>"
                 f"<span class='{cls(iv)}'>{sgn(iv)}</span><span class='{cls(gv)}'>{sgn(gv)}</span>"
                 f"<span class='{cls(cs)}'>{sgn(cs)}</span><span class='{cls(lv)}'>{sgn(lv)}</span>{icons.champ(champ_id(b), 24)}</div>")
    if not rows:
        return ""
    css = ("<style>.lr{display:grid;grid-template-columns:26px 70px repeat(4,1fr) 26px;gap:6px;align-items:center;padding:5px 0;"
           "border-bottom:1px solid rgba(255,255,255,.05);font-size:13px}.lr.me{background:rgba(200,40,50,.08)}.lr b{font-weight:600}"
           ".lr span{text-align:center;color:var(--mute)}.lr span.up{color:#8FD4A8}.lr span.dn{color:#E8817C}"
           ".lrh{display:grid;grid-template-columns:26px 70px repeat(4,1fr) 26px;gap:6px;font-size:11px;color:var(--mute);text-align:center}</style>")
    head = "<div class='lrh'><i></i><i></i><span>Itens</span><span>Ouro total*</span><span>Farm</span><span>Nível</span><i></i></div>"
    return (f"{css}<div class='lv-card'><h3>Rota a rota <small>seu time contra o deles</small></h3>{head}{rows}"
            "<p class='n' style='font-size:11px;margin-top:6px'>*Estimado pelo placar: o jogo não mostra o ouro dos inimigos.</p></div>")


def team_table(players, me_team, me):
    rows = ""
    for p in players:
        sc = p.get("scores") or {}
        dead = p.get("isDead")
        rows += (f"<div class='lv-pl{' dead' if dead else ''}{' me' if p is me else ''}'>{icons.champ(champ_id(p), 30)}"
                 f"<span class='lv-lv'>{p.get('level', '')}</span>"
                 f"<span class='lv-k'>{sc.get('kills', 0)}/{sc.get('deaths', 0)}/{sc.get('assists', 0)}</span>"
                 f"<span class='lv-v'>{live._value(p) / 1000:.1f}k</span>"
                 + (f"<span class='lv-rs'>{int(p.get('respawnTimer') or 0)}s</span>" if dead else "") + "</div>")
    return rows


def build_page(data, con, puuid, items_data, my_cs_avg, queued, position=None):
    me = live._find_me(data)
    gt = (data.get("gameData") or {}).get("gameTime") or 0
    if not me:
        return "<div class='lv-empty big'>Não consegui identificar você nesta partida (modo espectador ou treino).</div>"
    players = data.get("allPlayers") or []
    mine = [p for p in players if p.get("team") == me.get("team")]
    foes = [p for p in players if p.get("team") != me.get("team")]
    gold = int((data.get("activePlayer") or {}).get("currentGold") or 0)
    champ = champ_id(me)
    pos = me.get("position") or position
    _opp = next((p for p in foes if pos and p.get("position") == pos), None)
    plan = build_plan(con, puuid, champ, pos, items_data, champ_id(_opp) if _opp else None,
                      tuple(champ_id(p) for p in foes)) if items_data else None
    sm, sf = sum(live._value(p) for p in mine), sum(live._value(p) for p in foes)
    share = 50 if not (sm + sf) else round(100 * sm / (sm + sf))
    km = sum((p.get("scores") or {}).get("kills", 0) for p in mine)
    kf = sum((p.get("scores") or {}).get("kills", 0) for p in foes)
    opp = next((p for p in foes if pos and p.get("position") == pos), None)
    duel = ""
    if opp:
        dv = live._value(me) - live._value(opp)
        gdv = est_gold(me, gt) - est_gold(opp, gt)
        dl = (me.get("level") or 0) - (opp.get("level") or 0)
        csd = (me.get("scores") or {}).get("creepScore", 0) - (opp.get("scores") or {}).get("creepScore", 0)
        cls = lambda v: "up" if v > 0 else "dn" if v < 0 else ""
        duel = (f"<div class='lv-duel'>{icons.champ(champ, 52, 'me')}<div class='lv-dm'>"
                f"<span class='{cls(dl)}'>Nível {'+' if dl > 0 else ''}{dl}</span><span class='{cls(csd)}'>CS {'+' if csd > 0 else ''}{csd}</span>"
                f"<span class='{cls(dv)}'>Itens {'+' if dv > 0 else ''}{dv}</span>"
                f"<span class='{cls(gdv)}'>Ouro {'+' if gdv > 0 else ''}{gdv}*</span></div>{icons.champ(champ_id(opp), 52, 'foe')}</div>")
    objs = "".join(f"<span class='lv-obj'><i>{ic}</i>{e(t)}{f' <b>{e(s)}</b>' if s else ''}</span>" for ic, t, s in _objectives(data, me))
    top = (f"<div class='lv-top' style=\"--lvart:url('{e(icons.splash(champ_id(me)))}')\"><div class='lv-clock'><span class='lv-live'>Ao vivo</span><b>{_mmss(gt)}</b><small>{e(LANE.get(pos, ''))} · {e(me.get('championName'))}</small></div>"
           f"<div class='lv-score'><div class='lv-k2'><b class='a'>{km}</b><span>abates</span><b class='b'>{kf}</b></div>"
           f"<div class='lv-bar'><i style='width:{share}%'></i></div><div class='lv-gv'><span>{sm / 1000:.1f}k</span><small>valor dos itens</small><span>{sf / 1000:.1f}k</span></div></div>"
           f"{duel}<div class='lv-objs'>{objs}</div></div>")
    tagc = {"dado": "dado", "regra": "regra", "hipotese": "hipotese"}
    now = "".join(f"<div class='lv-now {tagc[k]}'><i>{ic}</i><span>{e(t)}</span></div>" for ic, t, k in now_list(data, me, foes, my_cs_avg))
    teams = (f"<div class='lv-card lv-teams'><h3>Partida</h3><div class='lv-cols'><div class='lv-side a'>{team_table(mine, me.get('team'), me)}</div>"
             f"<div class='lv-side b'>{team_table(foes, me.get('team'), me)}</div></div></div>") + lanes_card(mine, foes, me, gt)
    grid = (f"<div class='lv-grid'>{build_card(plan, me, gold, items_data or {}, me.get('championName'), queued)}"
            f"<div class='lv-card lv-nowc'><h3>Agora</h3>{now}</div>{teams}</div>")
    return top + grid


CSS = """
/* ---------- ao vivo: tela unica ---------- */
.lv-top{display:grid;grid-template-columns:auto minmax(220px,1fr) auto auto;gap:18px;align-items:center;padding:14px 18px;border:1px solid var(--rule);border-radius:16px;
background:linear-gradient(90deg,rgba(59,158,255,.12),var(--panel) 35%,var(--panel) 65%,rgba(255,122,133,.12));margin:0 0 14px}
.lv-clock b{display:block;font:800 34px/1 var(--head);color:#fff;font-variant-numeric:tabular-nums}
.lv-clock small{color:var(--mute);font-size:12.5px}
.lv-k2{display:flex;align-items:baseline;justify-content:center;gap:10px}.lv-k2 b{font:800 24px var(--head)}.lv-k2 .a{color:#8cc4ff}.lv-k2 .b{color:#ff9aa3}
.lv-k2 span{color:var(--mute);font-size:12px}
.lv-bar{height:8px;border-radius:99px;background:#E8817C;overflow:hidden;margin:6px 0 4px}.lv-bar i{display:block;height:100%;background:linear-gradient(90deg,#3b9eff,#8cc4ff);transition:width .8s}
.lv-gv{display:flex;justify-content:space-between;font:600 12.5px var(--head);color:#D6CCC0}.lv-gv small{color:var(--mute);font-weight:400}
.lv-duel{display:flex;align-items:center;gap:10px}.lv-dm{display:flex;flex-direction:column;gap:2px;font:700 12.5px var(--head);text-align:center;min-width:86px}
.lv-dm .up{color:var(--win)}.lv-dm .dn{color:var(--loss)}
.lv-objs{display:flex;flex-direction:column;gap:4px}.lv-obj{display:flex;align-items:center;gap:6px;font-size:13px;color:#DDD3C7;white-space:nowrap}
.lv-obj i{font-style:normal}.lv-obj b{color:var(--gold);margin-left:4px}
.lv-grid{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,1fr) minmax(0,1fr);gap:14px;align-items:start}
.lv-card{border:1px solid var(--rule);border-radius:16px;background:var(--panel);padding:14px 16px}
.lv-card h3{margin:0 0 10px;font:700 15px var(--head);color:#fff;display:flex;align-items:baseline;gap:8px;flex-wrap:wrap}.lv-card h3 small{color:var(--mute);font:400 12px var(--body)}
.lv-steps{display:flex;flex-direction:column;gap:8px}
.lv-step{display:grid;grid-template-columns:44px minmax(0,1fr) auto;gap:10px;align-items:center;padding:6px 8px;border-radius:12px;border:1px solid transparent}
.lv-step .it{border-radius:8px;border:1px solid #2a3245}
.lv-step b{display:block;font:700 14px var(--head)}.lv-step small{color:var(--mute);font-size:12px}
.lv-step.own{opacity:.55}.lv-step.own em{font-style:normal;color:var(--win);font-weight:800}
.lv-step.next{border-color:rgba(233,196,106,.6);background:rgba(233,196,106,.07);box-shadow:0 0 22px rgba(233,196,106,.12)}
.lv-step.next .it{border-color:var(--gold);box-shadow:0 0 12px rgba(233,196,106,.5)}
.lv-gold{display:block;height:6px;border-radius:99px;background:#261C1B;margin:5px 0 2px;overflow:hidden}.lv-gold i{display:block;height:100%;background:linear-gradient(90deg,#b8923f,#ffe39a);transition:width .8s}
.lv-extra{display:flex;align-items:center;gap:6px;margin-top:10px;padding-top:10px;border-top:1px solid var(--rule)}.lv-extra small{color:var(--mute);font-size:12px;margin-right:4px}
.lv-extra .it{border-radius:6px}
.lv-now{display:flex;gap:10px;align-items:flex-start;padding:9px 10px;border-radius:10px;background:rgba(16,11,11,.45);border-left:3px solid var(--rule);margin-bottom:8px;font-size:14px;color:#dfe5f2}
.lv-now i{font-style:normal}.lv-now.dado{border-left-color:var(--dado)}.lv-now.regra{border-left-color:var(--regra)}.lv-now.hipotese{border-left-color:var(--hip)}
.lv-cols{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.lv-side{display:flex;flex-direction:column;gap:5px}
.lv-pl{display:grid;grid-template-columns:30px 22px minmax(0,1fr) auto;gap:6px;align-items:center;padding:4px 6px;border-radius:8px;font:600 12.5px var(--head);position:relative}
.lv-side.a .lv-pl{background:rgba(59,158,255,.06)}.lv-side.b .lv-pl{background:rgba(255,122,133,.06)}
.lv-pl .cic{border-radius:7px}.lv-pl.me{outline:1px solid var(--gold)}
.lv-lv{color:var(--mute);font-size:11.5px}.lv-v{color:var(--gold)}
.lv-pl.dead{opacity:.45;filter:grayscale(.8)}.lv-rs{position:absolute;left:4px;top:3px;font:800 11px var(--head);color:#fff;text-shadow:0 0 4px #000}
.lv-empty{color:var(--mute);padding:14px;border:1px dashed var(--rule);border-radius:12px;font-size:14px}
.lv-empty.big{padding:30px;text-align:center}
@media (max-width:1200px){.lv-grid{grid-template-columns:1fr 1fr}.lv-teams{grid-column:1/-1}.lv-top{grid-template-columns:auto 1fr}}
@media (max-width:760px){.lv-grid,.lv-top{grid-template-columns:1fr}}
"""
