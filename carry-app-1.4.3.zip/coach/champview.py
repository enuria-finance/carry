"""Paginas de campeao (estilo guia): ficha oficial, habilidades, build/runas/feiticos e ordem de habilidades da amostra
dos melhores, confrontos (bons e ruins), especialistas do servidor (maestria) e dicas oficiais da Riot.

Fontes: Data Dragon (oficial), amostras guardadas pelo app (top.sqlite / tiers.sqlite) e a API oficial de maestria.
Nada inventado: cada numero mostra quantos jogos tem por tras.
"""
import html
import json
import os
import re
import sqlite3
from collections import Counter

from . import db, icons

e = lambda x: html.escape("" if x is None else str(x))
ROLE_PT = {"TOP": "Topo", "JUNGLE": "Selva", "MIDDLE": "Meio", "BOTTOM": "Atirador", "UTILITY": "Suporte"}
TAG_PT = {"Assassin": "Assassino", "Fighter": "Lutador", "Mage": "Mago", "Marksman": "Atirador", "Support": "Suporte", "Tank": "Tanque"}
SLOT = {1: "Q", 2: "W", 3: "E", 4: "R"}


def _strip(t):
    t = re.sub(r"<br\s*/?>", " ", t or "")
    return re.sub(r"<[^>]+>", "", t).strip()


def sample_paths(ddir):
    return [p for p in (os.path.join(ddir, "top.sqlite"), os.path.join(ddir, "tiers.sqlite")) if os.path.exists(p)]


def role_map(ddir, extra_con=None):
    c = {}
    cons = [sqlite3.connect(p) for p in sample_paths(ddir)]
    try:
        for con in cons + ([extra_con] if extra_con is not None else []):
            for ch, pos, n in con.execute("SELECT champion, position, COUNT(*) FROM participants WHERE COALESCE(position,'')<>'' GROUP BY 1,2"):
                c.setdefault(ch, Counter())[pos] += n
    finally:
        for x in cons:
            x.close()
    return {ch: cnt.most_common(1)[0][0] for ch, cnt in c.items()}


def matchup_stats(ddir, champ, pos):
    """[(oponente, jogos, vitorias)] do campeao na posicao, somando as amostras do app."""
    agg = {}
    for p in sample_paths(ddir):
        con = sqlite3.connect(p)
        try:
            q = """SELECT o.champion, a.win FROM participants a JOIN participants o
                   ON o.match_id=a.match_id AND o.team_id<>a.team_id AND o.position=a.position
                   JOIN matches m ON m.match_id=a.match_id
                   WHERE a.champion=? AND a.position=? AND COALESCE(m.duration_s,0)>=300"""
            for opp, win in con.execute(q, (champ, pos)):
                n, w = agg.get(opp, (0, 0))
                agg[opp] = (n + 1, w + (1 if win else 0))
        finally:
            con.close()
    return [(o, n, w) for o, (n, w) in agg.items()]


def skill_order(con, rows):
    """Ordem de habilidades mais comum: 3 primeiros niveis e prioridade de maximizar (amostra do topo)."""
    firsts, maxes, seqs, per = Counter(), Counter(), Counter(), [Counter() for _ in range(18)]
    for r in rows:
        seq = [json.loads(d).get("skillSlot") for (d,) in con.execute(
            "SELECT data FROM events WHERE match_id=? AND pid=? AND type='SKILL_LEVEL_UP' ORDER BY t_ms", (r["match_id"], r["participant_id"]))]
        seq = [s for s in seq if s in SLOT]
        if len(seq) < 9:
            continue
        firsts[tuple(seq[:3])] += 1
        seqs[tuple(seq[:15])] += 1
        for i, sl in enumerate(seq[:18]):
            per[i][sl] += 1
        cnt, order = Counter(), []
        for s in seq:
            if s == 4:
                continue
            cnt[s] += 1
            if cnt[s] == 5 and s not in order:
                order.append(s)
        for s in (1, 2, 3):
            if s not in order:
                order.append(s)
        maxes[tuple(order[:3])] += 1
    if not maxes:
        return None
    top_seq, k = seqs.most_common(1)[0]
    full = list(top_seq) if k >= 2 else [c.most_common(1)[0][0] for c in per if c]
    return {"first": firsts.most_common(1)[0][0], "max": maxes.most_common(1)[0][0], "n": sum(maxes.values()), "seq": full[:18]}


def experts(ddir, champ_key, limit=10):
    p = os.path.join(ddir, "top.sqlite")
    if not os.path.exists(p):
        return []
    con = sqlite3.connect(p)
    try:
        if not con.execute("SELECT 1 FROM sqlite_master WHERE name='top_mastery'").fetchone():
            return []
        rows = con.execute(
            """SELECT m.puuid, m.points, n.riot_id, t.tier, t.lp,
                      (SELECT champion_id FROM top_mastery x WHERE x.puuid=m.puuid ORDER BY points DESC LIMIT 1) AS best
               FROM top_mastery m LEFT JOIN top_names n USING(puuid) LEFT JOIN top_players t USING(puuid)
               WHERE m.champion_id=? ORDER BY m.points DESC LIMIT ?""", (int(champ_key), limit)).fetchall()
        return [{"riot_id": r[2] or "jogador do topo", "points": r[1], "tier": r[3], "lp": r[4], "mono": r[5] == int(champ_key)} for r in rows]
    finally:
        con.close()


def list_body(champs, roles, my_counts, q_role):
    chips = "".join(f"<button type='button' class='rolef{' on' if (q_role or '') == k else ''}' data-r='{k}'>{t}</button>"
                    for k, t in [("", "Todas")] + list(ROLE_PT.items()))
    cards = ""
    for cid, c in sorted(champs.items(), key=lambda kv: kv[1]["name"]):
        mine = my_counts.get(cid)
        cards += (f"<a class='chc' href='/campeao/{e(cid)}' data-n='{e(c['name'].lower())}' data-r='{e(roles.get(cid, ''))}'>"
                  f"{icons.champ(cid, 64)}<b>{e(c['name'])}</b>"
                  + (f"<small>{mine} jogo{'s' if mine != 1 else ''} seus</small>" if mine else "") + "</a>")
    js = """<script>(function(){var q=document.getElementById('chq'),role='';function f(){var t=(q.value||'').toLowerCase();
document.querySelectorAll('.chc').forEach(function(c){c.hidden=!(c.dataset.n.indexOf(t)>=0&&(!role||c.dataset.r===role))})}
q.addEventListener('input',f);document.querySelectorAll('.rolef').forEach(function(b){b.onclick=function(){role=b.dataset.r;
document.querySelectorAll('.rolef').forEach(function(x){x.classList.toggle('on',x===b)});f()}});f()})();</script>"""
    return (f"<div class='chtools'><input id='chq' placeholder='Buscar campeão…' autocomplete='off'><div class='rolefs'>{chips}</div></div>"
            f"<div class='chgrid'>{cards}</div>" + js)


def _bars(rows, good):
    out = ""
    for i, (o, n, w) in enumerate(rows, 1):
        pct = round(100 * w / n)
        out += (f"<a class='mrow' href='/campeao/{e(o)}'><span class='mi'>{i}</span>{icons.champ(o, 38)}<div><b>{e(o)}</b>"
                f"<small>{n} partida{'s' if n != 1 else ''}</small><span class='mbar {'g' if good else 'b'}'><i style='width:{pct}%'></i></span></div>"
                f"<em class='{'win' if good else 'loss'}'>{pct}%</em></a>")
    return out


def page_body(cid, data, info, ver, pos, mu, sk, exps, cfg_html, my_stats, vs_me, has_top):
    name = data.get("name", cid)
    tags = " ".join(f"<span class='badge'>{e(TAG_PT.get(t, t))}</span>" for t in data.get("tags", []))
    meters = "".join(
        f"<div class='cm'><small>{lab}</small><span>{''.join(f'<i class={chr(39)}on{chr(39)}></i>' if k < round(v / 2) else '<i></i>' for k in range(5))}</span></div>"
        for lab, v in (("Ataque", info.get("attack", 0)), ("Defesa", info.get("defense", 0)), ("Magia", info.get("magic", 0)), ("Dificuldade", info.get("difficulty", 0))))
    mine = ""
    if my_stats:
        n, w = my_stats
        mine = f"<span class='pill {'' if n < 5 else 'okp' if w / n >= .52 else 'badp' if w / n <= .45 else ''}'><small>Você com ele</small>{n} jogos · {round(100 * w / n)}%</span>"
    if vs_me:
        n, w = vs_me
        mine += f" <span class='pill'><small>Você contra ele</small>{w}V {n - w}D</span>"
    hero = (f"<section class='chero'><div class='sp' style=\"background-image:url('{icons.splash(cid)}')\"></div><div class='ch-in'>"
            f"<small>{e(data.get('title', '').capitalize())}</small><h1 class='ch-n'>{e(name)}</h1><div class='badges'>{tags}"
            f"<span class='badge'>{e(ROLE_PT.get(pos, pos or ''))}</span></div><p class='ch-b'>{e(_strip(data.get('blurb', '')))}</p>"
            f"<div class='cms'>{meters}</div><div class='ch-me'>{mine}</div></div></section>")
    # habilidades
    abil = ""
    pas = data.get("passive") or {}
    if pas:
        img = f"{icons.CDN}/cdn/{e(ver)}/img/passive/{e((pas.get('image') or {}).get('full', ''))}" if ver else ""
        abil += (f"<div class='ab'><span class='abk'>P</span>" + (f"<img src='{img}' width='44' height='44' alt=''>" if img else "")
                 + f"<div><b>{e(pas.get('name'))}</b><p>{e(_strip(pas.get('description'))[:260])}</p></div></div>")
    for k, sp in zip("QWER", data.get("spells") or []):
        img = f"{icons.CDN}/cdn/{e(ver)}/img/spell/{e((sp.get('image') or {}).get('full', ''))}" if ver else ""
        abil += (f"<div class='ab'><span class='abk'>{k}</span>" + (f"<img src='{img}' width='44' height='44' alt=''>" if img else "")
                 + f"<div><b>{e(sp.get('name'))}</b><p>{e(_strip(sp.get('description'))[:260])}</p></div></div>")
    body = hero + f"<h2>Habilidades</h2><div class='abs'>{abil}</div>"
    # build
    body += f"<h2>Build, runas e feitiços · os melhores do servidor</h2>{cfg_html}"
    if sk:
        def chip(s):
            return f"<span class='skc'>{SLOT[s]}</span>"
        body += (f"<div class='card'><b class='gl'>Ordem de habilidades</b><div class='sko'><small>Níveis 1-3</small>{''.join(chip(s) for s in sk['first'])}"
                 f"<small style='margin-left:18px'>Maximizar</small>{'<span class=ska>›</span>'.join(chip(s) for s in sk['max'])}</div>"
                 f"<p class='n'><span class='tag dado'>dado</span> {sk['n']} partidas da amostra.</p></div>")
    # confrontos
    ok = [m for m in mu if m[1] >= 20]          # amostra do topo: 3 jogos 3-0 nao e confronto bom
    sv = lambda m: (m[2] + 10) / (m[1] + 20)
    good = sorted([m for m in ok if sv(m) > .51], key=lambda m: -sv(m))[:6]
    bad = sorted([m for m in ok if sv(m) < .49], key=lambda m: sv(m))[:6]
    total = sum(m[1] for m in mu)
    if ok:
        body += (f"<h2>Confrontos no {e(ROLE_PT.get(pos, pos or ''))}</h2><div class='grid2'>"
                 f"<div class='card'><b class='gl'>Bons confrontos para {e(name)}</b>{_bars(good, True) or '<p class=n>Sem dados suficientes.</p>'}</div>"
                 f"<div class='card'><b class='gl'>Counters de {e(name)}</b>{_bars(bad, False) or '<p class=n>Sem dados suficientes.</p>'}</div></div>"
                 f"<p class='n'><span class='tag dado'>dado</span> {total} partidas nas amostras do app (topo e elos). Só aparece quem tem 3 jogos ou mais.</p>")
    else:
        body += ("<h2>Confrontos</h2><div class='empty'><span class='em'>⚔</span><b>Ainda sem partidas suficientes deste campeão</b>"
                 "<span>Baixe a amostra do topo dele (botão abaixo) para ver bons confrontos e counters.</span></div>")
    # especialistas
    if exps:
        rows = "".join(f"<div class='exr'><span class='mi'>{i}</span><b>{e(x['riot_id'])}</b>"
                       + ("<span class='badge adm'>Mono</span>" if x["mono"] else "")
                       + f"<small>{e((x['tier'] or '').title())} {x['lp'] or ''} PDL</small><em>{x['points']:,} pts</em></div>".replace(",", ".")
                       for i, x in enumerate(exps, 1))
        body += f"<h2>Especialistas do servidor</h2><div class='card'>{rows}<p class='n'>Jogadores do Desafiante ao Mestre com mais maestria neste campeão.</p></div>"
    else:
        body += ("<h2>Especialistas do servidor</h2><div class='card'><p class='n'>Ainda sem a lista de especialistas. "
                 "O administrador atualiza em Administração → Especialistas (leva alguns minutos).</p></div>")
    # dicas oficiais
    ally, enemy = data.get("allytips") or [], data.get("enemytips") or []
    if ally or enemy:
        li = lambda xs: "".join(f"<li>{e(_strip(x))}</li>" for x in xs[:4])
        body += (f"<h2>Dicas oficiais da Riot</h2><div class='grid2'><div class='card'><b class='gl'>Jogando de {e(name)}</b><ul class='tipl'>{li(ally)}</ul></div>"
                 f"<div class='card'><b class='gl'>Jogando contra {e(name)}</b><ul class='tipl'>{li(enemy)}</ul></div></div>")
    body += (f"<div class='ovl'><b>Dúvidas sobre {e(name)}?</b><span>Pergunte ao Coach IA: ele cruza com as suas partidas.</span>"
             f"<a class='btn gold' href='/coach?q={e('Como jogar contra ' + name + '?')}'>Perguntar ao Coach IA</a>"
             f"<form method='post' action='/sincronizar/iniciar'><input type='hidden' name='kind' value='top'><input type='hidden' name='champion' value='{e(cid)}'>"
             "<input type='hidden' name='games' value='30'><input type='hidden' name='back' value='1'><button class='btn ghost'>"
             f"{'Aumentar' if has_top else 'Baixar'} amostra do topo</button></form></div>")
    return body


CSS = """
.chtools{display:flex;gap:14px;align-items:center;flex-wrap:wrap;margin:0 0 16px}.chtools input{max-width:320px}
.rolefs{display:flex;gap:6px;flex-wrap:wrap}
.rolef{background:none !important;border:1px solid var(--hx-line,#463714) !important;color:var(--mute) !important;font:600 13px var(--body) !important;letter-spacing:0 !important;padding:7px 12px !important}
.rolef.on{border-color:var(--gold) !important;color:#fff !important;background:rgba(200,170,110,.1) !important}
.chgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(104px,1fr));gap:10px}
.chc{display:flex;flex-direction:column;align-items:center;gap:6px;padding:12px 6px;border:1px solid var(--rule);background:rgba(8,19,31,.6);text-decoration:none;color:var(--ink);transition:transform .2s,border-color .2s}
.chc[hidden]{display:none !important}
.chc:hover{transform:translateY(-3px);border-color:var(--gold)}.chc .cic{border-radius:4px}.chc b{font:600 13px var(--body);text-align:center}
.chc small{color:var(--gold);font-size:11.5px}
.chero{position:relative;overflow:hidden;min-height:360px;border:1px solid #785a28;margin:0 0 18px;display:flex;align-items:flex-end}
.chero .sp{position:absolute;inset:-30px;background-size:cover;background-position:center 18%;animation:mdrift 28s ease-in-out infinite alternate}
.chero::after{content:"";position:absolute;inset:0;background:linear-gradient(90deg,rgba(1,10,19,.95) 30%,rgba(1,10,19,.2) 75%),linear-gradient(0deg,rgba(1,10,19,.9),transparent 55%)}
.ch-in{position:relative;z-index:2;padding:30px 34px;max-width:680px}
.ch-in>small{color:var(--gold);font:600 14px var(--head);letter-spacing:.1em}.ch-n{margin:2px 0 8px;font-size:56px}
.ch-b{color:#D6CCC0;font-size:14.5px;margin:12px 0}
.cms{display:flex;gap:18px;flex-wrap:wrap;margin:6px 0 12px}.cm small{display:block;color:var(--mute);font-size:12px;margin-bottom:4px}
.cm span{display:flex;gap:3px}.cm i{width:18px;height:6px;background:#1b2533}.cm i.on{background:linear-gradient(90deg,#785a28,#c8aa6e)}
.ch-me{display:flex;gap:8px;flex-wrap:wrap}
.abs{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:10px}
.ab{display:grid;grid-template-columns:24px 44px minmax(0,1fr);gap:10px;align-items:start;padding:12px;border:1px solid var(--rule);background:rgba(8,19,31,.6)}
.ab img{border:1px solid #785a28}.abk{font:700 14px var(--head);color:var(--gold);padding-top:12px}
.ab b{display:block;font:700 14px var(--head);color:#fff}.ab p{margin:4px 0 0;font-size:13px;color:#b9c2d6;line-height:1.45}
.sko{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:10px 0}.sko small{color:var(--mute);font-size:12.5px;margin-right:4px}
.skc{width:34px;height:34px;display:inline-flex;align-items:center;justify-content:center;border:1px solid var(--gold);background:#0b1622;font:700 15px var(--head);color:#fff}
.ska{color:var(--gold);font-weight:700}
.mrow{display:grid;grid-template-columns:20px 38px minmax(0,1fr) auto;gap:10px;align-items:center;padding:8px 4px;border-bottom:1px solid var(--rule);text-decoration:none;color:var(--ink)}
.mrow:last-child{border-bottom:0}.mrow .cic{border-radius:4px}.mrow b{font:700 14px var(--body)}.mrow small{display:block;color:var(--mute);font-size:12px}
.mbar{display:block;height:5px;background:#16202d;margin-top:5px}.mbar i{display:block;height:100%}.mbar.g i{background:linear-gradient(90deg,#1f9c7d,#6BBF8A)}.mbar.b i{background:linear-gradient(90deg,#a3283c,#ff6b7a)}
.mrow em{font-style:normal;font:700 15px var(--head)}.mi{color:var(--mute);font-size:12.5px;text-align:center}
.exr{display:grid;grid-template-columns:24px minmax(0,1fr) auto auto auto;gap:10px;align-items:center;padding:9px 4px;border-bottom:1px solid var(--rule)}
.exr b{font:700 14px var(--body);color:#fff}.exr small{color:var(--mute);font-size:12.5px}.exr em{font-style:normal;color:var(--gold);font:600 13px var(--body)}
.ovl .btn,.ovl form{flex:none}
.ovl>a.btn{width:auto;display:inline-flex}
.tipl{margin:10px 0 0;padding-left:18px;color:#DDD3C7;font-size:14px;line-height:1.55}.tipl li{margin:6px 0}
"""
