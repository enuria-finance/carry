"""Pagina Habitos: quando, quanto e em que ordem voce joga, e o que isso muda no resultado.
Horarios no fuso do seu PC. Toda leitura mostra o tamanho da amostra."""
import html
import time
from collections import defaultdict

from . import habits, views2
from .tags import DADO, HIPOTESE, REGRA, tip

e = lambda x: html.escape("" if x is None else str(x))
DAYS = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"]
PERIODS = [("Madrugada", "0–5h", 0, 6), ("Manhã", "6–11h", 6, 12), ("Tarde", "12–17h", 12, 18), ("Noite", "18–23h", 18, 24)]
MIN_CELL = 4
SESSION_GAP_MIN = 60


def _wr(ws):
    return round(100 * sum(ws) / len(ws)) if ws else None


def sessions(res):
    out, cur = [], []
    for r in res:
        if cur:
            prev_end = cur[-1]["started_ms"] + (cur[-1]["duration_s"] or 0) * 1000
            if r["started_ms"] - prev_end > SESSION_GAP_MIN * 60000:
                out.append(cur)
                cur = []
        cur.append(r)
    if cur:
        out.append(cur)
    return out


def _tone(wr):
    """Cor da celula: vermelho abaixo de 50, verde-agua acima, pelo desvio."""
    d = max(-40, min(40, wr - 50)) / 40
    if d >= 0:
        return f"rgba(94,224,192,{0.10 + 0.50 * d:.2f})"
    return f"rgba(255,122,133,{0.10 + 0.50 * -d:.2f})"


def heatmap(res):
    cell = defaultdict(list)
    for r in res:
        t = time.localtime(r["started_ms"] / 1000)
        pi = next(i for i, p in enumerate(PERIODS) if p[2] <= t.tm_hour < p[3])
        cell[(t.tm_wday, pi)].append(r["win"])
    head = "<div class='hm'><span></span>" + "".join(f"<b>{d}</b>" for d in DAYS)
    rows = ""
    for pi, (nm, hrs, _, _) in enumerate(PERIODS):
        rows += f"<b class='hl'>{nm}<small>{hrs}</small></b>"
        for d in range(7):
            ws = cell.get((d, pi), [])
            if not ws:
                rows += "<i class='hc none'></i>"
                continue
            wr = _wr(ws)
            dim = " dim" if len(ws) < MIN_CELL else ""
            rows += (f"<i class='hc{dim}' style='background:{_tone(wr)}' title='{DAYS[d]} · {nm}: {wr}% de vitória em {len(ws)} jogo(s)'>"
                     f"<b>{wr}%</b><small>{len(ws)}</small></i>")
    return (head + rows + "</div><div class='lg'><span><i style='background:rgba(255,122,133,.55)'></i>abaixo de 50%</span>"
            "<span><i style='background:rgba(94,224,192,.55)'></i>acima de 50%</span>"
            f"<span>número pequeno = jogos · apagado = menos de {MIN_CELL} jogos (pode ser só sorte)</span></div>")


def session_bars(sess):
    pos = defaultdict(list)
    for s in sess:
        for i, r in enumerate(s):
            pos[min(i + 1, 5)].append(r["win"])
    out = ""
    for k in range(1, 6):
        ws = pos.get(k, [])
        if not ws:
            continue
        wr = _wr(ws)
        low = " low" if len(ws) < 8 else ""
        label = f"{k}º jogo" if k < 5 else "5º ou mais"
        out += (f"<div class='pb{low}'><span class='pn'>{label}</span><span class='pt2'><i style='width:{wr}%'></i><u></u></span>"
                f"<span class='pv'>{wr}% <small>· {len(ws)} jogo(s)</small></span></div>")
    return out, pos


def weekly(res, weeks=12):
    now = time.time()
    buckets = defaultdict(list)
    for r in res:
        w = int((now - r["started_ms"] / 1000) // (7 * 86400))
        if w < weeks:
            buckets[w].append(r["win"])
    if not buckets:
        return ""
    mx = max(len(v) for v in buckets.values())
    cols = ""
    for w in range(weeks - 1, -1, -1):
        ws = buckets.get(w, [])
        h = 6 if not ws else max(8, 100 * len(ws) / mx)
        wr = _wr(ws)
        tone = "none" if wr is None else "up" if wr >= 50 else "dn"
        tip_ = f"{len(ws)} jogo(s)" + (f" · {wr}% de vitória" if ws else " · sem jogos")
        when = "esta semana" if w == 0 else f"há {w} sem."
        cols += (f"<div class='wk {tone}' title='{when}: {tip_}'><span class='wv'>{wr if wr is not None else ''}{'%' if wr is not None else ''}</span>"
                 f"<i style='height:{h:.0f}%'></i><small>{len(ws) or ''}</small></div>")
    return ("<div class='wks'>" + cols + "</div><div class='lg'><span><i style='background:#6BBF8A'></i>semana com 50% ou mais</span>"
            "<span><i style='background:#E8817C'></i>abaixo de 50%</span><span>altura = jogos na semana</span></div>")


def after_stats(res):
    after_l, after_w, after_2l = [], [], []
    for i in range(1, len(res)):
        prev, cur = res[i - 1], res[i]
        gap = cur["started_ms"] - (prev["started_ms"] + (prev["duration_s"] or 0) * 1000)
        if gap > SESSION_GAP_MIN * 60000:
            continue  # recomecou depois de pausa
        (after_w if prev["win"] else after_l).append(cur["win"])
        if i >= 2 and not prev["win"] and not res[i - 2]["win"]:
            after_2l.append(cur["win"])
    return after_l, after_w, after_2l


def streak_now(res):
    n = 0
    kind = None
    for r in reversed(res):
        if kind is None:
            kind = bool(r["win"])
        if bool(r["win"]) != kind:
            break
        n += 1
    return n, kind


def stat_card(title, big, sub, cls=""):
    return f"<div class='kpi {cls}'><span class='kl'>{e(title)}</span><b class='kv'>{big}</b><span class='n'>{e(sub)}</span></div>"


def build(con, puuid, sample_note):
    res = sorted(habits.all_results(con, puuid, 1000), key=lambda r: r["started_ms"])
    if not res:
        return "<div class='empty'><span class='em'>🕒</span><b>Sem partidas ainda</b><span>Sincronize para ver seus hábitos.</span></div>"
    sess = sessions(res)
    n = len(res)
    wins = sum(1 for r in res if r["win"])
    avg = n / len(sess)
    sn, skind = streak_now(res)
    longest = max(len(s) for s in sess)
    body = ("<div class='kpis'>"
            + stat_card("Partidas analisadas", str(n), f"{round(100 * wins / n)}% de vitória no total")
            + stat_card("Sessões de jogo", str(len(sess)), f"pausa de mais de {SESSION_GAP_MIN} min separa uma sessão da outra")
            + stat_card("Jogos por sessão", f"{avg:.1f}", f"maior sessão: {longest} jogos")
            + stat_card("Sequência atual", f"{sn} {'vitória(s)' if skind else 'derrota(s)'}", "só conta o que já foi sincronizado",
                        "okc" if skind else "badc")
            + "</div>")

    body += "<h2>Em que dia e horário você rende mais</h2><div class='card'>" + heatmap(res) + "</div>"

    bars, pos = session_bars(sess)
    al, aw, a2 = after_stats(res)
    side = "<div class='pgrid'>"
    for title, ws, hint in (("Depois de uma derrota", al, "jogando em seguida"),
                            ("Depois de 2 derrotas", a2, "jogando em seguida"),
                            ("Depois de uma vitória", aw, "jogando em seguida")):
        if ws:
            low = " dim" if len(ws) < 8 else ""
            side += (f"<div class='pcard{low}'><b>{title}</b>{views2.ring(_wr(ws), 76)}"
                     f"<small>{hint} · {len(ws)} jogo(s)</small></div>")
        else:
            side += f"<div class='pcard dim'><b>{title}</b><small>sem jogos nessa situação</small></div>"
    side += "</div>"
    body += ("<div class='grid2'><div><h2>O que muda a cada jogo da sessão</h2><div class='card'>" + bars +
             "<p class='n'>Barras apagadas = menos de 8 jogos. A marca dourada é 50%.</p></div></div>"
             "<div><h2>Jogar logo depois de perder</h2>" + side + "</div></div>")

    wk = weekly(res)
    if wk:
        body += "<h2>Seu ritmo nas últimas 12 semanas</h2><div class='card'>" + wk + "</div>"

    # leituras (cada uma marcada)
    tips = []
    first = pos.get(1, [])
    later = [w for k in (3, 4, 5) for w in pos.get(k, [])]
    if len(first) >= 8 and len(later) >= 8:
        tips.append(tip(DADO, f"No 1º jogo da sessão você ganha {_wr(first)}%; do 3º em diante, {_wr(later)}%.", len(first) + len(later)))
        if _wr(first) - _wr(later) >= 10:
            tips.append(tip(REGRA, "Se rende menos nos jogos seguintes, defina um limite de jogos por sessão (por exemplo, 3) e pare nele.", None))
            tips.append(tip(HIPOTESE, "Pode ser cansaço ou tilt acumulado; com essa amostra também pode ser acaso.", None))
    if len(al) >= 8 and len(aw) >= 8:
        d = _wr(aw) - _wr(al)
        tips.append(tip(DADO, f"Jogando logo depois de uma derrota você ganha {_wr(al)}%; depois de uma vitória, {_wr(aw)}%.", len(al) + len(aw)))
        if d >= 10:
            tips.append(tip(REGRA, "Depois de perder, faça uma pausa curta antes de entrar na fila (a regra das 2 derrotas é o mínimo).", None))
    if not tips:
        tips.append(tip(DADO, "Ainda faltam jogos para tirar uma leitura dos hábitos. Continue sincronizando.", n))
    from .web import tips_html
    body += "<h2>O que isso diz</h2>" + tips_html(tips)

    hist = habits.focus_history(con)
    if hist:
        ms = ""
        for h in hist:
            ok = h["met"]
            ms += (f"<div class='meta {'ok' if ok else 'no'}'><span class='ck'>{'✓' if ok else '✕'}</span>"
                   f"<div><b>{e(h['text'])}</b><small>Resultado: {h['value']:.2f} · {'cumprido' if ok else 'não cumprido'}</small></div></div>")
        body += "<h2>Suas metas por jogo</h2><div class='metas'>" + ms + "</div>"
    return body


CSS = """
.hm{display:grid;grid-template-columns:110px repeat(7,minmax(0,1fr));gap:6px;align-items:stretch}
.hm>b{font:600 11.5px var(--mono);letter-spacing:.1em;text-transform:uppercase;color:var(--gold);text-align:center;align-self:end;padding-bottom:4px}
.hm .hl{display:flex;flex-direction:column;justify-content:center;text-align:left;color:var(--ink);font:600 13px var(--head);letter-spacing:0;text-transform:none;padding:0}
.hm .hl small{color:var(--mute);font:11px var(--mono)}
.hc{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:62px;border-radius:10px;border:1px solid rgba(255,255,255,.06);font-style:normal;transition:transform .18s,box-shadow .18s}
.hc:hover{transform:scale(1.07);box-shadow:0 0 18px rgba(59,158,255,.3);z-index:1}
.hc b{font:700 16px var(--head)}.hc small{font:11px var(--mono);color:#cbd5e6}.hc.dim{opacity:.55}.hc.none{background:rgba(255,255,255,.02);border-style:dashed}
.wks{display:grid;grid-template-columns:repeat(12,1fr);gap:8px;align-items:end;height:180px}
.wk{display:flex;flex-direction:column;justify-content:flex-end;align-items:center;height:100%;gap:4px}
.wk i{display:block;width:100%;border-radius:8px 8px 3px 3px;transition:filter .2s}.wk:hover i{filter:brightness(1.25)}
.wk.up i{background:linear-gradient(0deg,rgba(94,224,192,.35),#6BBF8A)}.wk.dn i{background:linear-gradient(0deg,rgba(255,122,133,.35),#E8817C)}.wk.none i{background:rgba(255,255,255,.06)}
.wk .wv{font:600 11px var(--mono);color:var(--ink)}.wk small{font:11px var(--mono);color:var(--mute)}
.kpi.okc{border-color:rgba(94,224,192,.5)}.kpi.badc{border-color:rgba(255,122,133,.45)}
.card .lg{margin-top:16px}.grid2 .pgrid{grid-template-columns:repeat(auto-fit,minmax(150px,1fr))}.wks{margin-bottom:4px}
@media (max-width:860px){.hm{grid-template-columns:70px repeat(7,1fr)}.hc b{font-size:13px}}
"""
