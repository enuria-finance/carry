"""Sentinela de Controle: so lembrar quando voce realmente esta sem uma.

A Live Client API nao diz se a sua sentinela esta no mapa. O app acompanha o inventario: se a Sentinela de Controle
estava com voce e saiu do inventario, voce a colocou. A partir dai ela conta como ativa por ACTIVE_S segundos e nenhum
lembrete de compra aparece (voz, overlay ou dica de rota). So volta a lembrar depois disso, e nunca com uma no inventario.
"""
import threading

CW = 2055
ACTIVE_S = 480          # 8 min: depois disso e provavel que tenha sido limpa

_LK = threading.Lock()
_ST = {"gt": 0.0, "had": False, "placed_at": None}


def _ids(me):
    return [int(it.get("itemID") or 0) for it in (me or {}).get("items") or []]


def update(me, gt):
    """Chamar a cada leitura da partida (overlay e voz chamam)."""
    gt = float(gt or 0)
    has = CW in _ids(me)
    with _LK:
        if gt + 5 < _ST["gt"]:                     # partida nova
            _ST.update(had=False, placed_at=None)
        _ST["gt"] = gt
        if _ST["had"] and not has:
            _ST["placed_at"] = gt                  # saiu do inventario: foi colocada no mapa
        _ST["had"] = has
    return has


def state(me, gt):
    """'inventario', 'no_mapa' (colocada ha menos de 8 min) ou 'sem'."""
    if update(me, gt):
        return "inventario"
    with _LK:
        p = _ST["placed_at"]
    if p is not None and float(gt or 0) - p < ACTIVE_S:
        return "no_mapa"
    return "sem"


def needs(me, gt):
    """True so quando vale comprar: nenhuma no inventario e nenhuma colocada recentemente."""
    return state(me, gt) == "sem"


def reset():
    with _LK:
        _ST.update(gt=0.0, had=False, placed_at=None)
