"""Meu desempenho: o resumo no estilo League of Graphs / DeepLOL, so com os dados oficiais da Riot.
Elo e PDL real, campeoes (onde voce ganha e onde perde PDL), rotas, padroes (lado, duracao, horario, tilt),
recordes, com quem voce joga e o elo medio dos inimigos."""
import html
import json
import threading
import time
from collections import Counter, defaultdict

from . import db, ranks

e = lambda x: html.escape("" if x is None else str(x))
SOLO = 420
FACTS_V = 2
WEEK = ["seg", "ter", "qua", "qui", "sex", "sáb", "dom"]


# ---------------- fatos extras de cada partida (do JSON bruto guardado) ----------------
def _ensure(con):
    con.execute("CREATE TABLE IF NOT EXISTS my_facts (match_id TEXT PRIMARY KEY, v INTEGER, data TEXT)")
    con.execute("CREATE TABLE IF NOT EXISTS player_rank (puuid TEXT PRIMARY KEY, tier TEXT, division TEXT, lp INTEGER, at_ms INTEGER)")


def _extract(m, puuid):
    info = (m or {}).get("info") or {}
    ps = info.get("participants") or []
    me = next((p for p in ps if p.get("puuid") == puuid), None)
    if not me:
        return {}
    ch = me.get("challenges") or {}
    team = me.get("teamId")
    nm = lambda p: (f"{p.get('riotIdGameName')}#{p.get('riotIdTagline', '')}" if p.get("riotIdGameName") else p.get("summonerName") or "")
    return {
        "dmg": me.get("totalDamageDealtToChampions"), "share": ch.get("teamDamagePercentage"), "solo": ch.get("soloKills"),
        "d2": me.get("doubleKills") or 0, "d3": me.get("tripleKills") or 0, "d4": me.get("quadraKills") or 0, "d5": me.get("pentaKills") or 0,
        "fb": bool(me.get("firstBloodKill") or me.get("firstBloodAssist")), "ff": bool(me.get("gameEndedInSurrender")),
        "early_ff": bool(me.get("gameEndedInEarlySurrender")), "taken": me.get("totalDamageTaken"),
        "mates": [[p.get("puuid"), nm(p), p.get("championName")] for p in ps if p.get("teamId") == team and p.get("puuid") != puuid],
    }


def facts(con, games):
    """{match_id: fatos}. Le o JSON bruto uma vez e guarda o resumo (as proximas aberturas sao instantaneas)."""
    _ensure(con)
    ids = [g["match_id"] for g in games]
    have = {}
    for i in range(0, len(ids), 500):
        chunk = ids[i:i + 500]
        for r in con.execute(f"SELECT match_id, v, data FROM my_facts WHERE match_id IN ({','.join('?' * len(chunk))})", chunk):
            if r[1] == FACTS_V:
                have[r[0]] = json.loads(r[2] or "{}")
    new = 0
    for g in games:
        if g["match_id"] in have:
            continue
        try:
            f = _extract(db.load_raw(con, g["match_id"], "match"), g["puuid"])
        except Exception:
            f = {}
        have[g["match_id"]] = f
        con.execute("INSERT OR REPLACE INTO my_facts VALUES (?,?,?)", (g["match_id"], FACTS_V, json.dumps(f, separators=(",", ":"))))
        new += 1
    if new:
        con.commit()
    return have


# ---------------- elo dos inimigos (league-v4, guardado por 7 dias) ----------------
_BUSY = {"at": 0}


def enemy_rank_backfill(user_db, key, region, puuid, n=10):
    """Em segundo plano: busca o elo de quem jogou contra voce nas ultimas n ranqueadas (no maximo 5 chamadas por partida)."""
    if time.time() - _BUSY["at"] < 600 or not key:
        return
    _BUSY["at"] = time.time()

    def go():
        from . import jobs
        try:
            client = jobs.client_for(key, region)
            con = db.connect(user_db)
            _ensure(con)
            cut = int(time.time() * 1000) - 7 * 86400000
            rows = con.execute(
                """SELECT DISTINCT o.puuid FROM participants p JOIN matches m USING (match_id)
                   JOIN participants o ON o.match_id=p.match_id AND o.team_id<>p.team_id
                   WHERE p.puuid=? AND m.queue_id=? AND COALESCE(m.duration_s,0)>=300
                     AND p.match_id IN (SELECT p2.match_id FROM participants p2 JOIN matches m2 USING (match_id)
                                        WHERE p2.puuid=? AND m2.queue_id=? ORDER BY m2.started_ms DESC LIMIT ?)""",
                (puuid, SOLO, puuid, SOLO, n)).fetchall()
            for (pu,) in rows:
                if not pu or con.execute("SELECT 1 FROM player_rank WHERE puuid=? AND at_ms>?", (pu, cut)).fetchone():
                    continue
                try:
                    solo = next((x for x in client.league_by_puuid(pu) if x.get("queueType") == "RANKED_SOLO_5x5"), None)
                except Exception:
                    continue
                con.execute("INSERT OR REPLACE INTO player_rank VALUES (?,?,?,?,?)",
                            (pu, (solo or {}).get("tier") or "UNRANKED", (solo or {}).get("rank"), (solo or {}).get("leaguePoints"),
                             int(time.time() * 1000)))
                con.commit()
            con.close()
        except Exception:
            pass
    threading.Thread(target=go, daemon=True).start()


def enemy_avg(con, puuid, n=10):
    """(texto do elo medio, quantos inimigos com elo) nas ultimas n ranqueadas solo."""
    _ensure(con)
    rows = con.execute(
        """SELECT r.tier, r.division, r.lp FROM participants p JOIN matches m USING (match_id)
           JOIN participants o ON o.match_id=p.match_id AND o.team_id<>p.team_id
           JOIN player_rank r ON r.puuid=o.puuid
           WHERE p.puuid=? AND m.queue_id=? AND r.tier<>'UNRANKED'
             AND p.match_id IN (SELECT p2.match_id FROM participants p2 JOIN matches m2 USING (match_id)
                                WHERE p2.puuid=? AND m2.queue_id=? ORDER BY m2.started_ms DESC LIMIT ?)""",
        (puuid, SOLO, puuid, SOLO, n)).fetchall()
    vs = [ranks.ladder(r[0], r[1], r[2] or 0) for r in rows]
    vs = [v for v in vs if v is not None]
    if not vs:
        return None, 0
    return ladder_name(sum(vs) / len(vs)), len(vs)


def ladder_name(v):
    v = int(round(v))
    if v >= ranks.APEX:
        return f"Mestre+ ({v - ranks.APEX} PDL)"
    t = ranks.TIERS[min(6, v // 400)]
    d = ["IV", "III", "II", "I"][min(3, (v % 400) // 100)]
    return f"{ranks.TIER_PT[t]} {d}"


# ---------------- PDL real de cada partida (pelo historico guardado depois de cada jogo) ----------------
def lp_by_match(con, solo_games):
    """{match_id: delta} quando ha um ponto de elo antes e outro logo depois da partida com exatamente 1 jogo de diferenca."""
    hist = ranks.history(con)
    if len(hist) < 2:
        return {}
    out = {}
    for g in solo_games:
        end = (g["started_ms"] or 0) + (g["duration_s"] or 0) * 1000
        before = [h for h in hist if h["at_ms"] <= (g["started_ms"] or 0)]
        after = [h for h in hist if h["at_ms"] >= end]
        if not before or not after:
            continue
        b, a = before[-1], after[0]
        if (a.get("wins") or 0) + (a.get("losses") or 0) - (b.get("wins") or 0) - (b.get("losses") or 0) != 1:
            continue
        out[g["match_id"]] = a["v"] - b["v"]
    return out


# ---------------- dados ----------------
def load_games(con, puuid, solo_only=True, since_ms=0):
    rows = con.execute(
        f"""SELECT p.*, m.queue_id, m.duration_s, m.started_ms, m.patch FROM participants p JOIN matches m USING (match_id)
            WHERE p.puuid=? AND COALESCE(m.duration_s,0)>=300 AND m.started_ms>=? {'AND m.queue_id=420' if solo_only else ''}
            ORDER BY m.started_ms DESC""", (puuid, since_ms)).fetchall()
    gs = [dict(r) for r in rows]
    if gs:
        ids = [g["match_id"] for g in gs]
        opp = {}
        for i in range(0, len(ids), 400):
            ch = ids[i:i + 400]
            for r in con.execute(
                    f"""SELECT o.match_id, o.champion FROM participants o JOIN participants p ON p.match_id=o.match_id
                        WHERE p.puuid=? AND o.team_id<>p.team_id AND o.position=p.position AND o.position<>''
                          AND o.match_id IN ({','.join('?' * len(ch))})""", [puuid] + ch):
                opp[r[0]] = r[1]
        for g in gs:
            g["opp"] = opp.get(g["match_id"])
    return gs


def season_start():
    return int(time.mktime((time.localtime().tm_year, 1, 1, 0, 0, 0, 0, 0, -1)) * 1000)


def _wr(gs):
    return round(100 * sum(1 for g in gs if g["win"]) / len(gs)) if gs else None


def _kda(gs):
    k = sum(g["kills"] for g in gs) / len(gs)
    d = sum(g["deaths"] for g in gs) / len(gs)
    a = sum(g["assists"] for g in gs) / len(gs)
    return k, d, a, (k + a) / max(d, 1)


# ---------------- html ----------------
CSS = """
.dz{display:flex;flex-direction:column;gap:16px}
.dz .dz-filt{display:flex;gap:6px;flex-wrap:wrap}.dz .dz-filt a{padding:7px 14px;border-radius:999px;border:1px solid var(--rule);color:#D6CCC0;text-decoration:none;font:600 13px var(--body)}
.dz .dz-filt a.on{background:var(--gold);color:#1a1405;border-color:var(--gold)}
.dz-top{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px}
.dz-k{border:1px solid var(--rule);border-radius:14px;padding:14px 16px;background:var(--panel)}
.dz-k small{display:block;color:var(--mute);font:600 11px var(--head);text-transform:uppercase;letter-spacing:.06em}
.dz-k b{display:block;font:700 24px var(--head);color:#fff;margin:4px 0 2px}.dz-k span{color:#D6CCC0;font-size:13px}
.dz-k .w{color:#8FD4A8}.dz-k .l{color:#E8817C}
.dz-form{display:flex;gap:3px;flex-wrap:wrap;margin-top:8px}.dz-form i{width:14px;height:14px;border-radius:3px;background:#E8817C;display:inline-block}.dz-form i.w{background:#6BBF8A}
.dz-card{border:1px solid var(--rule);border-radius:14px;padding:14px 16px;background:var(--panel);overflow-x:auto}
.dz-card h2{margin:0 0 10px;font:700 18px var(--head);color:#fff}.dz-card h2 small{color:var(--mute);font:500 12px var(--body);margin-left:8px}
.dz-t{width:100%;border-collapse:collapse;font-size:13px;min-width:640px}.dz-t th{text-align:left;color:var(--mute);font:600 11px var(--head);text-transform:uppercase;padding:6px 8px;border-bottom:1px solid var(--rule)}
.dz-t td{padding:7px 8px;border-bottom:1px solid rgba(255,255,255,.04);color:#E8DCCB;vertical-align:middle}
.dz-t td.c{display:flex;align-items:center;gap:8px;font-weight:600;color:#fff}
.dz-bar{display:inline-block;width:70px;height:6px;border-radius:3px;background:#3a2a28;vertical-align:middle;margin-right:6px;overflow:hidden}.dz-bar i{display:block;height:100%;background:#E8817C}
.dz-bar i.g{background:#6BBF8A}
.dz-v{font:700 11px var(--head);padding:3px 8px;border-radius:999px;white-space:nowrap}.dz-v.g{background:rgba(107,191,138,.16);color:#8FD4A8}
.dz-v.r{background:rgba(217,83,79,.15);color:#E8817C}.dz-v.n{background:#2C2120;color:#B9AC9C}
.dz-pos{color:#8FD4A8}.dz-neg{color:#E8817C}
.dz-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:16px}
.dz-rows div{display:grid;grid-template-columns:minmax(0,1fr) 130px;gap:8px;align-items:center;padding:5px 0;font-size:13px;color:#E8DCCB;border-bottom:1px solid rgba(255,255,255,.04)}
.dz-rows div small{color:var(--mute)}
.dz-rec{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px}.dz-rec div{border:1px solid var(--rule);border-radius:12px;padding:10px 12px}
.dz-rec small{color:var(--mute);font-size:12px;display:block}.dz-rec b{font:700 18px var(--head);color:#fff}.dz-rec a{color:#D6CCC0;font-size:12px}
.dz-note{color:var(--mute);font-size:12px;margin:8px 0 0}
.dz-alert{border:1px solid rgba(217,83,79,.45);background:rgba(217,83,79,.08);border-radius:14px;padding:12px 16px;color:#F0E4CC}
.dz-alert b{color:#E8817C}
.dz-chip{font:600 12px var(--body);padding:3px 9px;border-radius:999px;background:#2A1F1E;color:#E8DCCB}.lpb{font:700 12px var(--mono,monospace);margin-left:4px}.lpb.w{color:#8FD4A8}.lpb.l{color:#E8817C}
.dz-rec>div{display:flex;flex-direction:column;gap:4px}.dz-rec b{display:block;margin:2px 0}
"""


def _bar(wr):
    if wr is None:
        return ""
    return f"<span class='dz-bar'><i class='{'g' if wr >= 50 else ''}' style='width:{wr}%'></i></span>{wr}%"


def _rows(title, buckets, note=""):
    body = ""
    for label, gs in buckets:
        if not gs:
            continue
        wr = _wr(gs)
        body += f"<div><span>{e(label)} <small>· {len(gs)}</small></span><span>{_bar(wr)}</span></div>"
    if not body:
        return ""
    return f"<div class='dz-card'><h2>{e(title)}</h2><div class='dz-rows'>{body}</div>" + (f"<p class='dz-note'>{e(note)}</p>" if note else "") + "</div>"


def page_html(con, puuid, link, champ_icon, mode="solo", enemy=None):
    solo_only = mode != "todas"
    since = season_start() if mode in ("solo", "") else 0
    gs = load_games(con, puuid, solo_only=solo_only, since_ms=since)
    if mode == "solo" and len(gs) < 5:      # comeco de temporada: usa todas as ranqueadas guardadas
        gs = load_games(con, puuid, solo_only=True)
    filt = ("<div class='dz-filt'>" + "".join(
        f"<a href='/desempenho?modo={k}' class='{'on' if (mode or 'solo') == k else ''}'>{t}</a>"
        for k, t in (("solo", f"Ranqueada solo {time.localtime().tm_year}"), ("tudo", "Ranqueada solo (tudo)"), ("todas", "Todas as filas"))) + "</div>")
    if not gs:
        return (CSS_TAG + "<div class='dz'>" + filt + "<div class='empty'><b>Sem partidas ainda</b>"
                "<span>Sincronize as suas partidas para ver o resumo.</span></div></div>")
    link = dict(link) if link else {}
    fx = facts(con, gs)
    from . import pages4
    lp_all = pages4.lp_per_game(con, puuid)
    lp = {k: v[0] for k, v in lp_all.items()}

    # topo
    w = sum(1 for g in gs if g["win"])
    tier = link.get("tier")
    rank_txt = "Sem elo"
    rank_sub = ""
    if link and tier and tier != "UNRANKED":
        rank_txt = f"{ranks.TIER_PT.get(tier, tier)} {link.get('division') or ''} · {link.get('lp') or 0} PDL"
        lw, ll = link.get("wins"), link.get("losses")
        if lw is not None and ll is not None and lw + ll:
            rank_sub = f"<span class='w'>{lw}V</span> <span class='l'>{ll}D</span> · {round(100 * lw / (lw + ll))}% na temporada"
    hist = ranks.history(con)
    d14 = ranks.delta_days(hist, 14)
    streak, s_kind = 0, None
    for g in gs:
        if s_kind is None:
            s_kind = g["win"]
        if g["win"] != s_kind:
            break
        streak += 1
    form = "".join(f"<i class='{'w' if g['win'] else ''}' title=\"{e(g['champion'])} {'vitória' if g['win'] else 'derrota'}\"></i>" for g in reversed(gs[:20]))
    en_txt, en_n = enemy if enemy else (None, 0)
    top = (f"<div class='dz-top'>"
           f"<div class='dz-k'><small>Elo atual</small><b>{e(rank_txt)}</b><span>{rank_sub}</span></div>"
           f"<div class='dz-k'><small>Nestas {len(gs)} partidas</small><b>{round(100 * w / len(gs))}%</b><span><span class='w'>{w}V</span> <span class='l'>{len(gs) - w}D</span>"
           + (f" · PDL 14 dias: <span class='{'w' if d14 >= 0 else 'l'}'>{d14:+d}</span>" if d14 is not None else "") + "</span></div>"
           f"<div class='dz-k'><small>Forma recente (20)</small><b class='{'w' if s_kind else 'l'}'>{streak} {'vitória' if s_kind else 'derrota'}{'s' if streak != 1 else ''} seguida{'s' if streak != 1 else ''}</b>"
           f"<div class='dz-form'>{form}</div></div>"
           f"<div class='dz-k'><small>Elo médio dos inimigos (últimas 10)</small><b>{e(en_txt or 'buscando…')}</b>"
           f"<span>{f'{en_n} inimigos com elo' if en_txt else 'o app busca na Riot em segundo plano; recarregue em 1 minuto'}</span></div></div>")

    # alerta: onde voce perde PDL
    by_c = defaultdict(list)
    for g in gs:
        by_c[g["champion"]].append(g)
    losers = [(c, l) for c, l in by_c.items() if len(l) >= 6 and _wr(l) < 48]
    alert = ""
    if losers:
        lost = sum((sum(1 for g in l if not g["win"]) - sum(1 for g in l if g["win"])) for _, l in losers)
        alert = (f"<div class='dz-alert'><b>Onde o PDL vai embora:</b> "
                 + ", ".join(f"{e(c)} ({_wr(l)}% em {len(l)})" for c, l in sorted(losers, key=lambda x: _wr(x[1]))[:4])
                 + (f". Juntos: {lost} derrotas a mais que vitórias, uns {lost * 20} PDL." if lost > 0 else ".")
                 + "</div>")

    # campeoes
    rows = ""
    for c, l in sorted(by_c.items(), key=lambda x: -len(x[1]))[:25]:
        wr = _wr(l)
        k, d, a, ratio = _kda(l)
        dur = sum((g["duration_s"] or 1) for g in l) / 60
        csm = sum(g["cs"] for g in l) / max(dur, 1)
        dmgs = [fx.get(g["match_id"], {}).get("dmg") for g in l]
        dmgs = [x for x in dmgs if x]
        dpm = (sum(dmgs) / max(sum((g["duration_s"] or 1) for g in l if fx.get(g["match_id"], {}).get("dmg")) / 60, 1)) if dmgs else None
        known = [lp_all[g["match_id"]] for g in l if g["match_id"] in lp_all]
        if known:
            pdl = sum(v for v, _ in known)
            est = "" if all(r for _, r in known) else "~"
        else:
            pdl, est = (sum(1 for g in l if g["win"]) * 2 - len(l)) * 20, "~"
        if len(l) < 6:
            v = "<span class='dz-v n'>pouca amostra</span>"
        elif wr >= 55:
            v = "<span class='dz-v g'>seu campeão</span>"
        elif wr < 48:
            v = "<span class='dz-v r'>perde PDL</span>"
        else:
            v = "<span class='dz-v n'>na média</span>"
        rows += (f"<tr><td class='c'>{champ_icon(c, 28)}{e(c)}</td><td>{len(l)}</td><td>{_bar(wr)}</td>"
                 f"<td>{k:.1f} / <span class='dz-neg'>{d:.1f}</span> / {a:.1f} <small>({ratio:.2f})</small></td><td>{csm:.1f}</td>"
                 f"<td>{f'{dpm:.0f}' if dpm else '-'}</td><td class='{'dz-pos' if pdl >= 0 else 'dz-neg'}'>{est}{pdl:+d}</td><td>{v}</td></tr>")
    champs = (f"<div class='dz-card'><h2>Campeões<small>PDL com ~ é estimado (±20 por jogo); sem ~ é o PDL real guardado depois de cada partida</small></h2>"
              f"<table class='dz-t'><thead><tr><th>Campeão</th><th>Jogos</th><th>Vitórias</th><th>KDA</th><th>CS/min</th><th>Dano/min</th><th>PDL</th><th></th></tr></thead>"
              f"<tbody>{rows}</tbody></table></div>")

    # pdl
    from . import authview
    seq30, _ = pages4.pdl_seq(con, puuid, hist, time.time() * 1000 - 30 * 86400000)
    if len(seq30) < 2:
        seq30 = pages4.pdl_seq(con, puuid, hist)[0][-25:]
    chart = pages4.pdl_svg(seq30, hist, authview.TIER_COLOR, CH=240, bars=False, zoom=False, emblems=False) if len(seq30) >= 2 else ranks.chart(hist, authview.TIER_COLOR)
    last = [g for g in gs if g["match_id"] in lp_all and g.get("queue_id") == SOLO][:12]
    lst = "".join(f"<span class='dz-chip'>{e(g['champion'])} {pages4.lp_badge(lp_all[g['match_id']])}</span>" for g in last)
    pdl_card = (f"<div class='dz-card'><h2>PDL nos últimos 30 dias<small><a href='/pdl' style='color:var(--gold)'>ver o gráfico completo, com zoom</a></small></h2>{chart}"
                + (f"<p class='dz-note'>Últimas partidas (~ = estimado):</p><div class='dz-form' style='gap:6px'>{lst}</div>" if lst else "") + "</div>")

    # rotas e padroes
    POS = {"TOP": "Topo", "JUNGLE": "Selva", "MIDDLE": "Meio", "BOTTOM": "Atirador", "UTILITY": "Suporte"}
    by_p = defaultdict(list)
    for g in gs:
        by_p[POS.get(g["position"] or "", "Outra")].append(g)
    roles = _rows("Rotas", sorted(by_p.items(), key=lambda x: -len(x[1])))
    side = _rows("Lado do mapa", [("Azul (embaixo)", [g for g in gs if g["team_id"] == 100]), ("Vermelho (em cima)", [g for g in gs if g["team_id"] == 200])])
    dur = _rows("Duração da partida", [("Até 25 min", [g for g in gs if (g["duration_s"] or 0) < 1500]),
                                       ("25 a 30 min", [g for g in gs if 1500 <= (g["duration_s"] or 0) < 1800]),
                                       ("30 a 35 min", [g for g in gs if 1800 <= (g["duration_s"] or 0) < 2100]),
                                       ("Mais de 35 min", [g for g in gs if (g["duration_s"] or 0) >= 2100])],
                "Se você ganha mais nas curtas, jogue para fechar cedo; se ganha nas longas, segure o começo e escale.")
    hr = lambda g: time.localtime(g["started_ms"] / 1000).tm_hour
    hours = _rows("Horário", [("Manhã (6h–12h)", [g for g in gs if 6 <= hr(g) < 12]), ("Tarde (12h–18h)", [g for g in gs if 12 <= hr(g) < 18]),
                              ("Noite (18h–0h)", [g for g in gs if hr(g) >= 18]), ("Madrugada (0h–6h)", [g for g in gs if hr(g) < 6])])
    days = defaultdict(list)
    for g in gs:
        days[WEEK[time.localtime(g["started_ms"] / 1000).tm_wday]].append(g)
    week = _rows("Dia da semana", [(d, days[d]) for d in WEEK])
    # sessao: posicao no dia e depois de derrota
    chron = list(reversed(gs))
    after_l, after_w, after_2l, nth = [], [], [], defaultdict(list)
    for i, g in enumerate(chron):
        day = time.strftime("%Y%m%d", time.localtime(g["started_ms"] / 1000))
        prev = [p for p in chron[max(0, i - 3):i] if time.strftime("%Y%m%d", time.localtime(p["started_ms"] / 1000)) == day
                and g["started_ms"] - p["started_ms"] < 4 * 3600000]
        k = sum(1 for p in chron[:i] if time.strftime("%Y%m%d", time.localtime(p["started_ms"] / 1000)) == day)
        nth["1ª do dia" if k == 0 else "2ª e 3ª" if k <= 2 else "4ª em diante"].append(g)
        if prev:
            (after_w if prev[-1]["win"] else after_l).append(g)
            if len(prev) >= 2 and not prev[-1]["win"] and not prev[-2]["win"]:
                after_2l.append(g)
    tilt = _rows("Sessão e tilt", [("1ª partida do dia", nth["1ª do dia"]), ("2ª e 3ª do dia", nth["2ª e 3ª"]), ("4ª em diante", nth["4ª em diante"]),
                                    ("Logo depois de uma vitória", after_w), ("Logo depois de uma derrota", after_l), ("Depois de 2 derrotas seguidas", after_2l)],
                 "Se a linha 'depois de 2 derrotas' estiver bem abaixo, a regra é simples: perdeu 2, para.")
    ff = [g for g in gs if fx.get(g["match_id"], {}).get("ff")]
    fb = [g for g in gs if fx.get(g["match_id"], {}).get("fb")]
    extra = _rows("Momentos", [("Participou do primeiro abate", fb), ("Sem primeiro abate", [g for g in gs if g["match_id"] in fx and fx[g["match_id"]] and g not in fb]),
                               ("Partidas que acabaram em rendição", ff)])

    # oponentes de rota
    by_o = defaultdict(list)
    for g in gs:
        if g.get("opp"):
            by_o[g["opp"]].append(g)
    opp_ok = [(o, l) for o, l in by_o.items() if len(l) >= 3]
    worst = sorted(opp_ok, key=lambda x: (_wr(x[1]), -len(x[1])))[:6]
    best = sorted(opp_ok, key=lambda x: (-_wr(x[1]), -len(x[1])))[:6]
    vs = ""
    if opp_ok:
        vs = ("<div class='dz-card'><h2>Contra quem na rota<small>3 jogos ou mais</small></h2><div class='dz-grid'>"
              + "<div class='dz-rows'><b class='dz-neg'>Mais sofre</b>" + "".join(f"<div><span>{champ_icon(o, 22)} {e(o)} <small>· {len(l)}</small></span><span>{_bar(_wr(l))}</span></div>" for o, l in worst) + "</div>"
              + "<div class='dz-rows'><b class='dz-pos'>Mais ganha</b>" + "".join(f"<div><span>{champ_icon(o, 22)} {e(o)} <small>· {len(l)}</small></span><span>{_bar(_wr(l))}</span></div>" for o, l in best) + "</div>"
              + "</div></div>")

    # com quem voce joga
    mates = defaultdict(list)
    names = {}
    for g in gs:
        for pu, nm, _c in fx.get(g["match_id"], {}).get("mates") or []:
            if pu:
                mates[pu].append(g)
                names[pu] = nm or names.get(pu) or "?"
    duo = [(names[p], l) for p, l in mates.items() if len(l) >= 3]
    duo_html = ""
    if duo:
        duo_html = ("<div class='dz-card'><h2>Com quem você joga<small>3 partidas juntos ou mais</small></h2><div class='dz-rows'>"
                    + "".join(f"<div><span>{e(n)} <small>· {len(l)}</small></span><span>{_bar(_wr(l))}</span></div>"
                              for n, l in sorted(duo, key=lambda x: -len(x[1]))[:10]) + "</div></div>")

    # recordes
    def rec(label, key, fmt, src=None):
        cand = [(key(g), g) for g in gs]
        cand = [(v, g) for v, g in cand if v is not None]
        if not cand:
            return ""
        v, g = max(cand, key=lambda x: x[0])
        return (f"<div><small>{e(label)}</small><b>{fmt(v)}</b><a href='/partida/{e(g['match_id'])}'>{e(g['champion'])} · "
                f"{time.strftime('%d/%m/%y', time.localtime(g['started_ms'] / 1000))}</a></div>")
    multi = Counter()
    for g in gs:
        f = fx.get(g["match_id"]) or {}
        for k_ in ("d3", "d4", "d5"):
            multi[k_] += f.get(k_) or 0
    best_streak, cur = 0, 0
    for g in chron:
        cur = cur + 1 if g["win"] else 0
        best_streak = max(best_streak, cur)
    recs = "".join([
        rec("Mais abates", lambda g: g["kills"], lambda v: f"{v}"),
        rec("Melhor KDA", lambda g: (g["kills"] + g["assists"]) / max(g["deaths"], 1), lambda v: f"{v:.1f}"),
        rec("Mais farm", lambda g: g["cs"], lambda v: f"{v} CS"),
        rec("Mais dano", lambda g: (fx.get(g["match_id"]) or {}).get("dmg"), lambda v: f"{v:,}".replace(",", ".")),
        rec("Mais abates solo", lambda g: (fx.get(g["match_id"]) or {}).get("solo"), lambda v: f"{v}"),
        rec("Mais visão", lambda g: g["vision_score"], lambda v: f"{v}"),
        rec("Partida mais longa", lambda g: g["duration_s"], lambda v: f"{v // 60}:{v % 60:02d}"),
    ]) + (f"<div><small>Maior sequência de vitórias</small><b>{best_streak}</b></div>"
          f"<div><small>Multi-abates</small><b>{multi['d5']} penta</b><a>{multi['d4']} quadra · {multi['d3']} triplo</a></div>")
    rec_html = f"<div class='dz-card'><h2>Recordes</h2><div class='dz-rec'>{recs}</div></div>"

    return (CSS_TAG + "<div class='dz'>" + filt + top + alert + champs
            + pdl_card
            + "<div class='dz-grid'>" + roles + side + dur + hours + week + tilt + extra + "</div>"
            + vs + duo_html + rec_html
            + pages4.PDL_JS + "<p class='dz-note'>Tudo calculado com as suas partidas guardadas pelo app (API oficial da Riot). Ranking global e temporadas antigas não vêm da API.</p></div>")


CSS_TAG = f"<style>{CSS}</style>"
