"""Habitos: foco por jogo, regra das 2 derrotas e rendimento por horario.

Tudo vem das partidas ja sincronizadas. Se voce jogou e nao sincronizou, o app
nao sabe: rode o sync antes de confiar na regra das 2 derrotas.
"""
import statistics
import time

from . import db, report
from .tags import DADO, REGRA, HIPOTESE, tip

PAUSE_MIN = 15
METRIC_LABEL = {"deaths_before_10": "mortes antes dos 10 min",
                "vision_per_min": "visão por minuto",
                "csdiff10": "diferença de CS aos 10 min"}


def all_results(con, puuid, limit=20):
    rows = con.execute(
        """SELECT m.match_id, m.started_ms, m.duration_s, p.win, p.champion FROM participants p
           JOIN matches m USING (match_id) JOIN match_source s USING (match_id)
           WHERE p.puuid=? AND s.source='me' AND COALESCE(m.duration_s,0) >= 300
           ORDER BY m.started_ms DESC LIMIT ?""", (puuid, limit)).fetchall()
    return [dict(r) for r in rows]


def two_loss_rule(con, puuid, now_ms=None):
    """Depois de 2 derrotas seguidas o app pede pausa de 15 min."""
    now_ms = now_ms or int(time.time() * 1000)
    res = all_results(con, puuid, 10)
    streak = 0
    for r in res:
        if r["win"]:
            break
        streak += 1
    if not res:
        return {"streak": 0, "pause": False,
                "tips": [tip(DADO, "Nenhuma partida sincronizada ainda.")]}
    end_ms = res[0]["started_ms"] + (res[0]["duration_s"] or 0) * 1000
    left = PAUSE_MIN * 60000 - (now_ms - end_ms)
    pause = streak >= 2 and left > 0
    tips = [tip(DADO, f"Sequência atual: {streak} derrota(s) seguida(s) nas últimas {len(res)} partidas.", len(res))]
    if pause:
        tips.append(tip(REGRA, f"Regra das 2 derrotas: pause até completar {PAUSE_MIN} minutos "
                               f"(faltam cerca de {int(left // 60000) + 1} min)."))
    elif streak >= 2:
        tips.append(tip(REGRA, "Você está com 2 ou mais derrotas seguidas: a pausa de 15 min já passou; "
                               "só volte se estiver bem."))
    tips.append(tip(HIPOTESE, "O app só vê partidas sincronizadas; se jogou depois do último sync, a contagem pode estar errada."))
    return {"streak": streak, "pause": pause, "tips": tips}


def by_period(con, puuid):
    """Winrate por periodo do dia (horario do seu PC)."""
    res = all_results(con, puuid, 1000)
    buckets = {"madrugada (0h-5h)": [], "manha (6h-11h)": [], "tarde (12h-17h)": [], "noite (18h-23h)": []}
    for r in res:
        h = time.localtime(r["started_ms"] / 1000).tm_hour
        key = list(buckets)[0 if h < 6 else 1 if h < 12 else 2 if h < 18 else 3]
        buckets[key].append(r["win"])
    out = []
    for name, wins in buckets.items():
        if wins:
            out.append({"period": name, "n": len(wins), "wins": sum(wins),
                        "wr": 100.0 * sum(wins) / len(wins)})
    return out


# ---- foco -----------------------------------------------------------------
def suggest_focus(games):
    """Escolhe UMA meta para o proximo jogo, pelo seu padrao. E uma escolha do app."""
    s = report.summary(games)
    d10, n10 = s["deaths_before_10"]
    if n10 and d10 is not None and d10 > 0.6:
        return {"text": "No máximo 1 morte antes dos 10 min", "metric": "deaths_before_10", "op": "<=",
                "target": 1.0, "why": tip(DADO, f"Sua média é {d10:.2f} mortes antes dos 10 min.", n10)}
    v, nv = s["vision_per_min"]
    if nv and v is not None and v < 0.9:
        return {"text": "Visão de 0,9 por minuto ou mais", "metric": "vision_per_min", "op": ">=",
                "target": 0.9, "why": tip(DADO, f"Sua média é {v:.2f} de visão por minuto (meta 0,9 é sugestão do plano, não oficial).", nv)}
    c, nc = s["csdiff10"]
    if nc and c is not None and c < 0:
        return {"text": "CS aos 10 min igual ou melhor que o oponente", "metric": "csdiff10", "op": ">=",
                "target": 0.0, "why": tip(DADO, f"Sua diferença média de CS aos 10 é {c:+.1f}.", nc)}
    return None


def set_focus(con, text, metric, op, target):
    con.execute("INSERT INTO focus (created_ms, text, metric, op, target) VALUES (?,?,?,?,?)",
                (db.now_ms(), text, metric, op, target))
    con.commit()


def current_focus(con):
    r = con.execute("SELECT * FROM focus WHERE match_id IS NULL ORDER BY id DESC LIMIT 1").fetchone()
    return dict(r) if r else None


def last_focus_result(con):
    r = con.execute("SELECT * FROM focus WHERE match_id IS NOT NULL ORDER BY id DESC LIMIT 1").fetchone()
    return dict(r) if r else None


def evaluate_focus(con, puuid):
    """Cobra a meta no primeiro jogo sincronizado depois dela, sem julgamento."""
    f = current_focus(con)
    if not f:
        return None
    games = sorted(report.my_games(con, puuid, ""), key=lambda g: g["started_ms"] or 0)
    for g in games:
        if (g["started_ms"] or 0) <= f["created_ms"]:
            continue
        v = g.get(f["metric"])
        if v is None:
            continue
        met = (v <= f["target"]) if f["op"] == "<=" else (v >= f["target"])
        con.execute("UPDATE focus SET match_id=?, value=?, met=? WHERE id=?",
                    (g["match_id"], float(v), 1 if met else 0, f["id"]))
        con.commit()
        return {**f, "match_id": g["match_id"], "value": v, "met": met}
    return None


def focus_history(con, limit=10):
    return [dict(r) for r in con.execute(
        "SELECT * FROM focus WHERE match_id IS NOT NULL ORDER BY id DESC LIMIT ?", (limit,))]
