"""Pagina completa de campeao, em abas: Guia (habilidades, combos, build, ordem, plano de jogo, especialistas),
Jogar contra (counters, janelas e dicas) e Seus numeros (voce com ele e contra ele)."""
import html

from . import builds, champview, icons
from .ddragon import clean
from .polish import tip_attr

e = lambda x: html.escape("" if x is None else str(x))
KEYS = ["Q", "W", "E", "R"]
TAG_PT = champview.TAG_PT
ROLE_PT = champview.ROLE_PT


def _ab_img(ver, folder, file_, size=44, cls="abi"):
    if not ver or not file_:
        return f"<span class='{cls} ph' style='width:{size}px;height:{size}px'></span>"
    return f"<img class='{cls}' src='{icons.CDN}/cdn/{e(ver)}/img/{folder}/{e(file_)}' width='{size}' height='{size}' alt='' loading='lazy'>"


def key_icon(k, data, ver, size=40):
    """Icone de uma tecla do combo: habilidade (Q/W/E/R) com a letra, ou um chip de texto (AA, Flash, item)."""
    ku = (k or "").strip().upper()
    if ku in KEYS:
        sp = (data.get("spells") or [{}] * 4)[KEYS.index(ku)]
        return (f"<span class='ck'{tip_attr(sp.get('name', ku), ('Recarga ' + sp['cooldownBurn'] + 's') if sp.get('cooldownBurn') else '', clean(sp.get('description'))[:300])}>{_ab_img(ver, 'spell', (sp.get('image') or {}).get('full'), size)}<b>{ku}</b>"
                f"<em>{e(sp.get('name', ''))}</em></span>")
    label = {"AA": "Ataque", "FLASH": "Flash", "INCENDIAR": "Incendiar", "IGNITE": "Incendiar"}.get(ku, k)
    return f"<span class='ck txt'><span class='cktxt'>{e(label)}</span></span>"


def abilities(data, ver):
    out = ""
    pas = data.get("passive") or {}
    if pas:
        out += (f"<div class='ab2'><div class='ab2-h'>{_ab_img(ver, 'passive', (pas.get('image') or {}).get('full'), 52)}<span class='abk2'>Passiva</span>"
                f"<b>{e(pas.get('name'))}</b></div><p>{e(clean(pas.get('description')))}</p></div>")
    res = data.get("partype") or ""
    for k, sp in zip(KEYS, data.get("spells") or []):
        cost = clean((sp.get("costBurn") or "")).strip()
        ctype = clean(sp.get("costType") or "").replace("{{ abilityresourcename }}", res).strip() or res
        meta = []
        if sp.get("cooldownBurn"):
            meta.append(f"<span><small>Recarga</small>{e(sp['cooldownBurn'])}s</span>")
        if cost and cost != "0":
            meta.append(f"<span><small>Custo</small>{e(cost)} {e(ctype)}</span>")
        if sp.get("rangeBurn") and sp["rangeBurn"] not in ("25000", "0"):
            meta.append(f"<span><small>Alcance</small>{e(sp['rangeBurn'])}</span>")
        out += (f"<div class='ab2'><div class='ab2-h'>{_ab_img(ver, 'spell', (sp.get('image') or {}).get('full'), 52)}<span class='abk2'>{k}</span>"
                f"<b>{e(sp.get('name'))}</b></div><div class='ab2-m'>{''.join(meta)}</div><p>{e(clean(sp.get('description')))}</p></div>")
    return f"<div class='ab2s'>{out}</div>"


def skill_grid(sk, data, ver):
    if not sk or not sk.get("seq"):
        return ""
    seq = sk["seq"]
    rows = ""
    for slot, k in zip((1, 2, 3, 4), KEYS):
        sp = (data.get("spells") or [{}] * 4)[slot - 1]
        cells = "".join(f"<i class='{'on' if i < len(seq) and seq[i] == slot else ''}'>{i + 1 if i < len(seq) and seq[i] == slot else ''}</i>"
                        for i in range(18))
        rows += f"<div class='sgr'>{_ab_img(ver, 'spell', (sp.get('image') or {}).get('full'), 30)}<b>{k}</b><div class='sgc'>{cells}</div></div>"
    mx = " › ".join(KEYS[s - 1] for s in sk["max"])
    return (f"<div class='card'><b class='gl'>Ordem de habilidades</b><p class='n'>Maximizar: <b class='gold'>{e(mx)}</b> · "
            f"<span class='tag dado'>dado</span> {sk['n']} partidas dos melhores.</p><div class='sgrid'>{rows}</div></div>")


def _items_row(ids, items, ver, title, n=None, w=None):
    if not ids:
        return ""
    cells = ""
    for i in ids:
        it = items.get(str(i)) or {}
        img = (f"<img src='{icons.CDN}/cdn/{e(ver)}/img/item/{int(i)}.png' width='46' height='46' alt='' loading='lazy'>" if ver else "<span class='abi ph'></span>")
        cost = (it.get("gold") or {}).get("total")
        cells += (f"<div class='itc'{tip_attr(it.get('name', str(i)), f'{cost} de ouro' if cost else '', clean(it.get('description') or it.get('plaintext') or '')[:420])}>{img}<small>{e(it.get('name', i))}</small>"
                  + (f"<em>{cost}</em>" if cost else "") + "</div>")
    stat = f"<span class='n'>{round(100 * w / n)}% vitória · {n} jogos</span>" if n else ""
    return f"<div class='itrow'><div class='itr-h'><b>{e(title)}</b>{stat}</div><div class='itcs'>{cells}</div></div>"


def build_block(con, rows, dd, champion=None, position=None):
    if not rows:
        return None
    try:
        ver, info, items, spells = dd.version(), dd.rune_info(), dd.items(), dd.spells()
    except Exception:
        ver, info, items, spells = None, {}, {}, {}
    st = builds.item_stats(con, rows, items)
    runes = builds.rune_stats(rows)
    sp = builds.spell_stats(rows)
    left = "<div class='card'><b class='gl'>Itens</b>"
    if champion and position:
        cb = builds.clean_build(st, items, champion, position)
    else:
        cb = {"order": builds.full_build(st), "boots": st["boots"][0][0] if st["boots"] else None,
              "extra": [i for i, _ in st["finals"]], "start": list(st["starts"][0][0]) if st["starts"] else []}
    if cb["start"]:
        left += _items_row(cb["start"], items, ver, "Inicial", None)
    order = cb["order"]
    left += _items_row(order, items, ver, "Itens principais (na ordem)")
    if cb["boots"]:
        left += _items_row([cb["boots"]], items, ver, "Botas")
    extra = [i for i in cb["extra"] if i not in order][:6]
    left += _items_row(extra, items, ver, "Situacionais")
    if st.get("first_item_min"):
        left += f"<p class='n'>Primeiro item completo, em média, aos <b>{st['first_item_min']:.1f} min</b>.</p>"
    left += f"<p class='n'><span class='tag dado'>dado</span> {len(rows)} partidas dos melhores do servidor.</p></div>"
    right = "<div class='card'><b class='gl'>Runas</b>"
    if runes:
        (prim, sub, sel), n, w = runes[0]

        def rr(i, big=False):
            d = info.get(i) or {"name": str(i)}
            img = f"<img src='{icons.CDN}/cdn/img/{e(d['icon'])}' width='{44 if big else 34}' height='{44 if big else 34}' alt=''>" if d.get("icon") else ""
            return f"<div class='rn{' big' if big else ''}'{tip_attr(d['name'], '', d.get('desc') or '')}>{img}<div><b>{e(d['name'])}</b><small>{e(d.get('desc') or '')}</small></div></div>"
        right += (f"<p class='rtree'>{e((info.get(prim) or {}).get('name', ''))}</p>" + "".join(rr(i, k == 0) for k, i in enumerate(sel[:4]))
                  + f"<p class='rtree'>{e((info.get(sub) or {}).get('name', ''))}</p>" + "".join(rr(i) for i in sel[4:6])
                  + f"<p class='n'><span class='tag dado'>dado</span> {round(100 * w / n)}% de vitória · {n} jogos com esta página</p>")
    if sp:
        pair, n, w = sp[0]
        sps = "".join(f"<div class='itc'>{('<img src=' + chr(39) + icons.CDN + '/cdn/' + e(ver) + '/img/spell/' + e((spells.get(s) or {}).get('id', '')) + '.png' + chr(39) + ' width=40 height=40 alt=' + chr(39) + chr(39) + '>') if ver else ''}"
                      f"<small>{e((spells.get(s) or {}).get('name', s))}</small></div>" for s in pair)
        right += f"<b class='gl' style='display:block;margin-top:14px'>Feitiços</b><div class='itcs'>{sps}</div><p class='n'>{round(100 * w / n)}% de vitória · {n} jogos</p>"
    right += "</div>"
    return f"<div class='grid2 bb'>{left}{right}</div>"


def rich(text, data, ver):
    """Texto da IA com [Q]/[W]/[E]/[R]/[P] trocados pelo icone da habilidade (com o nome ao passar o mouse)."""
    import re as _re
    out = e(text or "")

    def rep(m):
        k = m.group(1).upper()
        if k == "P":
            p = data.get("passive") or {}
            return f"<span class='ii' title='{e(p.get('name', 'Passiva'))}'>{_ab_img(ver, 'passive', (p.get('image') or {}).get('full'), 22, 'iimg')}<b>P</b></span>"
        sp = (data.get("spells") or [{}] * 4)[KEYS.index(k)]
        return f"<span class='ii'{tip_attr(sp.get('name', k), k, clean(sp.get('description'))[:260])}>{_ab_img(ver, 'spell', (sp.get('image') or {}).get('full'), 22, 'iimg')}<b>{k}</b></span>"
    return _re.sub(r"\[([PQWER])\]", rep, out)


def timeline(phases, data, ver, current=0):
    """Cronograma Inicio/Meio/Fim: clique (ou arraste) para trocar a fase; cada fase mostra 3 dicas com icones."""
    labels = [("Início", "0 – 14 minutos"), ("Meio", "14 – 28 minutos"), ("Fim", "28 minutos +")]
    dots = "".join(f"<button type='button' class='tl-dot{' on' if i == current else ''}' data-i='{i}'><i></i><b>{a}</b><small>{b}</small></button>"
                   for i, (a, b) in enumerate(labels))
    panes = ""
    for i, tips in enumerate(phases):
        cards = "".join(f"<div class='tl-c'>{rich(t, data, ver)}</div>" for t in (tips or [])[:3])
        panes += f"<div class='tl-p' data-i='{i}'{'' if i == current else ' hidden'}>{cards}</div>"

    return (f"<div class='tline card' data-cur='{current}'><div class='tl-h'><b class='gl'>Dicas de jogo no Summoner's Rift</b><small class='n'>clique ou arraste para mudar de fase</small></div>"
            f"<div class='tl-track'><span class='tl-line'></span><span class='tl-fill'></span><div class='tl-dots'>{dots}</div></div>{panes}</div>")


def guide_sections(g, data, ver):
    if not g:
        return {}, ""
    lst = lambda xs: "".join(f"<li>{rich(x, data, ver)}</li>" for x in (xs or []))
    combos = ""
    for c in g.get("combos") or []:
        seq = "<span class='ca'>›</span>".join(key_icon(k, data, ver) for k in (c.get("sequencia") or []))
        combos += (f"<div class='combo'><div class='cb-h'><b>{e(c.get('nome'))}</b><span class='badge'>{e(c.get('dificuldade', ''))}</span></div>"
                   f"<div class='cb-s'>{seq}</div><p>{rich(c.get('quando'), data, ver)}</p></div>")
    picos = "".join(f"<div class='pico'><b>{e(p.get('quando'))}</b><span>{rich(p.get('porque'), data, ver)}</span></div>" for p in g.get("picos") or [])
    guide = {
        "ai": ("<div class='aiban'><span class='tag hipotese'>guia por IA</span>Escrito pela IA a partir das habilidades e dicas oficiais. "
               "É conhecimento geral do jogo, não estatística: confira na prática.</div>"),
        "ident": (f"<div class='ident'><p class='id-t'>{rich(g.get('identidade'), data, ver)}</p><div class='grid2'><div><b class='gl'>Pontos fortes</b><ul class='tipl good'>{lst(g.get('pontos_fortes'))}</ul></div>"
                  f"<div><b class='gl'>Pontos fracos</b><ul class='tipl bad'>{lst(g.get('pontos_fracos'))}</ul></div></div></div>"),
        "combos": f"<div class='combos'>{combos}</div>" if combos else "",
        "picos": f"<div class='picos'>{picos}</div>" if picos else "",
        "plano": timeline([g.get("rotas"), g.get("meio"), g.get("fim")], data, ver),
        "erros": f"<ul class='tipl'>{lst(g.get('erros_comuns'))}</ul>" if g.get("erros_comuns") else "",
    }
    num = "".join(f"<li><span>{i}</span><div>{rich(x, data, ver)}</div></li>" for i, x in enumerate(g.get("contra") or [], 1))
    weak = "".join(f"<li>{rich(x, data, ver)}</li>" for x in (g.get("janelas_contra") or []) + (g.get("pontos_fracos") or []))
    against = (f"<h2>Como jogar contra {e(data.get('name', ''))}</h2><p class='n'>Regras de rota e de luta que valem qualquer que seja a sua escolha.</p>"
               f"<div class='vsg'><div class='card vs-l'><b class='gl'>Na rota e nas lutas</b><ol class='numl'>{num}</ol></div>"
               f"<div class='card vs-w'><b class='gl'>Onde {e(data.get('name', ''))} é fraco</b><small class='n'>Explore isso na seleção e na rota.</small><ul class='tipl bad'>{weak}</ul></div></div>")
    return guide, against


def page(cid, data, ver, pos, mu, sk, exps, build_html, guide, guide_state, my, vsme, my_games, has_top, otp_html="", cnt_html=""):
    name = data.get("name", cid)
    info = data.get("info") or {}
    tags = " ".join(f"<span class='badge'>{e(TAG_PT.get(t, t))}</span>" for t in data.get("tags", []))
    meters = "".join(
        f"<div class='cm'><small>{lab}</small><span>{''.join('<i class=on></i>' if k < round(v / 2) else '<i></i>' for k in range(5))}</span></div>"
        for lab, v in (("Ataque", info.get("attack", 0)), ("Defesa", info.get("defense", 0)), ("Magia", info.get("magic", 0)), ("Dificuldade", info.get("difficulty", 0))))
    ok = [m for m in mu if m[1] >= 3]
    good = sorted([m for m in ok if m[2] / m[1] >= .5], key=lambda m: (-(m[2] / m[1]), -m[1]))[:6]
    bad = sorted([m for m in ok if m[2] / m[1] < .5], key=lambda m: ((m[2] / m[1]), -m[1]))[:6]
    tot_n = sum(m[1] for m in mu)
    tot_w = sum(m[2] for m in mu)
    stats = ""
    if tot_n:
        stats += f"<div class='hst'><small>Vitória na amostra</small><b>{round(100 * tot_w / tot_n)}%</b><em>{tot_n} jogos</em></div>"
    if my:
        stats += f"<div class='hst'><small>Você com ele</small><b>{round(100 * my[1] / my[0])}%</b><em>{my[0]} jogos</em></div>"
    if vsme:
        stats += f"<div class='hst'><small>Você contra ele</small><b>{vsme[1]}V {vsme[0] - vsme[1]}D</b><em>{vsme[0]} jogos</em></div>"
    hero = (f"<section class='chero'><div class='sp' style=\"background-image:url('{icons.splash(cid)}')\"></div><div class='ch-in'>"
            f"<small>{e((data.get('title') or '').capitalize())}</small><h1 class='ch-n'>{e(name)}</h1><div class='badges'>{tags}"
            f"<span class='badge'>{e(ROLE_PT.get(pos, pos or ''))}</span></div><p class='ch-b'>{e(clean(data.get('blurb', '')))}</p>"
            f"<div class='cms'>{meters}</div></div><div class='hsts'>{stats}</div></section>")
    from . import premium
    from .homepremium import _panel as P
    gp, against_ai = guide_sections(guide, data, ver)
    if not guide:
        ban = {"gerando": "<div class='aiban'><span class='spin'></span>A IA está escrevendo o guia completo (combos, picos de poder, plano de jogo e erros comuns). Leva uns 20 segundos; a página atualiza sozinha.</div>",
               "sem_chave": "<div class='aiban'>O guia completo com combos e plano de jogo é escrito pela IA. O administrador precisa ligar o Coach IA em Administração.</div>",
               "erro": "<div class='aiban'>Não consegui escrever o guia agora. Tente recarregar daqui a pouco.</div>"}.get(guide_state, "")
        gp = {"ai": ban}
    ally = data.get("allytips") or []
    enemy = data.get("enemytips") or []
    li = lambda xs: "".join(f"<li>{e(clean(x))}</li>" for x in xs[:5])
    # aba Visao geral: quem ele e, quando fica forte, o plano e os erros
    geral = gp.get("ai", "")
    if gp.get("ident"):
        geral += P(f"Quem é {e(name)}", "Identidade, pontos fortes e fracos.", gp["ident"])
    if gp.get("picos"):
        geral += P("Picos de poder", "Os momentos em que ele fica forte.", gp["picos"])
    if gp.get("plano"):
        geral += P("Plano de jogo", "O que fazer no começo, no meio e no fim.", gp["plano"])
    row = ""
    if gp.get("erros"):
        row += P("Erros comuns", "O que mais derruba quem joga com ele.", gp["erros"])
    if ally:
        row += P("Dicas oficiais da Riot", "Do próprio jogo.", f"<ul class='tipl'>{li(ally)}</ul>")
    if row:
        geral += f"<div class='hpn-2 hpn-gap'>{row}</div>"
    # aba Build
    build = (P("Build, runas e feitiços", f"Os melhores do servidor com {e(name)}. Clique num núcleo para ver a build de quem joga assim.",
               build_html or ("<div class='empty'><b>Ainda sem partidas dos melhores com " + e(name) + "</b>"
                              "<span>Use o botão Baixar amostra do topo no fim da página. Em alguns minutos aparecem build, runas e ordem de habilidades.</span></div>"))
             + P("Ordem de habilidades", "Nível a nível, do jeito que os melhores sobem.",
                 skill_grid(sk, data, ver).replace("<b class='gl'>Ordem de habilidades</b>", "")))
    # aba Habilidades e combos
    habil = P("Habilidades", "Passiva e as quatro habilidades.", abilities(data, ver))
    if gp.get("combos"):
        habil += P("Combos", "Sequências de habilidades e quando usar.", gp["combos"])
    # aba Especialistas
    if otp_html:
        espec = P("OTPs e especialistas do servidor", "Quem mais joga com ele no alto elo.", otp_html)
    elif exps:
        rows = "".join(f"<div class='exr'><span class='mi'>{i}</span><b>{e(x['riot_id'])}</b>"
                       + ("<span class='badge adm'>Mono</span>" if x["mono"] else "<span></span>")
                       + f"<small>{e((x['tier'] or '').title())} {x['lp'] or ''} PDL</small><em>{x['points']:,} pts</em></div>".replace(",", ".")
                       for i, x in enumerate(exps, 1))
        espec = P("Especialistas do servidor", f"Mestre ao Desafiante com mais maestria em {e(name)}.", rows)
    else:
        espec = ""
    contra = ""
    if cnt_html:
        contra += f"<h2>Counters de {e(name)}</h2>{cnt_html}"
    elif ok:
        contra += (f"<div class='grid2'><div class='card'><b class='gl'>Counters de {e(name)}</b><p class='n'>Quem mais vence {e(name)} no {e(ROLE_PT.get(pos, ''))}</p>"
                   f"{champview._bars(bad, False) or '<p class=n>Sem dados suficientes.</p>'}</div>"
                   f"<div class='card'><b class='gl'>Contra quem {e(name)} vai bem</b><p class='n'>Bons confrontos para ele</p>{champview._bars(good, True) or '<p class=n>Sem dados suficientes.</p>'}</div></div>"
                   f"<p class='n'><span class='tag dado'>dado</span> {tot_n} partidas nas amostras do app. Só entra quem tem 3 jogos ou mais.</p>")
    else:
        contra += ("<div class='empty'><span class='em'>⚔</span><b>Ainda sem confrontos suficientes</b>"
                   "<span>Baixe a amostra do topo para ver os counters e os bons confrontos.</span></div>")
    contra += against_ai
    if enemy:
        contra += P("Dicas oficiais da Riot", f"Como enfrentar {e(name)}, segundo o jogo.", f"<ul class='tipl'>{li(enemy)}</ul>")
    if my_games:
        mg = my_games
        opp = {}
        for g in mg:
            opp.setdefault(g.get("opp_champion") or "?", []).append(g)
        rows = sorted(((o, len(gs), sum(1 for x in gs if x["win"])) for o, gs in opp.items()), key=lambda r: -r[1])[:8]
        avg = lambda k: (sum(g[k] for g in mg if g.get(k) is not None) / max(1, len([1 for g in mg if g.get(k) is not None]))) if any(g.get(k) is not None for g in mg) else None
        kp = [("CS/min", avg("cs_per_min"), 1), ("Mortes antes dos 10", avg("deaths_before_10"), 2), ("CS contra o oponente aos 10", avg("csdiff10"), 1)]
        voce = ("<div class='kpis'>" + "".join(f"<div class='kpi'><small class='kl'>{e(t)}</small><b class='kv'>{'–' if v is None else f'{v:.{nd}f}'}</b></div>" for t, v, nd in kp) + "</div>"
                f"<div class='card'><b class='gl'>Seus confrontos com {e(name)}</b>{champview._bars([r for r in rows if r[0] != '?'], True)}</div>")
    else:
        voce = f"<div class='empty'><span class='em'>🎮</span><b>Você ainda não jogou de {e(name)}</b><span>Quando jogar e sincronizar, os seus números aparecem aqui.</span></div>"
    if vsme:
        voce += f"<p class='n'>Você enfrentou {e(name)} {vsme[0]} vez(es): {vsme[1]} vitória(s).</p>"
    actions = (f"<div class='ovl'><b>Dúvidas sobre {e(name)}?</b><span>Pergunte ao Coach IA: ele cruza com as suas partidas.</span>"
               f"<a class='btn gold' href='/coach?q={e('Como jogar contra ' + name + '?')}'>Perguntar ao Coach IA</a>"
               f"<form method='post' action='/sincronizar/iniciar'><input type='hidden' name='kind' value='top'><input type='hidden' name='champion' value='{e(cid)}'>"
               "<input type='hidden' name='games' value='30'><input type='hidden' name='back' value='1'><button class='btn ghost'>"
               f"{'Aumentar' if has_top else 'Baixar'} amostra do topo</button></form></div>")
    tabs = premium.tabbar([("geral", "Visão geral", geral or "<p class='n'>Sem guia ainda.</p>"), ("build", "Build", build),
                           ("habilidades", "Habilidades e combos", habil), ("counters", "Counters", contra),
                           ("especialistas", "Especialistas", espec), ("voce", "Seus números", voce)], "campeao")
    return hero + tabs + actions


CSS = """
.vsg{display:grid;grid-template-columns:minmax(0,1.5fr) minmax(0,1fr);gap:12px}.vsg .card{margin:0}
.numl{list-style:none;padding:0;margin:12px 0 0}.numl li{display:grid;grid-template-columns:26px minmax(0,1fr);gap:12px;padding:10px 0;border-top:1px solid rgba(255,255,255,.05);color:#d8dfec;line-height:1.55}
.numl li span{width:24px;height:24px;border-radius:6px;display:flex;align-items:center;justify-content:center;font:700 12px var(--body);color:#c9a7ff;border:1px solid rgba(167,139,250,.5);background:rgba(167,139,250,.1)}
@media (max-width:900px){.vsg{grid-template-columns:1fr}}
.chero{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:end}
.hsts{position:relative;z-index:2;display:flex;flex-direction:column;gap:8px;padding:24px}
.hst{min-width:170px;padding:10px 14px;border:1px solid rgba(200,170,110,.35);background:rgba(1,10,19,.7);backdrop-filter:blur(6px)}
.hst small{display:block;color:var(--mute);font-size:12px}.hst b{display:block;font:700 26px var(--head);color:#fff}.hst em{font-style:normal;color:var(--gold);font-size:12px}
.ctabs{display:flex;gap:4px;border-bottom:1px solid var(--hx-line,#463714);margin:4px 0 18px}
.ctab{background:none !important;border:0 !important;border-bottom:2px solid transparent !important;color:var(--mute) !important;font:600 14px var(--body) !important;
letter-spacing:.02em !important;padding:12px 16px !important;box-shadow:none !important}
.ctab.on{color:#fff !important;border-bottom-color:var(--gold) !important}
.cpane[hidden]{display:none}
.ab2s{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:10px}
.ab2{padding:14px;border:1px solid var(--rule);background:linear-gradient(180deg,rgba(30,35,40,.5),rgba(8,19,31,.9))}
.ab2-h{display:grid;grid-template-columns:52px auto minmax(0,1fr);gap:10px;align-items:center}
.ab2-h img,.abi{border:1px solid #785a28}.abi.ph{display:inline-block;background:#0b1622}
.abk2{padding:3px 8px;border:1px solid var(--gold);font:700 12px var(--head);color:var(--gold)}
.ab2-h b{font:700 16px var(--head);color:#fff}
.ab2-m{display:flex;gap:14px;flex-wrap:wrap;margin:10px 0 4px}.ab2-m span{font:600 13px var(--body);color:#dfe5f2}.ab2-m small{display:block;color:var(--mute);font-size:11px;font-weight:500}
.ab2 p{margin:8px 0 0;font-size:13.5px;color:#b9c2d6;line-height:1.5}
.aiban{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:12px 14px;margin:18px 0 6px;border:1px dashed rgba(140,196,255,.4);color:#D6CCC0;font-size:13.5px;background:rgba(59,158,255,.05)}
.aiban .tag{padding:0}.aiban .spin{width:16px;height:16px}
.ident{margin:10px 0}.id-t{font:600 19px/1.45 var(--body);color:#fff;margin:6px 0 14px;max-width:70ch}
.tipl.good li::marker{color:var(--win)}.tipl.bad li::marker{color:var(--loss)}
.combos{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:12px}
.combo{padding:14px 16px;border:1px solid var(--rule);background:linear-gradient(180deg,rgba(30,35,40,.5),rgba(8,19,31,.9))}
.cb-h{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:10px}.cb-h b{font:700 16px var(--head);color:#fff}
.cb-s{display:flex;align-items:center;flex-wrap:wrap;gap:6px}
.ck{position:relative;display:inline-flex;flex-direction:column;align-items:center;gap:3px;width:62px}
.ck img,.ck .abi{border:1px solid var(--gold);box-shadow:0 0 10px rgba(200,170,110,.25)}
.ck b{position:absolute;top:26px;right:9px;background:#010a13;border:1px solid var(--gold);font:700 10px var(--head);color:var(--gold);padding:0 3px}
.ck em{font-style:normal;font-size:10.5px;color:var(--mute);text-align:center;line-height:1.2;max-width:62px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ck.txt{width:auto}.cktxt{display:inline-flex;align-items:center;height:40px;padding:0 10px;border:1px solid #2c3a4d;background:#0b1622;font:600 12px var(--body);color:#dfe5f2}
.ca{color:var(--gold);font-weight:800;padding-bottom:18px}
.combo p{margin:10px 0 0;font-size:13.5px;color:#D6CCC0}
.picos{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px}
.pico{padding:12px 14px;border-left:2px solid var(--gold);background:rgba(200,170,110,.05)}.pico b{display:block;font:700 14px var(--head);color:var(--gold)}
.pico span{font-size:13.5px;color:#DDD3C7}
.phase3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.phase3 .card{margin:0}
.bb .card{margin:0}
.itrow{margin:10px 0 14px}.itr-h{display:flex;justify-content:space-between;align-items:baseline;gap:8px;margin-bottom:6px}.itr-h b{font:600 13px var(--body);color:#dfe5f2}
.itcs{display:flex;flex-wrap:wrap;gap:10px}
.itc{display:flex;flex-direction:column;align-items:center;gap:3px;width:78px;text-align:center}
.itc img{border:1px solid #785a28}.itc small{font-size:11.5px;color:#D6CCC0;line-height:1.25}.itc em{font-style:normal;font-size:11px;color:var(--gold)}
.rtree{margin:12px 0 6px;font:700 13px var(--head);color:var(--gold)}
.rn{display:grid;grid-template-columns:auto minmax(0,1fr);gap:10px;align-items:center;margin:6px 0}.rn b{display:block;font:600 14px var(--body);color:#fff}
.rn small{color:#9aa3b8;font-size:12px;line-height:1.35}.rn img{border-radius:50%;background:#0b1622}.rn.big img{box-shadow:0 0 14px rgba(200,170,110,.35)}
.sgrid{display:flex;flex-direction:column;gap:6px;margin-top:10px;overflow-x:auto}
.sgr{display:grid;grid-template-columns:30px 18px minmax(0,1fr);gap:8px;align-items:center}.sgr b{font:700 13px var(--head);color:var(--gold)}
.sgc{display:grid;grid-template-columns:repeat(18,minmax(24px,1fr));gap:3px}
.sgc i{height:26px;display:flex;align-items:center;justify-content:center;background:#0b1622;border:1px solid #1d2a3a;font:700 11px var(--body);font-style:normal;color:#010a13}
.sgc i.on{background:linear-gradient(180deg,#e2c792,#b8923f);border-color:#f0e6d2}
.gold{color:var(--gold)}
.ii{display:inline-flex;align-items:center;gap:2px;vertical-align:-6px;margin:0 2px;position:relative}
.ii .iimg{border:1px solid var(--gold);border-radius:3px}.ii b{position:absolute;right:-3px;bottom:-4px;background:#010a13;border:1px solid var(--gold);font:700 8px var(--head);color:var(--gold);padding:0 2px;line-height:1.3}
.tline{padding:18px 20px}.tl-h{display:flex;justify-content:space-between;gap:10px;align-items:baseline;margin-bottom:8px}
.tl-track{position:relative;height:74px;margin:6px 10px 10px;cursor:pointer;touch-action:none}
.tl-line,.tl-fill{position:absolute;left:0;top:16px;height:3px;background:#1d2a3a;width:100%}.tl-fill{background:linear-gradient(90deg,#785a28,#c8aa6e);width:0;transition:width .35s}
.tl-dots{position:absolute;inset:0;display:flex;justify-content:space-between}
.tl-dot{all:unset;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:4px;width:110px;margin:0 -55px}
.tl-dot{background:none !important;border:0 !important;box-shadow:none !important;padding:0 !important;letter-spacing:0 !important;font-family:var(--body) !important;text-transform:none !important}
.tl-dot::after{display:none !important}
.tl-dot:first-child{align-items:flex-start;margin-left:0}.tl-dot:last-child{align-items:flex-end;margin-right:0}
.tl-dot i{width:12px;height:12px;margin-top:11px;border-radius:50%;background:#1d2a3a;border:2px solid #3a4658;transition:all .25s}
.tl-dot.on i{width:26px;height:26px;margin-top:4px;background:radial-gradient(circle,#ffe39a,#c8aa6e);border-color:#f0e6d2;box-shadow:0 0 18px rgba(200,170,110,.6)}
.tl-dot b{font:700 14px var(--head) !important;color:var(--mute)}.tl-dot.on b{color:var(--gold)}.tl-dot small{font-size:11.5px;color:var(--mute)}
.tl-p{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;animation:dIn .35s ease both}.tl-p[hidden]{display:none}
.tl-c{padding:14px 16px;background:rgba(1,10,19,.55);border:1px solid var(--rule);font-size:14.5px;line-height:1.7;color:#e0e6f2}
@media (max-width:900px){.tl-p{grid-template-columns:1fr}}
@media (max-width:1000px){.chero{grid-template-columns:1fr}.hsts{flex-direction:row;flex-wrap:wrap;padding:0 24px 24px}.phase3{grid-template-columns:1fr}}
"""


TL_JS = """<script>(function(){function init(){document.querySelectorAll('.tline').forEach(function(t){if(t.dataset.on)return;t.dataset.on=1;
var bar=t.querySelector('.tl-fill');function go(i){t.querySelectorAll('.tl-dot').forEach(function(d){d.classList.toggle('on',+d.dataset.i===i)});
t.querySelectorAll('.tl-p').forEach(function(p){p.hidden=+p.dataset.i!==i});bar.style.width=(i*50)+'%'}
function pick(i){go(i);try{sessionStorage.setItem('tlsel',JSON.stringify({i:i,at:Date.now()}))}catch(x){}}
t.addEventListener('click',function(ev){var d=ev.target.closest('.tl-dot');if(d)pick(+d.dataset.i)});
var tr=t.querySelector('.tl-track');tr.addEventListener('pointerdown',function(ev){function mv(e2){var r=tr.getBoundingClientRect();pick(Math.max(0,Math.min(2,Math.round((e2.clientX-r.left)/r.width*2))))}
mv(ev);tr.setPointerCapture(ev.pointerId);tr.onpointermove=mv;tr.onpointerup=function(){tr.onpointermove=null}});var c=+(t.dataset.cur||0);try{var sv=JSON.parse(sessionStorage.getItem('tlsel')||'null');if(sv&&Date.now()-sv.at<60000)c=sv.i}catch(x){}go(c)})}init();document.addEventListener('liveswap',init)})();</script>"""
