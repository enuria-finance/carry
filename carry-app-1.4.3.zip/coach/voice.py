"""Voz dos avisos do overlay. Dois servicos, as duas chaves ficam em Administracao (nunca no codigo):

- ElevenLabs: vozes muito naturais, plano gratis sem cartao (cerca de 10 mil caracteres por mes, uso pessoal).
  Ids das vozes daqui comecam com "el:".
- Azure Speech (Microsoft): Francisca, Antonio, Thalita e outras vozes neurais, plano gratuito F0 com 500 mil caracteres por mes.
- Cada frase falada e guardada em cache/voz: a mesma frase nao gasta de novo.
- Saida em WAV (o Windows toca sem instalar nada).
"""
import hashlib
import io
import json
import time
import wave
import html
import os
import urllib.error
import urllib.request

VOICES = [("pt-BR-FranciscaNeural", "Francisca"), ("pt-BR-AntonioNeural", "Antonio"), ("pt-BR-ThalitaMultilingualNeural", "Thalita"),
          ("pt-BR-MacerioMultilingualNeural", "Macerio"), ("pt-BR-LeilaNeural", "Leila"), ("pt-BR-BrendaNeural", "Brenda")]
DEFAULT = VOICES[0][0]
SAMPLE = "Dragão nasce em quarenta segundos. Ahri está morta: a rota está livre."


def _cache_dir(ddir):
    d = os.path.join(ddir, "cache", "voz")
    os.makedirs(d, exist_ok=True)
    return d


def speakable(text):
    """Ajusta a frase para soar natural: 22s -> 22 segundos, 1:30 -> 1 minuto e 30."""
    import re
    t = re.sub(r"(\d+)s\b", lambda m: f"{m.group(1)} segundos", text)
    t = re.sub(r"(\d+):(\d{2})", lambda m: f"{int(m.group(1))} minuto{'s' if int(m.group(1)) != 1 else ''} e {int(m.group(2))}", t)
    t = re.sub(r"\bmin\b", "minutos", t)
    try:
        from . import pronuncia
        t = pronuncia.fix(t)
    except Exception:
        pass
    return t


def synth(ddir, key, region, voice, text):
    voice = voice if voice in dict(VOICES) else DEFAULT
    text = speakable((text or "").strip())[:220]
    if not text:
        raise ValueError("frase vazia")
    h = hashlib.sha1(f"{voice}|{text}".encode("utf-8")).hexdigest()
    fp = os.path.join(_cache_dir(ddir), h + ".wav")
    if os.path.exists(fp):
        with open(fp, "rb") as fh:
            return fh.read()
    ssml = (f"<speak version='1.0' xml:lang='pt-BR'><voice name='{voice}'><prosody rate='+6%'>"
            f"{html.escape(text)}</prosody></voice></speak>").encode("utf-8")
    req = urllib.request.Request(f"https://{region}.tts.speech.microsoft.com/cognitiveservices/v1", data=ssml, method="POST", headers={
        "Ocp-Apim-Subscription-Key": key, "Content-Type": "application/ssml+xml",
        "X-Microsoft-OutputFormat": "riff-24khz-16bit-mono-pcm", "User-Agent": "lol-coach"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            data = r.read()
    except urllib.error.HTTPError as ex:
        other = DEFAULT if voice != DEFAULT else VOICES[1][0]
        if ex.code == 400 and other and not getattr(synth, "_retry", False):   # voz fora do ar: tenta a outra
            synth._retry = True
            try:
                return synth(ddir, key, region, other, text)
            finally:
                synth._retry = False
        raise RuntimeError({401: "chave de voz inválida", 403: "chave de voz sem permissão para esta região",
                            429: "limite do plano de voz atingido"}.get(ex.code, f"serviço de voz respondeu {ex.code}"))
    with open(fp, "wb") as fh:
        fh.write(data)
    return data


# ---------------- ElevenLabs ----------------
EL = "el:"
EL_MODEL = "eleven_multilingual_v2"     # o modelo que fala portugues com mais naturalidade
EL_API = "https://api.elevenlabs.io/v1"
# vozes prontas de toda conta (se a lista da conta nao puder ser lida); todas falam portugues com o modelo multilingue
EL_PREMADE = [("EXAVITQu4vr4xnSDxMaL", "Sarah"), ("FGY2WhTYpPnrIDTdsKH5", "Laura"), ("Xb7hH8MSUJpSbSDYk0k2", "Alice"),
              ("XrExE9yKIg1WjnnlVkGX", "Matilda"), ("cgSgspJ2msm6clMCkdW9", "Jessica"), ("pFZP5JQG7iQjIQuC4Bku", "Lily"),
              ("nPczCjzI2devNBz1zQrb", "Brian"), ("JBFqnCBsd6RMkjVDRZzb", "George"), ("onwK4e9ZLuTAKqWW03F9", "Daniel"),
              ("TX3LPaxmHKxFdv7VOQHJ", "Liam"), ("cjVigY5qzO86Huf0OWal", "Eric"), ("CwhRBWXzGAHq8TQ4Fs17", "Roger")]


def _el_req(key, path, data=None, timeout=20):
    req = urllib.request.Request(EL_API + path, data=json.dumps(data).encode("utf-8") if data is not None else None,
                                 method="POST" if data is not None else "GET",
                                 headers={"xi-api-key": key, "Content-Type": "application/json", "User-Agent": "carry"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def el_voices(ddir, key, force=False):
    """Vozes da conta (as prontas + as que voce adicionou da biblioteca). Guarda a lista por 1 dia."""
    fp = os.path.join(_cache_dir(ddir), "el_vozes.json")
    try:
        if not force and os.path.exists(fp) and time.time() - os.path.getmtime(fp) < 86400:
            with open(fp, encoding="utf-8") as fh:
                return [tuple(x) for x in json.load(fh)]
    except Exception:
        pass
    try:
        js = json.loads(_el_req(key, "/voices", timeout=12).decode("utf-8"))
        out = []
        for v in js.get("voices") or []:
            lab = v.get("labels") or {}
            tr = {"female": "feminina", "male": "masculina", "brazilian": "brasileira", "portuguese": "portuguesa", "american": "americana", "british": "britânica"}
            extra = " · ".join(tr.get(str(x).lower(), str(x)) for x in (lab.get("gender"), lab.get("accent")) if x)
            mine = v.get("category") in ("generated", "cloned")      # feitas por voce (Voice Design): funcionam no plano gratis
            out.append((v["voice_id"], (v.get("name") or "Voz").split(" - ")[0][:40] + (f" ({extra})" if extra else ""), mine))
        out.sort(key=lambda x: (not x[2], x[1].lower()))
        out = [(a, b) for a, b, _ in out]
        if out:
            with open(fp, "w", encoding="utf-8") as fh:
                json.dump(out, fh)
            return out
    except Exception:
        pass
    return list(EL_PREMADE)


def _blocked_path(ddir):
    return os.path.join(_cache_dir(ddir), "el_bloqueadas.json")


def el_blocked(ddir):
    """Vozes que a ElevenLabs recusou no plano gratis (vozes da biblioteca): saem da lista."""
    try:
        with open(_blocked_path(ddir), encoding="utf-8") as fh:
            return set(json.load(fh))
    except Exception:
        return set()


def _block(ddir, vid):
    b = el_blocked(ddir)
    b.add(vid)
    try:
        with open(_blocked_path(ddir), "w", encoding="utf-8") as fh:
            json.dump(sorted(b), fh)
    except OSError:
        pass


def _el_message(detail):
    """Tira a mensagem legivel do erro da ElevenLabs ({"detail": {"status": ..., "message": ...}})."""
    try:
        d = json.loads(detail).get("detail")
        if isinstance(d, dict):
            return (d.get("message") or d.get("status") or "")[:220]
        if isinstance(d, list) and d:
            return str(d[0].get("msg") or d[0])[:220]
        return str(d or "")[:220]
    except Exception:
        return detail[:220]


def _pcm_to_wav(pcm, rate):
    b = io.BytesIO()
    with wave.open(b, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm)
    return b.getvalue()


def el_synth(ddir, key, voice_id, text):
    text = speakable((text or "").strip())[:220]
    if not text:
        raise ValueError("frase vazia")
    h = hashlib.sha1(f"el|{EL_MODEL}|{voice_id}|{text}".encode("utf-8")).hexdigest()
    fp = os.path.join(_cache_dir(ddir), h + ".wav")
    if os.path.exists(fp):
        with open(fp, "rb") as fh:
            return fh.read()
    full = {"text": text, "model_id": EL_MODEL, "voice_settings": {"stability": 0.5, "similarity_boost": 0.75}}
    tries = [(24000, full), (16000, full), (16000, {"text": text, "model_id": EL_MODEL}),
             (16000, {"text": text, "model_id": "eleven_flash_v2_5"})]   # do melhor para o mais simples
    data, last = None, None
    for rate, body in tries:
        try:
            data = _pcm_to_wav(_el_req(key, f"/text-to-speech/{voice_id}?output_format=pcm_{rate}", body), rate)
            break
        except urllib.error.HTTPError as ex:
            detail = ""
            try:
                detail = ex.read().decode("utf-8", "ignore")
            except Exception:
                pass
            msg = _el_message(detail)
            if "unusual" in detail:
                raise RuntimeError("a ElevenLabs bloqueou o plano grátis nesta conexão (atividade incomum; VPN ou rede compartilhada costumam causar isso)")
            if "missing_permissions" in detail:
                raise RuntimeError("a chave da ElevenLabs está sem a permissão de Text to Speech")
            if "quota" in detail or "credits" in detail:
                raise RuntimeError("os créditos do mês da ElevenLabs acabaram (quota)" + (f": {msg}" if msg else ""))
            if ex.code == 401:
                raise RuntimeError("chave da ElevenLabs inválida" + (f": {msg}" if msg else ""))
            if ex.code == 402 or "paid_plan" in detail:
                raise RuntimeError("a ElevenLabs pede plano pago para isso" + (f": {msg}" if msg else ""))
            if ex.code == 404 or "voice_not_found" in detail:
                raise RuntimeError("essa voz não existe na sua conta da ElevenLabs: escolha outra")
            if ex.code == 429:
                raise RuntimeError("muitos pedidos ao mesmo tempo na ElevenLabs")
            last = f"ElevenLabs respondeu {ex.code}" + (f": {msg}" if msg else "")
            if ex.code not in (400, 422):
                raise RuntimeError(last)
    if data is None:
        raise RuntimeError(last or "ElevenLabs não devolveu áudio")
    with open(fp, "wb") as fh:
        fh.write(data)
    return data


# ---------------- voz do Windows (sem chave, sem limite; reserva quando a ElevenLabs acaba) ----------------
WIN = "win:"
WIN_VOICE = WIN + "ptbr"


def win_available():
    return os.name == "nt"


def win_synth(ddir, text):
    """Gera o WAV com a voz em portugues instalada no Windows (System.Speech). Roda escondido, sem janela."""
    text = speakable((text or "").strip())[:300]
    if not text:
        raise ValueError("frase vazia")
    h = hashlib.sha1(f"win|{text}".encode("utf-8")).hexdigest()
    fp = os.path.join(_cache_dir(ddir), h + ".wav")
    if os.path.exists(fp):
        with open(fp, "rb") as fh:
            return fh.read()
    if not win_available():
        raise RuntimeError("a voz do Windows só existe no Windows")
    import subprocess
    import tempfile
    tf = os.path.join(tempfile.gettempdir(), "carry_txt_" + h[:10] + ".txt")
    with open(tf, "w", encoding="utf-8") as fh:
        fh.write(text)
    ps = ("Add-Type -AssemblyName System.Speech;$s=New-Object System.Speech.Synthesis.SpeechSynthesizer;"
          "$v=$s.GetInstalledVoices()|Where-Object{$_.VoiceInfo.Culture.Name -eq 'pt-BR'}|Select-Object -First 1;"
          "if($v){$s.SelectVoice($v.VoiceInfo.Name)};$s.Rate=1;"
          f"$s.SetOutputToWaveFile('{fp}');$s.Speak([IO.File]::ReadAllText('{tf}',[Text.Encoding]::UTF8));$s.Dispose()")
    try:
        subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], timeout=25,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), capture_output=True)
    finally:
        try:
            os.remove(tf)
        except OSError:
            pass
    if not os.path.exists(fp):
        raise RuntimeError("o Windows não gerou o áudio (sem voz em português instalada?)")
    with open(fp, "rb") as fh:
        return fh.read()


def _quota_path(ddir):
    return os.path.join(_cache_dir(ddir), "el_sem_creditos.txt")


def el_out_of_credits(ddir):
    """True se a ElevenLabs disse que os creditos do mes acabaram (vale por 6 horas, depois tenta de novo)."""
    try:
        return time.time() - os.path.getmtime(_quota_path(ddir)) < 6 * 3600
    except OSError:
        return False


def _mark_out_of_credits(ddir):
    try:
        with open(_quota_path(ddir), "w") as fh:
            fh.write(time.strftime("%Y-%m-%d %H:%M"))
    except OSError:
        pass


# ---------------- Edge (vozes neurais da Microsoft pelo pacote edge-tts): gratis, sem conta e sem cartao ----------------
# Nao oficial (usa o "Ler em voz alta" do navegador Edge): bom para uso pessoal; pode parar de funcionar um dia
# e NAO deve ir na versao vendida do app. Instala sozinho na primeira vez (pip install --user edge-tts).
ED = "ed:"
ED_VOICES = [("pt-BR-FranciscaNeural", "Francisca"), ("pt-BR-AntonioNeural", "Antonio"),
             ("pt-BR-ThalitaMultilingualNeural", "Thalita"), ("pt-BR-MacerioMultilingualNeural", "Macerio")]
_ED = {"state": None, "at": 0.0, "err": None}
# o pacote usa aiohttp; estas variaveis fazem ele rodar em Python puro (sem .pyd, nada para o Windows bloquear)
_PURE = {k: "1" for k in ("AIOHTTP_NO_EXTENSIONS", "MULTIDICT_NO_EXTENSIONS", "YARL_NO_EXTENSIONS",
                          "FROZENLIST_NO_EXTENSIONS", "PROPCACHE_NO_EXTENSIONS")}


def _py():
    import sys
    exe = sys.executable or "python"
    if exe.lower().endswith("pythonw.exe"):
        cand = exe[:-len("pythonw.exe")] + "python.exe"
        if os.path.exists(cand):
            exe = cand
    return exe


def _run(args, timeout):
    import subprocess
    env = dict(os.environ, **_PURE)
    return subprocess.run([_py()] + args, capture_output=True, text=True, timeout=timeout, env=env,
                          creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))


def ed_ready():
    """'ok' se o edge-tts esta instalado; 'installing' enquanto instala (em segundo plano); 'fail' se nao deu."""
    if _ED["state"] == "ok":
        return "ok"
    if _ED["state"] == "installing":
        return "installing"
    if _ED["state"] == "fail" and time.time() - _ED["at"] < 1800:
        return "fail"
    import importlib.util
    if importlib.util.find_spec("edge_tts") is not None:
        _ED["state"] = "ok"
        return "ok"
    _ED.update(state="installing", at=time.time())

    def go():
        try:
            r = _run(["-m", "pip", "install", "--user", "--disable-pip-version-check", "edge-tts"], 300)
            import importlib
            importlib.invalidate_caches()
            ok = r.returncode == 0
            _ED.update(state="ok" if ok else "fail", at=time.time(), err=None if ok else (r.stderr or r.stdout or "")[-300:])
        except Exception as ex:
            _ED.update(state="fail", at=time.time(), err=f"{type(ex).__name__}: {ex}")
    import threading
    threading.Thread(target=go, daemon=True).start()
    return "installing"


_ED_LOCK = None


def _ed_inproc(voice, text, fp):
    global _ED_LOCK
    import threading
    if _ED_LOCK is None:
        _ED_LOCK = threading.Semaphore(3)
    for k, v in _PURE.items():
        os.environ.setdefault(k, v)
    import importlib.util
    import sys
    if importlib.util.find_spec("edge_tts") is None:       # instalado depois que o app abriu: pasta do usuario
        import site
        up = site.getusersitepackages()
        if up and up not in sys.path and os.path.isdir(up):
            sys.path.append(up)
            importlib.invalidate_caches()
    import edge_tts
    with _ED_LOCK:
        tmp = fp + ".part"
        edge_tts.Communicate(text, voice, rate="+6%").save_sync(tmp)
        os.replace(tmp, fp)


def ed_synth(ddir, voice, text):
    """MP3 com a voz neural (o overlay toca MP3 pelo Windows)."""
    text = speakable((text or "").strip())[:300]
    if not text:
        raise ValueError("frase vazia")
    voice = voice if voice in dict(ED_VOICES) else ED_VOICES[0][0]
    h = hashlib.sha1(f"ed|{voice}|{text}".encode("utf-8")).hexdigest()
    fp = os.path.join(_cache_dir(ddir), h + ".mp3")
    if os.path.exists(fp) and os.path.getsize(fp) > 500:
        with open(fp, "rb") as fh:
            return fh.read()
    st = ed_ready()
    if st == "installing":
        raise RuntimeError("instalando a voz grátis da Microsoft (uma vez só, leva 1 ou 2 minutos)")
    if st != "ok":
        raise RuntimeError("não consegui instalar a voz grátis da Microsoft" + (f": {_ED['err']}" if _ED.get("err") else ""))
    # rapido: dentro do proprio app (sem abrir outro Python a cada frase)
    try:
        _ed_inproc(voice, text, fp)
        if os.path.exists(fp) and os.path.getsize(fp) > 500:
            with open(fp, "rb") as fh:
                return fh.read()
    except Exception:
        pass
    tf = fp + ".txt"
    with open(tf, "w", encoding="utf-8") as fh:
        fh.write(text)
    try:
        r = _run(["-m", "edge_tts", "--voice", voice, "--rate=+6%", "--no-progress", "--file", tf, "--write-media", fp], 30)
    finally:
        try:
            os.remove(tf)
        except OSError:
            pass
    if r.returncode != 0 or not os.path.exists(fp) or os.path.getsize(fp) < 500:
        try:
            os.remove(fp)
        except OSError:
            pass
        raise RuntimeError("a voz grátis da Microsoft não respondeu agora" + (f" ({(r.stderr or '').strip()[-160:]})" if r.stderr else ""))
    with open(fp, "rb") as fh:
        return fh.read()


def audio_type(data):
    return "audio/wav" if (data or b"")[:4] == b"RIFF" else "audio/mpeg"


# ---------------- Gemini (Google): usa a mesma chave grátis da IA, sem cadastro novo ----------------
GM = "gm:"
GM_VOICES = [("Kore", "Kore (feminina, firme)"), ("Aoede", "Aoede (feminina, leve)"), ("Charon", "Charon (masculina, clara)"),
             ("Puck", "Puck (masculina, animada)")]
GM_FALLBACK = ["gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts"]
GM_STYLE = ""   # a instrucao de estilo as vezes era lida em voz alta; o idioma vai em speechConfig.languageCode
_GMM = {"name": None, "at": 0.0}


def gm_key(c):
    return (c.get("gemini_api_key") or os.environ.get("GEMINI_API_KEY") or "").strip()


def _gm_models(gk):
    """Modelos de voz (TTS) da conta, do mais novo para o mais velho. Guarda por 6 horas."""
    if _GMM["name"] and time.time() - _GMM["at"] < 6 * 3600:
        return _GMM["name"]
    found = []
    try:
        with urllib.request.urlopen(f"https://generativelanguage.googleapis.com/v1beta/models?key={gk}&pageSize=200", timeout=15) as r:
            data = json.loads(r.read().decode("utf-8"))
        import re
        for m in data.get("models") or []:
            nm = (m.get("name") or "").split("/")[-1]
            if "tts" in nm.lower() and "generateContent" in (m.get("supportedGenerationMethods") or []) and "pro" not in nm.lower():
                v = re.findall(r"(\d+(?:\.\d+)?)", nm)
                found.append((float(v[0]) if v else 0, nm))
    except Exception:
        found = []
    names = [n for _, n in sorted(found, reverse=True)] or list(GM_FALLBACK)
    _GMM.update(name=names, at=time.time())
    return names


def _gm_quota_path(ddir):
    return os.path.join(_cache_dir(ddir), "gm_limite.txt")


def gm_limited(ddir):
    """True enquanto o limite gratis do Gemini estiver estourado (o arquivo guarda ate quando)."""
    try:
        with open(_gm_quota_path(ddir)) as fh:
            return time.time() < float(fh.read().strip() or 0)
    except (OSError, ValueError):
        return False


def gm_synth(ddir, gk, voice, text):
    import base64
    text = speakable((text or "").strip())[:300]
    if not text:
        raise ValueError("frase vazia")
    voice = voice if voice in dict(GM_VOICES) else GM_VOICES[0][0]
    h = hashlib.sha1(f"gm2|{voice}|{text}".encode("utf-8")).hexdigest()   # gm2: audios antigos podiam ter a instrucao lida em voz alta
    fp = os.path.join(_cache_dir(ddir), h + ".wav")
    if os.path.exists(fp):
        with open(fp, "rb") as fh:
            return fh.read()
    if gm_limited(ddir):
        raise RuntimeError("limite grátis de voz do Gemini atingido por agora; volta sozinho mais tarde")
    body = json.dumps({"contents": [{"parts": [{"text": text}]}],
                       "generationConfig": {"responseModalities": ["AUDIO"],
                                            "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voice}}}}}).encode("utf-8")
    last = None
    for model in _gm_models(gk)[:3]:
        req = urllib.request.Request(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={gk}",
                                     data=body, method="POST", headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=25) as r:
                data = json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as ex:
            if ex.code == 429:
                wait = 3600
                try:
                    det = json.loads(ex.read().decode("utf-8"))
                    for d in (det.get("error") or {}).get("details") or []:
                        rd = d.get("retryDelay")
                        if rd and rd.endswith("s"):
                            wait = max(30, int(float(rd[:-1])))
                except Exception:
                    pass
                last = "limite grátis de voz do Gemini atingido por agora; volta sozinho mais tarde"
                if wait >= 600:          # limite do dia: nao tenta de novo ate passar
                    try:
                        with open(_gm_quota_path(ddir), "w") as fh:
                            fh.write(str(time.time() + wait))
                    except OSError:
                        pass
                    break
                continue
            last = {400: "o Gemini recusou a frase", 403: "chave do Gemini sem permissão para voz", 404: "modelo de voz do Gemini indisponível"}.get(
                ex.code, f"Gemini respondeu {ex.code}")
            continue
        except Exception as ex:
            last = f"sem conexão com o Gemini ({type(ex).__name__})"
            continue
        try:
            part = data["candidates"][0]["content"]["parts"][0]["inlineData"]
            pcm = base64.b64decode(part["data"])
            mt = part.get("mimeType") or ""
            rate = int(mt.split("rate=")[1].split(";")[0]) if "rate=" in mt else 24000
        except Exception:
            last = "o Gemini não devolveu áudio"
            continue
        wav = _pcm_to_wav(pcm, rate)
        with open(fp, "wb") as fh:
            fh.write(wav)
        return wav
    raise RuntimeError(last or "o Gemini não devolveu áudio")


# ---------------- escolha do servico ----------------
def keys(c):
    return (c.get("elevenlabs_key") or "").strip(), (c.get("azure_speech_key") or "").strip()


def ed_available():
    return os.name == "nt" or os.environ.get("CARRY_EDGE_TTS") == "1"


def configured(c):
    return any(keys(c)) or bool(gm_key(c)) or ed_available()


def choices(ddir, c):
    el, az = keys(c)
    out = []
    if el:
        bl = el_blocked(ddir)
        out += [(EL + vid, f"{name} · ElevenLabs") for vid, name in el_voices(ddir, el) if vid not in bl]
    if az:
        out += [(v, f"{n} · Microsoft") for v, n in VOICES]
    if ed_available():
        out += [(ED + v, f"{n} · Microsoft (grátis, sem chave)") for v, n in ED_VOICES]
    if gm_key(c):
        out += [(GM + v, f"{n} · Gemini (grátis, usa a chave da IA)") for v, n in GM_VOICES]
    return out


def default(c):
    el, az = keys(c)
    if el:
        return EL + EL_PREMADE[0][0]
    if not az and ed_available():
        return ED + ED_VOICES[0][0]
    if not az and gm_key(c):
        return GM + GM_VOICES[0][0]
    return DEFAULT


def pick(ddir, c, wanted):
    """A voz escolhida, se ainda existir; senao a padrao do servico ligado."""
    ch = choices(ddir, c)
    return wanted if wanted in dict(ch) else (ch[0][0] if ch else wanted)


LAST = {"ok_at": 0.0, "err": None, "err_at": 0.0}


def say(ddir, c, voice_id, text):
    try:
        wav = _say(ddir, c, voice_id, text)
        LAST.update(ok_at=time.time(), err=None)
        return wav
    except Exception as ex:
        LAST.update(err=str(ex), err_at=time.time())
        raise


def status_line():
    """Uma linha sobre a ultima tentativa de falar (para a tela do app)."""
    if LAST["err"] and LAST["err_at"] >= LAST["ok_at"]:
        return "err", f"Última tentativa às {time.strftime('%H:%M', time.localtime(LAST['err_at']))}: {LAST['err']}."
    if LAST["ok_at"]:
        sub = f" A voz escolhida só funciona no plano pago; usando {LAST['sub']}." if LAST.get("sub") else ""
        return "ok", f"Funcionando. Última fala gerada às {time.strftime('%H:%M', time.localtime(LAST['ok_at']))}.{sub}"
    return "", ""


def _say(ddir, c, voice_id, text):
    el, az = keys(c)
    voice_id = pick(ddir, c, voice_id or "")
    region = c.get("azure_speech_region") or "brazilsouth"
    no_credit = ("os créditos do mês da ElevenLabs acabaram. Para continuar com voz, cole a chave grátis da Microsoft (Francisca) "
                 "em Administração > Voz dos avisos")

    gk = gm_key(c)

    def reserve():
        # creditos da ElevenLabs acabaram: Microsoft (Francisca), depois Gemini; senao fica so o texto no overlay
        if az:
            LAST["sub"] = "a Francisca da Microsoft (os créditos do mês da ElevenLabs acabaram)"
            return synth(ddir, az, region, c.get("voz_reserva") or DEFAULT, text)
        errs = []
        if ed_available():
            try:
                LAST["sub"] = "a Francisca grátis da Microsoft (os créditos do mês da ElevenLabs acabaram)"
                return ed_synth(ddir, c.get("voz_reserva_ed") or ED_VOICES[0][0], text)
            except RuntimeError as ex:
                errs.append(str(ex))
        if gk:
            LAST["sub"] = "a voz do Gemini (os créditos do mês da ElevenLabs acabaram)"
            return gm_synth(ddir, gk, GM_VOICES[0][0], text)
        raise RuntimeError(errs[0] if errs else no_credit)
    if voice_id.startswith(ED):
        try:
            return ed_synth(ddir, voice_id[len(ED):], text)
        except RuntimeError:
            if gk:                       # enquanto instala ou se cair: Gemini cobre
                LAST["sub"] = "a voz do Gemini (a voz grátis da Microsoft ainda não está pronta)"
                return gm_synth(ddir, gk, GM_VOICES[0][0], text)
            raise
    if voice_id.startswith(GM):
        if not gk:
            raise RuntimeError("sem chave do Gemini")
        return gm_synth(ddir, gk, voice_id[len(GM):], text)
    if voice_id.startswith(EL):
        if el_out_of_credits(ddir):
            return reserve()
        try:
            return _say_el(ddir, c, el, voice_id, text)
        except RuntimeError as ex:
            m = str(ex).lower()
            if "quota" in m or "credits" in m or "plano pago" in m:
                _mark_out_of_credits(ddir)
                return reserve()
            raise
    if not az:
        if ed_available():
            return ed_synth(ddir, ED_VOICES[0][0], text)
        if gk:
            return gm_synth(ddir, gk, GM_VOICES[0][0], text)
        raise RuntimeError("sem chave de voz")
    return synth(ddir, az, region, voice_id, text)


def _say_el(ddir, c, el, voice_id, text):
    if voice_id.startswith(EL):
        if not el:
            raise RuntimeError("sem chave da ElevenLabs")
        first = voice_id[len(EL):]
        cands = [first] + [v for v, _ in el_voices(ddir, el) if v != first]
        for vid in cands[:10]:
            if vid in el_blocked(ddir):
                continue
            try:
                wav = el_synth(ddir, el, vid, text)
                LAST["sub"] = None if vid == first else dict(el_voices(ddir, el)).get(vid, vid)
                return wav
            except RuntimeError as ex:
                if "library" in str(ex).lower():      # voz da biblioteca: so no plano pago. Tira da lista e tenta a proxima
                    _block(ddir, vid)
                    continue
                raise
        raise RuntimeError("nenhuma voz da sua conta funciona no plano grátis. Na ElevenLabs, crie uma voz sua em Voices > Create > Voice Design "
                           "(ex.: 'mulher brasileira jovem, voz natural e clara') e salve: ela aparece aqui na lista")
    raise RuntimeError("voz desconhecida")


def wav_level(wav):
    """Volume do audio de 0 a 1 (pico do RMS em janelas de 50 ms). None se nao for WAV legivel."""
    import io, wave, array, math
    try:
        w = wave.open(io.BytesIO(wav))
        sw, rate, raw = w.getsampwidth(), w.getframerate(), w.readframes(w.getnframes())
    except Exception:
        return None
    if sw == 2:
        a, full = array.array("h", raw[: len(raw) // 2 * 2]), 32768.0
    elif sw == 1:
        a, full = array.array("h", (b - 128 for b in raw)), 128.0
    else:
        return None
    step = max(1, int(rate * w.getnchannels() * 0.05))
    best = 0.0
    for k in range(0, len(a), step):
        chunk = a[k:k + step]
        if chunk:
            best = max(best, math.sqrt(sum(x * x for x in chunk) / len(chunk)) / full)
    return best


NO_SPEECH = ("nenhum fala", "nenhuma fala", "sem fala", "silêncio", "silencio", "não há fala", "nao ha fala", "(vazio)", "vazio")


def fix_champs(text, context, all_names):
    """Troca nome de campeao que o reconhecimento de voz ouviu errado pelo parecido que ESTA na partida/selecao.
    Ex.: 'Ivern ta forte' com Riven no jogo e sem Ivern -> 'Riven ta forte'. context/all_names: nomes de exibicao."""
    import difflib
    import re as _re
    ctx_low = {c.lower(): c for c in context if c}
    if not text or not ctx_low:
        return text
    all_low = {n.lower() for n in all_names if n}

    def troca(m):
        lw = m.group(0).lower()
        if lw in ctx_low or lw not in all_low:      # ja esta na partida, ou nao e nome de campeao
            return m.group(0)
        hit = difflib.get_close_matches(lw, list(ctx_low), n=1, cutoff=0.6)
        return ctx_low[hit[0]] if hit else m.group(0)
    return _re.sub(r"[A-Za-zÀ-ÿ']+", troca, text)


def gm_stt(gk, wav, hint=""):
    """Fala -> texto pelo Gemini (gratis, a mesma chave da IA). wav: bytes. hint: nomes que podem aparecer (campeoes da partida)."""
    import base64
    body = json.dumps({"contents": [{"parts": [
        {"text": "Transcreva exatamente o que a pessoa falou, em português do Brasil, durante uma partida de League of Legends. "
                 "Responda só com a transcrição, sem comentários. Se não houver fala, responda vazio. "
                 "Termos comuns: flash, ult, ultimate, ignite, TP, exaust, heal, barreira, cleanse, mid, top, jungle, jungler, adc, sup, dragão, barão, arauto, larvas, torre, inibidor, wave, gank, roam, recall, base, item, build, runa, counter, matchup."
                 + (f" Campeões nesta partida: {hint}. Se ouvir um nome parecido com um destes, escreva o desta lista." if hint else "")},
        {"inline_data": {"mime_type": "audio/wav", "data": base64.b64encode(wav).decode()}}]}],
        "generationConfig": {"temperature": 0}}).encode("utf-8")
    from . import ai
    try:
        data = ai.gemini_call(gk, json.loads(body), timeout=15, lite=False)   # o lite errava muito a fala
    except urllib.error.HTTPError as ex:
        raise RuntimeError({429: "limite grátis do Gemini atingido por agora"}.get(
            ex.code, "o Gemini está sobrecarregado agora, fale de novo em alguns segundos" if ex.code >= 500 else f"Gemini respondeu {ex.code}"))
    except (TimeoutError, OSError):
        raise RuntimeError("o Gemini demorou para transcrever, fale de novo")
    try:
        txt = "".join(p.get("text", "") for p in data["candidates"][0]["content"]["parts"]).strip()
    except Exception:
        return ""
    low = txt.lower().strip(" .!\"'")
    if not low or any(low.startswith(n) for n in NO_SPEECH) or sum(ch.isalpha() for ch in low) < 3:
        return ""          # silencio, "00:00" e outros chutes do modelo
    return txt


def el_stt(key, wav):
    """Fala -> texto (ElevenLabs Speech to Text). wav: bytes."""
    import uuid
    b = "----carry" + uuid.uuid4().hex
    parts = []
    for name, val in (("model_id", "scribe_v1"), ("language_code", "por")):
        parts.append(f"--{b}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n{val}\r\n".encode())
    parts.append(f"--{b}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"pergunta.wav\"\r\nContent-Type: audio/wav\r\n\r\n".encode() + wav + b"\r\n")
    parts.append(f"--{b}--\r\n".encode())
    req = urllib.request.Request(EL_API + "/speech-to-text", data=b"".join(parts), method="POST",
                                 headers={"xi-api-key": key, "Content-Type": f"multipart/form-data; boundary={b}", "User-Agent": "carry"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return (json.loads(r.read().decode("utf-8")).get("text") or "").strip()
    except urllib.error.HTTPError as ex:
        detail = ""
        try:
            detail = ex.read().decode("utf-8", "ignore")
        except Exception:
            pass
        raise RuntimeError(f"a ElevenLabs não transcreveu a pergunta ({ex.code}): {_el_message(detail)}")
