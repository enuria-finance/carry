"""Pronuncia dos termos de LoL na voz: troca so o texto FALADO (a tela continua com a grafia certa).
O usuario ajusta em Administracao > Pronuncia (uma regra por linha: palavra = como falar)."""
import json
import os
import re

PADRAO = {
    "gank": "guénk", "ganks": "guénks", "gankar": "guencar", "gankou": "guencou", "gankando": "guencando", "ganka": "guenca", "jungler": "djângler", "junglers": "djânglers", "jungle": "djângou", "PDL": "pê dê éle",
    "ADC": "a dê cê", "lane": "lêin", "mid": "míd", "wave": "uêiv", "ward": "uórd", "Smite": "Smáit",
    "Lee Sin": "Li Sin", "LeeSin": "Li Sin", "Kai'Sa": "Kaíssa", "Cho'Gath": "Tchô Gát", "Kha'Zix": "Kazíks", "Vel'Koz": "Vélkoz",
    "Rek'Sai": "Rék Sai", "Kog'Maw": "Kógmau", "Bel'Veth": "Bélvet", "K'Sante": "Kei Sânte", "Jhin": "Djín", "Jinx": "Djinks",
    "Jax": "Djéks", "Jayce": "Djêis", "Graves": "Grêivs", "Draven": "Dréiven", "Thresh": "Tréch", "Wukong": "Uucóng",
    "Yasuo": "Iassúo", "Yone": "Iônê", "Twisted Fate": "Tuísted Fêit", "Caitlyn": "Kêitlin", "Ezreal": "Ézrial",
    "Kayn": "Kêin", "Viego": "Viêgo", "Hecarim": "Récarim", "LeBlanc": "Lebláns", "Leblanc": "Lebláns", "Vayne": "Vêin",
    "Sylas": "Sáilas", "Aatrox": "Átroks", "Akshan": "Ákchan", "Briar": "Bráiar", "Nocturne": "Nóctârn",
    "Kayle": "Kêil", "Pyke": "Páik", "Seraphine": "Sérafin", "Smolder": "Smôlder", "Hwei": "Ruêi", "Naafiri": "Nafíri",
}
USER = {}
_RX = None


def load(ddir):
    """Le as regras do usuario (pronuncia.json na pasta de dados)."""
    global USER, _RX
    try:
        with open(os.path.join(ddir, "pronuncia.json"), encoding="utf-8") as fh:
            d = json.load(fh)
        USER = {str(k): str(v) for k, v in d.items() if k and v} if isinstance(d, dict) else {}
    except Exception:
        USER = {}
    _RX = None


def save(ddir, text):
    """Texto do formulario ('palavra = como falar' por linha) -> arquivo. Devolve quantas regras ficaram."""
    rules = {}
    for ln in (text or "").splitlines():
        if "=" in ln:
            a, b = ln.split("=", 1)
            a, b = a.strip(), b.strip()
            if a and b and len(a) <= 40 and len(b) <= 60:
                rules[a] = b
    with open(os.path.join(ddir, "pronuncia.json"), "w", encoding="utf-8") as fh:
        json.dump(rules, fh, ensure_ascii=False, indent=1)
    load(ddir)
    return len(rules)


def as_text():
    return "\n".join(f"{k} = {v}" for k, v in USER.items())


def _table():
    global _RX
    if _RX is None:
        t = dict(PADRAO)
        t.update(USER)
        keys = sorted(t, key=len, reverse=True)
        rx = re.compile(r"(?<![\wÀ-ÿ'])(" + "|".join(re.escape(k) for k in keys) + r")(?![\wÀ-ÿ'])", re.IGNORECASE)
        low = {k.lower(): v for k, v in t.items()}
        _RX = (rx, low)
    return _RX


def fix(text):
    if not text:
        return text
    rx, low = _table()
    return rx.sub(lambda m: low.get(m.group(1).lower(), m.group(1)), text)
