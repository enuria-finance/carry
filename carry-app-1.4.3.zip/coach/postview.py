"""Blocos visuais do pos-jogo (placar, radar, ouro por minuto, confronto de rota, fases, mapa).

Tudo vem das suas partidas ja sincronizadas (API oficial da Riot). Medias = as SUAS
outras partidas (nao ha media do elo aqui). Cada bloco diz de onde vem o numero.
"""
import math

from . import db, report

ORDER = ["TOP", "JUNGLE", "MIDDLE", "BOTTOM", "UTILITY"]
LANE_PT = {"TOP": "Topo", "JUNGLE": "Selva", "MIDDLE": "Meio", "BOTTOM": "Atirador", "UTILITY": "Suporte"}
from . import mapa as _mapa
import urllib.parse as _up
# mapa desenhado em vetor (nítido em qualquer tamanho), no lugar da imagem 512 px do Data Dragon
MAP_IMG = "data:image/svg+xml," + _up.quote("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'>" + _mapa.base(1) + "</svg>", safe="")
MAP_MAX = 14870


def _players(con, mid):
    rows = [dict(r) for r in con.execute("SELECT * FROM participants WHERE match_id=?", (mid,))]
    rows.sort(key=lambda r: (r["team_id"], ORDER.index(r["position"]) if r["position"] in ORDER else 9))
    return rows


def _last_level(con, mid, pid):
    r = con.execute("SELECT level FROM frames WHERE match_id=? AND participant_id=? ORDER BY minute DESC LIMIT 1",
                    (mid, pid)).fetchone()
    return r[0] if r else None


def scoreboard(con, mid, my_pid):
    out = {100: [], 200: []}
    for p in _players(con, mid):
        out[p["team_id"]].append(dict(p, level=_last_level(con, mid, p["participant_id"]),
                                      me=p["participant_id"] == my_pid))
    return out


def _damage(con, mid, pid):
    raw = db.load_raw(con, mid, "match")
    try:
        return raw["info"]["participants"][pid - 1]["totalDamageDealtToChampions"]
    except (TypeError, KeyError, IndexError):
        return None


def radar_data(con, puuid, mid):
    """[(rotulo, valor, media_das_outras, texto)] ou None. Media = suas outras partidas."""
    games = report.my_games(con, puuid, "")
    g = next((x for x in games if x["match_id"] == mid), None)
    if not g:
        return None
    others = [x for x in games if x["match_id"] != mid]

    def kda(x):
        return (x["kills"] + x["assists"]) / max(x["deaths"], 1)

    def dpm(x):
        d = _damage(con, x["match_id"], x["participant_id"])
        return d / (x["duration_s"] / 60) if d is not None and x["duration_s"] else None

    metrics = [("CS/min", "cs_per_min", "{:.1f}"), ("KDA", kda, "{:.2f}"),
               ("Part. em abates", lambda x: (x["kp"] * 100) if x["kp"] is not None else None, "{:.0f}%"),
               ("Visão/min", "vision_per_min", "{:.1f}"), ("Dano/min", dpm, "{:.0f}")]
    out = []
    for label, f, fmt in metrics:
        fn = (lambda x, k=f: x[k]) if isinstance(f, str) else f
        v = fn(g)
        vals = [y for y in (fn(o) for o in others) if y is not None]
        avg = sum(vals) / len(vals) if vals else None
        out.append((label, v, avg, fmt))
    return out


def radar_svg(data, e):
    if not data:
        return ""
    cx, cy, R = 210, 160, 110
    n = len(data)
    ang = [-math.pi / 2 + i * 2 * math.pi / n for i in range(n)]
    pt = lambda i, r: (cx + r * math.cos(ang[i]), cy + r * math.sin(ang[i]))
    s = ["<svg class='radar' viewBox='0 0 420 330' role='img' aria-label='Perfil de desempenho'>"]
    for k in (0.5, 1.0, 1.5):
        s.append("<polygon class='%s' points='%s'/>" % ("ring1" if k == 1.0 else "ringg",
                 " ".join("%.1f,%.1f" % pt(i, R * k / 1.5) for i in range(n))))
    for i in range(n):
        x, y = pt(i, R)
        s.append(f"<line class='spoke' x1='{cx}' y1='{cy}' x2='{x:.1f}' y2='{y:.1f}'/>")
    shape = []
    for i, (label, v, avg, fmt) in enumerate(data):
        ratio = 1.0 if (v is None or not avg) else max(0.05, min(v / avg, 1.5))
        shape.append(pt(i, R * ratio / 1.5))
        lx, ly = pt(i, R + 34)
        vt = "—" if v is None else fmt.format(v)
        at = "" if not avg else "média " + fmt.format(avg)
        anchor = "middle" if abs(lx - cx) < 20 else ("start" if lx > cx else "end")
        s.append(f"<text class='rl' x='{lx:.0f}' y='{ly - 10:.0f}' text-anchor='{anchor}'>{e(label)}</text>"
                 f"<text class='rv' x='{lx:.0f}' y='{ly + 5:.0f}' text-anchor='{anchor}'>{e(vt)}</text>"
                 f"<text class='ra' x='{lx:.0f}' y='{ly + 19:.0f}' text-anchor='{anchor}'>{e(at)}</text>")
    s.append("<polygon class='shape' points='%s'/>" % " ".join("%.1f,%.1f" % p for p in shape))
    for x, y in shape:
        s.append(f"<circle class='dot' cx='{x:.1f}' cy='{y:.1f}' r='3.5'/>")
    s.append("</svg>")
    return "".join(s)


def gold_series(con, mid, my_team):
    """[(minuto, diferenca de ouro do seu time)] a partir dos frames por minuto."""
    team = {p["participant_id"]: p["team_id"] for p in _players(con, mid)}
    by_min = {}
    for r in con.execute("SELECT participant_id, minute, gold FROM frames WHERE match_id=?", (mid,)):
        if r["gold"] is None:
            continue
        d = by_min.setdefault(r["minute"], 0)
        by_min[r["minute"]] = d + (r["gold"] if team.get(r["participant_id"]) == my_team else -r["gold"])
    return sorted(by_min.items())


def objective_events(con, mid, my_team):
    """Objetivos (dragao/barao/arauto/torre/inibidor) com o minuto e de quem foi."""
    out = []
    for r in con.execute("SELECT t_ms, type, team_id, x, y, data FROM events WHERE match_id=? AND "
                         "type IN ('ELITE_MONSTER_KILL','BUILDING_KILL') ORDER BY t_ms", (mid,)):
        out.append(dict(r))
    return out


def gold_svg(series, objs, my_team, e):
    if len(series) < 2:
        return "<p class='n'>Sem timeline desta partida: não há gráfico de ouro.</p>"
    W, H, L, T, B = 1000, 220, 50, 14, 24
    lim = max(1000, max(abs(v) for _, v in series))
    xs = lambda m: L + (W - L - 10) * m / series[-1][0]
    ys = lambda v: T + (H - T - B) * (1 - (v + lim) / (2 * lim))
    y0 = ys(0)
    pts = " ".join(f"{xs(m):.1f},{ys(v):.1f}" for m, v in series)
    s = [f"<svg class='gold' viewBox='0 0 {W} {H}' role='img' aria-label='Diferença de ouro entre as equipes'>",
         f"<line class='z' x1='{L}' x2='{W - 10}' y1='{y0:.1f}' y2='{y0:.1f}'/>",
         f"<text class='ax' x='6' y='{ys(lim) + 4:.0f}'>+{lim / 1000:.1f}k</text>",
         f"<text class='ax' x='6' y='{y0 + 4:.0f}'>0</text><text class='ax' x='6' y='{ys(-lim) + 4:.0f}'>-{lim / 1000:.1f}k</text>",
         f"<polygon class='fill' points='{L},{y0:.1f} {pts} {xs(series[-1][0]):.1f},{y0:.1f}'/>",
         f"<polyline class='line' points='{pts}'/>"]
    by_min = dict(series)
    for o in objs:
        m = min(int(o["t_ms"] // 60000), series[-1][0])
        v = by_min.get(m)
        if v is None:
            continue
        mine = o["team_id"] == my_team
        s.append(f"<circle class='{'ev me' if mine else 'ev foe'}' cx='{xs(m):.1f}' cy='{ys(v):.1f}' r='5'>"
                 f"<title>{e(_obj_name(o))} aos {m}min ({'seu time' if mine else 'inimigo'})</title></circle>")
    for m in range(0, series[-1][0] + 1, 5):
        s.append(f"<text class='ax' x='{xs(m):.0f}' y='{H - 6}' text-anchor='middle'>{m}'</text>")
    s.append("</svg>")
    return "".join(s)


def _obj_name(o):
    import json
    try:
        d = json.loads(o["data"] or "{}")
    except ValueError:
        d = {}
    if o["type"] == "ELITE_MONSTER_KILL":
        return {"DRAGON": "Dragão", "BARON_NASHOR": "Barão", "RIFTHERALD": "Arauto",
                "HORDE": "Larva do Vazio"}.get(d.get("monsterType"), "Monstro épico")
    return {"INHIBITOR_BUILDING": "Inibidor", "NEXUS_BUILDING": "Nexus"}.get(d.get("buildingType"), "Torre")


def lanes(con, mid, my_team, minute=14):
    """Confronto por rota: ouro do seu lado menos o do inimigo aos N min (ou ate onde houver)."""
    ps = _players(con, mid)
    last = con.execute("SELECT MAX(minute) FROM frames WHERE match_id=?", (mid,)).fetchone()[0]
    if last is None:
        return [], None
    m = min(minute, last)
    gold = {r["participant_id"]: r["gold"] for r in
            con.execute("SELECT participant_id, gold FROM frames WHERE match_id=? AND minute=?", (mid, m))}
    out = []
    for pos in ORDER:
        a = next((p for p in ps if p["team_id"] == my_team and p["position"] == pos), None)
        b = next((p for p in ps if p["team_id"] != my_team and p["position"] == pos), None)
        if a and b and a["participant_id"] in gold and b["participant_id"] in gold:
            out.append((pos, a, b, gold[a["participant_id"]] - gold[b["participant_id"]]))
    return out, m


PHASES = [("Início (fase de rotas)", 0, 14), ("Meio de jogo", 14, 28), ("Fim de jogo", 28, 999)]


def phases(con, mid, my_pid, opp_pid, duration_s):
    """Por fase: CS/min, abates e mortes seus, ouro vs oponente no fim da fase."""
    mins = duration_s / 60 if duration_s else 0
    rows = {r["minute"]: dict(r) for r in con.execute(
        "SELECT * FROM frames WHERE match_id=? AND participant_id=?", (mid, my_pid))}
    orows = {r["minute"]: dict(r) for r in con.execute(
        "SELECT * FROM frames WHERE match_id=? AND participant_id=?", (mid, opp_pid))} if opp_pid else {}
    out = []
    for name, a, b in PHASES:
        if mins <= a or not rows:
            out.append((name, None))
            continue
        end = min(b, int(mins), max(rows))
        start = a
        if end <= start:
            out.append((name, None))
            continue
        cs = (rows[end]["cs"] - rows.get(start, rows[min(rows)])["cs"]) / (end - start)
        k = con.execute("SELECT COUNT(*) FROM deaths WHERE match_id=? AND killer_id=? AND t_ms>=? AND t_ms<?",
                        (mid, my_pid, a * 60000, b * 60000)).fetchone()[0]
        d = con.execute("SELECT COUNT(*) FROM deaths WHERE match_id=? AND victim_id=? AND t_ms>=? AND t_ms<?",
                        (mid, my_pid, a * 60000, b * 60000)).fetchone()[0]
        gd = (rows[end]["gold"] - orows[end]["gold"]) if end in orows and rows[end]["gold"] is not None else None
        out.append((name, {"cs": cs, "k": k, "d": d, "gd": gd, "from": start, "to": end}))
    return out


def map_points(con, mid, my_team):
    team = {p["participant_id"]: p["team_id"] for p in _players(con, mid)}
    pts = []
    for r in con.execute("SELECT t_ms, victim_id, killer_id, x, y FROM deaths WHERE match_id=? AND x IS NOT NULL ORDER BY t_ms", (mid,)):
        pts.append({"t": r["t_ms"], "x": r["x"], "y": r["y"], "kind": "kill",
                    "mine": team.get(r["killer_id"]) == my_team, "victim": r["victim_id"], "killer": r["killer_id"]})
    for o in objective_events(con, mid, my_team):
        if o["x"] is not None:
            pts.append({"t": o["t_ms"], "x": o["x"], "y": o["y"], "kind": "obj",
                        "mine": o["team_id"] == my_team, "name": _obj_name(o)})
    pts.sort(key=lambda p: p["t"])
    return pts


def map_html(pts, names, duration_s, e, icon=None):
    """Mapa com os abates e objetivos; o controle desliza no tempo (so mostra o que ja aconteceu)."""
    if not pts:
        return "<p class='n'>Sem posições de eventos nesta partida (sem timeline).</p>"
    dots, rows = [], []
    for p in pts:
        left = 100 * p["x"] / MAP_MAX
        top = 100 - 100 * p["y"] / MAP_MAX
        mm = f"{p['t'] // 60000}:{(p['t'] // 1000) % 60:02d}"
        if p["kind"] == "kill":
            kn, vn = names.get(p["killer"], "?"), names.get(p["victim"], "?")
            who = f"{kn} abateu {vn}"
            cls = "pk me" if p["mine"] else "pk foe"
            inner = icon(kn, 26, "me" if p["mine"] else "foe") if icon else ""
            row_icons = (icon(kn, 24, "me" if p["mine"] else "foe") + "<span class='arrow'>⚔</span>" + icon(vn, 24, "foe" if p["mine"] else "me")) if icon else ""
        else:
            who = p["name"] + (" (seu time)" if p["mine"] else " (inimigo)")
            cls = "po me" if p["mine"] else "po foe"
            inner = ""
            row_icons = "<span class='obj'>◆</span>"
        dots.append(f"<i class='{cls}' data-t='{p['t']}' style='left:{left:.1f}%;top:{top:.1f}%' title='{e(mm)} {e(who)}'>{inner}</i>")
        rows.append(f"<li data-t='{p['t']}'><b>{e(mm)}</b><span class='ev'>{row_icons}</span><span>{e(who)}</span></li>")
    total = max(int(duration_s or 0) * 1000, pts[-1]["t"])
    return ("<div class='mapwrap'><div class='map' style=\"background-image:url('" + MAP_IMG + "')\">" + "".join(dots) + "</div>"
            "<div class='maplist'><label class='n'>Tempo: <output id='mt'>fim</output></label>"
            f"<input type='range' id='mr' min='0' max='{total}' step='1000' value='{total}'>"
            "<ul>" + "".join(rows) + "</ul></div></div>"
            "<script>(function(){var r=document.getElementById('mr'),o=document.getElementById('mt');"
            "function f(){var v=+r.value;o.textContent=Math.floor(v/60000)+':'+('0'+Math.floor(v/1000)%60).slice(-2);"
            "document.querySelectorAll('.map i,.maplist li').forEach(function(n){n.style.display=(+n.dataset.t<=v)?'':'none'})}"
            "r.addEventListener('input',f);f()})();</script>")


def mastery_html(con, games, champion, champ_key, e):
    """Maestria (API oficial) + a SUA evolucao de vitorias com o campeao nas partidas sincronizadas."""
    row = None
    try:
        row = con.execute("SELECT level, points FROM mastery_me WHERE champion_id=?", (champ_key,)).fetchone()
    except Exception:
        row = None
    mine = [g for g in games if g["champion"] == champion]  # mais novas primeiro
    out = ""
    if row:
        out += (f"<div class='stat'><b>{row['level']}</b><span>nível de maestria</span></div>"
                f"<div class='stat'><b>{row['points']:,}</b><span>pontos de maestria</span></div>".replace(",", "."))
    else:
        out += "<p class='n'>Sem dados de maestria ainda: sincronize (a maestria vem junto).</p>"
    n = len(mine)
    if n >= 10:
        k = max(5, n // 3)
        recent, old = mine[:k], mine[-k:]
        wr = lambda xs: round(100 * sum(1 for x in xs if x["win"]) / len(xs))
        out += (f"<div class='stat'><b>{wr(old)}% → {wr(recent)}%</b><span>vitórias com {e(champion)}: {k} jogos mais antigos → {k} mais novos</span></div>"
                f"<p class='n'><span class='tag dado'>dado</span> {n} jogos seus com {e(champion)} sincronizados "
                f"{'(amostra pequena: não é conclusivo)' if n < 30 else ''}</p>")
    else:
        out += f"<p class='n'><span class='tag dado'>dado</span> {n} jogo(s) seus com {e(champion)}: poucos para ver evolução (precisa de 10 ou mais).</p>"
    return out
