"""Coach IA: conversa sobre o SEU jogo. Usa a API do Claude (Anthropic) com ferramentas que leem os seus dados.

O modelo nunca recebe a sua senha nem a chave da Riot; recebe so os numeros das suas partidas quando pede uma ferramenta.
A chave da Anthropic fica com o admin (config.json ou variavel ANTHROPIC_API_KEY).
"""
import html
import json
import re
import time
import urllib.error
import urllib.request

from . import diagnosis, habits, insights, report

API = "https://api.anthropic.com/v1/messages"
DEFAULT_MODEL = "claude-sonnet-5-5"
MAX_TOOL_ROUNDS = 6
DAILY_LIMIT = 40

SYSTEM = """Você é o coach de League of Legends do app LoL Coach, conversando em português do Brasil com o jogador.
Seu objetivo é fazer ele subir de elo com conselhos práticos baseados nos DADOS DELE.

Regras:
- Antes de afirmar algo sobre o jogo dele, use as ferramentas para buscar os números. Nunca invente estatística.
- Sempre diga o tamanho da amostra (ex.: "em 12 jogos"). Com menos de 10 jogos, diga que é tendência, não conclusão.
- Marque cada afirmação importante com [dado] (veio dos números dele), [regra geral] (conhecimento do jogo) ou [hipótese] (sua interpretação).
- Para perguntas táticas (ex.: o mid inimigo roama muito, como jogar contra Ahri), dê regras gerais do LoL claras e cruze com os dados dele quando houver.
- Formato (use exatamente estes títulos em negrito, cada um numa linha sozinha terminando com dois pontos):
  **Resposta:** 1 a 2 frases diretas.
  **O que os seus números mostram:** 2 a 4 itens em lista ("- ") com os dados e a amostra.
  **O que fazer na próxima partida:** 3 a 5 ações concretas em lista ("- "), específicas para o campeão e a rota dele.
- Leve em conta o estilo do campeão: um assassino como Zed farma com habilidades (W/E/Q) no começo para não trocar dano à toa; não mande "trocar mais" ou "farmar com ataque básico" se isso contraria o campeão. Se o jogador explicar como joga, aceite e adapte o conselho.
- Você não vê a partida em andamento; trabalhe com o que ele conta e com as partidas salvas.
- Não dê conselhos que dependam de trapaça, programas de terceiros dentro do jogo ou quebra das regras da Riot."""

TOOLS = [
    {"name": "resumo_jogador", "description": "Resumo do jogador: elo, campeão e posição principais, winrate, médias (mortes antes dos 10, CS/min, diferença de CS aos 10, ouro aos 15, visão, participação em abates) nos últimos 10 jogos e no total.",
     "input_schema": {"type": "object", "properties": {}}},
    {"name": "diagnostico", "description": "O que mais separa as vitórias das derrotas dele (fatores, grupos, winrate e número de jogos de cada grupo).",
     "input_schema": {"type": "object", "properties": {}}},
    {"name": "confronto", "description": "Histórico dele contra um campeão inimigo de rota: resultado, KDA, farm e mortes cedo nesses jogos, e com quais campeões ele enfrentou.",
     "input_schema": {"type": "object", "properties": {"campeao": {"type": "string", "description": "Nome do campeão inimigo, ex.: Ahri"}}, "required": ["campeao"]}},
    {"name": "farm", "description": "Farm dele: CS aos 10, CS/min, diferença de CS aos 10 por campeão e a tendência recente; compara com a amostra do topo/elo se existir.",
     "input_schema": {"type": "object", "properties": {}}},
    {"name": "campeao", "description": "Desempenho dele com um campeão específico.",
     "input_schema": {"type": "object", "properties": {"nome": {"type": "string"}}, "required": ["nome"]}},
    {"name": "partidas_recentes", "description": "Lista das últimas partidas (campeão, oponente, resultado, KDA, CS, mortes antes dos 10).",
     "input_schema": {"type": "object", "properties": {"quantidade": {"type": "integer", "minimum": 1, "maximum": 20}}}},
    {"name": "habitos", "description": "Rendimento por horário, sequência atual de derrotas e como ele joga depois de perder.",
     "input_schema": {"type": "object", "properties": {}}},
]

KEYS = [("deaths_before_10", "mortes antes dos 10", 2), ("cs_per_min", "CS/min", 1), ("cs10", "CS aos 10", 0),
        ("csdiff10", "diferença de CS aos 10", 1), ("golddiff15", "diferença de ouro aos 15", 0),
        ("vision_per_min", "visão por minuto", 2), ("kp", "participação em abates", 2)]


def _avg(gs, k):
    v = [g[k] for g in gs if g.get(k) is not None]
    return (round(sum(v) / len(v), 2), len(v)) if v else (None, 0)


def _stats(gs):
    out = {"jogos": len(gs), "vitorias": sum(1 for g in gs if g["win"])}
    if gs:
        out["winrate_pct"] = round(100 * out["vitorias"] / len(gs))
        out["kda_medio"] = f"{sum(g['kills'] for g in gs) / len(gs):.1f}/{sum(g['deaths'] for g in gs) / len(gs):.1f}/{sum(g['assists'] for g in gs) / len(gs):.1f}"
    for k, label, _ in KEYS:
        v, n = _avg(gs, k)
        if v is not None:
            out[label] = v
    return out


def run_tool(name, args, con, puuid, link, tier_games=None):
    games = report.my_games(con, puuid, "")
    if name == "resumo_jogador":
        by = report.by_key(games, "champion")
        pos = {}
        for g in games:
            pos[g["position"]] = pos.get(g["position"], 0) + 1
        return {"elo": (f"{link['tier']} {link['division'] or ''} {link['lp'] or 0} PDL" if link and link["tier"] else "desconhecido"),
                "campeoes_mais_jogados": [{"campeao": n, "jogos": k, "winrate_pct": round(100 * wr)} for n, k, w, wr in sorted(by, key=lambda r: -r[1])[:5]],
                "posicoes": pos, "ultimos_10": _stats(games[:10]), "total": _stats(games)}
    if name == "diagnostico":
        if len(games) < 20:
            return {"aviso": f"Só {len(games)} partidas; o diagnóstico precisa de 20+."}
        return {"fatores": [{"fator": l["title"], "pesa": l["pesa"], "diferenca_pontos": l["gap"],
                             "grupos": [{"grupo": g["label"], "winrate_pct": g["wr"], "jogos": g["n"]} for g in l["groups"]]}
                            for l in diagnosis.levers(games)[:8]]}
    if name == "confronto":
        c = (args.get("campeao") or "").strip().lower()
        sel = [g for g in games if (g.get("opp_champion") or "").lower() == c]
        mine = {}
        for g in sel:
            mine.setdefault(g["champion"], []).append(g)
        return {"campeao_inimigo": args.get("campeao"), "nesses_jogos": _stats(sel),
                "com_qual_campeao": {k: _stats(v) for k, v in mine.items()},
                "comparacao_media_geral": _stats(games)}
    if name == "farm":
        by = {}
        for g in games:
            by.setdefault(g["champion"], []).append(g)
        out = {"geral": {k: v for k, v in _stats(games).items() if "CS" in k or k == "jogos"},
               "ultimos_10": {k: v for k, v in _stats(games[:10]).items() if "CS" in k or k == "jogos"},
               "por_campeao": {n: {"jogos": len(gs), "CS/min": _avg(gs, "cs_per_min")[0], "diferença de CS aos 10": _avg(gs, "csdiff10")[0]}
                               for n, gs in sorted(by.items(), key=lambda kv: -len(kv[1]))[:6]}}
        if tier_games:
            out["mediana_do_proximo_elo"] = {"CS/min": insights._median([g["cs_per_min"] for g in tier_games if g.get("cs_per_min")]),
                                             "CS aos 10": insights._median([g["cs10"] for g in tier_games if g.get("cs10") is not None]),
                                             "jogos_na_amostra": len(tier_games)}
        return out
    if name == "campeao":
        n = (args.get("nome") or "").strip().lower()
        return {"campeao": args.get("nome"), **_stats([g for g in games if g["champion"].lower() == n])}
    if name == "partidas_recentes":
        q = max(1, min(int(args.get("quantidade") or 8), 20))
        return [{"data": time.strftime("%d/%m %H:%M", time.localtime((g["started_ms"] or 0) / 1000)), "campeao": g["champion"],
                 "contra": g.get("opp_champion"), "resultado": "vitória" if g["win"] else "derrota",
                 "kda": f"{g['kills']}/{g['deaths']}/{g['assists']}", "cs": g["cs"], "mortes_antes_dos_10": g.get("deaths_before_10")}
                for g in games[:q]]
    if name == "habitos":
        lv = next((l for l in diagnosis.levers(games) if l["key"] == "tilt"), None) if len(games) >= 20 else None
        return {"por_horario": [{"periodo": p["period"], "jogos": p["n"], "winrate_pct": round(p["wr"])} for p in habits.by_period(con, puuid)],
                "sequencia_atual_de_derrotas": habits.two_loss_rule(con, puuid)["streak"],
                "depois_de_derrota": ([{"grupo": g["label"], "winrate_pct": g["wr"], "jogos": g["n"]} for g in lv["groups"]] if lv else None)}
    return {"erro": "ferramenta desconhecida"}


# ---- historico da conversa (no banco do proprio usuario) ----------------------
def _ensure(con):
    con.execute("CREATE TABLE IF NOT EXISTS chat (id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT, text TEXT, at_ms INTEGER)")


def history(con, limit=40):
    _ensure(con)
    rows = con.execute("SELECT role, text, at_ms FROM chat ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in reversed(rows)]


def clear(con):
    _ensure(con)
    con.execute("DELETE FROM chat")
    con.commit()


def used_today(con):
    _ensure(con)
    start = int(time.mktime(time.localtime()[:3] + (0, 0, 0, 0, 0, -1)) * 1000)
    return con.execute("SELECT COUNT(*) FROM chat WHERE role='user' AND at_ms>=?", (start,)).fetchone()[0]


def _call(key, model, messages):
    from . import ai
    body = {"model": model, "max_tokens": 1200, "system": SYSTEM, "messages": messages}
    if not ai.is_gemini(key):
        body["tools"] = TOOLS
    try:
        return ai.post(key, body, 90)
    except urllib.error.HTTPError as ex:
        detail = ex.read().decode("utf-8", "replace")[:300]
        if ex.code in (401, 403):
            raise RuntimeError("A chave da Anthropic foi recusada. O admin precisa conferir a chave em Administração.")
        if ex.code == 429:
            raise RuntimeError("Muitas perguntas ao mesmo tempo. Espere um pouco e tente de novo.")
        if "credit" in detail.lower() or "crédito" in detail.lower() or "saldo" in detail.lower():
            raise RuntimeError("A chave funcionou, mas a sua conta da Anthropic está sem crédito. Compre crédito em platform.claude.com, em Settings > Billing, e pergunte de novo.")
        raise RuntimeError(f"O serviço de IA respondeu com erro {ex.code}: {detail}")
    except urllib.error.URLError as ex:
        raise RuntimeError(f"Sem conexão com o serviço de IA: {ex.reason}")


def ask(con, puuid, link, key, model, text, tier_games=None):
    """Pergunta -> resposta (texto). Salva os dois lados no historico."""
    _ensure(con)
    msgs = [{"role": h["role"], "content": h["text"]} for h in history(con, 16)]
    msgs.append({"role": "user", "content": text})
    con.execute("INSERT INTO chat (role, text, at_ms) VALUES ('user', ?, ?)", (text, int(time.time() * 1000)))
    con.commit()
    reply = ""
    from . import ai
    if ai.is_gemini(key):      # sem ferramentas: manda os numeros dele junto com a pergunta
        ctx = {}
        for nm, args in (("resumo_jogador", {}), ("diagnostico", {}), ("farm", {}), ("partidas_recentes", {"quantidade": 10}), ("habitos", {})):
            try:
                ctx[nm] = run_tool(nm, args, con, puuid, link, tier_games)
            except Exception:
                pass
        low = text.lower()
        for g in report.my_games(con, puuid, "")[:200]:
            oc = (g.get("opp_champion") or "")
            if oc and oc.lower() in low:
                ctx["confronto"] = run_tool("confronto", {"campeao": oc}, con, puuid, link, tier_games)
                break
        msgs[-1] = {"role": "user", "content": "Dados do jogador (JSON, vindos das partidas dele):\n" + json.dumps(ctx, ensure_ascii=False)[:12000]
                    + "\n\nPergunta: " + text}
    for _ in range(MAX_TOOL_ROUNDS + 1):
        res = _call(key, model or DEFAULT_MODEL, msgs)
        content = res.get("content") or []
        if res.get("stop_reason") == "tool_use":
            msgs.append({"role": "assistant", "content": content})
            results = []
            for b in content:
                if b.get("type") == "tool_use":
                    try:
                        out = run_tool(b["name"], b.get("input") or {}, con, puuid, link, tier_games)
                    except Exception as ex:
                        out = {"erro": str(ex)[:200]}
                    results.append({"type": "tool_result", "tool_use_id": b["id"], "content": json.dumps(out, ensure_ascii=False)})
            msgs.append({"role": "user", "content": results})
            continue
        reply = "".join(b.get("text", "") for b in content if b.get("type") == "text").strip()
        break
    reply = reply or "Não consegui montar uma resposta agora. Tente perguntar de outro jeito."
    con.execute("INSERT INTO chat (role, text, at_ms) VALUES ('assistant', ?, ?)", (reply, int(time.time() * 1000)))
    con.commit()
    return reply


def render(text):
    """Texto do coach -> HTML seguro (titulos, negrito, listas e as marcas [dado]/[regra geral]/[hipótese])."""
    out, in_list = [], False
    for line in html.escape(text or "").split("\n"):
        mt = re.match(r"^\s*(?:#+\s*)?\*\*(.+?):?\*\*:?\s*$", line) or re.match(r"^\s*#+\s*(.+?):?\s*$", line)
        if mt:
            if in_list:
                out.append("</ul>")
                in_list = False
            out.append(f"<h4>{mt.group(1).rstrip(':')}</h4>")
            continue
        mi = re.match(r"^\s*\*\*(.+?):\*\*\s*(.+)$", line)
        if mi and not re.match(r"^\s*(?:[-*•]|\d+[.)])\s+", line):
            if in_list:
                out.append("</ul>")
                in_list = False
            out.append(f"<h4>{mi.group(1)}</h4>")
            line = mi.group(2)
        line = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", line)
        line = re.sub(r"\[dado\]", "<span class='tag dado'>dado</span>", line, flags=re.I)
        line = re.sub(r"\[regra geral\]", "<span class='tag regra'>regra geral</span>", line, flags=re.I)
        line = re.sub(r"\[hip[oó]tese\]", "<span class='tag hipotese'>hipótese</span>", line, flags=re.I)
        m = re.match(r"^\s*(?:[-*•]|\d+[.)])\s+(.*)", line)
        if m:
            if not in_list:
                out.append("<ul>")
                in_list = True
            out.append(f"<li>{m.group(1)}</li>")
            continue
        if in_list:
            out.append("</ul>")
            in_list = False
        out.append(f"<p>{line}</p>" if line.strip() else "")
    if in_list:
        out.append("</ul>")
    return "".join(out)


SUGGESTIONS = [("Subir de elo", ["Por que eu não subo de elo?", "Qual campeão devo focar?", "Como estão minhas últimas partidas?"]),
               ("Rota", ["Por que estou farmando mal?", "Como jogar contra Ahri?", "Como evitar morrer antes dos 10 minutos?"]),
               ("Mapa e macro", ["O mid deles roama toda hora, o que eu faço?", "Quando devo ir para o lado e quando agrupar?"]),
               ("Cabeça", ["Perdi 2 seguidas, devo parar?", "Em que horário eu jogo melhor?"])]


def page_body(hist, enabled, csrf, left, side=""):
    bubbles = "".join(
        (f"<div class='msg me'><p>{html.escape(h['text'])}</p></div>" if h["role"] == "user" else
         f"<div class='msg bot'><div class='mh'><i class='av'>C</i><b>Coach Carry</b></div>{render(h['text'])}</div>") for h in hist)
    if not hist:
        bubbles = ("<div class='msg bot'><div class='mh'><i class='av'>C</i><b>Coach Carry</b></div><p>Oi! Eu sou o seu coach. Pergunte qualquer coisa sobre o seu jogo: "
                   "eu olho as suas partidas antes de responder e digo o que os números mostram e o que fazer na próxima.</p></div>")
    chips = "".join(f"<div class='sgg'><small>{html.escape(g)}</small>" + "".join(f"<button type='button' class='sug'>{html.escape(x)}</button>" for x in lst) + "</div>"
                    for g, lst in SUGGESTIONS)
    if not enabled:
        form = ("<div class='alert info'>O coach IA ainda não está ligado: coloque a chave do Gemini (grátis) ou da Anthropic em Administração.</div>")
    else:
        form = (f"<form id='chatf' class='chatf' autocomplete='off'><input type='hidden' id='csrf' value='{html.escape(csrf or '')}'>"
                "<textarea id='q' rows='1' maxlength='1200' placeholder='Pergunte sobre o seu jogo… (Enter envia, Shift+Enter quebra linha)'></textarea><button id='send' class='btn gold'>Enviar</button></form>"
                f"<p class='n chatn'>{left} perguntas restantes hoje · As respostas usam os números das suas partidas e podem errar: confira os dados.</p>")
    return (f"<div class='cbx'><div class='chat'><div class='chatlog' id='log'>{bubbles}</div>{form}"
            "<form method='post' action='/coach/limpar' class='row' style='justify-content:flex-end;margin:0'><button class='btn ghost'>Apagar conversa</button></form></div>"
            f"<aside class='cside'>{side}<div class='cbox'><h3>Perguntas prontas</h3>{chips}</div>"
            "<div class='cbox'><h3>Como ler as respostas</h3><p><span class='tag dado'>dado</span> veio das suas partidas</p>"
            "<p><span class='tag regra'>regra geral</span> conhecimento do jogo</p><p><span class='tag hipotese'>hipótese</span> interpretação do coach</p></div></aside></div>"
            + JS)


JS = r"""<script>(function(){var f=document.getElementById('chatf'),q=document.getElementById('q'),log=document.getElementById('log');
function down(){log.scrollTop=log.scrollHeight}down();
function add(cls,html){var d=document.createElement('div');d.className='msg '+cls;d.innerHTML=html;log.appendChild(d);down();return d}
function esc(s){var d=document.createElement('div');d.textContent=s;return d.innerHTML}
document.querySelectorAll('.sug').forEach(function(b){b.onclick=function(){if(q){q.value=b.textContent;f.requestSubmit()}}});
if(!f)return;q.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();f.requestSubmit()}});
q.addEventListener('input',function(){q.style.height='auto';q.style.height=Math.min(q.scrollHeight,160)+'px'});
f.addEventListener('submit',function(e){e.preventDefault();var t=q.value.trim();if(!t)return;q.value='';q.style.height='auto';
add('me','<p>'+esc(t)+'</p>');var w=add('bot typing','<span></span><span></span><span></span><em>olhando as suas partidas…</em>');var btn=document.getElementById('send');btn.disabled=true;
fetch('/coach/enviar',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF':document.getElementById('csrf').value},body:JSON.stringify({msg:t})})
.then(function(r){return r.json()}).then(function(d){w.className='msg bot';w.innerHTML="<div class='mh'><i class='av'>C</i><b>Coach Carry</b></div>"+(d.html||('<p>'+esc(d.error||'Erro')+'</p>'));down()})
.catch(function(){w.className='msg bot';w.innerHTML='<p>Sem resposta do app. Tente de novo.</p>'}).finally(function(){btn.disabled=false;q.focus()})});})();</script>"""

CSS = """
.cbx{display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:18px;align-items:start}
@media (max-width:1100px){.cbx{grid-template-columns:1fr}}
.chat{display:flex;flex-direction:column;gap:12px;min-width:0}
.chatlog{display:flex;flex-direction:column;gap:14px;min-height:420px;max-height:calc(100vh - 300px);overflow-y:auto;padding:20px;border:1px solid var(--rule);border-radius:16px;
background:radial-gradient(1200px 400px at 0 0,rgba(233,196,106,.05),transparent 60%),linear-gradient(180deg,rgba(28,21,20,.85),rgba(16,11,11,.95));scroll-behavior:smooth}
.msg{max-width:86%;padding:14px 18px;line-height:1.6;font-size:15px;border-radius:14px}
.msg p{margin:.25em 0}.msg ul{margin:.3em 0 .4em;padding-left:20px}.msg li{margin:.3em 0}.msg li::marker{color:var(--gold)}
.msg h4{margin:.9em 0 .3em;font:700 13px var(--head);letter-spacing:.06em;text-transform:uppercase;color:var(--gold)}.msg h4:first-of-type{margin-top:.3em}
.msg .tag{display:inline-flex;padding:0 5px;margin:0 3px;font-size:10px;vertical-align:1px;border-radius:5px}
.msg.me{align-self:flex-end;background:linear-gradient(180deg,#F1E6D3,#E6D7BD);color:#1d1513;border-radius:14px 14px 4px 14px}
.msg.bot{align-self:flex-start;background:rgba(30,23,22,.92);border:1px solid var(--rule);border-radius:14px 14px 14px 4px;box-shadow:0 10px 28px rgba(0,0,0,.25)}
.msg .mh{display:flex;align-items:center;gap:8px;margin-bottom:6px}.msg .mh b{font:700 13px var(--head);color:#fff}
.msg .av{width:24px;height:24px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;background:var(--gold);color:#1a1405;font:800 12px var(--head);font-style:normal}
.msg.typing{display:flex;gap:6px;align-items:center;padding:14px 16px}.msg.typing span{width:8px;height:8px;border-radius:50%;background:var(--gold);animation:tdot 1.2s infinite}
.msg.typing em{font-style:normal;color:var(--mute);font-size:13px;margin-left:6px}
.msg.typing span:nth-child(2){animation-delay:.2s}.msg.typing span:nth-child(3){animation-delay:.4s}
@keyframes tdot{0%,80%,100%{opacity:.25;transform:translateY(0)}40%{opacity:1;transform:translateY(-4px)}}
.cside{display:flex;flex-direction:column;gap:12px;position:sticky;top:70px}
.cbox{border:1px solid var(--rule);border-radius:14px;padding:14px 16px;background:var(--panel)}.cbox h3{margin:0 0 10px;font:700 15px var(--head);color:#fff}
.cbox p{margin:6px 0;color:#D6CCC0;font-size:13px}
.cbst{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.cbst>div{min-width:0;border:1px solid rgba(255,255,255,.06);border-radius:10px;padding:8px 10px}
.cbst small{display:block;color:var(--mute);font-size:11px}.cbst b{font:700 17px var(--head);color:#fff}.cbst b.w{color:#8FD4A8}.cbst b.l{color:#E8817C}
.sgg{display:flex;flex-direction:column;gap:6px;margin-bottom:10px}.sgg small{color:var(--mute);font:700 10.5px var(--head);text-transform:uppercase;letter-spacing:.08em}
.sug{background:rgba(200,170,110,.06) !important;border:1px solid var(--rule) !important;color:#e6dcc4 !important;font:500 13px var(--body) !important;border-radius:10px !important;
letter-spacing:0 !important;padding:8px 11px !important;text-transform:none;text-align:left;cursor:pointer}
.sug:hover{border-color:var(--gold) !important;background:rgba(233,196,106,.1) !important}
.chatf{display:flex;gap:10px;align-items:flex-end;border:1px solid var(--rule);border-radius:14px;padding:8px;background:var(--panel)}
.chatf textarea{flex:1;resize:none;min-height:44px;font:15px var(--body);padding:10px 12px;border:0 !important;background:transparent !important;box-shadow:none !important}
.chatf button{width:auto;flex:none}
.chatn{margin:0;font-size:12px}
"""


LIVE_MODEL = "claude-haiku-5-5"
LIVE_SYSTEM = """Você é a voz do coach Carry, respondendo DURANTE uma partida de League of Legends, em português do Brasil.
A resposta vai ser FALADA no ouvido do jogador enquanto ele joga: no máximo 2 frases curtas, sem listas, sem marcações, sem emojis.
Use só o resumo da partida que vem junto (é o que o placar do jogo mostra para todos) e conhecimento geral do jogo.
Você NÃO sabe onde os inimigos estão nem quando usaram habilidades ou feitiços: nunca afirme isso.
Dê informação (números, recargas, itens, regras gerais), não ordens. Se não souber, diga que não sabe em uma frase."""


def ask_live(key, model, question, snapshot):
    from . import ai
    body = {"_lite": True, "model": model or LIVE_MODEL, "max_tokens": 160, "system": LIVE_SYSTEM,
            "messages": [{"role": "user", "content": f"Resumo da partida agora:\n{snapshot}\n\nPergunta do jogador: {question}"}]}
    try:
        res = ai.post(key, body, 25)
    except urllib.error.HTTPError as ex:
        if ex.code == 404 and (model or LIVE_MODEL) != DEFAULT_MODEL:      # modelo rapido indisponivel: usa o padrao
            return ask_live(key, DEFAULT_MODEL, question, snapshot)
        raise RuntimeError(f"a IA respondeu com erro {ex.code}")
    return "".join(b.get("text", "") for b in res.get("content") or [] if b.get("type") == "text").strip()
