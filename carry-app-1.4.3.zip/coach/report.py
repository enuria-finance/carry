"""Relatorios sobre as suas partidas. Cada numero mostra quantos jogos o sustentam."""
from collections import defaultdict


def _frame(con, mid, pid, minute):
    return con.execute(
        "SELECT cs, gold FROM frames WHERE match_id=? AND participant_id=? AND minute=?",
        (mid, pid, minute),
    ).fetchone()


def _games_from_rows(con, rows):
    """Uma linha por partida, com o oponente da mesma posicao e as medidas."""
    games = []
    for r in rows:
        opp = con.execute(
            """SELECT * FROM participants WHERE match_id=? AND team_id<>?
               AND position=? LIMIT 1""",
            (r["match_id"], r["team_id"], r["position"]),
        ).fetchone()
        g = dict(r)
        g["opp_champion"] = opp["champion"] if opp else None
        g["opp_id"] = opp["participant_id"] if opp else None
        for minute in (10, 15):
            mine = _frame(con, r["match_id"], r["participant_id"], minute)
            theirs = _frame(con, r["match_id"], opp["participant_id"], minute) if opp else None
            g[f"cs{minute}"] = mine["cs"] if mine else None
            g[f"csdiff{minute}"] = (mine["cs"] - theirs["cs"]) if mine and theirs else None
            g[f"golddiff{minute}"] = (mine["gold"] - theirs["gold"]) if mine and theirs else None
        has_tl = con.execute("SELECT has_timeline FROM matches WHERE match_id=?",
                             (r["match_id"],)).fetchone()[0]
        for limit, key in ((600000, "deaths_before_10"), (900000, "deaths_before_15")):
            g[key] = con.execute(
                "SELECT COUNT(*) FROM deaths WHERE match_id=? AND victim_id=? AND t_ms<?",
                (r["match_id"], r["participant_id"], limit),
            ).fetchone()[0] if has_tl else None
        g["vision_per_min"] = r["vision_score"] / (r["duration_s"] / 60) if r["duration_s"] else None
        tk = con.execute("SELECT team_kills FROM participant_extra WHERE match_id=? AND participant_id=?",
                         (r["match_id"], r["participant_id"])).fetchone()
        g["kp"] = ((r["kills"] + r["assists"]) / tk[0]) if tk and tk[0] else None
        g["cs_per_min"] = r["cs"] / (r["duration_s"] / 60) if r["duration_s"] else None
        games.append(g)
    return games


_MY_CACHE = {}


def _stamp(con, puuid):
    """Muda quando entra partida nova sua (ou o banco e outro)."""
    r = con.execute("SELECT COUNT(*), MAX(m.started_ms) FROM participants p JOIN matches m USING(match_id) WHERE p.puuid=?",
                    (puuid,)).fetchone()
    try:
        path = con.execute("PRAGMA database_list").fetchone()[2]
    except Exception:
        path = id(con)
    return (path, r[0], r[1])


def my_games(con, puuid, position=None):
    """Suas partidas (mais novas primeiro), com o oponente da mesma posicao (padrao: a sua mais jogada).
    Guardado em memoria ate entrar partida nova: quase toda pagina pede isso, e montar de novo custava caro."""
    if position is None:
        from . import profile
        position = profile.position()
    try:
        st = _stamp(con, puuid)
        hit = _MY_CACHE.get((st, position))
        if hit is not None:
            return [dict(g) for g in hit]
    except Exception:
        st = None
    games = _my_games(con, puuid, position)
    if st is not None:
        if len(_MY_CACHE) > 24:
            _MY_CACHE.clear()
        _MY_CACHE[(st, position)] = [dict(g) for g in games]
    return games


def _my_games(con, puuid, position):
    rows = con.execute(
        """SELECT p.*, m.duration_s, m.patch, m.started_ms FROM participants p
           JOIN matches m USING (match_id)
           WHERE p.puuid=? AND (?='' OR p.position=?)
             AND COALESCE(m.duration_s, 0) >= 300  -- ignora remake
           ORDER BY m.started_ms DESC""",
        (puuid, position, position),
    ).fetchall()
    return _games_from_rows(con, rows)


def top_games(con, champion, position=None):
    """Partidas da amostra dos melhores jogadores (so o participante escolhido)."""
    if position is None:
        from . import profile
        position = profile.position()
    rows = con.execute(
        """SELECT p.*, m.duration_s, m.patch, m.started_ms FROM participants p
           JOIN matches m USING (match_id)
           JOIN match_source s USING (match_id)
           JOIN top_players t ON t.puuid = p.puuid
           WHERE s.source='top' AND p.champion=? AND p.position=?
             AND COALESCE(m.duration_s, 0) >= 300
           ORDER BY m.started_ms DESC""",
        (champion, position),
    ).fetchall()
    return _games_from_rows(con, rows)


def _avg(values):
    values = [v for v in values if v is not None]
    return sum(values) / len(values) if values else None


def _fmt(v, nd=1):
    return "-" if v is None else f"{v:.{nd}f}"


def summary(games):
    """Resumo geral; cada medida traz o n de jogos que tem dado."""
    out = {"n": len(games), "wins": sum(g["win"] for g in games)}
    for key in ("cs10", "cs15", "csdiff10", "csdiff15", "golddiff15",
                "deaths_before_10", "deaths_before_15", "vision_per_min", "kp", "cs_per_min"):
        vals = [g[key] for g in games if g.get(key) is not None]
        out[key] = (_avg(vals), len(vals))
    return out


MIN_VEREDITO = 5     # minimo de jogos SEUS para chamar de forte/fraco/melhor/pior (2 jogos 2-0 nao e 100%)


def suave(w, n, prior=6):
    """Winrate puxado para 50% com poucos jogos: ordena e decide sem 1-0 virar 100%."""
    return (w + prior * 0.5) / (n + prior) if n >= 0 else 0.5


def by_key(games, key, min_games=1):
    groups = defaultdict(list)
    for g in games:
        if g.get(key):
            groups[g[key]].append(g)
    rows = []
    for name, gs in groups.items():
        if len(gs) >= min_games:
            wins = sum(g["win"] for g in gs)
            rows.append((name, len(gs), wins, wins / len(gs)))
    rows.sort(key=lambda r: (-r[1], -r[3]))
    return rows


def render(games, title="Suas partidas"):
    lines = [f"== {title} =="]
    if not games:
        return "\n".join(lines + ["Nenhuma partida no banco. Rode: python -m coach sync"])
    s = summary(games)
    lines.append(f"Jogos: {s['n']}  Vitorias: {s['wins']}  Winrate: {100*s['wins']/s['n']:.1f}%")
    if s["n"] < 30:
        lines.append("AVISO: menos de 30 jogos; trate como tendência, não como conclusão.")
    labels = [("cs10", "CS aos 10 min", 1), ("cs15", "CS aos 15 min", 1),
              ("csdiff10", "Dif. de CS vs oponente aos 10", 1),
              ("csdiff15", "Dif. de CS vs oponente aos 15", 1),
              ("golddiff15", "Dif. de ouro vs oponente aos 15", 0),
              ("deaths_before_15", "Mortes antes dos 15 min", 2),
              ("vision_per_min", "Visão por minuto", 2)]
    for key, label, nd in labels:
        avg, n = s[key]
        lines.append(f"  {label:<36} {_fmt(avg, nd):>7}   ({n} jogos)")
    lines.append("")
    lines.append("Por campeão seu:")
    for name, n, w, wr in by_key(games, "champion"):
        lines.append(f"  {name:<14} {n:>3} jogos  {w}V {n-w}D  {100*wr:.0f}%")
    lines.append("")
    lines.append("Contra cada oponente de rota (amostra pequena, leia com cuidado):")
    for name, n, w, wr in by_key(games, "opp_champion", min_games=2):
        lines.append(f"  vs {name:<14} {n:>3} jogos  {w}V {n-w}D  {100*wr:.0f}%")
    return "\n".join(lines)


def matchup(games, opponent):
    """Seus jogos contra um campeao especifico, por campeao seu."""
    sel = [g for g in games if (g["opp_champion"] or "").lower() == opponent.lower()]
    lines = [f"== Seus jogos contra {opponent} =="]
    if not sel:
        return "\n".join(lines + ["Nenhum jogo no banco contra esse campeão."])
    for name, n, w, wr in by_key(sel, "champion"):
        lines.append(f"  com {name:<14} {n:>3} jogos  {w}V {n-w}D  {100*wr:.0f}%")
    if len(sel) < 10:
        lines.append(f"AVISO: só {len(sel)} jogos no total; não é conclusivo.")
    return "\n".join(lines)
