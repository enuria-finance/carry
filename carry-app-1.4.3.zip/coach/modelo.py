"""Aprender com os melhores no MESMO confronto:
- primeira volta para a base: em que minuto e com quanto ouro os melhores voltam (e o aviso na partida);
- partida modelo: uma partida real de alto elo no confronto, minuto a minuto, ao lado da sua.
Tudo da amostra oficial da Riot que o app guarda."""
import html
import json
import statistics

e = lambda x: html.escape("" if x is None else str(x))
_C = {}


def _price(items, i):
    return ((items or {}).get(str(i)) or {}).get("gold", {}).get("total") or 0


def first_back(con, mid, pid, items):
    """(minuto, ouro gasto) da primeira volta: a primeira leva de compras depois de 1:30."""
    from .builds import START_MS
    buys = [(r[0], json.loads(r[1] or "{}").get("itemId")) for r in con.execute(
        "SELECT t_ms, data FROM events WHERE match_id=? AND pid=? AND type='ITEM_PURCHASED' AND t_ms>=? ORDER BY t_ms",
        (mid, pid, START_MS + 30000))]
    buys = [(t, i) for t, i in buys if i and i not in (3340, 3363, 3364)]
    if not buys:
        return None
    t0 = buys[0][0]
    spent = sum(_price(items, i) for t, i in buys if t - t0 <= 25000)
    return t0 / 60000, spent


def recall_window(con, champion, position, items, opp=None):
    """Janela da primeira volta dos melhores: (minuto_p25, minuto_p75, ouro_mediano, n)."""
    from . import builds
    key = ("rw", champion, position, opp)
    if key in _C:
        return _C[key]
    rows = builds.top_rows(con, champion, position)
    if opp:
        vs, why = builds.matchup_rows(con, rows, opp=opp)
        if why and why.startswith("contra"):
            rows = vs
    got = [first_back(con, r["match_id"], r["participant_id"], items) for r in rows[:120]]
    got = [g for g in got if g and 2.5 <= g[0] <= 12]
    res = None
    if len(got) >= 8:
        ts = sorted(g[0] for g in got)
        q = statistics.quantiles(ts, n=4)
        res = (q[0], q[2], int(statistics.median(g[1] for g in got)), len(got))
    _C[key] = res
    return res


def _timeline(con, mid, pid, items):
    """Momentos de uma partida: primeira volta, primeiro item completo, primeiro abate no oponente, farm e lugar aos 10/15/20."""
    from . import builds, vod
    out = {}
    fb = first_back(con, mid, pid, items)
    if fb:
        out["volta"] = fb
    out["item"] = builds.my_first_item_min(con, mid, pid, items)
    o = con.execute("""SELECT o.participant_id FROM participants me JOIN participants o ON o.match_id=me.match_id
                       AND o.team_id<>me.team_id AND o.position=me.position WHERE me.match_id=? AND me.participant_id=?""", (mid, pid)).fetchone()
    if o:
        for ev in con.execute("SELECT t_ms, data FROM events WHERE match_id=? AND type='CHAMPION_KILL' AND pid=? ORDER BY t_ms", (mid, o[0])):
            d = json.loads(ev[1] or "{}")
            if d.get("killer") == pid or pid in (d.get("assists") or []):
                out["abate"] = ev[0] / 60000
                break
    deaths = [r[0] / 60000 for r in con.execute("SELECT t_ms FROM deaths WHERE match_id=? AND victim_id=? ORDER BY t_ms", (mid, pid))]
    out["mortes15"] = sum(1 for t in deaths if t < 15)
    for m in (10, 15, 20):
        f = con.execute("SELECT cs, gold, x, y FROM frames WHERE match_id=? AND participant_id=? AND minute=?", (mid, pid, m)).fetchone()
        if f:
            out[f"cs{m}"] = f[0]
            out[f"ouro{m}"] = f[1]
            out[f"onde{m}"] = vod.ZONA_PT.get(vod.zona(f[2], f[3]), "-")
    return out


def model_match(con, champion, position, opp, items):
    """A partida modelo: vitoria de alto elo no confronto, com linha do tempo completa (a mais recente)."""
    from . import builds
    rows = builds.top_rows(con, champion, position)
    vs, why = builds.matchup_rows(con, rows, opp=opp)
    if not (why and why.startswith("contra")):
        return None
    for r in vs:
        if not r.get("win"):
            continue
        has = con.execute("SELECT 1 FROM frames WHERE match_id=? AND participant_id=? AND minute=10", (r["match_id"], r["participant_id"])).fetchone()
        if has:
            return r["match_id"], r["participant_id"], _timeline(con, r["match_id"], r["participant_id"], items)
    return None


def page_html(con, puuid, champion, opp, position, items):
    from . import report
    mm = model_match(con, champion, position, opp, items)
    if not mm:
        return (f"<div class='card'><p class='n'>Ainda não há partida de alto elo de {e(champion)} contra {e(opp)} com linha do tempo na amostra. "
                "Baixe mais partidas do topo em Comparar.</p></div>")
    mine_g = next((g for g in report.my_games(con, puuid, position) if g["champion"] == champion and (g.get("opp_champion") or "") == opp), None)
    mine = _timeline(con, mine_g["match_id"], mine_g["participant_id"], items) if mine_g else {}
    m = mm[2]
    mn = lambda v: f"{int(v)}:{int((v % 1) * 60):02d}" if isinstance(v, (int, float)) and v is not None else "-"
    rows = [("Primeira volta (minuto)", mn((m.get("volta") or (None,))[0]) if m.get("volta") else "-", mn((mine.get("volta") or (None,))[0]) if mine.get("volta") else "-"),
            ("Ouro gasto na primeira volta", (m.get("volta") or (0, "-"))[1], (mine.get("volta") or (0, "-"))[1]),
            ("Primeiro item completo", mn(m.get("item")) if m.get("item") else "-", mn(mine.get("item")) if mine.get("item") else "-"),
            (f"Primeiro abate no {opp}", mn(m.get("abate")) if m.get("abate") else "nenhum", mn(mine.get("abate")) if mine.get("abate") else "nenhum"),
            ("Mortes antes dos 15", m.get("mortes15", "-"), mine.get("mortes15", "-"))]
    for t in (10, 15, 20):
        rows.append((f"Farm aos {t}", m.get(f"cs{t}", "-"), mine.get(f"cs{t}", "-")))
        rows.append((f"Onde estava aos {t}", m.get(f"onde{t}", "-"), mine.get(f"onde{t}", "-")))
    head = ("<div style='display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;font-size:12px;color:var(--mute)'><span></span>"
            "<span>partida modelo (alto elo, vitória)</span><span>sua última partida nesse confronto</span></div>")
    body = "".join(f"<div style='display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.05)'>"
                   f"<span>{e(a)}</span><b>{e(b)}</b><span style='color:var(--mute)'>{e(c)}</span></div>" for a, b, c in rows)
    rw = recall_window(con, champion, position, items, opp)
    extra = (f"<p class='n'>Primeira volta dos melhores nesse confronto: entre {mn(rw[0])} e {mn(rw[1])}, gastando uns {rw[2]} de ouro ({rw[3]} partidas).</p>"
             if rw else "")
    return (f"<div class='card'><b class='gl'>{e(champion)} contra {e(opp)}: a partida modelo</b>{extra}{head}{body}"
            + ("" if mine_g else "<p class='n'>Você ainda não tem partida nesse confronto: a coluna da direita fica vazia.</p>") + "</div>")


def recall_cue(con, live_data, me, foes, pos, gt, items, champion, opp, state):
    """Aviso da primeira volta: dentro da janela dos melhores e com ouro para gastar."""
    if pos in (None, "", "JUNGLE") or gt > 720 or me.get("isDead"):
        return []
    rw = state.get("rw", "x")
    if rw == "x":
        return []
    if not rw:
        return []
    gold = int(((live_data.get("activePlayer") or {}).get("currentGold")) or 0)
    a, b, g, n = rw
    if a * 60 <= gt <= b * 60 + 30 and gold >= min(g, 1300) * 0.85:
        return [{"k": "ficha_volta", "t": f"Janela da primeira volta dos melhores ({int(a)} a {int(b) + 1} minutos) e você tem {gold} de ouro: "
                 "empurre a onda e volte para a base agora.", "v": f"Hora da primeira volta: empurre a onda e volte, você tem {gold} de ouro."}]
    return []
