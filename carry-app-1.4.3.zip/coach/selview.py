"""Tela de Selecao de campeoes no estilo 'lobby': arena dos dois times, seus picks com nota,
runas/feiticos/itens do topo (Mais popular / Alternativa) e ameacas ao seu pool."""
import html

from . import builds, champselect as cs, configview, draft, icons, profile, report, views2
from .tags import DADO, HIPOTESE, tip

ROLE_ORDER = ["TOP", "JUNGLE", "MIDDLE", "BOTTOM", "UTILITY"]
ROLE_LABEL = {"TOP": "TOP", "JUNGLE": "JG", "MIDDLE": "MID", "BOTTOM": "ADC", "UTILITY": "SUP"}


def _esc(x):
    return html.escape("" if x is None else str(x))


def _mring(val, size=46):
    r = views2.ring(0 if val is None else int(val), size)
    return r.replace(">0%<", ">–<") if val is None else r


def status(kind, msg):
    cls = {"live": "ok", "wait": "wait", "off": "off", "err": "off"}[kind]
    label = {"live": "NA SELEÇÃO", "wait": "AGUARDANDO A SELEÇÃO", "off": "CLIENTE FECHADO", "err": "SEM LEITURA"}[kind]
    return (f"<div class='sstat {cls}'><i></i><b>{label}</b><span>{_esc(msg)}</span>"
            "<a class='btn ghost' href='/selecao'>↻ Atualizar</a></div>")


def _ordered(team):
    if all(p.get("position") in ROLE_ORDER for p in team) and len({p["position"] for p in team}) == len(team):
        return sorted(team, key=lambda p: ROLE_ORDER.index(p["position"]))
    return sorted(team, key=lambda p: p.get("cell") if p.get("cell") is not None else 0)


def _slot(p, side, me):
    nm = p.get("champion") if p else None
    role = ROLE_LABEL.get((p or {}).get("position", ""), "")
    if nm:
        pic = icons.champ(nm, 58, "me" if side == "ally" else "foe")
        name = f"<b>{_esc(nm)}</b>"
    else:
        pic = "<span class='cic empty pulse' style='width:58px;height:58px'>?</span>"
        name = "<b class='dim2'>escolhendo…</b>" if p else "<b class='dim2'>—</b>"
    you = "<em class='you'>você</em>" if me else ""
    return (f"<div class='slot {side}{' mine' if me else ''}{'' if nm else ' blank'}'><span class='role'>{role or '·'}</span>{pic}"
            f"<span class='sn'>{name}{you}</span></div>")


def _bans(names, side):
    out = "".join(f"<span class='ban'>{icons.champ(n, 28)}<u></u></span>" for n in names)
    return f"<div class='bans {side}'><small>bans</small>{out or '<span class=dim2>–</span>'}</div>"


def arena(snap):
    if snap:
        mine, theirs = _ordered(snap["my_team"]), _ordered(snap["enemy_team"])
        me = snap["me"]
        left = "".join(_slot(p, "ally", p is me) for p in mine)
        right = "".join(_slot(p, "foe", False) for p in theirs)
        bl, br = _bans(snap["my_bans"], "ally"), _bans(snap["their_bans"], "foe")
    else:
        left = "".join(_slot({"position": r}, "ally", False) for r in ROLE_ORDER)
        right = "".join(_slot({"position": r}, "foe", False) for r in ROLE_ORDER)
        bl = br = ""
    note = "" if snap else "<p class='arn'>Quando a seleção abrir, os dois times aparecem aqui ao vivo.</p>"
    return (f"<div class='arena'><div class='side ally'><h3>Seu time</h3>{left}{bl}</div>"
            "<div class='vsmid'><span>VS</span></div>"
            f"<div class='side foe'><h3>Inimigos</h3>{right}{br}</div></div>{note}")


def _chips(games, name):
    strong, weak = cs._chips(games, name)
    c = "".join(f"<span class='chip good'>{icons.champ(r[0], 20)} {_esc(r[0])} · {r[2]}V {r[1] - r[2]}D</span>" for r in strong)
    w = "".join(f"<span class='chip bad'>{icons.champ(r[0], 20)} {_esc(r[0])} · {r[2]}V {r[1] - r[2]}D</span>" for r in weak)
    out = ""
    if c:
        out += f"<div class='chips'><small>Forte contra</small>{c}</div>"
    if w:
        out += f"<div class='chips'><small>Fraco contra</small>{w}</div>"
    return out


def _metric(label, val, n, kind, enemy=None):
    src = {"dado": "<span class='tag dado'>dado</span>", "hip": "<span class='tag hipotese'>hipótese</span>"}[kind]
    sub = "sem dados" if val is None else (f"{val}% · {n} jogo(s)" if (n and kind == "dado") else f"{val}")
    return (f"<div class='met'>{_mring(val, 52)}<div><b>{_esc(label)}</b><small>{_esc(sub)}</small></div>{src}</div>")


def _runes_html(runes, info, k):
    from . import icons as _ic
    (prim, sub, sel), n, w = runes[k] if isinstance(k, int) else k

    def rr(i, big=False):
        d = info.get(i) or {"name": str(i)}
        img = f"<img src='{_ic.CDN}/cdn/img/{_esc(d['icon'])}' width='{40 if big else 30}' height='{40 if big else 30}' alt=''>" if d.get("icon") else ""
        from .polish import tip_attr
        return (f"<div class='rn{' big' if big else ''}'{tip_attr(d['name'], 'Runa', d.get('desc') or '')}>{img}<div><b>{_esc(d['name'])}</b>"
                + (f"<small>{_esc((d.get('desc') or '')[:90])}{'…' if len(d.get('desc') or '') > 90 else ''}</small>" if big else "") + "</div></div>")
    return (f"<p class='rtree'>{_esc((info.get(prim) or {}).get('name', ''))} + {_esc((info.get(sub) or {}).get('name', ''))}</p>"
            + "".join(rr(i, j == 0) for j, i in enumerate(sel[:4])) + "".join(rr(i) for i in sel[4:6])
            + f"<p class='n'><b class='win'>{round(100 * w / n)}%</b> de vitória · {n} partidas</p>")


_PANEL = {}


def panel(con, name, games, scores, dd, enemy, e, tips_html, picked, snap=None):
    import time as _t
    foes_key = tuple(p.get("champion") or "" for p in (snap or {}).get("enemy_team", []))
    key = (name, enemy, picked, foes_key, profile.position(), len(games))
    hit = _PANEL.get(key)
    if hit and _t.time() - hit[0] < 120:
        return hit[1]
    html_ = _panel(con, name, games, scores, dd, enemy, e, tips_html, picked, snap)
    if len(_PANEL) > 60:
        _PANEL.clear()
    _PANEL[key] = (_t.time(), html_)
    return html_


def _panel(con, name, games, scores, dd, enemy, e, tips_html, picked, snap=None):
    """'Sua configuração': runas | carta do campeão | feitiços e itens — tudo da amostra dos melhores, com importar."""
    from . import champpage
    tier, avg = cs.tier_of(scores)
    sp = icons.splash(name)
    art = f"<div class='ph-art' style=\"background-image:url('{_esc(sp)}')\"></div>" if sp else ""
    n_hist = scores["hist"][1]
    note = ("poucos jogos (menos de 5): a nota fica '?'" if tier == "?" else f"nota = média das barras · {n_hist} jogos seus")
    big_ring = _mring(round(avg) if avg is not None else None, 86)
    tcls = "q" if tier == "?" else tier
    hero = (f"<div class='phero'>{art}<div class='ph-fade'></div><div class='ph-in'>"
            f"<span class='tierx t{tcls}'>{_esc(tier)}</span><div class='ph-t'>"
            f"<small>{'Sua escolha agora' if picked else 'Opção do seu pool'}</small><b>{_esc(name)}</b><small>{_esc(note)}</small></div>"
            f"<div class='ph-r'>{big_ring}<small>NOTA</small></div></div></div>")
    vs_label = f"Contra {enemy}" if enemy else "Contra " + profile.lane_enemy()
    mets = ("<div class='card mets'>"
            + _metric(vs_label, scores["vs"][0], scores["vs"][1], "dado")
            + _metric("Seu winrate com ele", scores["hist"][0], scores["hist"][1], "dado")
            + _metric("Encaixe no time", scores["fit"][0], None, "hip")
            + _chips(games, name) + "</div>")
    want_pos = profile.position()      # ja e a rota da partida (use_live no build)
    rows, used_pos, moved = builds.top_rows_info(con, name, want_pos)
    if not rows or not dd:
        side = ("<div class='card'><b class='gl'>Runas, feitiços e itens</b><p class='n'>Ainda sem partidas dos melhores com "
                f"{_esc(name)}.</p><form method='post' action='/sincronizar/iniciar' class='row'><input type='hidden' name='kind' value='top'>"
                f"<input type='hidden' name='champion' value='{_esc(name)}'><input type='hidden' name='games' value='30'><input type='hidden' name='back' value='1'>"
                "<button class='btn gold'>Baixar amostra agora</button></form>"
                + ("<p class='n'>Baixando sozinho as builds dos melhores com ele…</p><script>(function(){var k='auto_top_" + _esc(name) + "';"
                   "try{if(sessionStorage.getItem(k))return;sessionStorage.setItem(k,'1')}catch(x){}"
                   "var f=document.currentScript.parentNode.querySelector('form');if(f){var d=new FormData(f);"
                   "fetch(f.action,{method:'POST',body:new URLSearchParams(d)})}})();</script>" if picked else "")
                + "</div>")
        return (f"<section class='ppanel' data-ch='{_esc(name)}' hidden><h2>Sua configuração · {_esc(name)}</h2>"
                f"<div class='cfg-top'>{hero}{mets}</div><div class='cfg-row one'>{side}</div></section>")
    try:
        ver, info, items, spells = dd.version(), dd.rune_info(), dd.items(), dd.spells()
    except Exception:
        ver, info, items, spells = None, {}, {}, {}
    runes = builds.keystone_stats(rows)
    st = builds.item_stats(con, rows, items)
    sps = builds.spell_stats(rows)
    imp = lambda what, label: (f"<form method='post' action='/selecao/importar'><input type='hidden' name='champion' value='{_esc(name)}'>"
                               f"<button name='what' value='{what}' class='btn imp'>{label}</button></form>")
    tabs_r, vs_note, rune_opts = "", "", []
    if runes:
        opts = [("Mais usada", runes[0])] + [(f"Opção {k + 1}", r) for k, r in enumerate(runes[1:3], 1)]
        if enemy:
            try:
                champs = dd.champions()
                cls = builds.class_of((champs.get(enemy) or {}).get("tags"))
                by, counts = builds.runes_by_opponent(con, rows, champs)
                if cls and counts.get(cls, 0) >= 15:          # so com amostra de verdade; a mais usada continua primeiro
                    b = builds.best_page(by[cls])
                    if b and b[0] != runes[0][0]:
                        label = dict((k, l) for k, l, _ in builds.OPP_CLASS)[cls]
                        opts.insert(1, (f"Contra {enemy}", b))
                        vs_note = f"Contra {label.lower()} (como {enemy}), a runa que mais vence entre os melhores: {counts[cls]} partidas."
            except Exception:
                pass
        rune_opts = opts
        tabs_r = "<div class='rtabs'>" + "".join(f"<button type='button' class='tb{' on' if t == 0 else ''}' data-t='r{t}'>{_esc(lb)}</button>" for t, (lb, _) in enumerate(opts)) + "</div>"
        for t, (lb, r) in enumerate(opts):
            (pp, ss, sel), _, _ = r
            enc = ",".join(str(x) for x in [pp, ss] + list(sel))
            note = f"<p class='n' style='color:#c8aa6e'>{_esc(vs_note)}</p>" if lb.startswith("Contra ") and vs_note else ""
            tabs_r += (f"<div class='tabc' data-t='r{t}'{'' if t == 0 else ' hidden'}>{note}{_runes_html(runes, info, r)}"
                       f"<form method='post' action='/selecao/importar'><input type='hidden' name='champion' value='{_esc(name)}'>"
                       f"<input type='hidden' name='pagina' value='{enc}'><button name='what' value='runas' class='btn imp'>Importar esta página</button></form></div>")
    left = f"<div class='card'><b class='gl'>Runas</b>{tabs_r or '<p class=n>Sem página completa na amostra.</p>' + imp('runas', 'Importar runas para o cliente')}</div>"
    spell_html = ""
    if sps:
        pair, n, w = sps[0]
        cells = "".join(f"<div class='itc'>" + (f"<img src='{icons.CDN}/cdn/{_esc(ver)}/img/spell/{_esc((spells.get(x) or {}).get('id', ''))}.png' width='44' height='44' alt=''>" if ver else "")
                        + f"<small>{_esc((spells.get(x) or {}).get('name', x))}</small></div>" for x in pair)
        spell_html = f"<div class='card'><b class='gl'>Feitiços de invocador</b><div class='itcs'>{cells}</div><p class='n'><b class='win'>{round(100 * w / n)}%</b> de vitória · {n} partidas</p></div>"
    cb = builds.clean_build(st, items, name, used_pos)          # build conferida para o campeao NA ROTA
    order = cb["order"]
    filled = []
    if len(order) < 5:
        try:
            champs = dd.champions()
            tag = ((champs.get(name) or {}).get("tags") or [None])[0]
            similar = [c for c, v in champs.items() if tag and (v.get("tags") or [None])[0] == tag and c != name]
            filled = builds.similar_finals(con, similar, used_pos, items, exclude=order, limit=10)
            from . import itemfit
            filled = [i for i in filled if itemfit.fits(con, champs, items, name, used_pos, i)][:5 - len(order)]      # so item que serve para ele na rota
        except Exception:
            filled = []
    pos_name = {"TOP": "topo", "JUNGLE": "selva", "MIDDLE": "meio", "BOTTOM": "bot", "UTILITY": "suporte"}
    notes = []
    if moved:
        notes.append(f"Poucas partidas de {_esc(name)} no {pos_name.get(want_pos, want_pos)}: mostrando a build do {pos_name.get(used_pos, used_pos)}, onde ele é mais jogado.")
    if len(rows) < builds.MIN_ROWS:
        notes.append(f"Só {len(rows)} partida(s) dos melhores com {_esc(name)} no {pos_name.get(used_pos, used_pos)}: build ainda instável. Baixe mais amostra para firmar.")
    if filled:
        notes.append(f"A amostra tem só {len(rows)} partida(s): os últimos {len(filled)} itens vêm de campeões da mesma classe na mesma posição (hipótese).")
    start_html = ("<div class='card'><b class='gl'>Começo da partida</b>"
                  + (champpage._items_row(cb["start"], items, ver, "Itens iniciais") if cb["start"] else "")
                  + (champpage._items_row([cb["boots"]], items, ver, "Botas") if cb["boots"] else "")
                  + (f"<p class='n'>Primeiro item completo, em média, aos {st['first_item_min']:.0f} min.</p>" if st.get("first_item_min") else "")
                  + "</div>") if (st["starts"] or st["boots"]) else ""
    foes_ = [p["champion"] for p in (snap or {}).get("enemy_team", []) if p.get("champion")]
    if foes_ and dd:
        try:
            from . import pregame, voicecues
            chs = dd.champions()
            dfn = {"AP": voicecues.defensive_pick(con, name, used_pos, items, "magico"), "AD": voicecues.defensive_pick(con, name, used_pos, items, "fisico")}
            adj = pregame.comp_adjust(foes_, chs, pregame.my_dtype(chs, name), items, dfn, used_pos, mine=name, con=con, laner=enemy)
        except Exception:
            adj = []
        if adj:
            start_html += ("<div class='card adjc'><b class='gl'>Ajuste pela composição inimiga</b>"
                           + champpage._items_row([i for i, _, _, _ in adj], items, ver, "Considere")
                           + "".join(f"<p class='n' style='margin:6px 0'><span class='tag regra'>regra geral</span> <b>{_esc(nm)}</b>: {_esc(why)}</p>" for _, nm, why, _ in adj)
                           + "</div>")
    if enemy and dd:
        try:
            et = [t for t in (dd.champion(enemy).get("enemytips") or []) if t][:3]
        except Exception:
            et = []
        if et:
            start_html += (f"<div class='card'><b class='gl'>Como jogar contra {_esc(enemy)}</b>"
                           + "".join(f"<p class='n' style='margin:6px 0'><span class='tag dado'>dica oficial</span> {_esc(t)}</p>" for t in et)
                           + "</div>")
    from . import itemfit as _ifit
    _chs = dd.champions() if dd else {}

    def build_block(order_, finals_, extra_=()):
        sit_ = _ifit.clean_seq(_chs, items, name, used_pos, [i for i, _ in finals_ if i not in order_ and i not in extra_], dict(finals_), len(rows))
        return (champpage._items_row(list(order_) + list(extra_), items, ver, "Build completa, em ordem")
                + champpage._items_row(sit_[:4], items, ver, "Situacionais"))
    blocks = ""
    if rune_opts:      # a build acompanha a runa escolhida (quem vai de Conquistador nao faz os mesmos itens)
        for t, (lb, r) in enumerate(rune_opts):
            (pp, ss, sel), _, _ = r
            sub = builds.rows_with_page(rows, sel[0], ss)
            if t == 0 and not lb.startswith("Contra "):
                body = build_block(order, st["finals"], filled)
                cap = ""
            elif len(sub) >= 15:
                st2 = builds.item_stats(con, sub, items)
                body = build_block(builds.clean_build(st2, items, name, used_pos)["order"], st2["finals"])
                cap = f"<p class='n' style='color:#c8aa6e'>Build de quem joga com essa runa: {len(sub)} partidas.</p>"
            else:
                body = build_block(order, st["finals"], filled)
                cap = "<p class='n'>Poucas partidas com essa runa: mostrando a build geral.</p>"
            blocks += f"<div class='tabc' data-t='r{t}'{'' if t == 0 else ' hidden'}>{cap}{body}</div>"
    else:
        blocks = build_block(order, st["finals"], filled)
    items_html = ("<div class='card'><b class='gl'>Itemização</b>" + blocks
                  + imp("itens", "Importar itens para o cliente") + f"<p class='n'>{len(rows)} partidas dos melhores com {_esc(name)} no {pos_name.get(used_pos, used_pos)}.</p>"
                  + "".join(f"<p class='n' style='color:#c8aa6e'>{x}</p>" for x in notes) + "</div>")
    return (f"<section class='ppanel' data-ch='{_esc(name)}' hidden><h2>Sua configuração · {_esc(name)}{' · ao vivo' if picked else ''}</h2>"
            f"<div class='cfg-top'>{hero}{mets}</div><div class='cfg-row'>{left}{items_html}<div class='cfg-col'>{spell_html}{start_html}</div></div>"
            f"<details class='bxd' data-c='{_esc(name)}' data-p='{_esc(used_pos)}'><summary>Ver todas as opções dos melhores: núcleos de runa + item, runas, feitiços, "
            "itens iniciais, ordem de habilidades e sequências de 2 a 5 itens</summary><div class='bxd-in'><p class='n'>Carregando…</p></div></details></section>")


def rail_card(name, scores, selected, live=False):
    tier, avg = cs.tier_of(scores)
    sp = icons.splash(name)
    bg = (f"style=\"--bg:url('{_esc(sp)}')\"" if sp else "")
    tcls = "q" if tier == "?" else tier
    return (f"<button type='button' class='pk{' on' if selected else ''}' data-ch='{_esc(name)}'{' data-live=1' if live else ''} {bg}>"
            f"<span class='tierb t{tcls}'>{_esc(tier)}</span><span class='pkn'>{_esc(name)}</span>"
            f"<span class='pks'>{'—' if avg is None else round(avg)}<small>nota</small></span></button>")


def threats(games, e):
    opp = {}
    for g in games:
        if g["opp_champion"]:
            opp.setdefault(g["opp_champion"], []).append(g)
    rows = []
    for name, gs in opp.items():
        if len(gs) < report.MIN_VEREDITO:
            continue
        w = sum(1 for x in gs if x["win"])
        if report.suave(w, len(gs)) > 0.47:       # ameaca e quem te vence, nao quem empata
            continue
        rows.append((round(100 * (1 - report.suave(w, len(gs)))), name, gs))
    rows.sort(key=lambda r: (-r[0], -len(r[2])))
    if not rows:
        return "<div class='empty'><span class='em'>🛡</span><b>Sem ameaças ainda</b><span>Precisa de 5 jogos ou mais contra o mesmo campeão.</span></div>"
    out = ""
    for threat, name, gs in rows[:6]:
        sp = icons.splash(name)
        bg = (f"style=\"background-image:linear-gradient(90deg,rgba(14,17,22,.92) 30%,rgba(14,17,22,.35)),url('{_esc(sp)}')\"" if sp else "")
        mine = {}
        for g in gs:
            mine.setdefault(g["champion"], []).append(g)
        lines = "".join(
            f"<span class='thc'>{icons.champ(ch, 22, 'me')} {round(100 * sum(1 for x in xs if x['win']) / len(xs))}% <small>{len(xs)}j</small></span>"
            for ch, xs in sorted(mine.items(), key=lambda kv: -len(kv[1]))[:4])
        out += (f"<div class='thr' {bg}><div class='thl'>{icons.champ(name, 52, 'foe')}<div><b>{_esc(name)}</b>"
                f"<small>{len(gs)} jogo(s) seus · <span class='tag dado'>dado</span></small></div></div>"
                f"<div class='thm'>{_mring(threat, 56)}<small>AMEAÇA</small></div><div class='thx'>{lines}</div></div>")
    return "<div class='thrs'>" + out + "</div>"


def pool_editor(con, pool, valid, e):
    chips = "".join(
        f"<form method='post' action='/selecao/pool' class='pchip'><input type='hidden' name='champion' value='{e(n)}'>"
        f"{icons.champ(n, 30, 'me')}<span>{e(n)}</span><button name='op' value='remove' title='Tirar do pool'>✕</button></form>"
        for n in pool)
    opts = "".join(f"<option value='{e(n)}'>" for n in valid)
    return ("<div class='card'><div class='pchips'>" + (chips or "<span class='n'>vazio</span>") + "</div>"
            "<form method='post' action='/selecao/pool' class='row'><input type='text' name='champion' list='champs' placeholder='Adicionar campeão (ex.: Ahri)'>"
            f"<datalist id='champs'>{opts}</datalist><button name='op' value='add'>Adicionar</button></form>"
            "<form method='post' action='/sincronizar/iniciar' class='row'><input type='hidden' name='back' value='1'>"
            "<button name='kind' value='topall' class='btn gold'>Baixar runas e itens do topo para todo o pool</button></form></div>")


CLASS_PT = {"Assassin": "Assassino", "Mage": "Mago", "Fighter": "Lutador", "Tank": "Tanque", "Marksman": "Atirador", "Support": "Suporte"}
DMG_PT = {"AP": "dano mágico", "AD": "dano físico", "MIX": "dano misto"}


def _verdict(score):
    v = round(score * 100)
    if v >= 57:
        return v, "Forte", "g"
    if v >= 53:
        return v, "Boa", "g2"
    if v >= 48:
        return v, "Neutra", "n"
    return v, "Arriscada", "r"


def _meter(v):
    return max(4, min(100, round((v - 40) / 25 * 100)))


def _record(w, n):
    """Barra de vitorias x derrotas."""
    if not n:
        return ""
    return (f"<div class='crec'><span class='w' style='flex:{w}'></span><span class='l' style='flex:{n - w}'></span></div>"
            f"<small class='crecl'><b class='wv'>{w}V</b> <b class='lv'>{n - w}D</b></small>")


def _comp_bar(p, label):
    if not p or not p["n"]:
        return f"<div class='ctm'><span class='ctl'>{label}</span><small class='n'>ninguém escolheu ainda</small></div>"
    seg = "".join(f"<span class='{c}' style='flex:{p[k]}'></span>" for k, c in (("AD", "ad"), ("MIX", "mx"), ("AP", "ap")) if p[k])
    return (f"<div class='ctm'><span class='ctl'>{label} <small>{p['n']}/5</small></span><div class='dmg'>{seg}</div>"
            f"<small class='ctx'><i class='ad'></i>Físico {p['AD']} <i class='mx'></i>Misto {p['MIX']} <i class='ap'></i>Mágico {p['AP']}"
            f" · Linha de frente {p['front']}</small></div>")


def _stage(snap):
    """Em que passo da selecao voce esta: 'ban', 'pick' ou 'plan'."""
    if not snap:
        return "pick"
    turn = snap.get("my_turn")
    if turn in ("ban", "pick"):
        return turn
    if snap.get("locked") or snap.get("phase") == "FINALIZATION":
        return "plan"
    return "pick" if snap.get("ban_done") else "ban"


KIND_WORD = {"dado": "do seu histórico", "regra": "regra geral", "hipotese": "hipótese"}


def _why_li(t, k):
    return f"<li class='w-{k}' title='{KIND_WORD[k]}'><i></i><span>{_esc(t)}</span></li>"


def _team_row(team, me, champs, label, bans, foe=False):
    cells = ""
    for p in (team or [])[:5]:
        nm = p.get("champion")
        if not nm:
            cells += "<span class='tslot tblank'><span class='tq'>?</span></span>"
            continue
        c = champs.get(nm) or {}
        dt = draft.damage_type(c.get("info"), c.get("tags", [])).lower()
        you = " you" if p is me else ""
        cells += (f"<span class='tslot d-{dt}{you}' title='{_esc(c.get('name') or nm)} · {DMG_PT[dt.upper()]}'>"
                  f"{icons.champ(nm, 40, 'foe' if foe else 'me')}<i></i></span>")
    bans_h = "".join(f"<span class='tban'>{icons.champ(b, 22)}<u></u></span>" for b in (bans or [])[:5])
    return (f"<div class='trow{' foe' if foe else ''}'><span class='tlab'>{label}"
            + (f"<span class='tbans'>{bans_h}</span>" if bans_h else "") + f"</span><div class='tcells'>{cells}</div></div>")


def coach_panel(snap, games, pool, roles, champs, position, con=None):
    from . import gameview
    laner, guessed = draft.enemy_laner(snap, position, roles) if snap else (None, False)
    bans = draft.ban_ideas(games, snap, roles, position)
    picks, avoid = draft.pick_ideas(games, pool, snap, laner, champs)
    notes, mine, foe = draft.comp_notes(snap, champs) if snap else ([], None, None)
    stage = _stage(snap)
    dn = lambda nm: _esc((champs.get(nm) or {}).get("name") or nm)
    me_champ = ((snap or {}).get("me") or {}).get("champion")
    comp_bans = []
    if con is not None and snap:
        try:
            from . import pregame
            comp_bans = [c for c in pregame.comp_bans(con, snap, champs, position, limit=3) if c["champion"] not in {b["champion"] for b in bans}]
        except Exception:
            comp_bans = []

    # ---------- passos ----------
    done_ban = bool(snap and snap.get("ban_done"))
    steps = [("ban", "1", "Banir", "feito" if done_ban else ("sua vez" if stage == "ban" else "")),
             ("pick", "2", "Escolher", (dn(me_champ) if snap and snap.get("locked") and me_champ else ("sua vez" if stage == "pick" and snap and snap.get("my_turn") == "pick" else ""))),
             ("plan", "3", "Plano de jogo", "pronto" if stage == "plan" else "")]
    order = ["ban", "pick", "plan"]
    sbar = "<ol class='csteps'>"
    for k, n, lab, st in steps:
        cls = "on" if k == stage else ("done" if order.index(k) < order.index(stage) else "")
        sbar += f"<li class='{cls}'><span class='sn'>{n}</span><b>{lab}</b>" + (f"<small>{st}</small>" if st else "") + "</li>"
    sbar += "</ol>"

    # ---------- AGORA (um so recado grande) ----------
    def hero(kind, name, eyebrow, title, body, side=""):
        sp = icons.splash(name) if name else ""
        art = f"<div class='nh-art' style=\"background-image:url('{_esc(sp)}')\"></div>" if sp else ""
        return (f"<div class='nowh k-{kind}'>{art}<div class='nh-fade'></div><div class='nh-in'>"
                f"<span class='nh-eye'>{eyebrow}</span><div class='nh-main'>"
                + (icons.champ(name, 84, 'foe' if kind == 'ban' else 'me', 'nh-ic') if name else "")
                + f"<div class='nh-t'><b>{title}</b>{body}</div>{side}</div></div></div>")

    alts = lambda lst, ring: ("<div class='nh-alt'><span>ou</span>" + "".join(
        f"<span class='nh-a'>{icons.champ(x, 26, ring)}{dn(x)}</span>" for x in lst) + "</div>") if lst else ""
    if stage == "ban":
        if bans:
            b = bans[0]
            body = (f"<p class='nh-why'>{icons.ph('skull', 16)} Você perdeu <b>{b['n'] - b['w']} de {b['n']}</b> partidas contra ele.</p>"
                    f"{_record(b['w'], b['n'])}")
            now = hero("ban", b["champion"], f"{icons.ph('prohibit', 14)} Agora: banir", f"Bana {dn(b['champion'])}", body,
                       alts([x["champion"] for x in bans[1:3]] + [c["champion"] for c in comp_bans[:3 - len(bans[1:3])]], "foe"))
        else:
            cand = [c["champion"] for c in comp_bans]
            body = "<p class='nh-why'>Nenhum campeão te venceu 2 vezes ou mais ainda. Bana quem está forte no patch ou quem você não gosta de enfrentar.</p>"
            now = hero("ban", cand[0] if cand else None, f"{icons.ph('prohibit', 14)} Agora: banir",
                       f"Sugestão: {dn(cand[0])}" if cand else "Bana quem está forte", body, alts(cand[1:3], "foe"))
    elif stage == "pick":
        if picks:
            pk = picks[0]
            v, word, cls = _verdict(pk["score"])
            body = "<ul class='nh-list'>" + "".join(_why_li(t, k) for t, k in pk["why"][:3]) + "</ul>"
            side = (f"<div class='nh-score {cls}' title='Nota de 0 a 100: seu winrate com ele, o duelo e o que o time precisa'>"
                    f"<span>{v}</span><small>nota · {word}</small></div>")
            now = hero("pick", pk["champion"], f"{icons.ph('sword', 14)} Agora: escolher", f"Pegue {dn(pk['champion'])}", body,
                       side + alts([x["champion"] for x in picks[1:3]], "me"))
        else:
            now = hero("pick", None, f"{icons.ph('sword', 14)} Agora: escolher", "Monte o seu pool",
                       "<p class='nh-why'>Adicione seus campeões em <b>Meu pool</b> (lá embaixo) para ver a melhor escolha.</p>")
    else:
        parts = []
        if con is not None and snap:
            try:
                from . import pregame
                parts = pregame.plan_parts(con, games, snap, champs, position, roles)
            except Exception:
                parts = []
        ico = {"duelo": "crosshair", "perigo": "warning", "fraco": "shield-warning", "pico": "lightning"}
        rows = "".join(f"<div class='pl-r k-{k}'><span class='pl-i'>{icons.ph(ico.get(k, 'info'), 20)}</span><div><b>{_esc(t)}</b><p>{_esc(x)}</p></div></div>"
                       for k, t, x, _ in parts)
        body = f"<div class='pl-g'>{rows}</div>" if rows else "<p class='nh-why'>Assim que o inimigo aparecer, o plano completa aqui.</p>"
        now = hero("plan", me_champ, f"{icons.ph('flag', 14)} Plano de jogo", f"Você vai de {dn(me_champ)}" if me_champ else "Plano de jogo", body)

    # ---------- duelo + times ----------
    if laner:
        c = champs.get(laner) or {}
        tags = c.get("tags") or []
        dt = draft.damage_type(c.get("info"), tags)
        vs = [g for g in games if (g.get("opp_champion") or "").lower() == laner.lower()]
        vw = sum(1 for g in vs if g["win"])
        from . import champtips
        tips2 = champtips.tips_vs(laner, 2, tags=tags)
        tip_ = " ".join(tips2)
        rec = (f"<span class='{'good' if vw * 2 >= len(vs) else 'bad'}'>{vw}V {len(vs) - vw}D</span> no seu histórico" if vs
               else "<span class='n'>nunca enfrentou</span>")
        duel = (f"<div class='cbox cduel'><span class='cbl'>{icons.ph('crosshair', 14)} Seu oponente{' provável' if guessed else ''}</span>"
                f"<div class='du-m'>{icons.champ(laner, 56, 'foe')}<div><b>{dn(laner)}</b><p class='chips'>"
                + "".join(f"<span>{CLASS_PT.get(t, t)}</span>" for t in tags[:2]) + f"<span class='{dt.lower()}'>{DMG_PT[dt]}</span></p>"
                f"<small>{rec}</small></div></div>"
                + "".join(f"<p class='du-tip'><i class='kd w-regra' title='dica oficial da Riot para enfrentar este campeão'></i>{_esc(t)}</p>" for t in tips2)
                + ("<small class='n'>Adivinhado pela rota que ele mais joga (a ranqueada esconde as rotas).</small>" if guessed else "") + "</div>")
    else:
        duel = (f"<div class='cbox cduel'><span class='cbl'>{icons.ph('crosshair', 14)} Seu oponente</span>"
                "<div class='du-wait'><span class='tslot tblank'><span class='tq'>?</span></span><p>Ainda escondido. Quando o inimigo escolher, aparece aqui com o seu histórico contra ele.</p></div></div>")
    need = []
    if mine and mine["n"] >= 2:
        if not mine["AP"]:
            need.append("dano mágico")
        if not mine["AD"]:
            need.append("dano físico")
    if mine and mine["n"] >= 3 and not mine["front"]:
        need.append("linha de frente")

    def summary(p):
        if not p or not p["n"]:
            return "ninguém escolheu ainda"
        bits = [f"{p[k]} {w}" for k, w in (("AD", "físico"), ("AP", "mágico"), ("MIX", "misto")) if p[k]]
        return ", ".join(bits) + f" · {p['front']} na linha de frente"
    teams = (f"<div class='cbox teams'><span class='cbl'>{icons.ph('users-three', 14)} Times</span><div class='tgrid'>"
             f"<div class='tside'>{_team_row((snap or {}).get('my_team'), (snap or {}).get('me'), champs, 'Seu time', (snap or {}).get('my_bans'))}"
             f"<small class='tsum'>{summary(mine)}</small></div><span class='tvs'>VS</span>"
             f"<div class='tside foe'>{_team_row((snap or {}).get('enemy_team'), None, champs, 'Inimigo', (snap or {}).get('their_bans'), foe=True)}"
             f"<small class='tsum'>{summary(foe)}</small></div></div><div class='tfoot'>"
             + ("<div class='cneed'><span>Falta no seu time</span>" + "".join(f"<b>{x}</b>" for x in need) + "</div>" if need else "")
             + "".join(f"<p class='cnote'><i class='kd w-{k}' title='{KIND_WORD[k]}'></i>{_esc(t)}</p>" for t, k in notes
                       if not t.startswith(("Seu time ainda não", "Ninguém da linha")))
             + "<p class='tleg'><i class='d-ad'></i>físico <i class='d-ap'></i>mágico <i class='d-mix'></i>misto <i class='d-ban'></i>banido</p></div></div>")

    # ---------- listas completas ----------
    blist = ""
    for i, b in enumerate(bans):
        blist += (f"<div class='lrow'><span class='lnum'>{i + 1}</span>{icons.champ(b['champion'], 40, 'foe')}<div class='lt'><b>{dn(b['champion'])}</b>"
                  f"<small>te venceu {b['n'] - b['w']} de {b['n']}</small></div>{_record(b['w'], b['n'])}</div>")
    for c in comp_bans:
        blist += (f"<div class='lrow soft'><span class='lnum'>{icons.ph('info', 14)}</span>{icons.champ(c['champion'], 40, 'foe')}<div class='lt'><b>{dn(c['champion'])}</b>"
                  f"<small><i class='kd w-hipotese' title='hipótese'></i>{_esc('; '.join(c['why']))}</small></div></div>")
    blist = blist or "<p class='n'>Precisa de 2 ou mais jogos contra o mesmo campeão para sugerir ban.</p>"
    plist = ""
    for i, pk in enumerate(picks):
        v, word, cls = _verdict(pk["score"])
        plist += (f"<div class='lrow{' best' if i == 0 else ''}'><span class='lnum'>{i + 1}</span>{icons.champ(pk['champion'], 44, 'me')}"
                  f"<div class='lt'><b>{dn(pk['champion'])} <span class='vd {cls}'>{word}</span></b><ul class='lwhy'>"
                  + "".join(_why_li(t, k) for t, k in pk["why"]) + f"</ul></div><span class='lsc {cls}'>{v}</span></div>")
    plist = plist or "<p class='n'>Monte o seu pool (lá embaixo) para ver sugestões.</p>"
    if avoid:
        plist += f"<p class='cavoid'>{icons.ph('warning', 14)} Evite agora: <b>{dn(avoid['champion'])}</b> <span>({_esc(avoid['why'][-1][0])})</span></p>"
    legend = ("<p class='kleg'><i class='kd w-dado'></i>do seu histórico <i class='kd w-regra'></i>regra geral <i class='kd w-hipotese'></i>hipótese"
              " <span>· Nota de 0 a 100: 57+ forte, 53+ boa, abaixo de 48 arriscada</span></p>")
    lists = (f"<div class='clists'><div class='cbox{' hot' if stage == 'ban' else ''}'><span class='cbl'>{icons.ph('prohibit', 14)} Quem banir</span>{blist}</div>"
             f"<div class='cbox{' hot' if stage == 'pick' else ''}'><span class='cbl'>{icons.ph('sword', 14)} O que escolher</span>{plist}</div></div>")
    return ("<section class='cs2'>" + sbar + "<div class='cs2-top'>" + now + duel + "</div>" + teams
            + lists + legend + "</section>")


JS = """<script>(function(){
var key='sel_ch';function pick(ch,quiet){document.querySelectorAll('.ppanel').forEach(function(p){p.hidden=p.dataset.ch!==ch});
document.querySelectorAll('.pk').forEach(function(b){b.classList.toggle('on',b.dataset.ch===ch)});
try{sessionStorage.setItem(key,ch)}catch(x){}
var p=document.querySelector('.ppanel:not([hidden])');if(p){if(!quiet){p.classList.remove('swap');void p.offsetWidth;p.classList.add('swap')}
var tk=null;try{tk=sessionStorage.getItem('sel_tab_'+ch)}catch(x){}if(tk){var tb=p.querySelector('.tb[data-t="'+tk+'"]');if(tb)showTab(p,tb)}
p.querySelectorAll('.wring .fg').forEach(function(f){f.style.strokeDashoffset=f.getAttribute('stroke-dashoffset')});p.querySelectorAll('.rv:not(.in)').forEach(function(el){el.classList.add('in');el.querySelectorAll('.wring .fg').forEach(function(f){f.style.strokeDashoffset=f.getAttribute('stroke-dashoffset')})});}}
function showTab(box,t){box.querySelectorAll('.tb').forEach(function(x){x.classList.toggle('on',x===t)});
box.querySelectorAll('.tabc').forEach(function(c){c.hidden=c.dataset.t!==t.dataset.t})}
function init(ev){var first=document.querySelector('.pk.on');var ch=first?first.dataset.ch:null;
var live=document.querySelector('.pk[data-live]');
if(live&&window.__selLive!==live.dataset.ch){window.__selLive=ch=live.dataset.ch;ev=null;try{sessionStorage.setItem(key,ch)}catch(x){}}
else{try{var s=sessionStorage.getItem(key);if(s&&document.querySelector('.pk[data-ch="'+s+'"]'))ch=s}catch(x){}}
if(ch)pick(ch,!!ev);
document.querySelectorAll('.pk').forEach(function(b){b.addEventListener('click',function(){pick(b.dataset.ch)})});}
init();document.addEventListener('liveswap',init);
document.addEventListener('click',function(ev){var t=ev.target.closest('.tb');if(!t)return;var box=t.closest('.ppanel');
showTab(box,t);try{sessionStorage.setItem('sel_tab_'+box.dataset.ch,t.dataset.t)}catch(x){}});
})();</script>"""


def build(con, puuid, e, tips_html, wrap=True, snap_out=None):
    from . import lcu as lcu_mod
    from .ddragon import DataDragon
    games = report.my_games(con, puuid)
    snap = dd = None
    champs = {}
    version = None
    try:
        dd = DataDragon(cache_dir="cache")
        champs = dd.champions()
        version = dd.version()
    except Exception:
        dd = None
    kind, msg = "wait", "Entre na fila: quando a seleção abrir, esta tela se atualiza sozinha."
    try:
        client = lcu_mod.LCU.discover()
    except lcu_mod.LCUError as ex:
        client = None
        kind, msg = "off", "Abra o cliente do LoL. Enquanto isso, veja a pré-visualização com o seu histórico."
    if client:
        try:
            session = client.champ_select_session()
            snap = cs.snapshot(session, dd.champion_by_key()) if dd else None
        except Exception as ex:
            kind, msg = "err", f"Não consegui ler a seleção ({ex})."
        if snap:
            kind, msg = "live", "Lendo a seleção do cliente em tempo real."
    tags = {k: v["tags"] for k, v in champs.items()} if champs else {}
    roles = draft.role_map(con)
    # rota DESTA partida (o cliente diz: suporte e suporte, mesmo que voce jogue mais de mid)
    me_ = (snap or {}).get("me") or {}
    sel_pos = me_.get("position") or ""
    if sel_pos:
        profile.set_live(sel_pos)
    pos = profile.use_live(profile.resolve_pos(sel_pos, me_.get("champion"), me_.get("spells"), roles)) if snap else profile.position()
    games = report.my_games(con, puuid, pos)
    enemy_mid = draft.enemy_laner(snap, pos, roles)[0] if snap else None
    saved = cs.pool_get(con)
    pool = draft.pool_for(saved, games, roles, pos)
    default_pool = not saved or pool != [c for c in saved if c in pool]
    body = status(kind, msg) + coach_panel(snap, games, pool, roles, champs, pos, con)
    if snap:
        try:            # condicao de vitoria, resumo do time deles, dupla de baixo, counter revelado (lote das 100 ideias)
            from . import extras
            xs = extras.select_extra(con, puuid, snap, champs, pos, pool)
            if xs:
                body += ("<div class='card'><h3>Leitura do coach</h3><ul class='xl'>"
                         + "".join(f"<li>{_esc(t)}</li>" for _, t, _v in xs) + "</ul></div>")
        except Exception:
            pass
    mine = (snap["me"] or {}).get("champion") if snap else None
    names = list(pool) + ([mine] if mine and mine not in pool else [])
    cards = []
    for nm in names:
        sc = cs.champion_scores(games, nm, enemy_mid, snap, tags)
        cards.append((cs.tier_of(sc)[1] if cs.tier_of(sc)[1] is not None else -1, nm, sc))
    cards.sort(key=lambda t: (-t[0], t[1]))
    if cards:
        sel = mine if mine in [c[1] for c in cards] else cards[0][1]
        body += "<h2>Runas, itens e notas dos seus campeões</h2>"
        if default_pool:
            body += f"<p class='n'>Mostrando os seus campeões {profile.lane_in()} (a rota desta partida).</p>"
        body += "<div class='pkrail'>" + "".join(rail_card(nm, sc, nm == sel, nm == mine) for _, nm, sc in cards) + "</div>"
        body += "".join(panel(con, nm, games, sc, dd, enemy_mid, e, tips_html, nm == mine, snap) for _, nm, sc in cards)
    else:
        body += "<div class='empty'><span class='em'>⚔</span><b>Sem partidas ainda</b><span>Sincronize para ver as notas dos seus campeões.</span></div>"

    body += "<h2>Ameaças ao seu pool · pelo seu histórico</h2>" + threats(games, e)
    # plano B
    alt = [r for r in report.by_key(games, "champion", min_games=report.MIN_VEREDITO) if r[0] != (profile.CURRENT["champion"] or "")]
    alt.sort(key=lambda r: -report.suave(r[2], r[1]))
    if alt:
        cardsb = "".join(
            f"<div class='vsc'>{icons.champ(n, 52, 'me')}<div><b>{_esc(n)}</b><small>{k} jogo(s) · {w}V {k - w}D</small></div>{views2.ring(round(100 * wr))}</div>"
            for n, k, w, wr in alt[:3])
        body += "<h2>Plano B se o seu main for banido</h2><div class='vsgrid'>" + cardsb + "</div>"
    if snap:
        sy = cs.synergy(snap, tags)
        if sy:
            body += "<h2>Sinergia do time</h2>" + tips_html(sy)
    valid = sorted(champs) if champs else sorted({g["champion"] for g in games})
    body += "<h2>Meu pool</h2>" + pool_editor(con, cs.pool_get(con), valid, e)
    if snap_out is not None:
        snap_out["snap"] = snap
        snap_out["laner"] = enemy_mid
    if not wrap:
        return body
    live = " data-every='%d'" % (4000 if snap else 5000) if client else ""
    return f"<div id='liveroot'{live}>" + body + "</div>" + JS


CSS = """
.cfg3{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,.95fr) minmax(0,1fr);gap:14px;align-items:start}.cfg3 .card{margin:0 0 14px}
.rtabs{display:flex;gap:4px;margin:8px 0 6px;border-bottom:1px solid var(--rule)}
.rtabs .tb{background:none !important;border:0 !important;border-bottom:2px solid transparent !important;color:var(--mute) !important;font:600 13px var(--body) !important;letter-spacing:0 !important;padding:8px 10px !important;box-shadow:none !important}
.rtabs .tb.on{color:#fff !important;border-bottom-color:var(--gold) !important}
.btn.imp{width:100%;margin-top:10px;background:linear-gradient(180deg,rgba(200,170,110,.16),rgba(200,170,110,.04)) !important;color:#f0e6d2 !important}
@media (max-width:1200px){.cfg3{grid-template-columns:1fr}}
.coach{border:1px solid rgba(233,196,106,.35);border-radius:18px;padding:16px 18px;margin:0 0 16px;
background:radial-gradient(120% 140% at 0% 0%,rgba(233,196,106,.10),transparent 50%),var(--panel)}
.claner{display:flex;align-items:center;gap:10px;margin:0 0 12px;color:#D6CCC0;font-size:14px}.claner small{color:var(--mute)}
.ccols{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.3fr) minmax(0,1fr);gap:12px}
.ccol{border:1px solid var(--rule);border-radius:14px;padding:12px 14px;background:rgba(16,11,11,.4);display:flex;flex-direction:column;gap:8px;transition:border-color .3s,box-shadow .3s}
.ccol.on{border-color:var(--gold);box-shadow:0 0 0 3px rgba(233,196,106,.18),0 0 30px rgba(233,196,106,.15)}
.ccol h3{margin:0;display:flex;align-items:center;gap:8px;font:700 15px var(--head);color:#fff}
.turn{padding:3px 9px;border-radius:999px;background:var(--gold);color:#1a1405;font:700 11px var(--head);animation:ping2 1.4s infinite}
.cidea{display:grid;grid-template-columns:auto minmax(0,1fr) auto;gap:10px;align-items:center;padding:8px 10px;border-radius:12px;border:1px solid transparent}
.cidea b{display:block;font:700 15px var(--head);color:#fff}.cidea b em{font-style:normal;margin-left:6px;padding:2px 8px;border-radius:999px;font:700 10.5px var(--head);color:#1a1405;background:var(--gold)}
.cidea small{color:var(--mute);font-size:12.5px}
.cidea ul{list-style:none;margin:4px 0 0;padding:0;display:flex;flex-direction:column;gap:2px}
.cidea li{display:flex;gap:8px;align-items:center;font-size:12.5px;color:#D6CCC0}.cidea li .tag{padding:0;font-size:9.5px;min-width:72px}
.cidea.best{border-color:rgba(233,196,106,.45);background:rgba(233,196,106,.06)}
.cscore{font:800 22px var(--head);color:var(--gold)}
.cavoid{margin:2px 0 0}.cavoid b{color:var(--loss)}
.dmg{display:flex;height:12px;border-radius:99px;overflow:hidden;background:#261C1B}
.dmg .ad{background:#ff9a5a}.dmg .ap{background:#8c7dff}.dmg .mx{background:#6D625C}
.dmgl{display:flex;justify-content:space-between;margin:2px 0 4px;font:600 12px var(--head);color:var(--mute)}
.cnote{display:flex;flex-direction:column;gap:2px;margin:0;font-size:13.5px;color:#DDD3C7}.cnote .tag{padding:0;font-size:10px}
@media (max-width:1100px){.ccols{grid-template-columns:1fr}}
.cqrow{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin:0 0 14px}
.cq{position:relative;border:1px solid var(--rule);border-radius:16px;padding:14px 16px;background:rgba(16,11,11,.55);display:flex;flex-direction:column;gap:8px;overflow:hidden}
.cq:before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--mute)}
.cq.ban:before{background:var(--loss)}.cq.pick:before{background:var(--gold)}.cq.opp:before{background:#8DA2C0}
.cq.on{border-color:var(--gold);box-shadow:0 0 0 3px rgba(233,196,106,.18),0 0 30px rgba(233,196,106,.15)}
.cql{display:flex;align-items:center;gap:8px;font:700 11px var(--mono);letter-spacing:.16em;text-transform:uppercase;color:var(--mute)}
.cqm{display:grid;grid-template-columns:auto minmax(0,1fr) auto;gap:12px;align-items:center}
.cqm b{display:flex;align-items:center;gap:8px;flex-wrap:wrap;font:800 22px var(--head);color:#fff}
.cqm p{margin:3px 0 0;font-size:13.5px;color:#D6CCC0}
.cq p.bad,.cq p.bad b{color:#E8817C}.cq p.good{color:#8FD4A8}
.cbig{font:800 34px var(--d,var(--head));line-height:1}
.cqtip{margin:2px 0 0;font-size:13px;color:#DDD3C7;line-height:1.45;border-top:1px solid var(--rule);padding-top:8px}.cqtip .tag{font-size:10px;padding:0 6px 0 0}
.chips{display:flex;gap:6px;flex-wrap:wrap}.chips span{padding:2px 8px;border-radius:999px;background:#261C1B;border:1px solid var(--rule);font:600 11.5px var(--head);color:#D6CCC0}
.chips span.ap{color:#b9b0ff;border-color:rgba(140,125,255,.4)}.chips span.ad{color:#ffbd8f;border-color:rgba(255,154,90,.4)}
.vd{padding:2px 9px;border-radius:999px;font:700 11px var(--head);letter-spacing:.02em}
.vd.g{background:rgba(107,191,138,.16);color:#8FD4A8}.vd.g2{background:rgba(107,191,138,.10);color:#A9DDB9}.vd.n{background:#2C2120;color:#D6CCC0}.vd.r{background:rgba(217,83,79,.14);color:#E8817C}
.cbig.g,.cscore.g{color:#8FD4A8 !important}.cbig.g2,.cscore.g2{color:#A9DDB9 !important}.cbig.n,.cscore.n{color:#D6CCC0 !important}.cbig.r,.cscore.r{color:#E8817C !important}
.cmeter{height:7px;border-radius:99px;background:#261C1B;overflow:hidden;margin-top:8px}.cmeter.sm{height:5px;width:54px;margin-top:4px}
.cmeter span{display:block;height:100%;border-radius:99px}.cmeter .g{background:#6BBF8A}.cmeter .g2{background:#8FD4A8}.cmeter .n{background:#7C716A}.cmeter .r{background:#D9534F}
.crec{display:flex;height:6px;border-radius:99px;overflow:hidden;margin-top:6px;max-width:180px;background:#261C1B}.crec .w{background:#6BBF8A}.crec .l{background:#D9534F}
.crecl{font-size:11.5px;display:block;margin-top:3px}.crecl b{display:inline !important;font:700 11.5px var(--head) !important}.crecl .wv{color:#8FD4A8}.crecl .lv{color:#E8817C}
.csc{display:flex;flex-direction:column;align-items:flex-end}
.cidea li .tag{white-space:nowrap;min-width:86px !important}.cidea li.k-hipotese span{color:#e9d9a8}.cidea li.k-regra span{color:#b9c6e0}
.csub{margin:8px 0 0;font:700 11px var(--mono);letter-spacing:.12em;text-transform:uppercase;color:var(--mute)}
.cplan{border:1px solid rgba(233,196,106,.4);border-radius:14px;padding:12px 16px;margin:-4px 0 14px;background:rgba(233,196,106,.06)}.cplan p{margin:4px 0 0;color:#F0E4CC;font-size:14px;line-height:1.5}
.clegend{margin:4px 0 0;font-size:11.5px;color:var(--mute)}
.cavoid{margin:2px 0 0;font-size:13px;color:#D6CCC0}.cavoid b{color:var(--loss)}.cavoid span{color:var(--mute)}
.ctm{display:flex;flex-direction:column;gap:4px;margin:0 0 6px}.ctl{font:700 13px var(--head);color:#fff}.ctl small{color:var(--mute);font-weight:600}
.ctx{font-size:11.5px;color:var(--mute);display:flex;align-items:center;gap:4px;flex-wrap:wrap}.ctx i{width:8px;height:8px;border-radius:2px;display:inline-block;margin-left:4px}
.ctx i.ad{background:#ff9a5a}.ctx i.ap{background:#8c7dff}.ctx i.mx{background:#6D625C}
.cneed{display:flex;align-items:center;gap:6px;flex-wrap:wrap;padding:10px 12px;border-radius:12px;background:rgba(255,154,90,.08);border:1px solid rgba(255,154,90,.35)}
.cneed span{font:700 12px var(--head);color:#ffbd8f;margin-right:4px}.cneed b{padding:3px 10px;border-radius:999px;background:#ff9a5a;color:#1a1005;font:700 12px var(--head)}
@media (max-width:1100px){.cqrow{grid-template-columns:1fr}}
.sstat{display:flex;align-items:center;gap:14px;padding:12px 18px;border:1px solid var(--rule);border-radius:14px;background:var(--panel);margin-bottom:16px;flex-wrap:wrap}
.sstat i{width:11px;height:11px;border-radius:50%;background:var(--mute)}.sstat b{font:700 12px var(--mono);letter-spacing:.16em}
.sstat span{color:var(--mute);flex:1;min-width:200px}
.sstat.ok{border-color:rgba(94,224,192,.5)}.sstat.ok i{background:var(--win);box-shadow:0 0 0 0 rgba(94,224,192,.7);animation:ping 1.6s infinite}.sstat.ok b{color:var(--win)}
.sstat.wait i{background:var(--gold);animation:ping2 1.8s infinite}.sstat.wait b{color:var(--gold)}.sstat.off i{background:var(--loss)}.sstat.off b{color:var(--loss)}
@keyframes ping{70%{box-shadow:0 0 0 12px rgba(94,224,192,0)}100%{box-shadow:0 0 0 0 rgba(94,224,192,0)}}
@keyframes ping2{50%{opacity:.35}}
.arena{display:grid;grid-template-columns:1fr 90px 1fr;gap:0;align-items:stretch;border:1px solid var(--rule);border-radius:18px;overflow:hidden;
background:linear-gradient(90deg,rgba(59,158,255,.10),var(--panel) 40%,var(--panel) 60%,rgba(255,122,133,.10))}
.arena .side{padding:16px 18px;display:flex;flex-direction:column;gap:8px}.arena h3{margin:0 0 4px;font:700 12px var(--mono);letter-spacing:.2em;text-transform:uppercase}
.side.ally h3{color:#8cc4ff}.side.foe h3{color:#ff9aa3;text-align:right}
.vsmid{display:grid;place-items:center;position:relative}
.vsmid::before{content:"";position:absolute;top:10%;bottom:10%;left:50%;width:1px;background:linear-gradient(transparent,var(--gold),transparent)}
.vsmid span{position:relative;background:var(--bg);padding:10px 8px;font:800 22px var(--head);color:var(--gold);text-shadow:0 0 18px rgba(233,196,106,.7);animation:vsp 2.6s ease-in-out infinite}
@keyframes vsp{50%{transform:scale(1.18)}}
.slot{display:flex;align-items:center;gap:12px;padding:8px 12px;border-radius:12px;border:1px solid transparent;background:rgba(255,255,255,.03);transition:transform .2s,background .2s}
.slot:hover{transform:translateX(4px);background:rgba(255,255,255,.06)}
.side.foe .slot{flex-direction:row-reverse;text-align:right}.side.foe .slot:hover{transform:translateX(-4px)}
.slot .role{flex:none;width:38px;text-align:center;font:700 11px var(--mono);letter-spacing:.08em;color:var(--gold);padding:4px 0;border:1px solid rgba(233,196,106,.35);border-radius:6px}
.slot .sn{display:flex;flex-direction:column;gap:2px;min-width:0}.slot .sn b{font:700 16px var(--head)}.dim2{color:var(--mute)!important;font-weight:500!important}
.slot.mine{border-color:var(--gold);background:rgba(233,196,106,.08);box-shadow:0 0 22px rgba(233,196,106,.2)}
.you{font:700 10px var(--mono);letter-spacing:.14em;text-transform:uppercase;color:var(--gold);font-style:normal}
.cic.empty{display:grid;place-items:center;border-radius:50%;border:2px dashed var(--rule);color:var(--mute);font:700 20px var(--head)}
.pulse{animation:pl 1.8s ease-in-out infinite}@keyframes pl{50%{opacity:.35;transform:scale(.94)}}
.slot.blank{opacity:.65}
.bans{display:flex;align-items:center;gap:6px;margin-top:6px;padding-top:10px;border-top:1px solid var(--rule)}.bans small{font:600 10.5px var(--mono);letter-spacing:.14em;text-transform:uppercase;color:var(--mute);margin-right:4px}
.side.foe .bans{justify-content:flex-end;flex-direction:row-reverse}
.ban{position:relative;display:inline-block}.ban .cic{filter:grayscale(1) brightness(.7)}.ban u{position:absolute;left:-2px;right:-2px;top:50%;height:2px;background:var(--loss);transform:rotate(-35deg);text-decoration:none}
.arn{margin:10px 0 0;text-align:center;color:var(--mute);font-size:13.5px}
.pkrail{display:flex;gap:14px;overflow-x:auto;padding:6px 4px 14px;scroll-snap-type:x proximity}
.pk{position:relative;flex:none;width:176px;height:230px;border-radius:16px;border:1px solid var(--rule);background:var(--panel) center 15%/cover no-repeat;color:var(--ink);cursor:pointer;
display:flex;flex-direction:column;justify-content:flex-end;align-items:flex-start;gap:2px;padding:14px;text-align:left;scroll-snap-align:start;
text-transform:none;letter-spacing:0;transition:transform .25s,box-shadow .25s,border-color .25s,filter .25s;filter:saturate(.8) brightness(.85)}
.pk::after{display:none}
.pk:hover{transform:translateY(-6px);filter:saturate(1.1) brightness(1)}
.pk.on{border-color:var(--gold);box-shadow:0 0 0 1px var(--gold),0 14px 40px rgba(233,196,106,.28);filter:none;transform:translateY(-6px)}
.pk .pkn{font:700 20px var(--head)}.pk .pks{font:700 26px var(--head);color:var(--gold);text-shadow:0 0 14px rgba(233,196,106,.5)}.pk .pks small{font:10px var(--mono);color:var(--mute);margin-left:6px;letter-spacing:.14em}
.pk .tierb{top:12px;right:12px}
.tierb.tq{background:#2a3242;color:var(--mute)}
.tierb.tS{animation:sg 2.4s ease-in-out infinite}@keyframes sg{50%{box-shadow:0 0 22px rgba(217,70,239,.8)}}
.ppanel{display:block;margin-top:8px}
.cfg-top{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(0,1fr);gap:14px;align-items:stretch;margin-bottom:14px}
.cfg-top>*{margin:0 !important}.cfg-top .phero{min-height:100%}
.cfg-top .mets{display:flex;flex-direction:column;justify-content:center;gap:8px}
.cfg-row{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;align-items:stretch}.cfg-row.one{grid-template-columns:1fr}
.cfg-row>.card{margin:0 !important;height:100%;box-sizing:border-box}.cfg-col>.card{margin:0 !important}.cfg-col>.card:last-child{flex:1}.cfg-col{display:flex;flex-direction:column;gap:14px}
.cfg-row .rn{display:flex;gap:10px;align-items:center;padding:6px 0;border-top:1px solid rgba(255,255,255,.04)}.cfg-row .rn small{display:block;color:var(--steel);font-size:12px;line-height:1.35}
.cfg-row .rn b{font:600 13.5px var(--body)}.cfg-row .rn.big b{font-size:15px}
@media (max-width:1200px){.cfg-top,.cfg-row{grid-template-columns:1fr}}
.pk{background-image:linear-gradient(180deg,rgba(14,17,22,.05),#0e1116 92%),var(--bg,none) !important;background-size:cover !important;background-position:center 15% !important}
.ppanel.swap{animation:swp .45s cubic-bezier(.2,.7,.2,1)}@keyframes swp{from{opacity:0;transform:translateY(14px)}}
.ppanel .pr h2{margin-top:0}
.phero{position:relative;overflow:hidden;border-radius:18px;border:1px solid var(--rule);min-height:230px;display:flex;align-items:flex-end;background:#161a22}
.ph-art{position:absolute;inset:0;background-size:cover;background-position:center 18%;animation:kb 20s ease-in-out infinite alternate}
.ph-fade{position:absolute;inset:0;background:linear-gradient(0deg,rgba(14,17,22,.97) 12%,rgba(14,17,22,.15) 70%)}
.ph-in{position:relative;display:flex;align-items:center;gap:16px;padding:18px 20px;width:100%}
.ph-t{display:flex;flex-direction:column;flex:1}.ph-t b{font:800 34px/1.1 var(--head);text-shadow:0 2px 18px #000}.ph-t small{color:#b9c4d9;font-size:12.5px}
.ph-r{display:flex;flex-direction:column;align-items:center;gap:2px}.ph-r small{font:10px var(--mono);letter-spacing:.2em;color:var(--gold)}
.tierx{flex:none;width:58px;height:58px;display:grid;place-items:center;border-radius:14px;font:800 30px var(--head);color:#fff;border:1px solid rgba(255,255,255,.25)}
.tierx.tS{background:linear-gradient(135deg,#3b9eff,#d946ef);animation:sg 2.4s ease-in-out infinite}.tierx.tA{background:#3b6fd9}.tierx.tB{background:#a8823a}.tierx.tC{background:#7a3a44}.tierx.tq{background:#2a3242;color:var(--mute)}
.mets{margin-top:14px;display:flex;flex-direction:column;gap:12px}
.met{display:grid;grid-template-columns:52px 1fr auto;gap:14px;align-items:center}.met b{display:block;font:600 14px var(--head)}.met small{color:var(--mute);font:12px var(--mono)}
.tabs{display:inline-flex;gap:4px;padding:4px;border:1px solid var(--rule);border-radius:12px;background:var(--panel);margin-bottom:12px}
.tabs .tb{background:none;color:var(--mute);box-shadow:none;padding:9px 16px;border-radius:9px}.tabs .tb.on{background:linear-gradient(135deg,var(--purple),#2478d6);color:#fff;box-shadow:0 6px 18px rgba(59,158,255,.35)}
.tabs .tb:hover{filter:none;transform:none;box-shadow:none;color:#fff}
.tabc[hidden],.ppanel[hidden]{display:none}
.thrs{display:grid;grid-template-columns:repeat(auto-fill,minmax(360px,1fr));gap:14px}
.thr{display:grid;grid-template-columns:1.2fr auto;gap:10px 16px;align-items:center;padding:16px 18px;border:1px solid var(--rule);border-radius:16px;background:var(--panel) right center/cover;transition:transform .22s,box-shadow .22s,border-color .22s}
.thr:hover{transform:translateY(-4px);border-color:rgba(255,122,133,.6);box-shadow:0 14px 30px rgba(0,0,0,.45),0 0 22px rgba(255,122,133,.2)}
.thl{display:flex;align-items:center;gap:14px}.thl div{display:flex;flex-direction:column}.thl b{font:700 20px var(--head)}.thl small{color:var(--mute)}
.thm{display:flex;flex-direction:column;align-items:center}.thm small{font:10px var(--mono);letter-spacing:.2em;color:var(--loss)}
.thm .wring .fg{stroke:var(--loss)}
.thx{grid-column:1/-1;display:flex;gap:8px;flex-wrap:wrap}.thc{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border:1px solid var(--rule);border-radius:99px;background:rgba(0,0,0,.35);font:600 12.5px var(--head)}.thc small{color:var(--mute);font:11px var(--mono)}
.pchips{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:14px}
.pchip{display:inline-flex;align-items:center;gap:8px;padding:5px 6px 5px 6px;border:1px solid var(--rule);border-radius:99px;background:rgba(255,255,255,.03)}
.pchip span{font:600 14px var(--head)}.pchip button{padding:3px 9px;background:none;color:var(--mute);box-shadow:none;border-radius:99px;font-size:12px}.pchip button:hover{color:var(--loss);transform:none;box-shadow:none;filter:none}
@media (max-width:1000px){.ppanel{grid-template-columns:1fr}.arena{grid-template-columns:1fr}.vsmid{padding:6px}.side.foe h3{text-align:left}.side.foe .slot{flex-direction:row;text-align:left}}

/* ===== selecao v2: passos, um recado grande, duelo e times, listas ===== */
.cs2{display:flex;flex-direction:column;gap:14px;margin:0 0 22px}
.csteps{list-style:none;margin:0;padding:0;display:grid;grid-template-columns:repeat(3,1fr);gap:0;border:1px solid #2E2523;border-radius:14px;overflow:hidden;background:#161111}
.csteps li{position:relative;display:flex;align-items:center;gap:10px;padding:12px 18px;color:#8A7F77;border-right:1px solid #2E2523}
.csteps li:last-child{border-right:0}
.csteps .sn{width:26px;height:26px;border-radius:50%;display:grid;place-items:center;border:1px solid #3A2E2B;font:700 13px var(--d,var(--head))}
.csteps b{font:700 15px var(--d,var(--head));letter-spacing:.04em;text-transform:uppercase}
.csteps small{margin-left:auto;font:600 12px var(--body);color:#B8ADA3}
.csteps li.done{color:#C9BFB5}.csteps li.done .sn{background:#6BBF8A;border-color:#6BBF8A;color:#10170F}
.csteps li.on{color:#fff;background:linear-gradient(90deg,rgba(193,18,31,.22),rgba(193,18,31,.04))}
.csteps li.on .sn{background:#C1121F;border-color:#E0303D;color:#fff;box-shadow:0 0 0 4px rgba(193,18,31,.22)}
.csteps li.on small{color:#E9C46A}
.csteps li.on::after{content:'';position:absolute;left:0;right:0;bottom:0;height:2px;background:#C1121F}
.cs2-top{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(0,1fr);gap:14px;align-items:stretch}
.cs2-side{display:flex;flex-direction:column;gap:14px}
.nowh{position:relative;overflow:hidden;border-radius:18px;border:1px solid #3A2C29;min-height:280px;display:flex;background:#1A1414}
.nowh.k-ban{border-color:rgba(193,18,31,.55)}.nowh.k-pick{border-color:rgba(233,196,106,.5)}.nowh.k-plan{border-color:rgba(107,191,138,.45)}
.nh-art{position:absolute;inset:0;background-size:cover;background-position:62% 18%;opacity:.55;transform:scale(1.04);animation:kb 24s ease-in-out infinite alternate}
.nowh.k-ban .nh-art{filter:grayscale(.65) contrast(1.05)}
.nh-fade{position:absolute;inset:0;background:linear-gradient(90deg,#141010 30%,rgba(20,16,16,.82) 58%,rgba(20,16,16,.25)),linear-gradient(0deg,#141010,transparent 55%)}
.nh-in{position:relative;display:flex;flex-direction:column;gap:14px;padding:22px 24px;width:100%}.nh-main{flex:1}
.nh-eye{display:inline-flex;align-items:center;gap:7px;align-self:flex-start;padding:5px 12px;border-radius:999px;font:700 12px var(--body);letter-spacing:.14em;text-transform:uppercase}
.k-ban .nh-eye{background:#C1121F;color:#fff}.k-pick .nh-eye{background:#E9C46A;color:#1A1208}.k-plan .nh-eye{background:#6BBF8A;color:#0F1A12}
.nh-main{display:grid;grid-template-columns:auto minmax(0,1fr) auto;gap:18px;align-items:start}
.nh-ic{border-radius:18px !important;box-shadow:0 12px 30px -10px #000}
.nh-t>b{display:block;font:800 44px/1 var(--d,var(--head));letter-spacing:.01em;color:#fff;text-transform:uppercase;margin:2px 0 10px}
.nh-why{margin:0;font-size:15.5px;color:#E6DCD0;line-height:1.5;display:flex;gap:8px;align-items:flex-start}.nh-why b{color:#E8817C}
.nh-why .phg{flex:none;margin-top:3px;color:#E8817C}
.nh-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:7px}
.nh-list li,.lwhy li{display:flex;gap:9px;align-items:baseline;font-size:15px;color:#E6DCD0;line-height:1.4}
.nh-list li i,.lwhy li i,.kd{flex:none;width:8px;height:8px;border-radius:50%;display:inline-block;background:#8D99AE;transform:translateY(-1px)}
.w-dado i,i.w-dado{background:#6BBF8A !important}.w-regra i,i.w-regra{background:#E9C46A !important}.w-hipotese i,i.w-hipotese{background:transparent !important;border:1.5px dashed #8D99AE}
.nh-score{grid-row:span 2;display:flex;flex-direction:column;align-items:center;padding:10px 14px;border-radius:14px;background:rgba(0,0,0,.35);border:1px solid #3A2C29}
.nh-score span{font:800 52px/1 var(--d,var(--head))}.nh-score small{font:600 11.5px var(--body);color:#B8ADA3;white-space:nowrap}
.nh-score.g span{color:#8FD4A8}.nh-score.g2 span{color:#A9DDB9}.nh-score.n span{color:#D6CCC0}.nh-score.r span{color:#E8817C}
.nh-alt{grid-column:1/-1;align-self:end;display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:6px}
.nh-alt>span:first-child{font:600 12px var(--body);color:#8A7F77;text-transform:uppercase;letter-spacing:.1em}
.nh-a{display:inline-flex;align-items:center;gap:7px;padding:4px 12px 4px 4px;border-radius:999px;background:rgba(0,0,0,.4);border:1px solid #3A2C29;font:600 13px var(--body);color:#E6DCD0}
.nowh .crec{max-width:260px;height:8px;margin-top:12px}.nowh .crecl{font-size:12.5px}
.pl-g{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:4px}
.pl-r{display:flex;gap:12px;align-items:flex-start;padding:12px 14px;border-radius:12px;background:rgba(0,0,0,.42);border:1px solid #2E2523}
.pl-r b{display:block;font:700 13px var(--body);letter-spacing:.06em;text-transform:uppercase;margin-bottom:3px}
.pl-r p{margin:0;font-size:14px;line-height:1.45;color:#E6DCD0}
.pl-i{flex:none;width:34px;height:34px;border-radius:10px;display:grid;place-items:center}
.pl-r.k-duelo .pl-i{background:rgba(141,153,174,.16);color:#B9C3D3}.pl-r.k-duelo b{color:#B9C3D3}
.pl-r.k-perigo .pl-i{background:rgba(193,18,31,.18);color:#E8817C}.pl-r.k-perigo b{color:#E8817C}
.pl-r.k-fraco .pl-i{background:rgba(233,196,106,.14);color:#E9C46A}.pl-r.k-fraco b{color:#E9C46A}
.pl-r.k-pico .pl-i{background:rgba(107,191,138,.15);color:#8FD4A8}.pl-r.k-pico b{color:#8FD4A8}
.cbox{position:relative;border:1px solid #2E2523;border-radius:16px;padding:14px 16px;background:#1A1414;display:flex;flex-direction:column;gap:10px}
.cbox.hot{border-color:rgba(233,196,106,.55);box-shadow:0 0 0 3px rgba(233,196,106,.1)}
.cbl{display:flex;align-items:center;gap:7px;font:700 12px var(--body);letter-spacing:.14em;text-transform:uppercase;color:#B8ADA3}
.cbl .phg{color:#E9C46A}
.du-m{display:grid;grid-template-columns:auto 1fr;gap:12px;align-items:center}.du-m b{font:800 24px var(--d,var(--head));text-transform:uppercase;color:#fff}
.du-m small{font-size:13px;color:#B8ADA3}.du-m .good{color:#8FD4A8;font-weight:700}.du-m .bad{color:#E8817C;font-weight:700}
.du-tip{margin:0;font-size:14px;line-height:1.45;color:#E6DCD0;display:flex;gap:9px;align-items:baseline;border-top:1px solid #2E2523;padding-top:10px}
.du-wait{display:flex;gap:12px;align-items:center}.du-wait p{margin:0;color:#B8ADA3;font-size:13.5px;line-height:1.45}
.tgrid{display:grid;grid-template-columns:1fr auto 1fr;gap:18px;align-items:center}
.tside{display:flex;flex-direction:column;gap:8px}.tside.foe{align-items:flex-end;text-align:right}
.tvs{font:800 26px var(--d,var(--head));color:#C1121F;text-shadow:0 0 18px rgba(193,18,31,.55)}
.trow{display:flex;flex-direction:column;gap:8px}.tside.foe .trow{align-items:flex-end}
.tlab{display:flex;align-items:center;gap:10px;font:700 12px var(--body);letter-spacing:.12em;text-transform:uppercase;color:#E6DCD0}.trow.foe .tlab{color:#E8817C;flex-direction:row-reverse}
.tcells{display:flex;gap:8px}
.tslot{position:relative;width:48px;height:48px;border-radius:50%;display:inline-grid;place-items:center;flex:none}
.tslot img,.tslot .cic{width:48px !important;height:48px !important;border-radius:50%}
.tslot>i{position:absolute;right:-1px;bottom:-1px;width:13px;height:13px;border-radius:50%;border:2px solid #1A1414;background:#7C716A}
.tslot.d-ad>i{background:#E07B4F}.tslot.d-ap>i{background:#8C7DFF}.tslot.d-mix>i{background:#9A8F86}
.tslot.you{box-shadow:0 0 0 2px #1A1414,0 0 0 4px #E9C46A}
.tslot.tblank{border:1.5px dashed #3A2E2B;color:#5E534E}.tq{font:700 16px var(--d,var(--head))}
.tbans{display:inline-flex;gap:4px}.tban{position:relative;display:inline-flex}.tban img,.tban .cic{filter:grayscale(1) brightness(.6);border-radius:50%;width:20px !important;height:20px !important;font-size:8px}
.tban u{position:absolute;left:-1px;right:-1px;top:50%;height:2px;background:#C1121F;transform:rotate(-35deg)}
.tsum{font-size:12.5px;color:#9A8F86}
.tfoot{display:flex;align-items:center;gap:12px;flex-wrap:wrap;border-top:1px solid #2E2523;padding-top:10px}.tfoot .tleg{margin-left:auto}
.tleg{margin:0;font-size:11.5px;color:#8A7F77;display:flex;gap:6px;align-items:center}.tleg i{width:9px;height:9px;border-radius:50%;display:inline-block;margin-left:6px}
.tleg .d-ban{background:#C1121F;border-radius:1px;height:2px;width:12px;transform:rotate(-35deg)}.tleg .d-ad{background:#E07B4F}.tleg .d-ap{background:#8C7DFF}.tleg .d-mix{background:#9A8F86}
.cs2 .cneed{padding:8px 12px}.cs2 .cneed b{background:#E07B4F}
.cs2 .cnote{flex-direction:row;gap:9px;align-items:baseline;font-size:13.5px}
.clists{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.35fr);gap:14px}
.lrow{display:grid;grid-template-columns:22px auto minmax(0,1fr) auto;gap:12px;align-items:center;padding:10px 12px;border-radius:12px;border:1px solid transparent}
.lrow+.lrow{border-top-color:#251D1C}
.lrow.best{border-color:rgba(233,196,106,.35);background:rgba(233,196,106,.05)}
.lrow.soft{opacity:.88}
.lnum{font:800 18px var(--d,var(--head));color:#5E534E;text-align:center;display:grid;place-items:center}.lrow.best .lnum{color:#E9C46A}
.lt b{display:flex;align-items:center;gap:8px;font:700 16px var(--body);color:#fff}.lt small{display:flex;gap:7px;align-items:baseline;color:#B8ADA3;font-size:13px;margin-top:2px}
.lwhy{list-style:none;margin:5px 0 0;padding:0;display:flex;flex-direction:column;gap:3px}.lwhy li{font-size:13.5px}
.lsc{font:800 30px var(--d,var(--head))}.lsc.g{color:#8FD4A8}.lsc.g2{color:#A9DDB9}.lsc.n{color:#D6CCC0}.lsc.r{color:#E8817C}
.lrow .crec{width:110px;margin:0}.lrow .crecl{display:none}
.kleg{margin:-4px 0 0;font-size:12px;color:#8A7F77;display:flex;align-items:center;gap:6px;flex-wrap:wrap}.kleg i{margin-left:8px}.kleg i:first-child{margin-left:0}
.cs2 .cavoid{display:flex;align-items:center;gap:6px}.cs2 .cavoid .phg{color:#E8817C}
@media (max-width:1250px){.cs2-top,.clists{grid-template-columns:1fr}.pl-g{grid-template-columns:1fr}}
"""


def _bxd_js():
    from . import statsui
    return ("""<script>(function(){var M=window.__bxd=window.__bxd||{};function key(d){return d.dataset.c+'|'+d.dataset.p}
document.addEventListener('toggle',function(ev){var d=ev.target;if(!d.classList||!d.classList.contains('bxd'))return;var k=key(d);M[k]=M[k]||{};M[k].open=d.open;
if(!d.open||d.dataset.ok)return;d.dataset.ok=1;fetch('/selecao/opcoes?c='+encodeURIComponent(d.dataset.c)+'&p='+encodeURIComponent(d.dataset.p)).then(function(r){return r.text()})
.then(function(h){M[k].html=h;document.querySelectorAll('details.bxd').forEach(function(x){if(key(x)===k){x.dataset.ok=1;x.querySelector('.bxd-in').innerHTML=h}})})
.catch(function(){d.querySelector('.bxd-in').innerHTML='<p class=n>Não deu para carregar.</p>';d.dataset.ok=''})},true);
document.addEventListener('liveswap',function(){document.querySelectorAll('details.bxd').forEach(function(d){var m=M[key(d)];if(!m||!m.open)return;
if(m.html){d.dataset.ok=1;d.querySelector('.bxd-in').innerHTML=m.html}d.open=true})})})();</script>"""
            + statsui.BX_JS
            + "<style>.bxd{margin:14px 0 0;border:1px solid var(--rule);border-radius:14px;background:var(--panel)}.bxd>summary{cursor:pointer;padding:12px 16px;font:600 14px var(--body);color:#F0E4CC}"
              ".bxd>summary:hover{color:#fff}.bxd[open]>summary{border-bottom:1px solid var(--rule)}.bxd-in{padding:14px 16px}</style>")


JS = JS + _bxd_js()
