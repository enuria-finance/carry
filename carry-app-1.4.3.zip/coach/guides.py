"""Guia de campeao escrito pela IA (Claude) a partir dos dados OFICIAIS do campeao (habilidades, classes, dicas da Riot).

Gera uma vez por campeao e por versao do jogo e guarda em guides.sqlite (compartilhado). Assim cada guia custa uma vez so.
O texto sempre aparece marcado como "guia por IA": e conhecimento geral, nao estatistica.
"""
import json
import os
import re
import sqlite3
import time
import urllib.error
import urllib.request

API = "https://api.anthropic.com/v1/messages"

PROMPT = """Você é um analista de League of Legends escrevendo um guia em português do Brasil para jogadores que querem subir de elo.
Use SÓ o que é verdade sobre o campeão. Abaixo estão os dados oficiais da versão {patch} (habilidades e dicas da Riot) para você não errar mecânicas.

{data}

Responda APENAS com um JSON válido (sem texto antes ou depois), neste formato:
{{
 "identidade": "1-2 frases: como esse campeão ganha o jogo",
 "pontos_fortes": ["3 itens curtos"],
 "pontos_fracos": ["3 itens curtos"],
 "combos": [{{"nome": "nome curto", "sequencia": ["Q","W","E","R","AA","Flash"], "quando": "1 frase de quando usar", "dificuldade": "fácil|média|difícil"}}],
 "picos": [{{"quando": "ex.: Nível 6 / 1º item", "porque": "1 frase"}}],
 "rotas": ["3 dicas práticas da fase de rotas (0 a 14 min)"],
 "meio": ["3 dicas do meio de jogo (14 a 28 min)"],
 "fim": ["3 dicas do fim de jogo (28 min em diante)"],
 "erros_comuns": ["4 erros que jogadores de elo baixo cometem com ele"],
 "contra": ["4 dicas de como jogar CONTRA ele"],
 "janelas_contra": ["3 momentos em que ele está vulnerável"]
}}
Regras: ao citar uma habilidade do campeão no texto, escreva a marca [P], [Q], [W], [E] ou [R] logo depois do nome (ex.: "use a Shuriken Afiada [Q]") — o app troca a marca pelo ícone.
3 a 5 combos, sequências só com Q, W, E, R, AA (ataque básico), Flash, Incendiar ou nome de item ativo. Frases curtas e diretas, sem números inventados de dano."""


def _db(ddir):
    con = sqlite3.connect(os.path.join(ddir, "guides.sqlite"), timeout=10)
    con.execute("CREATE TABLE IF NOT EXISTS guide (champ TEXT, patch TEXT, data TEXT, created_ms INTEGER, PRIMARY KEY (champ, patch))")
    return con


def get(ddir, champ, patch):
    con = _db(ddir)
    try:
        r = con.execute("SELECT data FROM guide WHERE champ=? AND patch=?", (champ, patch)).fetchone()
        if not r:  # guia de uma versao anterior ainda serve enquanto o novo nao fica pronto
            r = con.execute("SELECT data FROM guide WHERE champ=? ORDER BY created_ms DESC LIMIT 1", (champ,)).fetchone()
        return json.loads(r[0]) if r else None
    finally:
        con.close()


def _official(cdata):
    from .ddragon import clean
    lines = [f"Campeão: {cdata.get('name')} — {cdata.get('title')}", f"Classes: {', '.join(cdata.get('tags', []))}",
             f"Recurso: {cdata.get('partype', '')}"]
    p = cdata.get("passive") or {}
    lines.append(f"Passiva — {p.get('name')}: {clean(p.get('description'))}")
    for k, sp in zip("QWER", cdata.get("spells") or []):
        lines.append(f"{k} — {sp.get('name')}: {clean(sp.get('description'))} (recarga {sp.get('cooldownBurn')}s)")
    for t in (cdata.get("allytips") or [])[:4]:
        lines.append(f"Dica oficial (jogando de): {clean(t)}")
    for t in (cdata.get("enemytips") or [])[:4]:
        lines.append(f"Dica oficial (jogando contra): {clean(t)}")
    return "\n".join(lines)


def generate(ddir, key, model, cid, cdata, patch, log=print):
    from . import ai
    body = {"model": model, "max_tokens": 2500,
            "messages": [{"role": "user", "content": PROMPT.format(patch=patch, data=_official(cdata))}]}
    last = None
    for attempt in range(2):
        try:
            res = ai.post(key, body, 120)
        except urllib.error.HTTPError as ex:
            raise RuntimeError(f"Serviço de IA respondeu {ex.code}: {ex.read().decode('utf-8', 'replace')[:200]}")
        text = "".join(b.get("text", "") for b in res.get("content") or [] if b.get("type") == "text")
        m = re.search(r"\{.*\}", text, re.S)
        try:
            data = json.loads(m.group(0)) if m else None
        except ValueError as ex:
            data, last = None, ex
        if isinstance(data, dict) and data.get("combos"):
            con = _db(ddir)
            try:
                con.execute("INSERT OR REPLACE INTO guide VALUES (?,?,?,?)", (cid, patch, json.dumps(data, ensure_ascii=False), int(time.time() * 1000)))
                con.commit()
            finally:
                con.close()
            log(f"Guia de {cdata.get('name')} pronto.")
            return data
        log("Resposta fora do formato; tentando de novo…")
    raise RuntimeError(f"Não consegui montar o guia agora ({last or 'formato inválido'}).")
