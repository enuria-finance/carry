"""Relatorio do coach: a partida inteira lida como um coach de time faria (fase de rotas, lutas, objetivos, visao,
itens, viradas de ouro) e as 3 prioridades com treino. Tambem monta o dossie completo que vai para a IA.

Tudo sai da linha do tempo oficial da partida (dado). Leituras e prioridades = hipotese/regra geral do app.
"""
import html
import json

from . import review, vod

e = lambda s: html.escape("" if s is None else str(s), quote=True)
FIGHT_GAP = 15000


def _mm(t):
    s = int(t // 1000)
    return f"{s // 60}:{s % 60:02d}"


def build(con, puuid, mid):
    ms, G = vod.moments(con, puuid, mid)
    if not G or not G.me:
        return None
    me, opp = G.me, G.opp
    R = {"champ": me["champion"], "opp": opp["champion"] if opp else None, "pos": me["position"], "win": bool(me["win"]),
         "kda": f"{me['kills']}/{me['deaths']}/{me['assists']}", "dur": G.duration, "moments": ms}
    # ---- fase de rotas ----
    lane = []
    if opp:
        for m in (3, 5, 8, 10, 14):
            a, b = G.frames.get((G.pid, m)), G.frames.get((opp["participant_id"], m))
            if a and b:
                lane.append({"m": m, "gold": a["gold"] - b["gold"], "cs": a["cs"] - b["cs"], "xp": (a.get("xp") or 0) - (b.get("xp") or 0),
                             "lv": (a["level"], b["level"])})
    R["lane"] = lane
    # ---- ouro do time minuto a minuto ----
    mine_ids = [G.pid] + [p["participant_id"] for p in G.allies]
    foe_ids = [p["participant_id"] for p in G.foes]
    series = []
    m = 0
    while (G.pid, m) in G.frames:
        gm = sum((G.frames.get((p, m)) or {}).get("gold", 0) for p in mine_ids)
        gf = sum((G.frames.get((p, m)) or {}).get("gold", 0) for p in foe_ids)
        series.append(gm - gf)
        m += 1
    R["series"] = series
    if series:
        mx = max(range(len(series)), key=lambda i: series[i])
        mn = min(range(len(series)), key=lambda i: series[i])
        R["peak"] = (mx, series[mx])
        R["low"] = (mn, series[mn])
        R["throw"] = series[mx] >= 2500 and not me["win"]
        R["comeback"] = series[mn] <= -2500 and me["win"]
    # ---- lutas (3+ abates com menos de 15 s entre eles) ----
    fights, cur = [], []
    for k in G.kills:
        if cur and k["t"] - cur[-1]["t"] > FIGHT_GAP:
            if len(cur) >= 3:
                fights.append(cur)
            cur = []
        cur.append(k)
    if len(cur) >= 3:
        fights.append(cur)
    F = []
    for f in fights:
        t0 = f[0]["t"]
        us = sum(1 for k in f if G.parts.get(k["victim"], {}).get("team_id") != G.team)
        them = len(f) - us
        inv = any(k["killer"] == G.pid or G.pid in k["assists"] or k["victim"] == G.pid for k in f)
        died = next((i for i, k in enumerate(f) if k["victim"] == G.pid), None)
        first_side = "nós" if G.parts.get(f[0]["victim"], {}).get("team_id") != G.team else "eles"
        xs = [k["x"] for k in f if k["x"] is not None]
        ys = [k["y"] for k in f if k["y"] is not None]
        zone = review.zone(sum(xs) / len(xs), sum(ys) / len(ys)) if xs else "?"
        mine_after, their_after = vod._after(G, f[-1]["t"])
        F.append({"t": t0, "us": us, "them": them, "inv": inv, "died": died, "first": first_side, "zone": zone,
                  "after_us": mine_after, "after_them": their_after})
    R["fights"] = F
    # ---- objetivos ----
    R["objs"] = [dict(o, ours=o["team"] == G.team) for o in G.objs if o["kind"] == "monstro"]
    R["towers"] = [o for o in G.objs if o["kind"] == "torre"]
    plates = con.execute("SELECT team_id FROM events WHERE match_id=? AND type='TURRET_PLATE_DESTROYED'", (mid,)).fetchall()
    R["plates"] = (sum(1 for p in plates if p[0] != G.team), sum(1 for p in plates if p[0] == G.team))   # (nossas, deles)
    # ---- visao ----
    def wards(pid):
        out = {"early": 0, "mid": 0, "late": 0, "control": 0}
        for r in con.execute("SELECT t_ms, ward_type FROM wards WHERE match_id=? AND participant_id=?", (mid, pid)):
            ph = "early" if r[0] < 14 * 60000 else "mid" if r[0] < 25 * 60000 else "late"
            out[ph] += 1
            if (r[1] or "").upper() == "CONTROL_WARD":
                out["control"] += 1
        return out
    R["wards"] = wards(G.pid)
    R["wards_opp"] = wards(opp["participant_id"]) if opp else None
    R["vision_score"] = me["vision_score"]
    # ---- voltas a base antes dos 14 (foto do minuto na fonte) ----
    fx = (lambda x, y: x < 1600 and y < 1600) if G.team == 100 else (lambda x, y: x > 13200 and y > 13200)
    R["recalls"] = sum(1 for m in range(2, 15) if (f := G.frames.get((G.pid, m))) and f["x"] is not None and fx(f["x"], f["y"]))
    # ---- primeiro item completo (voce x oponente) ----
    try:
        from . import builds
        from .ddragon import DataDragon
        import os
        from . import web
        items = DataDragon(cache_dir=os.path.join(web.CTX.get("ddir") or ".", "cache")).items()

        def first_legend(pid):
            for t, i in builds._purchases(con, mid, pid):
                it = items.get(str(i)) or {}
                if ((it.get("gold") or {}).get("total") or 0) >= 2500 and "Boots" not in (it.get("tags") or []) and not it.get("into"):
                    return t, it.get("name")
            return None
        R["item_me"] = first_legend(G.pid)
        R["item_opp"] = first_legend(opp["participant_id"]) if opp else None
    except Exception:
        R["item_me"] = R["item_opp"] = None
    R["priorities"] = priorities(R)
    R["verdict"] = verdict(R)
    return R


def verdict(R):
    """Uma frase: por que a partida foi como foi."""
    bits = []
    l10 = next((x for x in R["lane"] if x["m"] == 10), None)
    if l10:
        bits.append(("ganhou" if l10["gold"] > 300 else "perdeu" if l10["gold"] < -300 else "empatou") + f" a rota ({'+' if l10['gold'] >= 0 else ''}{l10['gold']} aos 10)")
    lost_f = [f for f in R["fights"] if f["them"] > f["us"]]
    won_f = [f for f in R["fights"] if f["us"] > f["them"]]
    if R["fights"]:
        bits.append(f"venceu {len(won_f)} de {len(R['fights'])} lutas grandes")
    if R.get("throw"):
        bits.append(f"chegou a +{R['peak'][1] / 1000:.1f}k aos {R['peak'][0]} min e deixou virar")
    if R.get("comeback"):
        bits.append(f"virou um jogo que estava {R['low'][1] / 1000:.1f}k aos {R['low'][0]} min")
    res = "Vitória" if R["win"] else "Derrota"
    return f"{res}: " + (", ".join(bits) if bits else "partida equilibrada nos números") + "."


DRILLS = {
    "numbers": ("Lutar sem saber onde estão os inimigos",
                "Antes de qualquer troca depois dos 10 min, olhe o minimapa e conte quantos inimigos estão visíveis. Se 2 ou mais sumiram, não entre.",
                "Treino: 3 partidas falando em voz alta 'faltam X' antes de cada luta."),
    "early": ("Mortes na fase de rotas",
              "Nos primeiros 10 min, só troque quando o oponente gastar a habilidade principal e com a onda do seu lado.",
              "Treino: meta de no máximo 1 morte antes dos 10 em 5 partidas seguidas."),
    "lane": ("Perder a rota no farm e no ouro",
             "Priorize o último golpe sobre a troca enquanto o oponente tem as habilidades prontas.",
             "Treino: 10 min de último golpe na ferramenta de prática antes de jogar."),
    "convert": ("Não transformar vantagem em objetivo",
                "Depois de um abate ou de uma luta ganha, a primeira pergunta é: qual torre ou objetivo dá para pegar agora?",
                "Treino: em toda luta ganha, digite no chat do time o objetivo seguinte (dragão, torre, barão)."),
    "objdeath": ("Morrer antes dos objetivos",
                 "Nos 60 s antes de dragão, larvas ou barão, jogue para não morrer: empurre a onda e chegue antes no rio com o time.",
                 "Treino: olhe o timer do objetivo a cada volta à base e planeje chegar 30 s antes."),
    "vision": ("Visão baixa",
               "Compre Sentinela de Controle em toda volta à base e use o amuleto sempre que estiver pronto.",
               "Treino: meta de 1 Sentinela de Controle por volta à base e visão acima do alvo da rota."),
    "throw": ("Deixar a vantagem virar",
              "Com vantagem, jogue junto do time e pelo objetivo; evite lados do mapa sem visão depois dos 20 min.",
              "Treino: com 2k ou mais de vantagem, só lute perto de objetivo ou com visão."),
}


def priorities(R):
    score = {}
    deaths = [m for m in R["moments"] if m["kind"] == "morte"]
    num = sum(1 for m in deaths if any("desvantagem numérica" in r for r in m["read"]))
    early = sum(1 for m in deaths if m["minute"] < 10)
    costly = sum(1 for m in deaths if any("custou objetivo" in r for r in m["read"]))
    if num:
        score["numbers"] = 3 * num
    if early >= 2:
        score["early"] = 3 * early
    l10 = next((x for x in R["lane"] if x["m"] == 10), None)
    if l10 and (l10["cs"] <= -10 or l10["gold"] <= -600):
        score["lane"] = 4 + abs(l10["gold"]) // 400
    kills = [m for m in R["moments"] if m["kind"] == "abate"]
    if kills and sum(1 for m in kills if any("convertido" in r for r in m["read"])) < len(kills) / 3:
        score["convert"] = 3 + len(kills) // 2
    if costly:
        score["objdeath"] = 4 * costly
    w, wo = R["wards"], R.get("wards_opp")
    if wo and (w["early"] + w["mid"] + w["late"]) < 0.6 * (wo["early"] + wo["mid"] + wo["late"]):
        score["vision"] = 4
    if R.get("throw"):
        score["throw"] = 8
    out = [(k, *DRILLS[k]) for k, _ in sorted(score.items(), key=lambda kv: -kv[1])[:3]]
    return out


def _gold_svg(R):
    s = R["series"]
    if len(s) < 3:
        return ""
    W, H, P = 900, 170, 30
    mx = max(1000, max(abs(v) for v in s))
    X = lambda i: P + (W - 2 * P) * i / (len(s) - 1)
    Y = lambda v: H / 2 - (H / 2 - 14) * v / mx
    pts = " ".join(f"{X(i):.1f},{Y(v):.1f}" for i, v in enumerate(s))
    area_up = f"M{X(0):.1f},{H / 2} L" + " L".join(f"{X(i):.1f},{Y(max(v, 0)):.1f}" for i, v in enumerate(s)) + f" L{X(len(s) - 1):.1f},{H / 2} Z"
    area_dn = f"M{X(0):.1f},{H / 2} L" + " L".join(f"{X(i):.1f},{Y(min(v, 0)):.1f}" for i, v in enumerate(s)) + f" L{X(len(s) - 1):.1f},{H / 2} Z"
    g = (f"<line x1='{P}' x2='{W - P}' y1='{H / 2}' y2='{H / 2}' stroke='rgba(255,255,255,.2)'/>"
         f"<path d='{area_up}' fill='rgba(107,191,138,.18)'/><path d='{area_dn}' fill='rgba(217,83,79,.18)'/>"
         f"<polyline points='{pts}' fill='none' stroke='#E9C46A' stroke-width='2'/>")
    for f in R["fights"]:
        i = f["t"] / 60000
        if i <= len(s) - 1:
            c = "#6BBF8A" if f["us"] > f["them"] else "#D9534F" if f["them"] > f["us"] else "#D6CCC0"
            g += (f"<g><line x1='{X(i):.1f}' x2='{X(i):.1f}' y1='8' y2='{H - 8}' stroke='{c}' stroke-opacity='.5' stroke-dasharray='3 3'/>"
                  f"<circle cx='{X(i):.1f}' cy='10' r='6' fill='{c}'><title>Luta aos {_mm(f['t'])}: {f['us']} x {f['them']}</title></circle></g>")
    for i in range(0, len(s), 5):
        g += f"<text x='{X(i):.1f}' y='{H - 2}' text-anchor='middle' style='font:600 10px var(--body);fill:#9A8F86'>{i}'</text>"
    return (f"<svg viewBox='0 0 {W} {H}' style='width:100%;height:auto'>{g}</svg>"
            "<p class='n'>Ouro do seu time menos o do inimigo, minuto a minuto. Bolinhas: lutas grandes (verde ganhou, vermelho perdeu).</p>")


def html_report(R):
    if not R:
        return ""
    T = lambda k: {"dado": "<span class='tag dado'>dado</span>", "hip": "<span class='tag hipotese'>hipótese</span>", "regra": "<span class='tag regra'>regra geral</span>"}[k]
    out = f"<div class='cr'><div class='cr-v {'w' if R['win'] else 'l'}'><small>Veredito do coach</small><b>{e(R['verdict'])}</b></div>"
    # prioridades
    if R["priorities"]:
        out += "<div class='cr-s'><h3>As 3 prioridades para subir</h3><ol class='cr-p'>"
        for k, title, fix, drill in R["priorities"]:
            out += f"<li><b>{e(title)}</b><p>{T('regra')} {e(fix)}</p><p class='n'>{e(drill)}</p></li>"
        out += "</ol></div>"
    # fase de rotas
    if R["lane"]:
        has_xp = any(x["xp"] for x in R["lane"])
        rows = "".join(f"<tr><td>{x['m']} min</td><td class='{'w' if x['gold'] >= 0 else 'l'}'>{'+' if x['gold'] >= 0 else ''}{x['gold']}</td>"
                       f"<td class='{'w' if x['cs'] >= 0 else 'l'}'>{x['cs']:+d}</td>"
                       + (f"<td class='{'w' if x['xp'] >= 0 else 'l'}'>{x['xp']:+d}</td>" if has_xp else "")
                       + f"<td>{x['lv'][0]} x {x['lv'][1]}</td></tr>" for x in R["lane"])
        l10 = next((x for x in R["lane"] if x["m"] == 10), R["lane"][-1])
        read = ("Rota ganha: a vantagem precisa virar placa, dragão ou ajuda no rio." if l10["gold"] > 300 else
                "Rota perdida: o foco é perder menos (farm seguro, não morrer) e jogar para o time depois dos 14." if l10["gold"] < -300 else
                "Rota empatada: quem rotacionar primeiro para objetivos ganha o mapa.")
        pl_us, pl_them = R["plates"]
        out += (f"<div class='cr-s'><h3>Fase de rotas contra {e(R['opp'] or '?')}</h3><table class='cr-t'><tr><th></th><th>Ouro</th><th>Farm</th>{'<th>XP</th>' if has_xp else ''}<th>Nível</th></tr>{rows}</table>"
                f"<p>{T('hip')} {e(read)}</p><p class='n'>{T('dado')} Placas de torre: seu time {pl_us}, inimigo {pl_them}. Voltas à base vistas antes dos 14 min: {R['recalls']}.</p>")
        if R.get("item_me"):
            t, nm = R["item_me"]
            vs = ""
            if R.get("item_opp"):
                d = (R["item_opp"][0] - t) / 60000
                vs = f" ({abs(d):.1f} min {'antes' if d > 0 else 'depois'} do {R['opp']} fechar {R['item_opp'][1]})"
            out += f"<p class='n'>{T('dado')} Primeiro item completo: {e(nm)} aos {_mm(t)}{e(vs)}.</p>"
        out += "</div>"
    # ouro e lutas
    out += "<div class='cr-s'><h3>Como a partida andou</h3>" + _gold_svg(R)
    if R.get("peak"):
        out += f"<p class='n'>{T('dado')} Maior vantagem: {R['peak'][1] / 1000:+.1f}k aos {R['peak'][0]} min. Maior desvantagem: {R['low'][1] / 1000:+.1f}k aos {R['low'][0]} min.</p>"
    if R.get("throw"):
        out += f"<p>{T('hip')} Jogo jogado fora: com mais de 2.5k de vantagem, a partida virou. O momento de olhar no replay é logo depois dos {R['peak'][0]} min.</p>"
    if R["fights"]:
        out += "<table class='cr-t'><tr><th>Luta</th><th>Onde</th><th>Placar</th><th>Você</th><th>Depois</th></tr>"
        for f in R["fights"]:
            you = ("morreu" + (" primeiro" if f["died"] == 0 else "")) if f["died"] is not None else ("participou" if f["inv"] else "não estava")
            after = ", ".join(f["after_us"]) + (" (nosso)" if f["after_us"] else "") + (", " if f["after_us"] and f["after_them"] else "") + ", ".join(f["after_them"]) + (" (deles)" if f["after_them"] else "")
            out += (f"<tr><td>{_mm(f['t'])}</td><td>{e(f['zone'])}</td><td class='{'w' if f['us'] > f['them'] else 'l' if f['them'] > f['us'] else ''}'>{f['us']} x {f['them']}</td>"
                    f"<td class='{'l' if f['died'] is not None else ''}'>{e(you)}</td><td>{e(after or '-')}</td></tr>")
        out += "</table>"
        absent = sum(1 for f in R["fights"] if not f["inv"])
        died_first = sum(1 for f in R["fights"] if f["died"] == 0)
        if absent:
            out += f"<p>{T('hip')} Você não estava em {absent} luta(s) grande(s): o time lutou com um a menos.</p>"
        if died_first:
            out += f"<p>{T('hip')} Você foi o primeiro a morrer em {died_first} luta(s): posição ou entrada cedo demais.</p>"
    out += "</div>"
    # objetivos e visao
    objs = R["objs"]
    w, wo = R["wards"], R.get("wards_opp")
    out += "<div class='cr-s'><h3>Objetivos e visão</h3>"
    if objs:
        out += "<p class='n'>" + " · ".join(f"<b>{_mm(o['t'])}</b> {e(o['name'])} <span class='{'w' if o['ours'] else 'l'}'>({'nosso' if o['ours'] else 'deles'})</span>" for o in objs) + "</p>"
        ou, ot = sum(1 for o in objs if o["ours"]), sum(1 for o in objs if not o["ours"])
        out += f"<p>{T('dado')} Objetivos grandes: seu time {ou}, inimigo {ot}.</p>"
    out += (f"<p class='n'>{T('dado')} Sentinelas colocadas: {w['early']} até os 14 min, {w['mid']} dos 14 aos 25, {w['late']} depois; {w['control']} de controle. "
            f"Pontuação de visão: {R['vision_score']}." + (f" O {e(R['opp'])} colocou {wo['early'] + wo['mid'] + wo['late']} ({wo['control']} de controle)." if wo else "") + "</p></div>")
    return out + "</div>"


def dossier_text(R):
    """Tudo o que a IA precisa para analisar como coach (texto compacto)."""
    L = [f"Jogador: {R['champ']} ({R['pos']}), contra {R['opp']}. Resultado: {'vitória' if R['win'] else 'derrota'}. KDA {R['kda']}. Duração {R['dur'] // 60} min.",
         "Veredito automático: " + R["verdict"]]
    for x in R["lane"]:
        L.append(f"Rota {x['m']} min: ouro {x['gold']:+d}, farm {x['cs']:+d}, xp {x['xp']:+d}, nível {x['lv'][0]} x {x['lv'][1]}.")
    L.append(f"Placas: nossas {R['plates'][0]}, deles {R['plates'][1]}. Voltas à base antes dos 14 (aprox.): {R['recalls']}.")
    if R.get("item_me"):
        L.append(f"Primeiro item: {R['item_me'][1]} aos {_mm(R['item_me'][0])}" + (f"; oponente {R['item_opp'][1]} aos {_mm(R['item_opp'][0])}" if R.get("item_opp") else ""))
    if R["series"]:
        L.append("Ouro do time (nós - eles) por minuto: " + ", ".join(f"{i}:{v / 1000:+.1f}k" for i, v in enumerate(R["series"]) if i % 2 == 0))
    for f in R["fights"]:
        L.append(f"Luta {_mm(f['t'])} em {f['zone']}: {f['us']} x {f['them']}, você: {'morreu' if f['died'] is not None else ('participou' if f['inv'] else 'ausente')}"
                 + (" (primeiro a morrer)" if f["died"] == 0 else "") + f"; depois: nós {f['after_us'] or '-'}, eles {f['after_them'] or '-'}.")
    for o in R["objs"]:
        L.append(f"Objetivo {_mm(o['t'])}: {o['name']} ({'nosso' if o['ours'] else 'deles'}).")
    w = R["wards"]
    L.append(f"Visão: {w['early']}/{w['mid']}/{w['late']} sentinelas por fase, {w['control']} de controle, pontuação {R['vision_score']}.")
    for m in R["moments"]:
        L.append(f"Lance {m['title']}: " + " ".join(m["facts"]) + " Leitura: " + " ".join(m["read"]))
    return "\n".join(L)


CSS = """
.cr{display:flex;flex-direction:column;gap:14px;margin:0 0 18px}
.cr-v{border-radius:16px;padding:16px 20px;border:1px solid var(--rule);background:var(--panel);border-left:5px solid #D9534F}
.cr-v.w{border-left-color:#6BBF8A}.cr-v small{display:block;font:700 11px var(--mono);letter-spacing:.14em;text-transform:uppercase;color:var(--mute)}
.cr-v b{display:block;font:700 19px/1.4 var(--head);color:#fff;margin-top:4px}
.cr-s{border:1px solid var(--rule);border-radius:16px;padding:14px 18px;background:var(--panel)}
.cr-s h3{margin:0 0 10px;font:700 16px var(--head);color:#fff}.cr-s p{margin:6px 0;color:#DDD3C7;font-size:14px}
.cr-p{margin:0;padding-left:20px;display:flex;flex-direction:column;gap:10px}.cr-p li b{color:#fff;font:700 15px var(--head)}
.cr-t{width:100%;border-collapse:collapse;margin:6px 0}.cr-t th{text-align:left;font:700 11px var(--mono);letter-spacing:.08em;color:var(--mute);padding:6px 8px;border-bottom:1px solid var(--rule)}
.cr-t td{padding:6px 8px;border-bottom:1px solid rgba(255,255,255,.04);font-size:13.5px;color:#E6DDD2}.cr-t td.w,.cr-s span.w{color:#8FD4A8}.cr-s span.l{color:#E8817C}.cr-t td.w{color:#8FD4A8}.cr-t td.l{color:#E8817C}
.cr-ai{border:1px solid rgba(233,196,106,.5);border-radius:16px;padding:16px 20px;background:radial-gradient(120% 140% at 0% 0%,rgba(233,196,106,.10),transparent 50%),var(--panel)}
.cr-ai h3{margin:0 0 8px;font:700 17px var(--head);color:#fff}.cr-ai h4{margin:14px 0 6px;font:700 14px var(--head);color:var(--gold)}
.cr-ai p,.cr-ai li{color:#EEE6DB;font-size:14.5px;line-height:1.6}.cr-ai .er{border-left:3px solid #D9534F;padding:6px 12px;margin:8px 0;background:rgba(217,83,79,.05);border-radius:0 10px 10px 0}
.cr-ai .ok{border-left:3px solid #6BBF8A;padding:6px 12px;margin:8px 0;background:rgba(107,191,138,.05);border-radius:0 10px 10px 0}
.cr-ai .er b,.cr-ai .ok b{color:#fff}
.cr-off{border:1px dashed rgba(233,196,106,.5);border-radius:14px;padding:14px 18px;color:#F0E4CC}
"""
