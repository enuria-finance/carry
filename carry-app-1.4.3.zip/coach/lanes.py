"""Pagina "Rotas": como jogar e como melhorar em cada rota (topo, selva, meio, atirador, suporte), com os SEUS numeros em cada uma.

Conteudo de jogo = regra geral (vale para a temporada atual, pode mudar com o patch). Numeros da pessoa = dado.
"""
import html

from . import icons, postmore

e = lambda s: html.escape("" if s is None else str(s), quote=True)

LANES = {
    "TOP": {
        "nome": "Topo", "frase": "A ilha do mapa: duelos longos, controle de onda e Teleporte.",
        "funcao": "Segurar o lado de cima, ganhar o duelo ou pelo menos não perder, e ajudar o time no meio do jogo com Teleporte ou dividindo o mapa.",
        "classes": "Lutadores e tanques (Darius, Garen, Ornn, Sett, Camille, Fiora).",
        "vitoria": ["Ganhar o duelo e transformar em placas e torre", "Dividir a rota no meio e fim de jogo (puxar 2 inimigos para você)",
                    "Usar o Teleporte para virar lutas no dragão"],
        "fases": {
            "Começo (0 a 14 min)": ["Saiba o seu nível 2 e 3: quem chega antes ganha a troca.", "Controle a onda: congele perto da sua torre quando estiver atrás ou com o caçador inimigo por perto.",
                                    "Volte à base quando a onda estiver indo para a torre inimiga, nunca com ela batendo na sua."],
            "Meio (14 a 25 min)": ["Empurre a rota lateral antes de cada objetivo.", "Guarde o Teleporte para lutas no dragão ou para não perder ondas.",
                                   "Arauto e larvas ficam do seu lado: ajude o caçador quando a onda estiver empurrada."],
            "Fim (25+ min)": ["Divida o mapa só com visão e sabendo onde estão os 5.", "Na luta: entre depois das habilidades principais do inimigo, nos alvos que você alcança."],
        },
        "erros": ["Trocar com a onda contra você", "Ficar sem Teleporte na hora do dragão", "Dividir a rota sem visão no fim de jogo", "Perder ondas inteiras para a torre"],
        "treino": ["Prática: 10 min de último golpe com o seu campeão", "Aprenda os 3 níveis de onda: empurrar, congelar e preparar (slow push)",
                   "Assista a um jogador de elo alto do seu campeão só olhando a onda"],
    },
    "JUNGLE": {
        "nome": "Selva", "frase": "O ritmo do mapa: acampamentos, ganks e objetivos.",
        "funcao": "Farmar a selva, ajudar as rotas com ganks na hora certa e controlar dragão, larvas, Arauto e Barão.",
        "classes": "Lutadores, assassinos e tanques (Lee Sin, Vi, Kayn, Nocturne, Sejuani, Jarvan IV).",
        "vitoria": ["Estar no lugar certo antes dos objetivos", "Gankar a rota que já tem vantagem (mais nível ou onda boa)",
                    "Farmar mais que o caçador inimigo e não perder tempo"],
        "fases": {
            "Começo (0 a 14 min)": ["Planeje a primeira volta: comece do lado oposto de onde quer chegar aos 3 min.", "Caranguejos aos 2:55: dispute com as rotas do meio e do lado com prioridade.",
                                    "Ganke rotas com o oponente sem Flash ou com a onda indo para a sua torre."],
            "Meio (14 a 25 min)": ["Dragão e larvas: chegue com as rotas do lado empurradas.", "Troque objetivos: se o inimigo pega um, pegue outro do outro lado.",
                                   "Visão no rio e na selva inimiga antes dos objetivos."],
            "Fim (25+ min)": ["Barão e Ancião decidem: tenha Destruição (Smite) pronta e o time vivo.", "Ande com o time; não farme sozinho do outro lado quando um objetivo nasce."],
        },
        "erros": ["Gankar rota sem prioridade de onda", "Farmar enquanto o inimigo faz o dragão", "Esquecer os tempos dos acampamentos", "Lutar no rio sem as rotas por perto"],
        "treino": ["Prática: rota completa de acampamentos terminando antes dos 2:45 (eles nascem aos 0:55)", "Em toda partida, anote quando o caçador inimigo apareceu", "Use o Modo caçador do app para ver a rota dos melhores com o seu campeão"],
    },
    "MIDDLE": {
        "nome": "Meio", "frase": "O centro do mapa: prioridade de onda e rotação.",
        "funcao": "Ganhar a prioridade da rota do meio (empurrar primeiro) para ajudar o caçador e rotacionar para as outras rotas e objetivos.",
        "classes": "Magos e assassinos (Ahri, Syndra, Orianna, Zed, LeBlanc, Yasuo).",
        "vitoria": ["Empurrar primeiro e chegar antes no rio", "Rotacionar para o lado com objetivo ou com abate fácil", "Dano nas lutas: posição e habilidade principal na hora certa"],
        "fases": {
            "Começo (0 a 14 min)": ["Troque quando o oponente gastar a habilidade principal.", "Empurre antes de voltar à base e antes do caranguejo.",
                                    "Avise o time quando o oponente sumir da rota."],
            "Meio (14 a 25 min)": ["Empurre o meio e vá para o lado do próximo objetivo.", "Use o tempo da onda: empurrou, tem 20 a 30 s livres.",
                                   "Visão nos dois lados do rio do meio."],
            "Fim (25+ min)": ["Fique perto do time; você é dano importante.", "Não seja o primeiro a ser visto: entre no mapa escuro só com o time."],
        },
        "erros": ["Rotacionar sem empurrar a onda antes", "Trocar com o oponente com todas as habilidades prontas", "Ficar no meio farmando enquanto o time luta", "Morrer sozinho no rio sem visão"],
        "treino": ["Prática: o combo principal do seu campeão até sair sem pensar", "Em 5 partidas, empurre e rotacione em todo caranguejo e dragão", "Anote onde o oponente estava quando sumiu da rota"],
    },
    "BOTTOM": {
        "nome": "Atirador", "frase": "O dano constante do time: farm, posição e picos de item.",
        "funcao": "Farmar muito para chegar forte no meio do jogo e causar dano contínuo nas lutas, sempre bem posicionado.",
        "classes": "Atiradores (Jinx, Kai'Sa, Ezreal, Caitlyn, Jhin, Ashe).",
        "vitoria": ["Farm alto (perto de 8 por minuto)", "Posicionamento nas lutas: bater no alvo mais próximo com segurança", "Picos de item: 2 itens completos é hora de pressionar"],
        "fases": {
            "Começo (0 a 14 min)": ["Jogue junto do suporte: troque quando ele trocar.", "Último golpe acima de tudo; troque só com vantagem.",
                                    "Dragão: com a onda empurrada e o caçador por perto."],
            "Meio (14 a 25 min)": ["Farm nas rotas laterais seguras e volte para os objetivos com o time.", "Não fique na rota de baixo sozinho depois de cair a primeira torre."],
            "Fim (25+ min)": ["Fique atrás da sua linha de frente.", "Bata no alvo mais próximo; procurar o alvo de trás é como atiradores morrem."],
        },
        "erros": ["Perder farm trocando sem motivo", "Avançar demais nas lutas", "Andar sozinho pelo rio sem visão", "Esquecer de comprar item quando tem ouro"],
        "treino": ["Prática: 10 min de último golpe (meta: 80 de farm aos 10 min)", "Treine andar e atacar (kiting) contra um boneco", "Revise as suas mortes: quantas foram por posicionamento?"],
    },
    "UTILITY": {
        "nome": "Suporte", "frase": "Os olhos do time: visão, proteção e roaming.",
        "funcao": "Proteger o atirador, controlar a visão do mapa e ajudar outras rotas quando a rota de baixo está segura.",
        "classes": "Encantadores e tanques de controle (Lulu, Nami, Thresh, Leona, Nautilus, Karma).",
        "vitoria": ["Visão: mais sentinelas e Sentinelas de Controle que o inimigo", "Roaming no meio quando a onda de baixo está segura",
                    "Engajar ou proteger na hora certa nas lutas"],
        "fases": {
            "Começo (0 a 14 min)": ["Visão no rio antes do caçador inimigo chegar (por volta de 2:15, os acampamentos nascem aos 0:55).", "Troque quando o atirador inimigo for dar o último golpe.",
                                    "Compre Sentinela de Controle em toda volta à base."],
            "Meio (14 a 25 min)": ["Visão nos objetivos 1 minuto antes de nascerem.", "Ande com o caçador para limpar e colocar visão.", "Ajude o meio quando o atirador estiver seguro."],
            "Fim (25+ min)": ["Visão em volta do Barão e do Ancião.", "Na luta: proteja quem causa dano ou engaje no alvo certo, não nos dois ao mesmo tempo."],
        },
        "erros": ["Visão baixa (menos de 1,5 por minuto)", "Deixar o atirador sozinho em hora errada", "Entrar na luta sem o time seguir", "Não comprar Sentinela de Controle"],
        "treino": ["Meta: pontuação de visão acima de 2 por minuto", "Em 5 partidas, coloque visão no rio antes dos 2:30", "Aprenda os pontos de visão de cada objetivo"],
    },
}
ORDER = ["TOP", "JUNGLE", "MIDDLE", "BOTTOM", "UTILITY"]


def my_numbers(games, pos):
    gs = [g for g in games if g.get("position") == pos]
    if not gs:
        return None
    n = len(gs)
    w = sum(1 for g in gs if g["win"])
    avg = lambda k: (sum(g[k] for g in gs if g.get(k) is not None) / max(1, sum(1 for g in gs if g.get(k) is not None))) if any(g.get(k) is not None for g in gs) else None
    sc = [postmore.score(g)["total"] for g in gs]
    sc = [x for x in sc if x is not None]
    return {"n": n, "w": w, "cspm": avg("cs_per_min"), "vis": avg("vision_per_min"), "kp": avg("kp"), "d10": avg("deaths_before_10"),
            "score": sum(sc) / len(sc) if sc else None, "champs": sorted({g["champion"] for g in gs}, key=lambda c: -sum(1 for g in gs if g["champion"] == c))[:5]}


def page_html(games, pos, tier_rows_fn=None, champs=None):
    pos = pos if pos in LANES else "MIDDLE"
    L = LANES[pos]
    tabs = "".join(f"<a href='/rotas?r={p}' class='{'on' if p == pos else ''}'>{e(LANES[p]['nome'])}</a>" for p in ORDER)
    t_cs, t_vis, t_kp = postmore.TARGETS[pos]
    nm = my_numbers(games, pos)
    def meter(lbl, val, tgt, fmt, pct=False):
        if val is None:
            return f"<div class='ln-m'><small>{e(lbl)}</small><b>–</b><span>alvo {fmt.format(tgt * 100 if pct else tgt)}</span></div>"
        ok = val >= tgt
        v = val * 100 if pct else val
        return (f"<div class='ln-m'><small>{e(lbl)}</small><b class='{'g' if ok else 'r'}'>{fmt.format(v)}</b>"
                f"<span>alvo {fmt.format(tgt * 100 if pct else tgt)}</span><i style='width:{min(100, 100 * val / tgt):.0f}%' class='{'g' if ok else 'r'}'></i></div>")
    mine = ""
    if nm:
        mine = (f"<div class='ln-card'><h3>Os seus números de {e(L['nome'].lower())}</h3><p class='n'><span class='tag dado'>dado</span> {nm['n']} partidas, "
                f"{nm['w']} vitórias ({round(100 * nm['w'] / nm['n'])}%)." + (f" Nota média {nm['score']:.0f}." if nm["score"] is not None else "") + "</p>"
                "<div class='ln-ms'>" + meter("Farm por minuto", nm["cspm"], t_cs, "{:.1f}") + meter("Visão por minuto", nm["vis"], t_vis, "{:.2f}")
                + meter("Participação em abates", nm["kp"], t_kp, "{:.0f}%", pct=True) + "</div>"
                + ("<p class='n'>Seus campeões aqui: " + " ".join(icons.champ(c, 26) for c in nm["champs"]) + "</p>" if nm["champs"] else "") + "</div>")
    else:
        mine = f"<div class='ln-card'><h3>Os seus números de {e(L['nome'].lower())}</h3><p class='n'>Você ainda não tem partidas nessa rota.</p></div>"
    best = ""
    if tier_rows_fn:
        try:
            rows, _ = tier_rows_fn(pos)
            if rows:
                best = ("<div class='ln-card'><h3>Mais fortes agora entre os melhores</h3><div class='ln-best'>"
                        + "".join(f"<a href='/campeao/{e(icons.champ_id(r['champion']))}'>{icons.champ(r['champion'], 40)}<span>{e((champs or {}).get(r['champion'], {}).get('name', r['champion']))}</span><small>{r['wr']:.0f}%</small></a>" for r in rows[:6])
                        + "</div><p class='n'><a href='/tierlist?pos=" + pos + "'>Ver a tier list completa</a></p></div>")
        except Exception:
            pass
    fases = "".join(f"<div class='ln-ph'><h4>{e(f)}</h4><ul>" + "".join(f"<li>{e(x)}</li>" for x in xs) + "</ul></div>" for f, xs in L["fases"].items())
    body = (f"<div class='p4-seg ln-tabs'>{tabs}</div>"
            f"<section class='ln-hero'><div><small>Rota</small><div class='ln-name'>{e(L['nome'])}</div><p class='lead'>{e(L['frase'])}</p></div>"
            f"<div class='ln-role'><p><b>O seu trabalho:</b> {e(L['funcao'])}</p><p class='n'><b>Quem joga aqui:</b> {e(L['classes'])}</p></div></section>"
            "<div class='ln-grid'>"
            f"<div class='ln-card ln-wide'><h3>Como se ganha jogando de {e(L['nome'].lower())}</h3><ol class='ln-win'>" + "".join(f"<li>{e(x)}</li>" for x in L["vitoria"]) + "</ol></div>"
            + mine + (best or "<div class='ln-card'><h3>Mais fortes agora entre os melhores</h3><p class='n'>Baixe a amostra dos melhores em Sincronizar para ver.</p></div>") +
            f"<div class='ln-card ln-wide'><h3>Fase a fase</h3><div class='ln-phs'>{fases}</div></div>"
            f"<div class='ln-card'><h3>Erros mais comuns no elo baixo</h3><ul class='ln-x'>" + "".join(f"<li>{e(x)}</li>" for x in L["erros"]) + "</ul></div>"
            f"<div class='ln-card'><h3>Treino</h3><ul class='ln-t'>" + "".join(f"<li>{e(x)}</li>" for x in L["treino"]) + "</ul></div>"
            + "</div>"
            "<p class='n'><span class='tag regra'>regra geral</span> Os conselhos valem para a temporada atual e podem mudar com o patch. Os alvos de farm, visão e participação são do app.</p>")
    return body


CSS = """
.ln-hero{display:grid;grid-template-columns:minmax(0,.9fr) minmax(0,1.1fr);gap:28px;align-items:end;padding:26px 28px;border-radius:22px;margin:0 0 18px;
background:radial-gradient(90% 140% at 0% 0%,color-mix(in srgb,var(--ac,#d7263d) 22%,transparent),transparent 60%),var(--panel);border:1px solid var(--rule)}
.ln-hero small{font:700 11px var(--mono);letter-spacing:.2em;text-transform:uppercase;color:var(--mute)}
.ln-name{margin:4px 0 6px;font:800 72px/.9 var(--d);letter-spacing:.01em;color:var(--bone,#fff)}
.ln-hero .lead{margin:0;font-size:17px;color:#DDD3C7}.ln-role p{margin:6px 0;font-size:14.5px;color:#DDD3C7}
.ln-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.ln-card{border:1px solid var(--rule);border-radius:18px;padding:18px 20px;background:var(--panel)}.ln-card.ln-wide{grid-column:1/-1}
.ln-card h3{margin:0 0 10px;font:700 17px var(--head) !important;color:#fff;text-transform:none !important;letter-spacing:0 !important}
.ln-card li{text-transform:none !important;letter-spacing:0 !important;font-weight:400 !important}
.ln-win{margin:0;padding:0;list-style:none;counter-reset:w;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
.ln-win li{counter-increment:w;position:relative;padding:14px 14px 14px 52px;border-radius:14px;background:rgba(16,11,11,.45);border:1px solid var(--rule);color:#EEE6DB;font-size:14px}
.ln-win li:before{content:counter(w);position:absolute;left:14px;top:12px;font:800 28px/1 var(--d);color:var(--ac,#d7263d)}
.ln-phs{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.ln-ph{padding:12px 14px;border-radius:14px;background:rgba(16,11,11,.45);border:1px solid var(--rule)}
.ln-ph h4{margin:0 0 6px;font:700 13px var(--head);color:var(--gold)}.ln-ph ul,.ln-x,.ln-t{margin:0;padding-left:18px}.ln-ph li,.ln-x li,.ln-t li{margin:5px 0;font-size:13.5px;color:#DDD3C7}
.ln-x li::marker{color:#D9534F}.ln-t li::marker{color:#6BBF8A}
.ln-ms{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin:8px 0}
.ln-m{position:relative;padding:10px 12px 14px;border-radius:12px;background:rgba(16,11,11,.45);border:1px solid var(--rule);overflow:hidden}
.ln-m small{display:block;font-size:11.5px;color:var(--mute)}.ln-m b{display:block;font:800 22px var(--d);color:#fff}.ln-m b.g{color:#8FD4A8}.ln-m b.r{color:#E8817C}
.ln-m span{font-size:11px;color:var(--mute)}.ln-m i{position:absolute;left:0;bottom:0;height:3px}.ln-m i.g{background:#6BBF8A}.ln-m i.r{background:#D9534F}
.ln-best{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.ln-best a{display:flex;align-items:center;gap:8px;padding:8px;border-radius:12px;background:rgba(16,11,11,.45);text-decoration:none;color:#EEE6DB;font-size:13px}
.ln-best small{margin-left:auto;color:#8FD4A8;font-weight:700}
@media (max-width:1000px){.ln-hero,.ln-grid,.ln-win,.ln-phs,.ln-ms,.ln-best{grid-template-columns:1fr}}
"""
