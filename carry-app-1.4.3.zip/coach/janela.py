"""Janela propria do Carry (como um programa), em vez de uma aba do navegador.

Usa o pywebview com o motor do Edge (WebView2, que ja vem no Windows 10 e 11). Se nao der (falta o pacote ou o
WebView2), abre no navegador como antes. Fechar a janela nao desliga o Carry: o overlay e a sincronizacao continuam.
Abrir de novo (atalho ou instalador) so traz a janela para a frente.

Uso interno: abrir(url) no app; o processo da janela roda com  pythonw -m coach.janela <url>.
"""
import importlib.util
import os
import socket
import subprocess
import sys
import threading
import time
import webbrowser

PORTA = 8766                          # a janela escuta aqui para "aparecer" quando abrem o Carry de novo
AQUI = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ICONE = next((p for p in (os.path.join(AQUI, "carry.ico"), os.path.join(os.path.dirname(AQUI), "carry.ico")) if os.path.exists(p)),
             os.path.join(AQUI, "carry.ico"))
SEM_JANELA = 0x08000000 if os.name == "nt" else 0


def _ping(msg):
    try:
        with socket.create_connection(("127.0.0.1", PORTA), timeout=0.6) as s:
            s.sendall(msg.encode("utf-8"))
            return True
    except OSError:
        return False


def _pythonw():
    exe = sys.executable
    if exe.lower().endswith("python.exe"):
        cand = exe[:-len("python.exe")] + "pythonw.exe"
        if os.path.exists(cand):
            return cand
    return exe


def _launcher():
    """Carry.exe (o lancador com o icone do app), ao lado do app ou uma pasta acima (instalador).
    Desligado ate o Carry.exe ter assinatura digital: sem ela o Controle Inteligente de Aplicativos do Windows bloqueia."""
    if os.environ.get("CARRY_LAUNCHER") != "1":
        return None
    for d in (AQUI, os.path.dirname(AQUI)):
        p = os.path.join(d, "Carry.exe")
        if os.path.exists(p):
            return p
    return None


def _grava_python():
    """O Carry.exe le este arquivo para saber qual Python abrir."""
    try:
        os.makedirs(os.path.join(AQUI, "cache"), exist_ok=True)
        with open(os.path.join(AQUI, "cache", "carry_python.txt"), "w", encoding="utf-8") as f:
            f.write(_pythonw())
    except OSError:
        pass


def tem_webview():
    return importlib.util.find_spec("webview") is not None


def instalar_em_fundo():
    """Instala o pywebview para a proxima vez (sem travar: desta vez abre no navegador)."""
    if os.name != "nt":
        return
    exe = sys.executable.replace("pythonw.exe", "python.exe")
    try:
        subprocess.Popen([exe, "-m", "pip", "install", "--user", "--quiet", "pywebview"], creationflags=SEM_JANELA,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def abrir(url):
    """Mostra o Carry: traz a janela para a frente, cria a janela ou, se nao der, abre no navegador."""
    if os.environ.get("CARRY_NAVEGADOR") == "1":
        webbrowser.open(url)
        return "navegador"
    if _ping("show " + url):
        return "janela"
    if os.name != "nt" or not tem_webview():
        instalar_em_fundo()
        webbrowser.open(url)
        return "navegador"
    try:
        subprocess.Popen([_pythonw(), "-m", "coach.janela", url], cwd=AQUI, creationflags=SEM_JANELA)
    except Exception:
        webbrowser.open(url)
        return "navegador"
    for _ in range(40):                    # ate 10 s para a janela subir; senao, navegador
        time.sleep(0.25)
        if _ping("ping"):
            return "janela"
    webbrowser.open(url)
    return "navegador"


def _icone_win32(titulo="Carry"):
    """Poe o icone do Carry na janela (barra de titulo, barra de tarefas e Alt+Tab) pela API do Windows.
    Funciona de qualquer thread, ao contrario de mexer no WinForms por fora."""
    import ctypes
    from ctypes import wintypes
    u = ctypes.windll.user32
    u.LoadImageW.restype = wintypes.HANDLE
    u.LoadImageW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR, wintypes.UINT, ctypes.c_int, ctypes.c_int, wintypes.UINT]
    u.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    set_cls = getattr(u, "SetClassLongPtrW", None) or u.SetClassLongW
    set_cls.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_void_p]
    pid = os.getpid()
    alvo = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def cada(h, _):
        p = wintypes.DWORD()
        u.GetWindowThreadProcessId(h, ctypes.byref(p))
        if p.value == pid and u.IsWindowVisible(h):
            n = u.GetWindowTextLengthW(h)
            b = ctypes.create_unicode_buffer(n + 1)
            u.GetWindowTextW(h, b, n + 1)
            if b.value == titulo:
                alvo.append(h)
        return True
    u.EnumWindows(cada, 0)
    if not alvo:
        return False
    LR_LOADFROMFILE, IMAGE_ICON, WM_SETICON = 0x10, 1, 0x80
    grande = u.LoadImageW(None, ICONE, IMAGE_ICON, u.GetSystemMetrics(11), u.GetSystemMetrics(12), LR_LOADFROMFILE)
    pequeno = u.LoadImageW(None, ICONE, IMAGE_ICON, u.GetSystemMetrics(49), u.GetSystemMetrics(50), LR_LOADFROMFILE)
    if not grande:
        return False
    for h in alvo:
        u.SendMessageW(h, WM_SETICON, 1, grande)
        u.SendMessageW(h, WM_SETICON, 0, pequeno or grande)
        set_cls(h, -14, grande)             # GCLP_HICON
        set_cls(h, -34, pequeno or grande)  # GCLP_HICONSM
        try:
            _relaunch_props(h)
        except Exception:
            pass
    return True


AUMID = "Carry.Coach"


def _relaunch_props(hwnd):
    """Fixar na barra de tarefas: diz ao Windows que esta janela e o 'Carry' (icone, nome e como abrir de novo),
    e nao o Python que roda por baixo. Sem isso o atalho fixado aparece com o icone do Python."""
    import ctypes
    from ctypes import wintypes

    class GUID(ctypes.Structure):
        _fields_ = [("a", ctypes.c_uint32), ("b", ctypes.c_uint16), ("c", ctypes.c_uint16), ("d", ctypes.c_ubyte * 8)]

    class PROPERTYKEY(ctypes.Structure):
        _fields_ = [("fmtid", GUID), ("pid", wintypes.DWORD)]

    class PROPVARIANT(ctypes.Structure):
        _fields_ = [("vt", ctypes.c_ushort), ("r1", ctypes.c_ushort), ("r2", ctypes.c_ushort), ("r3", ctypes.c_ushort),
                    ("p", ctypes.c_void_p), ("p2", ctypes.c_void_p)]

    def guid(t):
        h = t.replace("-", "")
        return GUID(int(h[0:8], 16), int(h[8:12], 16), int(h[12:16], 16), (ctypes.c_ubyte * 8)(*bytes.fromhex(h[16:])))
    fmt = guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3")
    iid = guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99")       # IPropertyStore
    store = ctypes.c_void_p()
    if ctypes.windll.shell32.SHGetPropertyStoreForWindow(wintypes.HWND(hwnd), ctypes.byref(iid), ctypes.byref(store)) != 0 or not store:
        return False
    vt = ctypes.cast(ctypes.cast(store, ctypes.POINTER(ctypes.c_void_p))[0], ctypes.POINTER(ctypes.c_void_p))
    SetValue = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, ctypes.POINTER(PROPERTYKEY), ctypes.POINTER(PROPVARIANT))(vt[6])
    Commit = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p)(vt[7])
    Release = ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(vt[2])
    lz = _launcher()
    cmd = f'"{lz}"' if lz else f'"{_pythonw()}" "{os.path.join(AQUI, "LoL Coach.pyw")}"'
    keep = []
    for pid, val in ((5, AUMID), (2, cmd), (4, "Carry"), (3, ICONE + ",0")):
        buf = ctypes.create_unicode_buffer(val)
        keep.append(buf)
        pv = PROPVARIANT(31, 0, 0, 0, ctypes.cast(buf, ctypes.c_void_p), None)    # VT_LPWSTR
        SetValue(store, ctypes.byref(PROPERTYKEY(fmt, pid)), ctypes.byref(pv))
    Commit(store)
    Release(store)
    return True


def _icone(window=None):
    """Icone do Carry na barra de titulo e na barra de tarefas (no lugar do icone do Python)."""
    if os.name != "nt" or not os.path.exists(ICONE):
        return
    for _ in range(60):                     # espera a janela aparecer (ate ~15 s)
        try:
            if _icone_win32():
                return
        except Exception:
            pass
        time.sleep(0.25)


def criar_atalho():
    """Atalho 'Carry' com o icone do app na area de trabalho e no menu Iniciar. Refaz sempre: corrige atalho quebrado
    ou que aponta para um Python/pasta antigos."""
    if os.name != "nt":
        return
    alvo = os.path.join(AQUI, "LoL Coach.pyw")
    if not os.path.exists(alvo) or not os.path.exists(ICONE):
        return
    _grava_python()
    lz = _launcher()
    ps = (
        "$w=New-Object -ComObject WScript.Shell;"
        "foreach($d in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){"
        "$p=Join-Path $d 'Carry.lnk'; if($true){"
        "$s=$w.CreateShortcut($p);$s.TargetPath='" + (lz or _pythonw()).replace("'", "''") + "';"
        "$s.Arguments='" + ("" if lz else '\"' + alvo.replace("'", "''") + '\"') + "';$s.WorkingDirectory='" + AQUI.replace("'", "''") + "';"
        "$s.IconLocation='" + ICONE.replace("'", "''") + ",0';$s.Description='Carry - coach de LoL';$s.Save()}}"
    )
    try:
        subprocess.Popen(["powershell", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-Command", ps],
                         creationflags=SEM_JANELA, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def main(url):
    import webview
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(AUMID)
        except Exception:
            pass
    try:
        webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = True
        webview.settings["ALLOW_DOWNLOADS"] = True
    except Exception:
        pass
    w = webview.create_window("Carry", url, width=1400, height=880, min_size=(1000, 640), background_color="#120D0E",
                              text_select=True)
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", PORTA))
    srv.listen(5)

    def escuta():
        while True:
            try:
                c, _ = srv.accept()
                msg = c.recv(2048).decode("utf-8", "ignore")
                c.close()
            except OSError:
                return
            if msg.startswith("show"):
                try:
                    w.restore()
                    w.show()
                    w.on_top = True
                    w.on_top = False
                    novo = msg[5:].strip()
                    if novo and "/guia" in novo:
                        w.load_url(novo)
                except Exception:
                    pass
    threading.Thread(target=escuta, daemon=True).start()

    def ao_abrir():
        _icone(w)
        criar_atalho()

    store = os.path.join(AQUI, "cache", "janela")
    os.makedirs(store, exist_ok=True)
    webview.start(ao_abrir, private_mode=False, storage_path=store)     # guarda o login entre uma abertura e outra
    try:
        srv.close()
    except Exception:
        pass


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8765/launcher")
