"""Saude do app: anota quando o overlay fecha sozinho ou trava (com o motivo) e junta os diarios para reportar problema."""
import io
import os
import time
import zipfile

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG = os.path.join(RAIZ, "cache", "saude.log")
VIVO = os.path.join(RAIZ, "cache", "overlay_vivo.txt")
ERR = os.path.join(RAIZ, "cache", "overlay_erro.log")


def anota(msg, extra=""):
    try:
        os.makedirs(os.path.dirname(LOG), exist_ok=True)
        with open(LOG, "a", encoding="utf-8") as fh:
            fh.write(time.strftime("%d/%m %H:%M:%S ") + msg + (("\n    " + extra.replace("\n", "\n    ")) if extra else "") + "\n")
    except Exception:
        pass


def vivo_idade():
    try:
        t = float(open(VIVO).read().split()[0])
        return time.time() - t
    except Exception:
        return None


def erro_tail(n=12):
    try:
        return "\n".join(open(ERR, encoding="utf-8", errors="ignore").read().splitlines()[-n:])
    except Exception:
        return ""


def ultimas(n=12):
    try:
        lines = open(LOG, encoding="utf-8").read().splitlines()
        return [ln for ln in lines if not ln.startswith("    ")][-n:]
    except Exception:
        return []


def _tail(path, n):
    import re
    try:
        txt = "\n".join(open(path, encoding="utf-8", errors="ignore").read().splitlines()[-n:])
    except Exception:
        return ""
    # nunca leva chave nem token junto
    txt = re.sub(r"RGAPI-[0-9a-fA-F-]+", "[chave da Riot]", txt)
    txt = re.sub(r"AIza[0-9A-Za-z_\-]{20,}", "[chave do Gemini]", txt)
    txt = re.sub(r"sk[-_][0-9A-Za-z_\-]{16,}", "[chave]", txt)
    txt = re.sub(r"(?i)(token|senha|password)=\S+", r"\1=[oculto]", txt)
    return txt


def pacote(descricao, versao):
    """Zip com o que precisa para achar um problema: descricao, versao, diarios (sem chaves, senhas nem partidas)."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("descricao.txt", f"Versão: {versao}\nData: {time.strftime('%d/%m/%Y %H:%M')}\n\n{descricao or ''}\n")
        z.writestr("saude.log", _tail(LOG, 400))
        z.writestr("overlay.log", _tail(os.path.join(RAIZ, "overlay.log"), 1500))
        z.writestr("coach.log", _tail(os.path.join(RAIZ, "coach.log"), 1500))
        z.writestr("overlay_erro.log", _tail(ERR, 400))
    return buf.getvalue()
