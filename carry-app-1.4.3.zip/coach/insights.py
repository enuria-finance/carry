"""Dicas e comparacoes. Cada linha diz de onde vem (dado, regra geral ou hipotese)."""
import statistics

from . import profile, report
from .tags import DADO, REGRA, HIPOTESE, LOW_SAMPLE, tip

VISION_GOAL = 0.9
COMPARE = [("cs10", "CS aos 10 min", 0), ("cs15", "CS aos 15 min", 0),
           ("deaths_before_15", "Mortes antes dos 15", 2), ("vision_per_min", "Visão por minuto", 2),
           ("kp", "Participação em abates", 2), ("cs_per_min", "CS por minuto", 1)]


def home_tips(games):
    """Quadro geral: o que os seus jogos mostram, sem misturar com regra ou palpite."""
    tips = []
    if not games:
        return [tip(DADO, "Nenhuma partida sua no banco. Rode o sync.")]
    s = report.summary(games)
    n = s["n"]
    wr = 100.0 * s["wins"] / n
    tips.append(tip(DADO, f"Winrate {profile.lane_in()}: {wr:.0f}% ({s['wins']}V {n - s['wins']}D).", n))
    d10, n10 = s["deaths_before_10"]
    if n10 and d10 is not None:
        tips.append(tip(DADO, f"Você morre em média {d10:.2f} vez(es) antes dos 10 min.", n10))
    v, nv = s["vision_per_min"]
    if nv and v is not None:
        tips.append(tip(DADO, f"Sua visão é {v:.2f} por minuto.", nv))
        if v < VISION_GOAL:
            tips.append(tip(REGRA, f"Meta do plano: {VISION_GOAL} por minuto, com 1 control ward a cada recall "
                                   "(sugestão do plano, não é padrão oficial)."))
    c, nc = s["csdiff10"]
    if nc and c is not None:
        tips.append(tip(DADO, f"Diferença média de CS aos 10 min contra o oponente: {c:+.1f}.", nc))
    worst = [(name, nn, w, wr_) for name, nn, w, wr_ in report.by_key(games, "opp_champion", min_games=5)]
    worst.sort(key=lambda r: (r[3], -r[1]))
    if worst:
        name, nn, w, wr_ = worst[0]
        tips.append(tip(DADO, f"Pior matchup com amostra mínima: {name}, {w}V {nn - w}D ({100 * wr_:.0f}%).", nn))
        tips.append(tip(HIPOTESE, f"Pode ser o matchup, o seu plano contra ele ou só amostra; use 'vs {name}' para ver por campeão seu."))
    if d10 is not None and c is not None and d10 > 0.6 and c < 0:
        tips.append(tip(HIPOTESE, "Mortes cedo junto com CS atrás sugerem trocas cedo demais ou falta de visão; confirme na revisão dos replays."))
    return tips


def _median(values):
    values = [v for v in values if v is not None]
    return statistics.median(values) if values else None


def compare_top(mine, top):
    """Voce (media) contra mediana do topo, mostrando n dos dois lados."""
    rows = []
    for key, label, nd in COMPARE:
        mv = [g[key] for g in mine if g.get(key) is not None]
        tv = [g[key] for g in top if g.get(key) is not None]
        rows.append({"label": label, "nd": nd,
                     "mine": (sum(mv) / len(mv)) if mv else None, "n_mine": len(mv),
                     "top": _median(tv), "n_top": len(tv)})
    notes = []
    n_top = len(top)
    if n_top == 0:
        notes.append(tip(DADO, "Ainda não há partidas do topo no banco. Em Dados e chave, clique em Baixar amostra.", 0))
    elif n_top < LOW_SAMPLE:
        notes.append(tip(DADO, "Amostra do topo pequena: a comparação não é conclusiva.", n_top))
    else:
        notes.append(tip(DADO, "Amostra do topo.", n_top))
    return rows, notes
