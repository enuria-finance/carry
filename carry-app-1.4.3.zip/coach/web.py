"""Tela local no navegador (so no seu PC: 127.0.0.1). Sem dependencias.

O app olha partidas terminadas, a selecao de campeoes e (tela /aovivo) a partida em
andamento pela API oficial Live Client Data, so com o que o jogo ja mostra.
"""
import hmac
import html
import http.cookies
import json
import os
import re
import secrets
import time
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer

from . import noxus, lanes, learn, champstats, ai, coachreport, vod, jungle, roles, pages4, postmore, pregame, polish, accounts, analysis, authview, bg, champpage, champview, guides, coachbot, diagview, gameview, hextech, liveview, growthview, missions, ranks, tiers, userdata, config as config_mod, profile, diagnosis, icons, jobs, postview, db, habits, insights, postgame, report, review, theme, top as top_mod, views2, habitsview, selview, statsui, premium, homepremium, voice, effects, visual, extras
from .localctx import LocalDict
from .tags import LOW_SAMPLE, REGRA, sample_note, tip
_GUIDE_TRIED = set()

# Fontes do proprio Windows (sem internet): Bahnschrift nos titulos e numeros,
# Segoe UI no texto. Em outros sistemas cai para a fonte padrao.
CSS = """
:root{--bg:#0e1116;--panel:#161a22;--panel2:#211918;--ink:#eef0ff;--mute:#8e97b8;--rule:#262c38;
--gold:#E9C46A;--purple:#3b9eff;--purple2:#8cc4ff;--peach:#8cc4ff;
--dado:#6BBF8A;--regra:#E9C46A;--hip:#8cc4ff;--loss:#E8817C;--win:#6BBF8A;
--btn:#3b9eff;--btnfg:#fff;--head:"Bahnschrift","Segoe UI Variable Display","Segoe UI",system-ui,sans-serif;
--body:"Segoe UI Variable Text","Segoe UI",system-ui,sans-serif;--mono:"Cascadia Mono",Consolas,monospace}
*{box-sizing:border-box}
html{color-scheme:dark}
body{margin:0;color:var(--ink);font:15.5px/1.6 var(--body);background:var(--bg)}
.shell{display:grid;grid-template-columns:240px minmax(0,1fr);min-height:100vh}
.rail{position:sticky;top:0;align-self:start;height:100vh;padding:26px 16px;
border-right:1px solid var(--rule);background:#0b0e13;display:flex;flex-direction:column;gap:4px}
.brand{font:700 22px/1.1 var(--head);letter-spacing:-.01em;margin:0 10px 2px;
color:#fff}
.who{color:var(--gold);font:12px var(--mono);letter-spacing:.08em;text-transform:uppercase;margin:0 10px 24px}
.rail a{display:block;padding:9px 12px;color:var(--mute);text-decoration:none;border:1px solid transparent;border-radius:8px;
font:600 12.5px var(--head);letter-spacing:.08em;text-transform:uppercase}
.rail a:hover{color:var(--ink);background:rgba(59,158,255,.08)}
.rail a[aria-current=page]{color:#fff;background:rgba(59,158,255,.2);border-color:rgba(59,158,255,.5)}
main{max-width:1560px;width:100%;margin:0 auto;padding:26px 44px 90px}
h1{font:700 34px/1.12 var(--head);letter-spacing:-.02em;margin:0 0 24px;
color:#fff}
h2{font:700 12.5px/1.3 var(--head);letter-spacing:.14em;text-transform:uppercase;color:var(--gold);margin:40px 0 10px;padding-top:0}
h2:first-child{margin-top:0}
p{margin:.5em 0}.mut,.n{color:var(--mute)}.n{font-size:.88rem}
a{color:var(--purple2)}
.hero{padding:22px 24px;border:1px solid var(--rule);border-radius:14px;
background:linear-gradient(135deg,rgba(59,158,255,.16),rgba(13,18,36,.9) 60%)}
.hero .lead{color:var(--gold);font:12px var(--mono);letter-spacing:.12em;text-transform:uppercase;margin:0 0 8px}
.hero .big{font:700 clamp(26px,4.2vw,40px)/1.12 var(--head);letter-spacing:-.02em;margin:0 0 14px;max-width:22ch;
color:#fff}
.tip{display:grid;grid-template-columns:8.4rem minmax(0,1fr);gap:14px;padding:14px 18px;margin:8px 0;background:var(--panel);border:1px solid var(--rule);border-left:3px solid var(--rule);border-radius:10px}
.tip:has(.tag.dado){border-left-color:var(--dado)}.tip:has(.tag.regra){border-left-color:var(--regra)}.tip:has(.tag.hipotese){border-left-color:var(--hip)}
.tag{display:flex;align-items:center;gap:8px;font:600 11.5px var(--mono);letter-spacing:.08em;text-transform:uppercase;padding-top:4px}
.tag::before{content:"";flex:none;width:9px;height:9px;background:currentColor}
.tag.dado{color:var(--dado)}
.tag.regra{color:var(--regra)}.tag.regra::before{transform:rotate(45deg) scale(.9)}
.tag.hipotese{color:var(--hip)}.tag.hipotese::before{background:none;border:2px dotted currentColor;border-radius:50%}
.tip>div{max-width:none}
.card{border:1px solid var(--rule);background:var(--panel);border-radius:12px;padding:16px 20px;margin:14px 0}
.card.warn{border-color:rgba(233,196,106,.45);box-shadow:inset 3px 0 0 var(--regra)}
.card.ok{border-color:rgba(94,224,192,.4);box-shadow:inset 3px 0 0 var(--dado)}
.strip{display:grid;grid-template-columns:repeat(auto-fill,minmax(132px,1fr));gap:10px;margin:8px 0}
.tile{display:block;text-decoration:none;background:var(--panel);border:1px solid var(--rule);
border-top:3px solid var(--rule);border-radius:10px;padding:10px 12px;color:var(--ink)}
.tile:hover{border-color:var(--purple);box-shadow:0 0 18px rgba(59,158,255,.25)}
.tile.v{border-top-color:var(--win)}.tile.d{border-top-color:var(--loss)}
.tile b{font:700 17px/1.2 var(--head);display:block}
.tile span{display:block;color:var(--mute);font-size:13px}
.tile .kda{font-family:var(--mono);color:var(--ink)}
table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}
th,td{padding:9px 10px 9px 0;border-bottom:1px solid var(--rule);text-align:left;vertical-align:top}
th{color:var(--gold);font:600 11.5px var(--mono);letter-spacing:.1em;text-transform:uppercase}
.win{color:var(--win);font-weight:600}.loss{color:var(--loss);font-weight:600}
textarea,select,input[type=text],input[type=password]{width:100%;padding:10px 12px;border-radius:8px;border:1px solid var(--rule);
background:#10141b;color:var(--ink);font:inherit}
select{width:auto;max-width:100%}
button,.btn{background:linear-gradient(135deg,var(--purple),#2478d6);color:var(--btnfg);border:0;border-radius:8px;padding:10px 18px;
font:600 13px var(--head);letter-spacing:.06em;text-transform:uppercase;cursor:pointer;text-decoration:none;display:inline-block;
box-shadow:0 0 16px rgba(59,158,255,.35)}
button:hover,.btn:hover{filter:brightness(1.12)}
.btn.ghost{background:none;color:var(--ink);border:1px solid var(--rule);box-shadow:none}
:focus-visible{outline:2px solid var(--purple2);outline-offset:2px}
.moment{border-left:3px solid var(--regra);padding:2px 0 6px 18px;margin:22px 0;scroll-margin-top:20px}
.moment.done{border-left-color:var(--dado)}
.moment h3{font:700 20px/1.2 var(--head);margin:0 0 8px}
.moment h3 small{font:400 14px var(--body);color:var(--mute);margin-left:8px}
.tl{width:100%;height:auto;margin:6px 0 2px;overflow:visible}
.tl .axis{stroke:var(--rule);stroke-width:2}.tl .tick{stroke:var(--rule)}
.tl text{fill:var(--mute);font:12px var(--body)}
.tl .death{fill:var(--loss)}.tl .obj{fill:var(--regra)}
.tl .ring{fill:none;stroke:var(--ink);stroke-width:2}
.tl a:hover circle,.tl a:hover rect{stroke:var(--ink);stroke-width:2}
.legend{display:flex;gap:18px;flex-wrap:wrap;color:var(--mute);font-size:13px;margin:0 0 6px}
.champs{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:14px;margin:10px 0}
.champ{border:1px solid var(--rule);border-radius:14px;background:var(--panel);overflow:hidden;padding-bottom:12px}
.champ.picked{border-color:var(--purple);box-shadow:0 0 22px rgba(59,158,255,.35)}
.champ .art{position:relative;height:150px;background:#211918 center 20%/cover no-repeat;display:flex;align-items:flex-end;padding:12px 14px}
.champ .art b{font:700 22px var(--head);text-shadow:0 2px 8px #000}
.tierb{position:absolute;top:10px;right:10px;width:34px;height:34px;display:grid;place-items:center;border-radius:9px;
font:700 17px var(--head);color:#fff;background:#2a3358;border:1px solid rgba(255,255,255,.2)}
.tierb.tS{background:linear-gradient(135deg,#3b9eff,#d946ef)}.tierb.tA{background:#3b6fd9}.tierb.tB{background:#a8823a}.tierb.tC{background:#7a3a44}
.pickd{position:absolute;top:12px;left:12px;font:600 10.5px var(--mono);letter-spacing:.1em;text-transform:uppercase;
background:var(--purple);padding:3px 8px;border-radius:99px}
.bar{display:grid;grid-template-columns:1fr;gap:3px;padding:8px 14px 0}
.bar .bl{font:600 11px var(--mono);letter-spacing:.08em;text-transform:uppercase;color:var(--gold)}
.bar .bt{display:block;height:7px;border-radius:99px;background:#1a2342;overflow:hidden}
.bar .bt i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,var(--purple),var(--peach))}
.bar.hipotese .bt i{background:repeating-linear-gradient(90deg,var(--purple2) 0 6px,transparent 6px 9px)}
.bar .bv{font:12px var(--mono);color:var(--mute)}
.chips{padding:8px 14px 0;display:flex;flex-wrap:wrap;gap:6px;align-items:center}
.chips small{font:600 10.5px var(--mono);letter-spacing:.08em;text-transform:uppercase;color:var(--mute);width:100%}
.chip{font:600 12px var(--body);padding:3px 9px;border-radius:99px;border:1px solid}
.chip.good{color:var(--dado);border-color:rgba(94,224,192,.4);background:rgba(94,224,192,.08)}
.chip.bad{color:var(--loss);border-color:rgba(255,122,133,.4);background:rgba(255,122,133,.08)}
.champ .n{padding:8px 14px 0;margin:0;font-size:12px}
.teams{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.mate{display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid var(--rule)}
.mate img,.mate .ph{width:44px;height:44px;border-radius:10px;border:1px solid var(--rule);background:#211918;display:grid;place-items:center}
.mate span{display:flex;flex-direction:column}.mate small{font:11px var(--mono);color:var(--mute);letter-spacing:.08em}
.pool{display:flex;flex-wrap:wrap;gap:8px;margin:8px 0}.pool-chip{margin:0}.pool-chip .btn{padding:6px 12px}
.row{display:flex;gap:10px;align-items:center;margin-top:8px}.row input{max-width:320px}
.phead{display:flex;justify-content:space-between;align-items:center;gap:16px;padding:18px 22px;border:1px solid var(--rule);border-radius:14px;
background:linear-gradient(135deg,rgba(94,224,192,.12),var(--panel) 60%);margin-bottom:16px}
.phead.l{background:linear-gradient(135deg,rgba(255,122,133,.14),var(--panel) 60%)}
.phead .res{display:block;font:700 28px var(--head);letter-spacing:.1em}.phead.w .res{color:var(--win)}.phead.l .res{color:var(--loss)}
.phead span{color:var(--mute)}.kdab{text-align:right}.kdab b{font:700 26px var(--head);display:block}
.kdab small{font:11px var(--mono);letter-spacing:.12em;color:var(--mute)}
.sbwrap{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:6px}
.sbteam h3{font:700 12px var(--head);letter-spacing:.14em;text-transform:uppercase;margin:0 0 4px}
.sbteam.mine h3{color:#8DA2C0}.sbteam.foe h3{color:var(--loss)}
.sb td small{display:block;color:var(--mute);font-size:11px}.sb tr.me td{background:rgba(233,196,106,.1)}
.sb th,.sb td{padding:6px 8px 6px 4px;font-size:13.5px}
.sec{display:flex;gap:14px;align-items:flex-start;margin:42px 0 6px}
.sec .num{font:700 40px/1 var(--head);color:rgba(59,158,255,.45)}.sec h2{margin:2px 0 0}
.gl{display:block;font:700 12px var(--head);letter-spacing:.14em;text-transform:uppercase;color:var(--gold);margin-bottom:6px}
.card.verdict{border-color:rgba(59,158,255,.5);background:linear-gradient(135deg,rgba(59,158,255,.18),var(--panel))}
.radar{width:100%;max-width:520px;display:block;margin:0 auto}
.radar .ringg{fill:none;stroke:var(--rule)}.radar .ring1{fill:none;stroke:var(--gold);stroke-dasharray:4 4}
.radar .spoke{stroke:var(--rule)}.radar .shape{fill:rgba(59,158,255,.28);stroke:var(--purple2);stroke-width:2}
.radar .dot{fill:var(--purple2)}.radar .rl{fill:var(--mute);font:600 10px var(--mono);letter-spacing:.08em;text-transform:uppercase}
.radar .rv{fill:var(--ink);font:700 15px var(--head)}.radar .ra{fill:var(--mute);font:10px var(--mono)}
.phases{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.phase{border:1px solid var(--rule);border-radius:10px;padding:12px 14px;background:#10141b}
.phase h4{margin:0;font:700 12px var(--head);letter-spacing:.1em;text-transform:uppercase}
.stat{display:flex;justify-content:space-between;align-items:baseline;padding:6px 0;border-top:1px solid var(--rule)}
.stat b{font:700 18px var(--head)}.stat span{color:var(--mute);font-size:12px}
.lanes .lane{display:grid;grid-template-columns:70px 1fr auto 1fr;gap:12px;align-items:center;padding:9px 6px;border-top:1px solid var(--rule)}
.lane.me{background:rgba(233,196,106,.08);border-radius:8px}.lane .ln{font:600 11px var(--mono);letter-spacing:.1em;text-transform:uppercase;color:var(--gold)}
.lane .r{text-align:right;color:var(--mute)}.lane b{font:700 16px var(--head)}
.gold{width:100%;height:auto}.gold .z{stroke:var(--rule)}.gold .fill{fill:rgba(59,158,255,.18)}
.gold .line{fill:none;stroke:var(--purple2);stroke-width:2.5}.gold .ax{fill:var(--mute);font:11px var(--mono)}
.gold .ev.me{fill:#8DA2C0}.gold .ev.foe{fill:var(--loss)}
.mapwrap{display:grid;grid-template-columns:minmax(0,420px) minmax(0,1fr);gap:16px}
.map{position:relative;aspect-ratio:1;background:#10141b center/cover;border-radius:10px;border:1px solid var(--rule)}
.map i{position:absolute;width:12px;height:12px;border-radius:50%;transform:translate(-50%,-50%);border:2px solid #fff}
.map i.me{background:#4d7cff}.map i.foe{background:#ff4d5e}.map i.po{border-radius:3px;transform:translate(-50%,-50%) rotate(45deg);width:14px;height:14px}
.maplist ul{list-style:none;margin:8px 0 0;padding:0;max-height:330px;overflow:auto;font-size:13px}
.maplist li{padding:4px 0;border-bottom:1px solid var(--rule)}.maplist li b{font-family:var(--mono);color:var(--gold);margin-right:6px}
.maplist input{width:100%}
.gbar{display:grid;grid-template-columns:auto 1fr auto;gap:12px;align-items:center;font:700 13px var(--head)}
.gt{height:10px;border-radius:99px;background:var(--loss);overflow:hidden;display:block}.gt i{display:block;height:100%;background:#4d7cff}
.gdiff{text-align:center;font:700 22px var(--head);margin:6px 0}.phase.now{border-color:var(--purple);box-shadow:0 0 18px rgba(59,158,255,.3)}
.phase .tip{grid-template-columns:1fr;gap:2px}
.threat{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:14px}
.chip-st{display:block;margin:0 10px 14px;padding:6px 10px;border-radius:99px;font:600 11.5px var(--mono);text-decoration:none;
border:1px solid var(--rule);color:var(--mute)!important}
.chip-st.run{color:var(--purple2)!important;border-color:var(--purple)}.chip-st.warn{color:var(--regra)!important;border-color:rgba(233,196,106,.5)}
.chip-st.ok{color:var(--dado)!important}
.cfg{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.ic{width:36px;height:36px;border-radius:8px;border:1px solid var(--rule);background:#10141b}.ic.big{width:46px;height:46px;border-radius:50%}
.rune{display:flex;gap:10px;align-items:center;padding:5px 0}.rune span{display:flex;flex-direction:column}
.rune small{color:var(--mute);font-size:11.5px;line-height:1.3;max-width:34ch}.ics{display:flex;gap:6px;flex-wrap:wrap}
.spell{display:inline-flex;flex-direction:column;align-items:center;gap:3px;margin-right:14px}.spell small{color:var(--mute)}
.topbar{display:flex;justify-content:flex-end;align-items:center;gap:12px;margin:0 0 14px;min-height:42px}
.topbar form{margin:0}.syncbtn{display:inline-flex;align-items:center;gap:8px;font:700 13px var(--head);letter-spacing:.06em;text-transform:uppercase;
text-decoration:none;color:#fff;background:linear-gradient(135deg,var(--purple),#2478d6);padding:11px 20px;border-radius:10px;border:0;cursor:pointer;
box-shadow:0 0 18px rgba(59,158,255,.4)}.syncbtn small{font:11px var(--mono);text-transform:none;letter-spacing:0;opacity:.85}
.syncbtn.busy{background:#26204a;box-shadow:none;border:1px solid var(--purple)}.syncbtn.warn{background:#3a2f12;color:var(--gold);box-shadow:none;border:1px solid rgba(233,196,106,.5)}
.topbar .bad{color:var(--loss)}
.grid2{display:grid;grid-template-columns:3fr 2fr;gap:16px;align-items:stretch;margin:0 0 6px}.grid2.b{margin-top:16px}
.grid2.c{margin-top:6px}.grid2.even{grid-template-columns:1fr 1fr;margin-top:16px}.grid2>.card{margin:0}
.grid2.c{grid-template-columns:3fr 2fr}.strip.wide{grid-template-columns:repeat(auto-fill,minmax(190px,1fr))}
.tile{display:flex;gap:10px;align-items:center}.tile img{border-radius:8px;border:1px solid var(--rule)}.tile div{min-width:0}
.tile small{font:700 11px var(--mono)}.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px}
.kpi{background:linear-gradient(180deg,var(--panel2),var(--panel));border:1px solid var(--rule);border-radius:12px;padding:14px 16px;display:flex;flex-direction:column;gap:4px}
.kl{font:600 11px var(--mono);letter-spacing:.08em;text-transform:uppercase;color:var(--gold)}.kv{font:700 30px/1.1 var(--head)}
.dl{font:600 12.5px var(--mono)}.dl small{color:var(--mute);font-weight:400}.dl.good{color:var(--dado)}.dl.bad{color:var(--loss)}.dl.same{color:var(--mute)}
.kn{font:11px var(--mono);color:var(--mute)}.spark{width:100%;height:34px;margin-top:4px}.spark polyline{fill:none;stroke:var(--purple2);stroke-width:2}
.spark .last{fill:var(--purple2)}.spark .hit{fill:transparent}.spark .hit:hover{fill:rgba(183,148,255,.35)}
.wl{display:flex;gap:2px;align-items:flex-end;height:34px;margin-top:4px}.wl i{flex:1;border-radius:2px;display:block}
.wl i.w{height:100%;background:var(--win)}.wl i.l{height:40%;background:var(--loss)}
.evo{width:100%;height:auto}.evo .g{stroke:var(--rule)}.evo .mid{stroke:var(--gold);stroke-dasharray:4 4;opacity:.6}
.evo .ln{fill:none;stroke:var(--purple2);stroke-width:2.5}.evo .ax{fill:var(--mute);font:11px var(--mono)}
.evo .pt{fill:transparent}.evo .pt:hover{fill:rgba(183,148,255,.45)}
.pb{display:grid;grid-template-columns:110px 1fr auto;gap:10px;align-items:center;padding:5px 0}.pb .pn{font-weight:600;overflow:hidden;text-overflow:ellipsis}
.pt2{position:relative;display:block;height:8px;border-radius:99px;background:#1a2342}.pt2 i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,var(--purple),var(--peach))}
.pt2 u{position:absolute;left:50%;top:-3px;bottom:-3px;width:2px;background:var(--gold);opacity:.7}.pb.low{opacity:.6}
.pb .pv{font:600 12.5px var(--mono)}.pb .pv small{color:var(--mute);font-weight:400}
.cic{border-radius:50%;border:2px solid var(--rule);background:#10141b;object-fit:cover;flex:none;display:inline-block}
.cic.ring-me{border-color:#4d7cff}.cic.ring-foe{border-color:#ff4d5e}
.cic.ph{display:inline-grid;place-items:center;font:700 11px var(--head);color:var(--mute)}
.rail a{display:flex;align-items:center;gap:10px}.rail a .ni{flex:none;opacity:.85}
.pc{display:flex;align-items:center;gap:10px}.pc span{display:flex;flex-direction:column}
.pn{display:flex;align-items:center;gap:8px}
.glist{display:flex;flex-direction:column;gap:10px;margin-top:8px}
.gcard{display:grid;grid-template-columns:150px minmax(250px,1.6fr) 130px 130px auto;gap:18px;align-items:center;padding:12px 18px;border:1px solid var(--rule);
border-left:4px solid var(--rule);border-radius:12px;background:linear-gradient(90deg,var(--panel2),var(--panel))}
.gcard.v{border-left-color:var(--win)}.gcard.d{border-left-color:var(--loss)}
.gres{font:700 13px var(--head);letter-spacing:.1em;display:flex;flex-direction:column}.gcard.v .gres{color:var(--win)}.gcard.d .gres{color:var(--loss)}
.gres small{font:11px var(--mono);color:var(--mute);letter-spacing:0}
.gvs{display:flex;align-items:center;gap:10px}.gvs .vs{font:700 11px var(--mono);color:var(--mute)}.gn{display:flex;flex-direction:column;margin-left:8px}
.gn small,.gk small{color:var(--mute);font-size:12px}.gk{display:flex;flex-direction:column}.gk b{font:700 20px var(--head)}
.gl2{display:flex;flex-direction:column;font:12px var(--mono);color:var(--mute)}.gact{display:flex;gap:8px}.gact .btn{padding:8px 12px}
.mgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:12px}
.mcard{display:flex;align-items:center;gap:14px;padding:12px 16px;border:1px solid var(--rule);border-radius:12px;text-decoration:none;color:var(--ink);
background:linear-gradient(180deg,var(--panel2),var(--panel))}.mcard:hover{border-color:var(--purple);box-shadow:0 0 18px rgba(59,158,255,.25)}
.mcard div{flex:1;display:flex;flex-direction:column}.mcard small{color:var(--mute)}.mcard.low{opacity:.6}
.wring .bg{fill:none;stroke:#1a2342;stroke-width:6}.wring .fg{fill:none;stroke:var(--purple2);stroke-width:6;stroke-linecap:round}
.wring text{fill:var(--ink);font:700 12px var(--mono)}
.map i.pk{width:28px;height:28px;background:none;border:0;overflow:visible}.map i.pk .cic{display:block}
.maplist li{display:flex;align-items:center;gap:8px}.maplist .ev{display:inline-flex;align-items:center;gap:3px;min-width:76px}
.maplist .arrow{font-size:11px;color:var(--mute)}.maplist .obj{color:var(--gold)}
@media (max-width:1100px){.gcard{grid-template-columns:1fr 1fr}}
.levers{display:grid;grid-template-columns:repeat(auto-fit,minmax(470px,1fr));gap:14px}.levers .tip{grid-template-columns:1fr;gap:2px}.levers .card{margin:0}
.big2{font:700 26px/1.2 var(--head);margin:4px 0 8px}.lever .pb{grid-template-columns:minmax(120px,190px) minmax(80px,1fr) auto}
.dcards{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;margin:14px 0 4px}
.dcard{display:flex;flex-direction:column;gap:4px;padding:14px 16px;border:1px solid rgba(59,158,255,.45);border-radius:12px;text-decoration:none;color:var(--ink);
background:linear-gradient(135deg,rgba(59,158,255,.14),var(--panel))}.dcard:hover{box-shadow:0 0 18px rgba(59,158,255,.3)}
.dcard b{font:700 17px var(--head)}.dcard small{color:var(--mute)}.dcard.go{justify-content:center;align-items:center;font:700 13px var(--head);letter-spacing:.06em;text-transform:uppercase}
pre{white-space:pre-wrap;font:14px/1.5 var(--mono);margin:0}
code{font-family:var(--mono);font-size:.92em;color:var(--peach)}
@media (max-width:1000px){.grid2,.grid2.c,.grid2.even{grid-template-columns:1fr}}
@media (max-width:860px){main{padding:18px 14px 60px}.cfg{grid-template-columns:1fr}.sbwrap,.phases,.mapwrap{grid-template-columns:1fr}.teams{grid-template-columns:1fr}.shell{grid-template-columns:1fr}
.rail{position:static;height:auto;flex-direction:row;flex-wrap:wrap;padding:14px;border-right:0;border-bottom:1px solid var(--rule)}
.brand,.who{width:100%;margin-left:0}main{padding:24px 16px 60px}.tip{grid-template-columns:1fr;gap:2px}}
"""

CSS = CSS + theme.CSS + habitsview.CSS + selview.CSS + authview.CSS + diagview.CSS + liveview.CSS + gameview.CSS + coachbot.CSS + champview.CSS + champpage.CSS + analysis.CSS + bg.CSS + growthview.CSS + statsui.CSS + statsui.RO_CSS + premium.CSS + homepremium.CSS + effects.CSS + postmore.SCORE_CSS + pages4.CSS + vod.CSS + coachreport.CSS + champstats.CSS + lanes.CSS + learn.CSS + noxus.CSS

NAV = [("/", "Início"), ("/coach", "Coach IA"), ("/perfil", "Meu perfil"), ("/diagnostico", "Diagnóstico"), ("/partidas", "Partidas"), ("/padroes", "Padrões"), ("/matchups", "Matchups"), ("/campeoes", "Campeões"),
       ("/topo", "Comparar"), ("/habitos", "Hábitos"), ("/jogo", "Partida"), ("/sincronizar", "Sincronizar")]
TAG_LABEL = {"dado": "dado", "regra geral": "regra geral", "hipotese": "hipótese"}
CURRENT = LocalDict(path="/")
CTX = LocalDict(has_key=True, has_data=True)


def e(x):
    return html.escape("" if x is None else str(x))


JOB_LABEL = {"analise": "Analisando a partida com IA", "guia": "Escrevendo o guia do campeão com IA", "experts": "Atualizando os especialistas do servidor", "tier": "Baixando a amostra do seu próximo elo", "sync": "Sincronizando suas partidas", "auto": "Sincronização automática", "top": "Baixando a amostra dos melhores",
             "test": "Testando a chave"}


def job_banner(st):
    """Faixa em TODAS as telas: mostra a tarefa da pessoa (na fila, rodando, resultado ou erro, com X para fechar)."""
    if not st.get("name"):
        return ""
    if st["name"] == "auto" and not st["error"]:
        return ""
    label = JOB_LABEL.get(st["name"], st["name"])
    last = e(st["log"][-1]) if st["log"] else ""
    if st["running"]:
        title = f"{e(label)}: na fila" if st.get("queued") else f"{e(label)}…"
        return (f"<div class='jobbar run'><span class='spin'></span><div><b>{title}</b><small>{last or 'iniciando…'}</small></div>"
                "<div class='jb-bar'><i></i></div></div>")
    fin = st.get("finished_ms") or 0
    if not fin or time.time() * 1000 - fin > 15 * 60000:
        return ""
    box = f"<div class='jobbar {'err' if st['error'] else 'done'}' data-fin='{fin}'>"
    if st["error"]:
        body = f"<span class='jb-i'>✕</span><div><b>{e(label)}: deu erro</b><small>{e(st['error'])}</small></div>"
    else:
        body = f"<span class='jb-i'>✓</span><div><b>{e(label)}: terminou</b><small>{last or 'ok'}</small></div>"
    return (box + body + "<button type='button' class='jb-x' aria-label='Fechar' "
            f"onclick=\"try{{localStorage.setItem('jb','{fin}')}}catch(x){{}}this.parentNode.remove()\">✕</button></div>"
            "")


def _sync_button(st):
    if st["running"]:
        last = st["log"][-1] if st["log"] else "trabalhando…"
        return f"<a class='syncbtn busy' href='/sincronizar'>↻ {'Na fila' if st.get('queued') else 'Sincronizando'}… <small>{e(last[:60])}</small></a>"
    if not CTX.get("puuid"):
        return "<a class='syncbtn warn' href='/vincular'>Vincular minha conta do LoL</a>"
    if not CTX["has_key"]:
        if CTX.get("is_admin"):
            return "<a class='syncbtn warn' href='/admin'>Configurar a chave da Riot</a>"
        return "<span class='syncbtn warn'>Aguardando o admin configurar a chave</span>"
    err = f"<small class='bad'>último erro: {e(st['error'][:80])}</small>" if st.get("error") else ""
    return ("<form method='post' action='/sincronizar/iniciar'><input type='hidden' name='kind' value='sync'>"
            "<input type='hidden' name='count' value='50'><input type='hidden' name='back' value='1'>"
            f"<button class='syncbtn'>↻ Sincronizar agora</button></form>{err}")


def job_area_html():
    """So a faixa de cima (botao de sincronizar + tarefa). O navegador troca isso sozinho, sem recarregar a pagina."""
    st = jobs.MANAGER.snapshot(CTX.get("uid"))
    return f"<div class='topbar'>{_sync_button(st)}</div>" + job_banner(st)


def page(title, body, show_title=True):
    if CURRENT.get("body_only"):
        return body
    here = CURRENT["path"]
    nav_items = list(NAV) + ([("/admin", "Administração")] if CTX.get("is_admin") else [])
    nav = "".join(
        f'<a href="{h}"{" aria-current=page" if (here == h or (h != "/" and here.startswith(h))) else ""}>{icons.nav_icon(h)}<span>{e(t)}</span></a>'
        for h, t in nav_items)
    user = CTX.get("user")
    link = CTX.get("link")
    who = (link["riot_id"] if link else None) or (user["name"] if user else "")
    st = jobs.MANAGER.snapshot(CTX.get("uid"))
    if st["running"]:
        chip = "<a class='chip-st run' href='/sincronizar'>● " + ("Na fila…" if st.get("queued") else "Sincronizando…") + "</a>"
    elif not CTX.get("puuid"):
        chip = "<a class='chip-st warn' href='/vincular'>● Vincular conta do LoL</a>"
    elif not CTX["has_key"]:
        chip = "<a class='chip-st warn' href='/admin'>● Chave da Riot pendente</a>" if CTX.get("is_admin") else "<span class='chip-st warn'>● Aguardando o admin</span>"
    else:
        chip = "<a class='chip-st ok' href='/sincronizar'>● Dados em dia · sincronizar</a>"
    topbar = f"<div id='jobarea' data-running='{1 if st['running'] else 0}'><div class='topbar'>{_sync_button(st)}</div>" + job_banner(st) + "</div>"
    try:
        from . import atualizar
        topbar = atualizar.banner_html(e) + topbar
    except Exception:
        pass
    mc = CTX.get("main_champ")
    h1 = theme.banner(e(title), here, icons.splash(mc) if mc else "") if show_title else ""
    if st["running"]:
        pst = "<a class='pst run' href='/sincronizar'><i></i>" + ("Na fila" if st.get("queued") else "Sincronizando") + "</a>"
    elif not CTX.get("puuid"):
        pst = "<a class='pst warn' href='/vincular'><i></i>Vincular conta do LoL</a>"
    elif not CTX["has_key"]:
        pst = "<a class='pst warn' href='/admin'><i></i>Chave da Riot pendente</a>" if CTX.get("is_admin") else "<span class='pst warn'><i></i>Aguardando o admin</span>"
    else:
        pst = "<a class='pst' href='/sincronizar'><i></i>Dados em dia</a>"
    me = ""
    sync_f = ""
    if user:
        tier = (link["tier"] if link else None) or "UNRANKED"
        sync_f = ("<form method='post' action='/sincronizar/iniciar'><input type='hidden' name='kind' value='sync'><input type='hidden' name='count' value='50'>"
                  "<input type='hidden' name='back' value='1'><button>Sincronizar agora</button></form>") if CTX.get("puuid") and CTX["has_key"] and not st["running"] else ""
        me = (f"<a class='side-me' href='/perfil'><span class='pav' style='--tc:{authview.TIER_COLOR.get(tier, '#6BBF8A')}'>"
              f"{authview.profile_icon(link['icon'] if link else None, 38)}</span><div><b>{e(who)}</b><small>{e(authview.rank_text(link) if link else 'sem conta do LoL')}</small>"
              f"<span class='side-mini'><i style='width:{min(100, (link['lp'] or 0) if link else 0)}%'></i></span></div></a>")
        try:
            from . import overlay as _ovs
            on_ = _ovs.running()
            me += f"<div class='side-st'><span><i class='{'ok' if on_ else ''}'></i>Overlay {'ligado' if on_ else 'desligado'}</span></div>"
        except Exception:
            pass
        sync_f += "<a class='n' href='/reportar' style='display:block;font-size:12.5px;margin:4px 0 8px;text-align:center'>Reportar um problema</a>"
        sync_f += "<form method='post' action='/sair'><button class='btn ghost'>Sair</button></form>"
    head = premium.sidebar(here, CTX.get("is_admin"), pst, me, sync_f, icons.nav_icon)
    from . import rotk
    return rotk.apply(f"<!doctype html><html lang='pt-BR'><meta charset='utf-8'>"
            f"<meta name='viewport' content='width=device-width,initial-scale=1'>"
            f"<title>{e(title)} · Carry</title><link rel='icon' href=\"{premium.FAVICON}\"><style>{CSS}{premium.SUBNAV_CSS}</style>{premium.accent_style(mc)}<style>{visual.CSS}{extras.CSS}{rotk.CSS}</style>"
            f"<div class='shell'>{head}"
            f"<main>{topbar}{premium.subnav(here)}{h1}{body}</main></div>{theme.JS}{champpage.TL_JS}{polish.JS}{statsui.SORT_JS}{premium.JS}{premium.TABS_JS}{effects.JS}{pages4.KEYS_JS}{noxus.JS}{PHASE_JS}{TOAST_JS}{visual.JS}</html>")


def tips_html(tips):
    out = []
    for t in tips:
        cls = t["kind"].split()[0]
        n = f" <span class='n'>({e(sample_note(t['n']))})</span>" if t.get("n") is not None else ""
        out.append(f"<div class='tip'><span class='tag {cls}'>{e(TAG_LABEL.get(t['kind'], t['kind']))}</span>"
                   f"<div>{e(t['text'])}{n}</div></div>")
    return "".join(out)


def mmss(ms):
    s = int(ms // 1000)
    return f"{s // 60}:{s % 60:02d}"


def fmt(v, nd=1):
    return "-" if v is None else f"{v:.{nd}f}"


def timeline_svg(moments, duration_s, ring=()):
    """Linha do tempo da partida: mortes (bolas) e objetivos do inimigo (losangos)."""
    total = max(int(duration_s or 0) * 1000, max([m["t_ms"] for m in moments] + [60000]))
    left, width = 24, 952
    xs = lambda t: left + width * t / total
    parts = [f"<svg class='tl' viewBox='0 0 1000 84' role='img' aria-label='Linha do tempo da partida'>",
             f"<line class='axis' x1='{left}' y1='56' x2='{left + width}' y2='56'/>"]
    for m5 in range(0, int(total // 60000) + 1, 5):
        x = xs(m5 * 60000)
        parts.append(f"<line class='tick' x1='{x:.1f}' y1='50' x2='{x:.1f}' y2='62'/>"
                     f"<text x='{x:.1f}' y='80' text-anchor='middle'>{m5}'</text>")
    for m in moments:
        x = xs(m["t_ms"])
        label = e(m["title"])
        if m["kind"] == "morte":
            ringed = f"<circle class='ring' cx='{x:.1f}' cy='56' r='11'/>" if m["t_ms"] in ring else ""
            parts.append(f"<a href='#m{m['t_ms']}'><title>{label}</title>{ringed}"
                         f"<circle class='death' cx='{x:.1f}' cy='56' r='7'/></a>")
        else:
            parts.append(f"<a href='#m{m['t_ms']}'><title>{label}</title>"
                         f"<rect class='obj' x='{x - 7:.1f}' y='15' width='14' height='14' "
                         f"transform='rotate(45 {x:.1f} 22)'/></a>")
    parts.append("</svg>")
    legend = ("<div class='legend'><span>● morte sua</span><span>◆ objetivo grande do inimigo</span>"
              + ("<span>◎ entre as 3 decisões mais caras</span>" if ring else "") + "</div>")
    return "".join(parts) + legend


# ---- paginas --------------------------------------------------------------
def p_home(con, puuid):
    from . import homeview
    games = report.my_games(con, puuid)
    all_games = report.my_games(con, puuid, "")
    mst = missions.ensure_today(con, all_games) if all_games else None
    link = CTX.get("link")
    if not all_games:
        return page("Início", _onboarding([]) + "<div class='empty'><b>Ainda sem partidas</b><span>A primeira sincronização baixa as suas últimas partidas sozinha (alguns minutos). Para forçar, use Sincronizar agora no rodapé da barra lateral.</span></div>")
    pick_html = _onboarding(all_games)
    if not CTX.get("main_ok"):
        try:
            from . import mainpick
            pick_html += mainpick.html_block(con, _dd().champions(), all_games[:200], None, None, CTX.get("csrf"), first=True)
        except Exception:
            pass
    diag_html = ""
    if len(games) >= 20:
        lvs = [l for l in diagnosis.levers(games) if l["pesa"] and l["actionable"]][:2]
        cards = ""
        for l in lvs:
            ok = sorted([g for g in l["groups"] if g["n"] >= diagnosis.MIN_GROUP], key=lambda g: -g["wr"])
            cards += (f"<a class='dcard' href='/diagnostico'><span class='kl'>Pesa nos seus jogos</span><b>{e(l['title'])}</b>"
                      f"<span><b class='win'>{ok[0]['wr']}%</b> {e(ok[0]['label'])} <small>({ok[0]['n']})</small>, "
                      f"<b class='loss'>{ok[-1]['wr']}%</b> {e(ok[-1]['label'])} <small>({ok[-1]['n']})</small></span></a>")
        if cards:
            diag_html = f"<div class='dcards'>{cards}</div>"
    more = ""
    P = homepremium._panel
    if len(games) >= 3:
        rd = []
        rec = games[:10]
        for label, fn, fmt, _ in homeview.METRICS:
            if label == "Mortes antes dos 10":
                continue
            rd.append((label, homeview._avg([fn(g) for g in rec]), homeview._avg([fn(g) for g in games]), fmt))
        radar = P("Perfil dos últimos 10 jogos", f"Linha tracejada: a sua média de todos os jogos ({len(games)}).", "<div class='in'>" + postview.radar_svg(rd, e) + "</div>")
        pool = homeview.pool_bars(games, e)
        more += (f"<div class='hpn-2 hpn-gap'>{radar}" + P("Seu pool", "Vitória por campeão.", pool or "<p class='n'>Sem jogos.</p>") + "</div>"
                 + P("Matchups mais difíceis", "Os oponentes de rota contra quem você mais perde.", homeview.matchup_bars(games, e),
                     "<a class='hpn-a' href='/matchups'>Todos os matchups</a>"))
    try:
        from . import pregame
        lim = CTX.get("limite_dia")
        td = pregame.today(con, puuid, lim)
        col = {"stop": "loss", "pause": "loss", "warn": "gold", "go": "win", "ok": ""}[td["verdict"]]
        dots = "".join(f"<i class='td-d {'w' if i < td['w'] else 'l' if i < td['n'] else ''}'></i>" for i in range(max(td["limit"], td["n"])))
        opts = "".join(f"<option value='{k}'{' selected' if k == td['limit'] else ''}>{k}</option>" for k in (2, 3, 4, 5, 6, 8, 10, 15))
        lf = pregame.last_focus(con, puuid)
        more += P("Hoje", "Limite do dia: só pede para parar se você estiver em sequência ruim.",
                  f"<div class='td-row'>{dots}</div><p class='td-m {col}'>{e(td['msg'])}</p>"
                  + (f"<p class='n'>Aquecimento: {e(lf)}.</p>" if lf else "")
                  + f"<form method='post' action='/conta/limite' class='row td-f'><label>Partidas por dia</label><select name='n'>{opts}</select><button class='btn'>Salvar</button></form>")
    except Exception:
        pass
    try:
        rc = roles.card_html(profile.position(), games)
        if rc:
            more += P("O modo da sua rota", "O app se adapta à rota que você mais joga.", rc,
                      "<a class='hpn-a' href='/selva'>Abrir o modo caçador</a>" if profile.position() == "JUNGLE" else "")
    except Exception:
        pass
    rule = habits.two_loss_rule(con, puuid)
    more += ("<div class='hpn-2 hpn-gap'>" + P("Regra das 2 derrotas", "Quando parar de jogar no dia.", tips_html(rule["tips"]))
             + P("O que os seus jogos mostram", "Padrões tirados das suas partidas.", tips_html(insights.home_tips(games))) + "</div>")
    try:
        from . import caminho
        cam = caminho.build(con, puuid, link)
    except Exception:
        cam = None
    body = homepremium.build(con, games, all_games, link, ranks.history(con), mst, _dd(), CTX["ddir"], diag_html, more, cam=cam)
    if not body:
        return page("Início", pick_html + "<div class='empty'><b>Ainda sem partidas</b><span>Sincronize para começar.</span></div>")
    try:
        from . import atualizar
        body = atualizar.novidades_html(e) + body
    except Exception:
        pass
    try:            # check antes da fila e modo so uma (ideias 76 e 80)
        body += ("<div class='grid2' style='display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px'>"
                 + extras.mood_html(con, puuid, None) + extras.souma_html(_SOUMA.get("dia") == time.strftime("%Y%m%d")) + "</div>")
    except Exception:
        pass
    body += TOUR_HTML
    return page("Início", pick_html + body, show_title=False)


def p_games(con, puuid):
    games = report.my_games(con, puuid, "")[:60]
    if not games:
        return page("Partidas", "<p>Nenhuma partida. Clique em Sincronizar agora.</p>")
    champs = sorted({g["champion"] for g in games})
    w = sum(1 for g in games if g["win"])
    filt = ("<div class='hp-filt'><div class='seg' id='pgf' role='group' aria-label='Filtrar partidas'><button type='button' aria-pressed='true' data-f='all'>Todas</button>"
            "<button type='button' aria-pressed='false' data-f='w'>Vitórias</button><button type='button' aria-pressed='false' data-f='l'>Derrotas</button></div>"
            "<select id='pgc' aria-label='Campeão'><option value=''>Todos os campeões</option>" + "".join(f"<option>{e(c)}</option>" for c in champs) + "</select>"
            "<span class='n' id='pgn'></span></div>")
    js = """<script>(function(){var f='all',c='';function run(){var n=0,w=0;document.querySelectorAll('.hg').forEach(function(g){var ok=(f==='all'||(f==='w'&&g.classList.contains('w'))||(f==='l'&&g.classList.contains('l')))&&(!c||g.dataset.c===c);
g.hidden=!ok;if(ok){n++;if(g.classList.contains('w'))w++}});document.getElementById('pgn').textContent=n?n+' partidas, '+Math.round(100*w/n)+'% de vitória':'nenhuma partida'}
document.getElementById('pgf').addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;this.querySelectorAll('button').forEach(function(x){x.setAttribute('aria-pressed',x===b)});f=b.dataset.f;run()});
document.getElementById('pgc').onchange=function(){c=this.value;run()};document.addEventListener('click',function(e){var r=e.target.closest('.hg-row');if(!r)return;var x=document.getElementById(r.getAttribute('aria-controls')),o=r.getAttribute('aria-expanded')==='true';r.setAttribute('aria-expanded',!o);x.hidden=o});run()})();</script>"""
    body = (homepremium.nums(games) + f"<div class='hp-pg'><p class='hp-lead'>Últimas {len(games)}: {w} vitórias e {len(games) - w} derrotas. Clique numa partida para ver o ouro contra o oponente minuto a minuto e onde você morreu.</p>"
            + filt + f"<ol class='hp-games'>{homepremium.game_rows(con, games, _dd(), 60, 'pg')}</ol></div>" + js)
    return page("Partidas", body)


def _team_table(rows, title, cls):
    t = f"<div class='sbteam {cls}'><h3>{e(title)}</h3><table class='sb'><tr><th>Campeão</th><th>K/D/A</th><th>CS</th><th>Ouro</th><th>Nív.</th></tr>"
    for r in rows:
        t += (f"<tr class='{'me' if r['me'] else ''}'><td><div class='pc'>{icons.champ(r['champion'], 34, 'me' if r['me'] else None)}"
              f"<span>{e(r['champion'])}<small>{e(postview.LANE_PT.get(r['position'], ''))}{' · você' if r['me'] else ''}</small></span></div></td>"
              f"<td>{r['kills']}/<span class='loss'>{r['deaths']}</span>/{r['assists']}</td><td>{r['cs']}</td>"
              f"<td>{(r['gold'] or 0) / 1000:.1f}k</td><td>{e(r['level'] if r['level'] is not None else '–')}</td></tr>")
    return t + "</table></div>"


def _sec(n, title, sub):
    return f"<div class='sec'><span class='num'>{n}</span><div><h2>{e(title)}</h2><p class='n'>{e(sub)}</p></div></div>"


def _mark_spell(q):
    """Marca o Flash/ult de um inimigo (atalho do overlay ou botao da Partida ao vivo). Devolve o texto do aviso."""
    from . import live, spelltimers
    data = live.fetch()
    if not data:
        return "Fora de partida."
    me = live._find_me(data)
    try:
        slot = int((q.get("slot") or ["0"])[0] or 0)
    except ValueError:
        slot = 0
    kind = "r" if (q.get("k") or ["f"])[0] == "r" else "f"
    spell = (q.get("s") or [""])[0] or None
    if spell and spell not in spelltimers.SPELL_CD:
        spell = None
    try:
        if (q.get("clear") or [""])[0] == "1":
            return spelltimers.clear(data, slot, kind, spell) or "Não achei esse inimigo."
        return spelltimers.mark(data, me, slot, kind, CTX.get("ddir") or "", spell) or "Não achei esse inimigo."
    except Exception as ex:
        return f"Não deu para marcar ({type(ex).__name__})."


MARK_JS = """<script>(function(){document.addEventListener('click',function(ev){var b=ev.target.closest('[data-mark]');if(!b)return;ev.preventDefault();
var f=b.closest('form'),fd=new FormData(f);fd.set('slot',b.dataset.slot);fd.set('k',b.dataset.mark);window.__hold=Date.now()+2500;
fetch('/partida/marcar',{method:'POST',body:new URLSearchParams(fd)}).then(function(r){return r.json()}).then(function(d){var m=document.getElementById('mkmsg');if(m)m.textContent=d.t||''})})})();</script>"""


def mark_card(data):
    """Como marcar feitico do inimigo: so pela voz (a Riot nao deixa mostrar contagem de Flash/ult na tela).
    A voz avisa quando falta 1 minuto e quando volta."""
    return ("<div class='card mk'><b class='gl'>Feitiço do inimigo</b><p class='n'>No jogo, fale no botão do coach: <b>“Zed usou flash”</b>, "
            "<b>“Sett queimou ignite”</b>. A voz avisa quando falta 1 minuto e quando volta. Nada aparece na tela.</p></div>")


MARK_CSS = """<style>.mk-g{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:8px;margin:8px 0 0}
.mk-r{display:flex;align-items:center;gap:8px;padding:6px 8px;border:1px solid var(--rule);border-radius:12px}.mk-r b{flex:1;font:700 14px var(--body)}
.mk-r small{color:var(--mute);font-size:11.5px}.mk-r .btn{width:auto;padding:6px 12px;margin:0}
#mkmsg{color:#E9C46A;margin-top:8px}</style>"""


def Handler_run_analysis(upath, puuid, mid, key, model, log):
    c = db.connect(upath)
    try:
        analysis.generate(c, puuid, mid, key, model)
        log("Análise pronta.")
    except RuntimeError as ex:
        raise jobs.RiotError(str(ex))
    finally:
        c.close()


def p_postgame(con, puuid, mid):
    pg = postgame.build(con, puuid, mid)
    if not pg:
        return page("Pós-jogo", "<p>Partida não encontrada.</p>")
    g = pg["game"]
    my_pid, my_team = g["participant_id"], g["team_id"]
    ms = review.moments(con, puuid, mid)
    ring = {c["t_ms"] for c in pg["costly"]}
    title = f"{g['champion']} contra {g['opp_champion'] or '?'}"
    win = bool(g["win"])
    ai = analysis.get(con, mid)
    key, _m = _ai_cfg()
    st = jobs.MANAGER.snapshot(CTX["uid"])
    state = "sem_chave" if not key else ("gerando" if st.get("name") == "analise" and st["running"] else None)
    if key and not ai and state is None and not st.get("running"):
        # partida sem analise: a IA analisa sozinha ao abrir (sem precisar clicar nem responder perguntas)
        try:
            upath = userdata.user_db(CTX["ddir"], CTX["user"])[0]
            if jobs.MANAGER.submit(CTX["uid"], "analise", lambda log: Handler_run_analysis(upath, puuid, mid, key, _m, log)):
                state = "gerando"
        except Exception:
            pass
    ai_html = analysis.block(ai, state, mid)
    body = (f"<div class='phead vph {'w' if win else 'l'}'><i class='vph-art' style=\"background-image:url('{e(icons.splash(g['champion']))}')\"></i><div><b class='res'>{'VITÓRIA' if win else 'DERROTA'}</b>"
            f"<span>{e(g['champion'])} · {e(postview.LANE_PT.get(g['position'], g['position'] or ''))} · {g['duration_s'] // 60}:{g['duration_s'] % 60:02d}"
            f" · patch {e(g['patch'])}</span></div><div class='kdab'><b>{g['kills']} / {g['deaths']} / {g['assists']}</b><small>K / D / A</small></div></div>")
    sb = postview.scoreboard(con, mid, my_pid)
    body += postmore.score_html(postmore.score(g))
    body += ("<div class='sbwrap'>" + _team_table(sb[my_team], "Seu time", "mine")
             + _team_table(sb[300 - my_team], "Time inimigo", "foe") + "</div>")

    try:
        from . import evolucao
        body += evolucao.match_card(con, puuid, g)
    except Exception:
        pass
    if g.get("opp_champion"):
        try:
            from . import ficha
            nt = ficha.note_get(con, g["champion"], g["opp_champion"])
            q_ = urllib.parse.urlencode({"c": g["champion"], "o": g["opp_champion"], "p": g.get("position") or ""})
            body += (f"<div class='card'><b class='gl'>Sua nota contra {e(g['opp_champion'])}</b>"
                     f"<p class='n'>Uma linha sobre o confronto. O coach lê na tela de carregamento da próxima vez que você pegar {e(g['opp_champion'])}.</p>"
                     f"<form method='post' action='/nota-confronto' class='row'><input type='hidden' name='c' value='{e(g['champion'])}'>"
                     f"<input type='hidden' name='o' value='{e(g['opp_champion'])}'><input type='hidden' name='back' value='/partida/{e(mid)}'>"
                     f"<input name='nota' maxlength='300' value='{e(nt)}' placeholder='Ex.: não trocar antes do 6, ela ganha no nível 3' style='flex:1'>"
                     "<button class='btn gold' style='width:auto'>Salvar</button></form>"
                     f"<p style='margin-top:8px'><a class='btn' href='/modelo?{q_}'>Ver a partida modelo deste confronto (alto elo)</a></p></div>")
        except Exception:
            pass
    body += _sec(1, "O veredicto", "O que aconteceu e o que fazer a seguir.")
    body += "<div class='card verdict'><b class='gl'>Foco para a próxima partida</b>" + tips_html([pg["focus"]]) + "</div>"
    body += "<div class='card'><b class='gl'>Resumo</b>" + tips_html(pg["summary"]) + "</div>"
    body += "<div class='card ok'><b class='gl'>O que você fez bem</b>" + tips_html(pg["well"]) + "</div>"
    body += "<h2>As 3 decisões que mais custaram</h2>"
    if ms:
        body += timeline_svg(ms, g["duration_s"], ring)
    if pg["costly"]:
        for c in pg["costly"]:
            mm_ = f"{c['t_ms'] // 60000}:{(c['t_ms'] // 1000) % 60:02d}"
            azar = extras.death_tags(con, mid).get(int(c["t_ms"])) == "azar"
            body += (f"<div class='moment'><h3>{e(c['title'])}{' <small class=n>(marcada como azar)</small>' if azar else ''}</h3>{tips_html(c['facts'])}"
                     f"<div class='row' style='gap:8px;flex-wrap:wrap'><form method='post' action='/partida/{e(mid)}/replay'><input type='hidden' name='t' value='{c['t_ms']}'>"
                     f"<button class='btn'>Ver este momento no replay ({mm_})</button></form>"
                     f"<form method='post' action='/partida/{e(mid)}/azar'><input type='hidden' name='t' value='{c['t_ms']}'>"
                     f"<button class='btn ghost' style='width:auto'>{'Desmarcar azar' if azar else 'Foi azar, não erro'}</button></form></div></div>")
        body += tips_html([pg["costly"][0]["rank_note"]])
    else:
        body += "<p class='mut'>Sem mortes registradas (ou sem timeline desta partida).</p>"

    try:            # tempo morto, nota por fase, build contra os melhores, objetivos, visao por fase (lote das 100 ideias)
        from . import liveview as _lv
        xb = ""
        dt = extras.dead_time(con, mid, my_pid, g.get("cs_per_min"))
        if dt:
            xb += (f"<div class='card'><h3>Tempo morto</h3><p><b>{dt[0] // 60}:{dt[0] % 60:02d}</b> esperando renascer, "
                   f"cerca de <b>{dt[1]}</b> de ouro que você deixou de ganhar.</p></div>")
        xb += extras.phase_html(extras.phase_grades(con, mid, my_pid, my_team))
        try:
            from .ddragon import DataDragon as _DD
            _items = _DD(cache_dir="cache").items()
        except Exception:
            _items = {}
        xb += extras.build_vs_html(extras.build_vs_top(con, mid, my_pid, g["champion"], g.get("position"), _items), _items, lambda i: _lv.item_img(i, 34))
        xb += extras.where_html(extras.where_at_objectives(con, mid, my_pid, my_team))
        xb += extras.vision_html(extras.vision_by_phase(con, mid, my_pid, g["champion"], g.get("position")))
        if g.get("opp_champion"):
            sm = extras.similar_match(con, puuid, mid, g["champion"], g["opp_champion"])
            if sm:
                xb += (f"<div class='card'><h3>Partida parecida</h3><p>Você já jogou {e(g['champion'])} contra {e(g['opp_champion'])}: "
                       f"<a href='/partida/{e(sm[0])}'>{'vitória' if sm[1] else 'derrota'}, {sm[2]}/{sm[3]}/{sm[4]}</a>. Compare o que mudou.</p></div>")
        if xb:
            body += "<h2>Mais leituras da partida</h2>" + xb
    except Exception:
        pass
    body += "<h2>Onde você morreu</h2>" + "<div class='card'>" + postmore.deaths_map_html(con, mid, my_pid, my_team, g.get("position"), postview.MAP_IMG) + "</div>"
    body += _sec(2, "As evidências", "Os dados por trás do diagnóstico. A comparação é com as suas outras partidas.")
    rd = postview.radar_data(con, puuid, mid)
    body += ("<div class='card'><b class='gl'>Perfil de desempenho</b>" + postview.radar_svg(rd, e) +
             "<p class='n'><span class='tag dado'>dado</span> linha tracejada = a média das suas outras partidas "
             f"({max(len(rep_games(con, puuid)) - 1, 0)} jogos). Fora dela = acima ou abaixo do seu normal.</p></div>")
    try:
        from .ddragon import DataDragon
        dd_ = DataDragon(cache_dir="cache")
        champs_ = dd_.champions()
    except Exception:
        dd_, champs_ = None, {}
    if dd_:
        from . import configview
        body += "<div class='card'><b class='gl'>Sua configuração nesta partida</b></div>" + configview.my_panel(con, mid, my_pid, dd_, e)
    ck = (champs_.get(g["champion"]) or {}).get("key")
    body += ("<div class='card'><b class='gl'>Maestria de campeão</b>"
             + postview.mastery_html(con, rep_games(con, puuid), g["champion"], ck, e) + "</div>")
    ph = postview.phases(con, mid, my_pid, g.get("opp_id"), g["duration_s"])
    body += "<div class='card'><b class='gl'>Análise por fase</b><div class='phases'>"
    for name, d in ph:
        if d is None:
            body += f"<div class='phase'><h4>{e(name)}</h4><p class='n'>Fase não alcançada ou sem timeline.</p></div>"
            continue
        gd = "–" if d["gd"] is None else f"{'+' if d['gd'] >= 0 else ''}{d['gd']}"
        body += (f"<div class='phase'><h4>{e(name)}</h4><p class='n'>{d['from']}–{d['to']} min</p>"
                 f"<div class='stat'><b>{d['cs']:.1f}</b><span>CS/min</span></div>"
                 f"<div class='stat'><b>{d['k']}/<span class='loss'>{d['d']}</span></b><span>abates/mortes</span></div>"
                 f"<div class='stat'><b class='{'win' if d['gd'] and d['gd'] > 0 else 'loss'}'>{e(gd)}</b><span>ouro vs oponente</span></div></div>")
    body += "</div></div>"

    body += _sec(3, "O confronto", "Ouro de cada rota contra o oponente, aos 14 min (ou até onde a partida foi).")
    lane_rows, at = postview.lanes(con, mid, my_team)
    if lane_rows:
        body += f"<div class='card lanes'><p class='n'><span class='tag dado'>dado</span> ouro aos {at} min</p>"
        for pos, a_, b_, diff in lane_rows:
            body += (f"<div class='lane {'me' if a_['participant_id'] == my_pid else ''}'><span class='ln'>{e(postview.LANE_PT[pos])}</span>"
                     f"<span>{e(a_['champion'])}</span><b class='{'win' if diff > 0 else 'loss'}'>{'+' if diff >= 0 else ''}{diff}</b>"
                     f"<span class='r'>{e(b_['champion'])}</span></div>")
        body += "</div>"
    else:
        body += "<p class='n'>Sem timeline desta partida.</p>"

    series = postview.gold_series(con, mid, my_team)
    objs = postview.objective_events(con, mid, my_team)
    body += _sec(4, "Diferença de ouro entre as equipes", "Pontos azuis: objetivos do seu time. Vermelhos: do inimigo.")
    body += "<div class='card'>" + postview.gold_svg(series, objs, my_team, e) + "</div>"

    names = {p["participant_id"]: p["champion"] for p in postview._players(con, mid)}
    body += _sec(5, "Mapa da partida", "Abates e objetivos. Deslize o tempo para ver como a partida andou.")
    body += "<div class='card'>" + postview.map_html(postview.map_points(con, mid, my_team), names, g["duration_s"], e, icons.champ) + "</div>"

    body += "<h2>Foco e plano</h2>" + tips_html([pg["map_plan"]])
    n = pg["notes"] or {}
    body += ("<h2>Pergunta final</h2><p>O que você faria diferente? Escreva antes de ver qualquer sugestão.</p>"
             f"<form method='post' action='/partida/{e(mid)}/nota'><textarea name='do_different' rows='3'>{e(n.get('do_different'))}</textarea>"
             f"<p>Como você se sentiu? (uma frase)</p><input type='text' name='feeling' value='{e(n.get('feeling'))}'>"
             "<p><button>Salvar</button></p></form>")
    body += extras.feel_html(mid, None)
    body += f"<p class='row' style='gap:8px'><a class='btn' href='/revisao/{e(mid)}'>Revisão das mortes pela IA</a>{extras.pdf_button()}</p>"
    body = body.replace("<div class='sbwrap'>", ai_html + "<div class='sbwrap'>", 1)
    if state == "gerando":
        body = "<div id='liveroot' data-every='5000'>" + body + "</div>"
    return page(title, body)


def _open_replay(mid, t_ms):
    """Abre o replay no cliente e tenta pular para o momento (API de replay do jogo, se estiver ligada)."""
    from . import lcu
    try:
        lcu.enable_replay_api()          # para conseguir pular direto para o momento
    except Exception:
        pass
    janela_ = False
    try:
        if not lcu.game_running():       # nunca mexe com partida aberta
            janela_ = lcu.replay_windowed_start() is not None     # replay em janela, ao lado do app
    except Exception:
        janela_ = False
    try:
        gid = int(str(mid).split("_")[-1])
        client = lcu.LCU.discover()
        client.watch_replay(gid)
    except Exception as ex:
        return f"replayerro:{str(ex)[:120]}"
    target = max(0, t_ms / 1000 - 15)

    def seek():
        import ssl, urllib.request as ur
        ctx = ssl.create_default_context()
        ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
        for _ in range(90):          # ate ~3 min esperando o replay carregar
            time.sleep(2)
            try:
                req = ur.Request("https://127.0.0.1:2999/replay/playback", data=json.dumps({"time": target}).encode(),
                                 headers={"Content-Type": "application/json"}, method="POST")
                with ur.urlopen(req, timeout=3, context=ctx) as r:
                    if r.status == 200:
                        return
            except Exception:
                continue
    import threading
    threading.Thread(target=seek, daemon=True).start()
    if janela_:
        def volta():
            for _ in range(60):          # espera o replay abrir (ate 2 min: o cliente pode estar baixando)
                if lcu.game_running():
                    break
                time.sleep(2)
            try:                         # depois espera ele fechar e devolve o modo de tela de antes
                lcu.replay_windowed_restore()
            except Exception:
                pass
        threading.Thread(target=volta, daemon=True).start()
    return f"replay:{int(target) // 60}:{int(target) % 60:02d}"


def _resolve_champ(champs, txt):
    if not txt:
        return None
    t = txt.strip().lower().replace(" ", "").replace("'", "").replace(".", "")
    for k, v in champs.items():
        if k.lower() == t or v.get("name", "").lower().replace(" ", "").replace("'", "").replace(".", "") == t:
            return k
    return None


def p_duel(con, puuid, a, b):
    try:
        dd = _dd()
        champs, items, ver = dd.champions(), dd.items(), dd.version()
    except Exception:
        champs, items, ver = {}, {}, None
    a_ = _resolve_champ(champs, a) or (profile.champion() if not a else None)
    b_ = _resolve_champ(champs, b)
    body = pages4.duel_page(con, puuid, a_, b_, champs, CTX["ddir"], items, ver, None)
    if (a and not _resolve_champ(champs, a)) or (b and not b_):
        body = "<p class='n' style='color:#E8817C'>Não achei um dos campeões: use o nome como aparece no jogo.</p>" + body
    return page("Explorador de duelos", body)


def p_tierlist(con, puuid, pos):
    pos = pos if pos in pages4.POSITIONS else profile.position()
    try:
        champs = _dd().champions()
    except Exception:
        champs = {}
    try:
        from . import champselect
        pool = champselect.pool_get(con)
    except Exception:
        pool = []
    return page("Tier list", pages4.tierlist_page(con, puuid, pos, champs, pool))


def p_pdl(con, puuid, period="tudo", t_from=None, t_to=None):
    import time as _t
    y0 = int(_t.mktime((_t.localtime().tm_year, 1, 1, 0, 0, 0, 0, 0, -1)) * 1000)
    n_year = con.execute("""SELECT COUNT(*) FROM participants p JOIN matches m USING (match_id) WHERE p.puuid=? AND m.queue_id=420 AND m.started_ms>=?""",
                         (puuid, y0)).fetchone()[0]
    hist = ranks.history(con)
    link = CTX.get("link")
    if not hist and link and link["tier"]:
        v = ranks.ladder(link["tier"], link["division"], link["lp"])
        if v is not None:
            hist = [{"at_ms": int(_t.time() * 1000), "v": v, "tier": link["tier"], "division": link["division"], "lp": link["lp"]}]
    return page("Histórico de PDL", pages4.pdl_page(con, puuid, hist, authview.TIER_COLOR, n_year, period, t_from, t_to))


def p_desempenho(con, puuid, mode):
    from . import desempenho
    link = CTX.get("link")
    try:
        key = config_mod.Config(os.path.join(CTX["ddir"], "coach.sqlite")).riot_key()
        region = (link["region"] if link else "br1") or "br1"
        path, _ = userdata.user_db(CTX["ddir"], CTX.get("user"))
        desempenho.enemy_rank_backfill(path, key, region, puuid)
    except Exception:
        pass
    try:
        enemy = desempenho.enemy_avg(con, puuid)
    except Exception:
        enemy = (None, 0)
    return page("Meu desempenho", desempenho.page_html(con, puuid, link, icons.champ, mode, enemy))


def p_patch(con, puuid, show_all):
    games = report.my_games(con, puuid, "")[:80]
    focus = {g["champion"] for g in games[:40]}
    focus |= {r[0] for r in report.by_key(games, "opp_champion", min_games=2)[:10] if r[0]}
    try:
        from . import champselect
        focus |= set(champselect.pool_get(con) or [])
    except Exception:
        pass
    try:
        ver = _dd().version()
    except Exception:
        ver = None
    xb = ""
    try:            # o seu main no patch novo: winrate antes e depois, e a build atual dos melhores (ideias 71 e 72)
        from . import liveview as _lv
        xb = extras.patch_html(con, _mains(con, puuid), _dd().items(), lambda i: _lv.item_img(i, 34), profile.position())
    except Exception:
        xb = ""
    return page("Patch", xb + pages4.patch_page(CTX["ddir"], focus, show_all, ver))


def p_jungle(con, puuid, c):
    try:
        champs = _dd().champions()
    except Exception:
        champs = {}
    jg = [g for g in report.my_games(con, puuid, "JUNGLE")]
    mine = [r[0] for r in sorted(report.by_key(jg, "champion"), key=lambda r: -r[1])[:6]]
    cid = _resolve_champ(champs, c) if c else (mine[0] if mine else "LeeSin")
    cid = cid or "LeeSin"
    name = (champs.get(cid) or {}).get("name", cid)
    opts = "".join(f"<option value='{e(k)}'>{e(v.get('name', k))}</option>" for k, v in sorted(champs.items(), key=lambda kv: kv[1].get("name", kv[0])))
    chips = "".join(f"<a href='/selva?c={e(m)}' class='{'on' if m == cid else ''}'>{e((champs.get(m) or {}).get('name', m))}</a>" for m in mine)
    form = (f"<form class='p4-f' method='get' action='/selva'><datalist id='chl'>{opts}</datalist>"
            f"<label>Campeão<input name='c' list='chl' value='{e(name)}'></label><button class='btn gold'>Ver</button></form>"
            + (f"<div class='p4-seg'>{chips}</div>" if chips else ""))
    mygs = []
    for g in jg:
        if g["champion"] != cid:
            continue
        f4 = con.execute("SELECT cs FROM frames WHERE match_id=? AND participant_id=? AND minute=4", (g["match_id"], g["participant_id"])).fetchone()
        if f4:
            mygs.append({"cs4": f4[0]})
    body = form + jungle.page_html(jungle.summary(con, cid), name, mygs)
    return page(f"Modo caçador · {name}", body)


TOUR_HTML = """<div id='tour' style='position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:999;display:none;align-items:center;justify-content:center;padding:16px'>
<div style='max-width:460px;width:100%;background:#1B1112;border:1px solid #3a2629;border-radius:16px;padding:22px'>
<small id='tstep' style='color:var(--mute)'></small><h3 id='ttit' style='margin:6px 0 8px;font:700 22px var(--head);color:#fff'></h3><p id='ttxt' style='color:#D9CDC4'></p>
<div style='display:flex;gap:8px;justify-content:flex-end;margin-top:14px'><button type='button' class='btn ghost' id='tskip' style='width:auto'>Pular</button>
<button type='button' class='btn gold' id='tnext' style='width:auto'>Próximo</button></div></div></div>
<script>(function(){var S=[
['Partida ao vivo','Abra antes de jogar: seleção de campeões com counters, runas automáticas e, no jogo, o overlay com a voz do coach. Tudo que ele fala aparece no balão.'],
['Revisão das mortes pela IA','Depois de cada partida, no Pós-jogo: cada morte já vem analisada pela IA, com o lance no mapa e o replay aberto no momento certo.'],
['Meu desempenho','Comparar mostra onde está a diferença entre você e os melhores do seu campeão e o treino do dia. Derrotas responde se foi o time ou você. Semana mostra o que melhorou.'],
['Editar overlay','Liga e desliga cada tipo de aviso, muda o tamanho e a posição. O modo só o necessário já vem ligado.'],
['Coach IA','Pergunte qualquer coisa sobre as suas partidas. No jogo, aperte o botão de falar e pergunte por voz.']];
var k='carry_tour_v1',i=0,t=document.getElementById('tour');if(!t)return;var f=location.search.indexOf('tour=1')>=0;
try{if(!f&&localStorage.getItem(k))return}catch(e){}
function sh(){document.getElementById('tstep').textContent=(i+1)+' de '+S.length;document.getElementById('ttit').textContent=S[i][0];
document.getElementById('ttxt').textContent=S[i][1];document.getElementById('tnext').textContent=i==S.length-1?'Começar':'Próximo'}
function end(){t.style.display='none';try{localStorage.setItem(k,'1')}catch(e){}}
document.getElementById('tskip').onclick=end;document.getElementById('tnext').onclick=function(){if(i<S.length-1){i++;sh()}else end()};
t.style.display='flex';sh()})();</script>"""


_ACCEPTED = {}


def _mais():
    from . import mais
    return mais


def _safe(fn):
    try:
        return fn() or ""
    except Exception as ex:
        print("bloco:", type(ex).__name__, ex)
        return ""


def _fatigue_html(con, puuid):
    from . import evolucao2
    try:
        return evolucao2.fatigue_card(report.my_games(con, puuid, ""))
    except Exception:
        return ""


def p_mistakes(con, puuid):
    games = report.my_games(con, puuid, "")[:60]
    items = postmore.common_mistakes(con, puuid, games)
    pats = review.patterns(con, puuid)
    extra = ""
    if pats["total"]:
        extra = ("<h2>O que você mesmo marcou na revisão guiada</h2>"
                 + "".join(f"<div class='card'><b class='gl'>{e(it['label'])}</b>{tips_html(it['tips'])}</div>" for it in pats["items"]))
    return page("Meus erros mais comuns", postmore.mistakes_html(items, len(games)) + extra)


def rep_games(con, puuid):
    return report.my_games(con, puuid, "")


def p_review(con, puuid, mid):
    try:
        ans = review.answers(con, mid)
        key0_, m0_ = _ai_cfg()
        full_ = analysis.get(con, mid)
        st0_ = jobs.MANAGER.snapshot(CTX["uid"])
        if key0_ and not full_ and not st0_.get("running"):
            # a IA analisa sozinha: o jogador so le (as perguntas viraram opcionais)
            try:
                upath0_ = userdata.user_db(CTX["ddir"], CTX["user"])[0]
                jobs.MANAGER.submit(CTX["uid"], "analise", lambda log: Handler_run_analysis(upath0_, puuid, mid, key0_, m0_, log))
            except Exception:
                pass
        html_ = vod.page_html(con, puuid, mid, ans, bool(key0_), full_)
    except Exception as ex:
        html_ = None
        print("revisao:", ex)
    if html_:
        try:
            R = coachreport.build(con, puuid, mid)
            rep = coachreport.html_report(R)
        except Exception as ex:
            rep = ""
            print("relatorio:", ex)
        key_, _m = _ai_cfg()
        ai = analysis.get(con, mid)
        st = jobs.MANAGER.snapshot(CTX["uid"])
        running = st.get("name") == "analise" and st["running"]
        if not key_:
            ai_html = ("<div class='cr-off'><b>Análise do Coach IA desligada.</b> O relatório acima é do próprio app (regras e números). "
                       "Para a análise escrita de coach (causas, o certo em cada lance, treino), coloque a chave do Gemini (grátis) em Administração, no Coach IA.</div>")
        elif running:
            ai_html = "<div class='aiban'><span class='spin'></span>O Coach IA está analisando a partida… a página atualiza sozinha.</div>"
        elif ai and ai.get("veredito"):
            ai_html = (analysis.full_html(ai) + f"<form method='post' action='/partida/{e(mid)}/analisar' style='margin-top:8px'><input type='hidden' name='back' value='revisao'>"
                       "<button class='btn'>Refazer a análise (com as suas respostas novas)</button></form>")
        else:
            ai_html = (f"<form method='post' action='/partida/{e(mid)}/analisar' class='aian-cta'><input type='hidden' name='back' value='revisao'><div><b>Análise completa do Coach IA</b>"
                       "<span>Lê a partida inteira (rota, lutas, objetivos, visão e as suas respostas) e escreve como um coach: os erros que mais custaram com o certo, os acertos e o treino.</span></div>"
                       "<button class='btn gold'>Analisar a partida</button></form>")
        intro = ("<p>Cada lance já vem analisado: o que o Coach IA viu, os números e o que fazer. Abra o replay direto no momento. "
                 "Anotar o que você via é opcional.</p>")
        body_ = rep + ai_html + "<h2>Lance a lance</h2>" + intro + html_ + vod.JS
        if running:
            body_ = "<div id='liveroot' data-every='5000'>" + body_ + "</div>"
        return page("Revisão da partida", body_)
    ms = review.moments(con, puuid, mid)
    if not ms:
        return page("Revisão guiada", "<p>Sem momentos críticos (sem timeline ou partida não encontrada).</p>")
    ans = review.answers(con, mid)
    dur = con.execute("SELECT duration_s FROM matches WHERE match_id=?", (mid,)).fetchone()
    done = sum(1 for m in ms if (ans.get((m["t_ms"], m["kind"])) or {}).get("cause"))
    body = (f"<p>Para cada momento, <b>primeiro responda</b> o que você via e o que ia fazer. "
            f"O contexto aparece depois de salvar. Respondidos: {done} de {len(ms)}.</p>")
    body += timeline_svg(ms, dur[0] if dur else 0)
    body += (f"<form method='post' action='/revisao/{e(mid)}/replay'><button class='ghost'>Abrir o replay no cliente do LoL</button> "
             "<span class='n'>só partidas recentes; o cliente precisa estar aberto</span></form>")
    for m in ms:
        a = ans.get((m["t_ms"], m["kind"]))
        is_done = bool(a and a["cause"])
        opts = "".join(f"<option value='{k}' {'selected' if a and a['cause'] == k else ''}>{k}) {e(v)}</option>"
                       for k, v in review.CAUSES.items())
        kj = a["knew_jungler"] if a else ""
        body += (f"<section class='moment {'done' if is_done else ''}' id='m{m['t_ms']}'>"
                 f"<h3>{mmss(m['t_ms'])}<small>{e(m['title'])}</small></h3>"
                 f"<form method='post' action='/revisao/{e(mid)}'>"
                 f"<input type='hidden' name='t_ms' value='{m['t_ms']}'><input type='hidden' name='kind' value='{e(m['kind'])}'>"
                 "<p>O que você via e o que ia fazer?</p>"
                 f"<textarea name='thought' rows='2'>{e(a['thought'] if a else '')}</textarea>"
                 f"<p>Sabia onde estava o jungler inimigo? <select name='knew'><option value=''>-</option>"
                 f"<option value='sim' {'selected' if kj == 'sim' else ''}>sim</option>"
                 f"<option value='nao' {'selected' if kj == 'nao' else ''}>não</option></select>"
                 f" &nbsp;Causa: <select name='cause'><option value=''>-</option>{opts}</select></p>"
                 "<button>Salvar resposta</button></form>")
        if is_done:
            body += "<h2 style='border:0;margin:18px 0 4px;padding:0;font-size:15px'>Contexto</h2>" + tips_html(m["facts"])
        elif a:
            body += "<p class='n'>Escolha uma causa para liberar o contexto.</p>"
        body += "</section>"
    body += "<p><a class='btn' href='/padroes'>Ver meus padrões</a></p>"
    return page("Revisão guiada", body)


def p_patterns(con, puuid):
    pt = review.patterns(con, puuid)
    if not pt["total"]:
        return page("Padrões", "<p>Ainda sem revisões. Faça a revisão guiada de uma partida em Partidas.</p>")
    body = ""
    if pt["total"] < LOW_SAMPLE:
        body += f"<div class='card warn'>Só {pt['total']} momentos classificados: os padrões abaixo são tendência, não conclusão.</div>"
    for i, it in enumerate(pt["items"], 1):
        body += f"<div class='card'><b>Padrão {i}: {e(it['label'])}</b>{tips_html(it['tips'])}</div>"
    if pt.get("extra"):
        body += "<div class='card'>" + tips_html(pt["extra"]) + "</div>"
    return page("Padrões", body)


def _ring(pct, size=54):
    r = 21
    c = 2 * 3.14159 * r
    off = c * (1 - pct / 100)
    return (f"<svg class='wring' width='{size}' height='{size}' viewBox='0 0 54 54'><circle cx='27' cy='27' r='{r}' class='bg'/>"
            f"<circle cx='27' cy='27' r='{r}' class='fg' stroke-dasharray='{c:.1f}' stroke-dashoffset='{off:.1f}' transform='rotate(-90 27 27)'/>"
            f"<text x='27' y='31' text-anchor='middle'>{pct}%</text></svg>")


def p_matchups(con, puuid, op=None, order="melhor"):
    games = report.my_games(con, puuid)
    cards = ""
    rows = report.by_key(games, "opp_champion")
    if order == "pior":
        rows = sorted(rows, key=lambda r: report.suave(r[2], r[1]))
    elif order == "jogos":
        rows = sorted(rows, key=lambda r: (-r[1], -r[3]))
    else:
        rows = sorted(rows, key=lambda r: -report.suave(r[2], r[1]))      # 1-0 nao fica na frente de 8-3
    for n, k, w_, r in rows:
        pct = round(100 * r)
        cards += (f"<a class='mcard {'low' if k < 3 else ''}' href='/matchups?op={e(n)}'>{icons.champ(n, 56, 'foe')}"
                  f"<div><b>{e(n)}</b><small>{k} jogo(s) · {w_}V {k - w_}D</small></div>{_ring(pct)}</a>")
    body = views2.matchup_detail(games, op) if op else ""
    body += "<h2>Todos os confrontos</h2>" if op else ""
    body += ("<nav class='modes' aria-label='Ordem'>" + "".join(
        f"<a href='/matchups?ordem={k}{'&op=' + e(op) if op else ''}'{' aria-current=page' if order == k else ''}>{t}</a>"
        for k, t in (("melhor", "Melhores primeiro"), ("pior", "Piores primeiro"), ("jogos", "Mais jogados"))) + "</nav>")
    body += "<div class='mgrid'>" + cards + "</div>"
    body += "<p class='n'>Anel = % de vitória. Cartões apagados = menos de 3 jogos (pode ser só amostra). Clique em um campeão para ver o detalhe.</p>"
    return page("Matchups", body)


def _ai_cfg():
    c = config_mod.Config(os.path.join(CTX["ddir"], "coach.sqlite")).load()
    return ai.pick(c)


def _dd():
    from .ddragon import DataDragon
    return DataDragon(cache_dir=os.path.join(CTX["ddir"], "cache"))


def p_champs(con, puuid, role=""):
    try:
        champs = _dd().champions()
    except Exception:
        return page("Campeões", "<div class='empty'><span class='em'>⚔</span><b>Não consegui carregar a lista de campeões</b><span>Confira a internet e tente de novo.</span></div>")
    roles = champview.role_map(CTX["ddir"], con)
    mine = {}
    for g in report.my_games(con, puuid, ""):
        mine[g["champion"]] = mine.get(g["champion"], 0) + 1
    return page("Campeões", champview.list_body(champs, roles, mine, role))


def p_champ(con, puuid, cid):
    dd = _dd()
    try:
        champs = dd.champions()
        by_lower = {k.lower(): k for k in champs}
        cid = by_lower.get(cid.lower(), cid)
        data = dd.champion(cid)
        ver = dd.version()
    except Exception:
        return page("Campeão", "<div class='empty'><span class='em'>⚔</span><b>Campeão não encontrado</b><span><a href='/campeoes'>Voltar para a lista</a></span></div>"), 404
    try:
        userdata.import_top(CTX["ddir"], con)
    except Exception:
        pass
    pos = champview.role_map(CTX["ddir"], con).get(cid) or "MIDDLE"
    from . import builds
    rows = builds.top_rows(con, cid, pos)
    build_html = statsui.build_explorer(con, rows, dd, data) if rows else None
    if build_html:
        try:
            build_html += statsui.rune_options(con, rows, dd)
        except Exception:
            pass
    if not rows:
        gn, gk = jobs.general_status(CTX["ddir"])
        build_html = (f"<div class='empty'><span class='spin' style='width:22px;height:22px;display:inline-block'></span><b>Ainda sem partidas de alto elo com {e(data.get('name', cid))}</b>"
                      f"<span>O app monta sozinho uma base com as partidas dos melhores do servidor enquanto fica aberto: já são {gn} partidas e {gk} campeões cobertos. "
                      "Cada partida serve para os 10 campeões dela, então build, runas e counters aparecem aqui assim que ele aparecer em alguma. "
                      "Se tiver pressa, use Baixar amostra do topo lá embaixo.</span></div>")
    sk = champview.skill_order(con, rows) if rows else None
    mu = champview.matchup_stats(CTX["ddir"], cid, pos)
    exps = champview.experts(CTX["ddir"], champs[cid]["key"])
    otp_html = statsui.otp_table(CTX["ddir"], champs[cid]["key"], cid)
    cnt_html = statsui.counters(mu, statsui.gold15(CTX["ddir"], cid, pos), data.get("name", cid), pos) if mu else ""
    games = report.my_games(con, puuid, "")
    mg = [g for g in games if g["champion"] == cid]
    vs = [g for g in games if (g.get("opp_champion") or "") == cid]
    my = (len(mg), sum(1 for g in mg if g["win"])) if mg else None
    vsme = (len(vs), sum(1 for g in vs if g["win"])) if vs else None
    guide = guides.get(CTX["ddir"], cid, ver)
    state = None
    if not guide:
        cfgx = config_mod.Config(os.path.join(CTX["ddir"], "coach.sqlite")).load()
        key, _mdl = ai.pick(cfgx)
        if not key:
            state = "sem_chave"
        else:
            st = jobs.MANAGER.snapshot(CTX["uid"])
            if st.get("name") == "guia" and st.get("error") and not st["running"]:
                state = "erro"
            else:
                model = _mdl or coachbot.DEFAULT_MODEL
                ddir_ = CTX["ddir"]
                jobs.MANAGER.submit(CTX["uid"], "guia", lambda log: guides.generate(ddir_, key, model, cid, data, ver, log))
                state = "gerando"
    body = champpage.page(cid, data, ver, pos, mu, sk, exps, build_html, guide, state, my, vsme, mg, bool(rows), otp_html, cnt_html)
    if state == "gerando":
        body = "<div id='liveroot' data-every='6000'>" + body + "</div>"
    return page(data.get("name", cid), body, show_title=False)


def _modes(cur):
    return ("<nav class='modes' aria-label='Comparar com'>"
            f"<a href='/topo?modo=elo'{' aria-current=page' if cur == 'elo' else ''}>Seu próximo elo</a>"
            f"<a href='/topo?modo=topo'{' aria-current=page' if cur == 'topo' else ''}>Os melhores do servidor</a></nav>")


ELO_ROWS = [("cs_per_min", "CS por minuto", 1, True), ("cs10", "CS aos 10 min", 0, True), ("csdiff10", "CS contra o oponente aos 10", 1, True),
            ("deaths_before_10", "Mortes antes dos 10", 2, False), ("golddiff15", "Ouro contra o oponente aos 15", 0, True),
            ("vision_per_min", "Visão por minuto", 2, True), ("kp", "Participação em abates", 2, True)]


def p_elo(con, puuid, tier_q=None):
    link = CTX.get("link")
    user = CTX.get("user")
    my_tier = (link["tier"] if link else None) or None
    target = tier_q if tier_q in tiers.TIERS else tiers.next_tier(my_tier, user["goal"] if user else None)
    pos = profile.position()
    mine = report.my_games(con, puuid)
    tg = tiers.games(CTX["ddir"], target, pos)
    rows = []
    for key, label, nd, higher in ELO_ROWS:
        mv = [g[key] for g in mine if g.get(key) is not None]
        tv = [g[key] for g in tg if g.get(key) is not None]
        if not mv and not tv:
            continue
        rows.append({"label": label, "nd": nd, "higher": higher, "mine": (sum(mv) / len(mv)) if mv else None, "n_mine": len(mv),
                     "top": insights._median(tv), "n_top": len(tv)})
    opts = "".join(f"<option value='{t}'{' selected' if t == target else ''}>{e(authview.TIER_PT[t])}</option>" for t in tiers.TIERS)
    form = (f"<div class='card'><form method='get' action='/topo' class='row' style='flex-wrap:wrap'><input type='hidden' name='modo' value='elo'>"
            f"<label class='n'>Comparar com</label><select name='t' onchange='this.form.submit()'>{opts}</select></form>"
            f"<form method='post' action='/sincronizar/iniciar' class='row'><input type='hidden' name='kind' value='tier'>"
            f"<input type='hidden' name='tier' value='{e(target)}'><input type='hidden' name='back' value='1'>"
            f"<button>{'Baixar amostra de ' if not tg else 'Aumentar a amostra de '}{e(authview.TIER_PT[target])} ({e(profile.lane_name())})</button>"
            "<span class='n'>Leva alguns minutos; continua sozinho.</span></form></div>")
    body = _modes("elo")
    if not tg:
        body += growthview.elo_compare(my_tier, target, [], 0, authview.TIER_PT, authview.crest, form)
        body += ("<div class='empty'><span class='em'>🎯</span><b>Ainda não há partidas desse elo</b>"
                 f"<span>Baixe uma amostra de jogadores {e(authview.TIER_PT[target])} {e(profile.lane_in())} para ver o que separa você deles.</span></div>")
        return page("Comparar", body)
    body += growthview.elo_compare(my_tier, target, rows, len(tg), authview.TIER_PT, authview.crest, form)
    worst = []
    for r in rows:
        if r["mine"] is None or r["top"] is None or not r["top"]:
            continue
        gap = (r["mine"] - r["top"]) / (abs(r["top"]) or 1) * (1 if r["higher"] else -1)
        worst.append((gap, r))
    worst.sort(key=lambda x: x[0])
    if worst and worst[0][0] < 0:
        r = worst[0][1]
        body += tips_html([{"kind": "dado", "n": len(tg), "text": f"A maior distância para {authview.TIER_PT[target]}: {r['label'].lower()} "
                            f"(você {r['mine']:.{r['nd']}f}, mediana deles {r['top']:.{r['nd']}f})."}])
    if len(tg) < 20:
        body += tips_html([{"kind": "dado", "n": len(tg), "text": "Amostra pequena: aumente para a comparação ficar mais confiável."}])
    return page("Comparar", body)


def p_top(con, puuid, champion=None):
    champion = champion or profile.champion()
    if not champion:
        return page("Comparar com o topo", "<div class='empty'><span class='em'>🏆</span><b>Sem partidas suas ainda</b>"
                    "<span>Sincronize suas partidas para comparar o seu campeão principal com o topo.</span></div>")
    mine = [g for g in report.my_games(con, puuid) if g["champion"] == champion]
    top = report.top_games(con, champion)
    rows, notes = insights.compare_top(mine, top)
    try:
        from . import builds
        from .ddragon import DataDragon
        items = DataDragon(cache_dir="cache").items()
        mf = [builds.my_first_item_min(con, g["match_id"], g["participant_id"], items) for g in mine]
        tf = [builds.my_first_item_min(con, g["match_id"], g["participant_id"], items) for g in top]
        mf, tf = [v for v in mf if v is not None], [v for v in tf if v is not None]
        rows.append({"label": "Primeiro item completo (minuto)", "nd": 1,
                     "mine": sum(mf) / len(mf) if mf else None, "n_mine": len(mf),
                     "top": insights._median(tf), "n_top": len(tf)})
    except Exception:
        pass  # sem rede para o Data Dragon: segue sem essa linha
    if not top:
        body = ("<div class='empty'><span class='em'>🏆</span><b>Ainda não há partidas do topo</b>"
                "<span>Baixe uma amostra dos melhores do BR para comparar com você.</span>"
                "<form method='post' action='/sincronizar/iniciar'><input type='hidden' name='kind' value='top'>"
                f"<input type='hidden' name='champion' value='{e(champion)}'><input type='hidden' name='games' value='30'>"
                "<input type='hidden' name='back' value='1'><button>Baixar amostra do topo</button></form>"
                "<small class='n'>Leva alguns minutos com a chave de desenvolvimento. Pode sair da tela, ele continua sozinho.</small></div>")
        return page("Comparar com o topo", body)
    try:
        from . import evolucao
        gap_html = evolucao.html_card(evolucao.gaps(con, puuid, champion))
    except Exception:
        gap_html = ""
    try:
        from . import evolucao2
        dd_ = _dd()
        gap_html += evolucao2.builds_card(con, puuid, champion, dd_.items(), dd_.rune_names())
    except Exception:
        pass
    body = _modes("topo") + gap_html + views2.top_compare(champion, rows, tips_html(notes), {"Mortes antes dos 15": False})
    alts = [r for r in report.by_key(report.my_games(con, puuid), "champion") if r[0] != champion][:5]
    if alts:
        body = ("<div class='pchips'>" + "".join(
            f"<a class='pchip' href='/topo?c={e(n)}' style='text-decoration:none;color:inherit'>{icons.champ(n, 30, 'me')}<span>{e(n)}</span></a>"
            for n, k, w, wr in alts) + "</div>") + body
    body += ("<div class='card'><b class='gl'>Quer uma amostra maior do topo?</b>"
             "<form method='post' action='/sincronizar/iniciar' class='row'><input type='hidden' name='kind' value='top'>"
             f"<input type='hidden' name='champion' value='{e(champion)}'><input type='hidden' name='games' value='60'>"
             "<input type='hidden' name='back' value='1'><button>Baixar mais 60 partidas</button></form>"
             "<p class='n'>Continua de onde parou, então pode repetir.</p></div>")
    return page("Comparar com o topo", body)


def p_habits(con, puuid):
    body = habitsview.build(con, puuid, sample_note)
    return page("Hábitos", body)


def _lever_card(lv, e):
    bars = ""
    for g in lv["groups"]:
        low = g["n"] < diagnosis.MIN_GROUP
        bars += (f"<div class='pb{' low' if low else ''}'><span class='pn'>{e(g['label'])}</span>"
                 f"<span class='pt2'><i style='width:{g['wr']}%'></i><u></u></span>"
                 f"<span class='pv'>{g['wr']}% <small>· {g['n']} jogo(s)</small></span></div>")
    return (f"<div class='card lever {'big' if lv['pesa'] else 'small'}'><b class='gl'>{e(lv['title'])}"
            f"{' · pesa nos seus resultados' if lv['pesa'] else ' · quase não pesa'}</b>{bars}"
            + tips_html(diagnosis.reading(lv)) + "</div>")


def _onboarding(all_games):
    """Primeiros passos no Inicio ate a pessoa terminar (ou dispensar)."""
    if CTX.get("onb_ok"):
        return ""
    try:
        c = config_mod.Config(os.path.join(CTX["ddir"], "coach.sqlite")).load()
    except Exception:
        c = {}
    from . import overlay as _ov
    mt = _ov.STATE.get("mictest") or {}
    steps = [("Chave da Riot salva", bool(CTX.get("has_key")), "/admin", "Colocar a chave"),
             ("Conta do LoL vinculada", bool(CTX.get("puuid")), "/vincular", "Vincular"),
             ("Partidas sincronizadas", bool(all_games), "/sincronizar", "Sincronizar"),
             ("Seu main escolhido", bool(CTX.get("main_ok")), "#main", "Escolher abaixo"),
             ("Chave do Gemini (IA e perguntas por voz)", bool(c.get("gemini_api_key")), "/admin", "Colocar a chave"),
             ("Overlay ligado", os.path.exists(AUTOSTART), "/overlay", "Ligar"),
             ("Microfone testado", mt.get("state") == "pronto" and (mt.get("level") or 0) >= 0.3, "/overlay", "Testar")]
    done = sum(1 for _, ok, _, _ in steps if ok)
    if done == len(steps):
        return ""
    rows = "".join(f"<li class='{'ok' if ok else ''}'><i>{'✓' if ok else n}</i><span>{e(t)}</span>"
                   + ("" if ok else f"<a href='{h}'>{e(b)}</a>") + "</li>" for n, (t, ok, h, b) in enumerate(steps, 1))
    return ("<style>.onb{border:1px solid rgba(233,196,106,.45);border-radius:18px;padding:18px 20px;margin:0 0 16px;"
            "background:radial-gradient(700px 220px at 100% 0,rgba(233,196,106,.09),transparent 70%),linear-gradient(180deg,rgba(32,24,23,.92),rgba(18,13,13,.96))}"
            ".onb h2{margin:0;font:700 22px var(--head);color:#fff}.onb .bar{height:6px;border-radius:99px;background:#2A1F1E;margin:10px 0 14px;overflow:hidden}"
            ".onb .bar .fl{display:block;height:100%;min-height:6px;background:var(--gold);border-radius:99px}.onb ol{list-style:none;margin:0;padding:0;display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:8px}"
            ".onb li{display:flex;align-items:center;gap:10px;padding:9px 12px;border:1px solid var(--rule);border-radius:12px;color:#E8DCCB;font-size:14px}"
            ".onb li i{font-style:normal;width:24px;height:24px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;background:#2A1F1E;color:var(--gold);font:700 12px var(--head);flex:none}"
            ".onb li.ok{opacity:.6}.onb li.ok i{background:var(--gold);color:#1a1405}.onb li span{flex:1}.onb li a{color:var(--gold);font-weight:600;font-size:13px;white-space:nowrap}"
            ".onb .f{display:flex;gap:10px;align-items:center;margin-top:12px;flex-wrap:wrap}.onb .f form{margin:0}</style>"
            f"<div class='onb'><h2>Primeiros passos</h2><p class='n' style='margin:4px 0 0'>{done} de {len(steps)} prontos. Faça uma vez e o resto é automático.</p>"
            f"<div class='bar'><span class='fl' style='width:{round(100 * done / len(steps))}%'></span></div><ol>{rows}</ol>"
            "<div class='f'><a class='btn gold' href='/guia' style='width:auto'>Abrir o passo a passo completo</a>"
            "<form method='post' action='/conta/onboarding'><button class='btn ghost' style='width:auto'>Já sei usar, esconder</button></form></div></div>")


def _coach_side(con, puuid):
    """Quadro ao lado do chat: o que o coach ve de voce agora."""
    try:
        gs = report.my_games(con, puuid, "")[:20]
        if not gs:
            return ""
        w = sum(1 for g in gs if g["win"])
        avg = lambda k: (sum(g[k] for g in gs if g.get(k) is not None) / max(1, sum(1 for g in gs if g.get(k) is not None)))
        from collections import Counter as _C
        main = _C(g["champion"] for g in gs).most_common(1)[0][0]
        link = CTX.get("link")
        elo = authview.rank_text(link) if link else ""
        try:
            top = postmore.common_mistakes(con, puuid, gs)[:1]
        except Exception:
            top = []
        return ("<div class='cbox'><h3>O que o coach vê de você</h3>"
                + (f"<p style='margin-top:0'><b>{e(elo)}</b> · mais jogado: {e(main)}</p>" if elo else f"<p style='margin-top:0'>Mais jogado: {e(main)}</p>")
                + f"<div class='cbst'><div><small>Últimas {len(gs)}</small><b class='{'w' if w * 2 >= len(gs) else 'l'}'>{round(100 * w / len(gs))}%</b></div>"
                f"<div><small>Mortes antes dos 10</small><b>{avg('deaths_before_10'):.1f}</b></div>"
                f"<div><small>Farm por minuto</small><b>{avg('cs_per_min'):.1f}</b></div>"
                f"<div><small>Visão por minuto</small><b>{avg('vision_per_min'):.2f}</b></div></div>"
                + (f"<p style='margin-bottom:0'>Erro que mais pesa: <b>{e(top[0]['title'].lower())}</b> ({top[0]['pct']}% das partidas)</p>" if top else "")
                + "</div>")
    except Exception:
        return ""


def p_analise(con, puuid):
    """Diagnostico, erros e padroes numa aba so (cada um numa sub-aba)."""
    CURRENT["body_only"] = True
    try:
        parts = []
        for k, t, fn in (("diag", "Diagnóstico", p_diag), ("erros", "Erros que mais se repetem", p_mistakes), ("padroes", "Padrões da revisão", p_patterns)):
            try:
                parts.append((k, t, fn(con, puuid)))
            except Exception as ex:
                parts.append((k, t, f"<p class='n'>Não deu para montar ({e(type(ex).__name__)}).</p>"))
    finally:
        CURRENT["body_only"] = False
    return page("Diagnóstico", premium.tabbar(parts, "analise"))


def p_diag(con, puuid):
    games = report.my_games(con, puuid, "")
    mid = [g for g in games if g["position"] == profile.position()]
    base = mid if len(mid) >= 20 else games
    if len(base) < 20:
        return page("Diagnóstico", "<div class='card warn'>Precisa de pelo menos 20 partidas sincronizadas para um diagnóstico confiável. "
                    "Clique em Sincronizar agora.</div>")
    wins = sum(1 for g in base if g["win"])
    body = diagview.build(base, profile.lane_in() if base is mid else "", wins, sample_note)
    try:            # mini-aula sobre o erro que mais pesa (ideia 64)
        top_ = postmore.common_mistakes(con, puuid, games[:60])
        body += extras.lesson_html(top_[0]["k"] if top_ else "d10")
    except Exception:
        pass
    return page("Diagnóstico", body)


def _mains(con, puuid):
    from . import champselect
    pool = champselect.pool_get(con)
    if pool:
        return pool[:8]
    return [r[0] for r in sorted(report.by_key(report.my_games(con, puuid), "champion"), key=lambda r: -r[1])[:4]]


def p_data(con, puuid):
    st = jobs.MANAGER.snapshot(CTX.get("uid"))
    n = con.execute("SELECT COUNT(*) FROM participants WHERE puuid=?", (puuid,)).fetchone()[0] if puuid else 0
    nt = con.execute("SELECT COUNT(*) FROM matches m JOIN match_source s USING(match_id) WHERE s.source='top'").fetchone()[0]
    body = ""
    if not CTX["has_key"]:
        body += ("<div class='card warn'><b class='gl'>Chave da Riot pendente</b><p class='n'>"
                 + ("Configure a chave no painel de administração para o app voltar a buscar partidas.</p><a class='btn gold' href='/admin'>Ir para a administração</a>"
                    if CTX.get("is_admin") else "O administrador ainda não configurou a chave (ou ela venceu). Suas análises continuam aqui; só a busca de partidas novas espera.</p>")
                 + "</div>")
    body += (f"<div class='grid2'><div class='card'><b class='gl'>Minhas partidas</b><p class='n'>{n} partidas ranqueadas suas salvas. "
             "Enquanto você usar o app, ele também busca as novas sozinho a cada 15 minutos.</p>"
             "<form method='post' action='/sincronizar/iniciar' class='row'><select name='count'>"
             "<option value='20'>últimas 20</option><option value='50'>últimas 50</option><option value='100' selected>últimas 100</option></select>"
             "<button name='kind' value='sync'>Sincronizar agora</button></form></div>")
    mc_val = e(profile.CURRENT["champion"] or "")
    body += (f"<div class='card'><b class='gl'>Amostra dos melhores do servidor</b><p class='n'>{nt} partidas do topo disponíveis para você. "
             "A amostra é compartilhada: o que alguém baixou serve para todos. Pode repetir: continua de onde parou.</p>"
             f"<form method='post' action='/sincronizar/iniciar' class='row'><input type='text' name='champion' value='{mc_val}' placeholder='Campeão (ex.: Ahri)' style='max-width:180px'>"
             "<select name='games'><option value='30'>30 partidas</option><option value='60'>60 partidas</option></select>"
             "<button name='kind' value='top'>Baixar amostra</button></form>"
             f"<form method='post' action='/sincronizar/iniciar' class='row'><input type='hidden' name='games' value='20'>"
             f"<button name='kind' value='topall' class='btn gold'>Baixar para todos os meus mains</button>"
             f"<span class='n'>{e(', '.join(_mains(con, puuid)))}</span></form></div></div>")
    if st["name"]:
        label = {"sync": "Sincronizar", "auto": "Sincronização automática", "top": "Amostra do topo", "test": "Teste da chave"}.get(st["name"], st["name"])
        status = ("na fila" if st.get("queued") else "rodando…") if st["running"] else ("deu erro" if st["error"] else "terminou")
        body += f"<div class='card {'warn' if st['error'] else ''}'><b class='gl'>{e(label)}: {status}</b>"
        if st["error"]:
            body += f"<p class='loss'>{e(st['error'])}</p>"
        body += views2.joblog(st["log"][-14:]) + "</div>"
    return page("Sincronizar", body)


def region_select(current):
    from .riot import REGIONS
    opts = "".join(f"<option value='{k}'{' selected' if k == current else ''}>{e(v[0])} ({k.upper()})</option>" for k, v in REGIONS.items())
    return f"<select name='region' title='Servidor da sua conta'>{opts}</select>"


def p_profile(con, acc, user, puuid, msg=""):
    link = accounts.link(acc, user["id"])
    games = report.my_games(con, puuid, "")
    mastery = []
    names = {}
    try:
        mastery = [dict(r) for r in con.execute("SELECT champion_id, level, points FROM mastery_me ORDER BY points DESC LIMIT 6")]
    except Exception:
        mastery = []
    if mastery:
        try:
            from .ddragon import DataDragon
            names = {str(v["key"]): k for k, v in DataDragon(cache_dir=os.path.join(CTX["ddir"], "cache")).champions().items()}
        except Exception:
            mastery = []
    body = authview.profile_body(user, link, games, mastery, names, sample_note, jobs.MANAGER.snapshot(user['id'])['running'])
    rise = growthview.rise_section(ranks.history(con), games, authview.TIER_COLOR, link, wide=True)
    body = body.replace("<h2>Seu jogo</h2>", rise + "<h2>Seu jogo</h2>", 1) if "<h2>Seu jogo</h2>" in body else body + rise
    try:
        from . import mainpick
        body += mainpick.html_block(con, _dd().champions(), games[:200], accounts.pref(acc, user["id"], "main_fixo") or (link["main_champ"] if link else None),
                                    accounts.pref(acc, user["id"], "role_fixo") or (link["main_role"] if link else None), CTX.get("csrf"))
    except Exception:
        pass
    if msg:
        body = f"<div class='alert ok'>{e(msg)}</div>" + body
    return page("Meu perfil", body, show_title=False)


def p_select(con, puuid):
    return page("Seleção de campeões", selview.build(con, puuid, e, tips_html))


def p_live_body(con, puuid, data):
    from . import live, liveview, report as rep
    items = {}
    try:
        from .ddragon import DataDragon
        items = DataDragon(cache_dir=os.path.join(CTX["ddir"], "cache")).items()
    except Exception:
        pass
    me = live._find_me(data)
    champ = liveview.champ_id(me) if me else None
    avg = None
    queued = False
    if champ:
        gs = [g for g in rep.my_games(con, puuid, "") if g["champion"] == champ and g.get("cs_per_min")]
        if gs:
            avg = (sum(g["cs_per_min"] for g in gs) / len(gs), len(gs))
        pos = profile.game_pos(me)
        if items and not liveview.build_plan(con, puuid, champ, pos, items) and CTX.get("has_key") and CTX.get("link"):
            ddir = CTX["ddir"]
            key = config_mod.Config(os.path.join(ddir, "coach.sqlite")).riot_key()
            path = userdata.user_db(ddir, CTX["user"])[0]
            region = CTX["link"]["region"]
            jobs.MANAGER.submit(CTX["uid"], "top", lambda log: jobs.run_top(ddir, path, key, region, champ, 20, log, puuid))
            queued = True
    return liveview.build_page(data, con, puuid, items, avg, queued, profile.game_pos(me) if me else profile.position())


def _tags():
    try:
        from .ddragon import DataDragon
        return {k: v["tags"] for k, v in DataDragon(cache_dir=os.path.join(CTX["ddir"], "cache")).champions().items()}
    except Exception:
        return {}


def _voz_admin(c):
    el, az = voice.keys(c)
    st = lambda k: (f"chave salva ({len(k)} caracteres)" if k else "sem chave")
    return ("<div class='card'><b class='gl'>Voz dos avisos</b><p class='n'>Os avisos do overlay podem ser falados. Cada frase fica guardada e não gasta de novo.</p>"
            f"<b class='gl' style='display:block;margin-top:12px'>ElevenLabs (recomendado)</b><p class='n'>Estado: {st(el)}. Vozes muito naturais; plano grátis sem cartão, cerca de 10 mil caracteres por mês (uso pessoal). "
            "Crie a conta, vá em <b>Developers &gt; API Keys</b>, crie uma chave com permissão de <b>Text to Speech</b> e de <b>Voices (leitura)</b>, e cole aqui. "
            "Para uma voz com sotaque brasileiro, adicione uma da <b>Voice Library</b> às suas vozes: ela aparece na lista do app.</p>"
            "<p><a class='btn gold' style='display:inline-flex;width:auto' href='https://elevenlabs.io/app/developers/api-keys' target='_blank' rel='noopener noreferrer'>Abrir a ElevenLabs</a></p>"
            "<form method='post' action='/admin/voz' class='row' style='flex-wrap:wrap'><input type='hidden' name='svc' value='el'>"
            "<input type='password' name='key' autocomplete='off' placeholder='Cole a chave (começa com sk_)'><button>Salvar</button>"
            + ("<button name='apagar' value='1' class='btn ghost'>Remover chave</button>" if el else "") + "</form>"
            f"<b class='gl' style='display:block;margin-top:16px'>Microsoft Azure Speech (Francisca, Antonio, Thalita)</b><p class='n'>Estado: {st(az)}. "
            "Vozes brasileiras naturais, plano gratuito <b>F0</b> com 500 mil caracteres por mês (dá para centenas de partidas). "
            "Se a ElevenLabs acabar, o app usa a Francisca automaticamente. "
            "Passo a passo: crie a conta grátis do Azure (pede cartão só para confirmar identidade; o F0 não cobra), "
            "clique em <b>Criar recurso &gt; Speech</b>, escolha a região <b>Brazil South</b> e o tipo de preço <b>Free F0</b>, "
            "depois abra o recurso em <b>Chaves e Ponto de Extremidade</b> e cole a <b>Chave 1</b> aqui.</p>"
            "<p><a class='btn' style='display:inline-flex;width:auto' href='https://portal.azure.com/#create/Microsoft.CognitiveServicesSpeechServices' target='_blank' rel='noopener noreferrer'>Abrir o Azure (criar Speech)</a></p>"
            "<form method='post' action='/admin/voz' class='row' style='flex-wrap:wrap'><input type='hidden' name='svc' value='az'><input type='password' name='key' autocomplete='off' placeholder='Cole a Key 1 do recurso Speech'>"
            f"<input name='region' value='{e(c.get('azure_speech_region') or 'brazilsouth')}' style='max-width:180px' title='Região'><button>Salvar</button>"
            + ("<button name='apagar' value='1' class='btn ghost'>Remover chave</button>" if az else "") + "</form></div>")


def _ovl_card():
    from . import overlay
    on = overlay.running()
    return ("<div class='ovl'><b>Overlay no jogo</b><span>Uma faixa pequena por cima do LoL com o próximo item, e os tempos de dragão, barão e acampamentos da selva em cima do minimapa. "
            "<a href='/overlay'>Editar o que aparece</a>. Perguntar ao coach por voz: Ctrl+Shift+A (fale e aperte de novo). Mostrar/esconder: Ctrl+Shift+O. Repetir o último aviso: Ctrl+Shift+R. Silenciar a voz por 2 minutos: Ctrl+Shift+S. Timer da selva: passe o mouse no acampamento do minimapa e aperte Ctrl+Shift+J (de novo cancela). Ajustar posição: Ctrl+Shift+M, arraste (no minimapa, a roda do mouse muda o tamanho) e aperte de novo. Use o LoL no modo de tela Sem bordas.</span>"
            + ("<span class='pill okp'><small>Overlay</small>ligado</span>" if on else
               "<form method='post' action='/overlay/abrir'><button class='btn gold'>Ligar overlay</button></form>")
            + ("<form method='post' action='/overlay/fechar'><button class='btn ghost'>Desligar</button></form>" if on else "") + "</div>" + _voice_card())


def _voice_diag():
    from . import overlay
    kind, line = voice.status_line()
    tail = overlay.log_tail(5)
    out = ""
    if line:
        out += f"<p class='n' style='margin:8px 0 0;font-size:13px;color:{'#6BBF8A' if kind == 'ok' else '#e6a0ab'}'>{e(line)}</p>"
    if tail:
        out += ("<details open style='margin-top:6px'><summary class='n' style='cursor:pointer;font-size:13px'>Diário da voz no overlay</summary>"
                "<pre style='white-space:pre-wrap;font-size:12px;color:var(--steel);margin:6px 0 0'>" + e("\n".join(tail)) + "</pre></details>")
    return out


def _pron_card():
    from . import pronuncia
    ex = ", ".join(f"{k} → {v}" for k, v in list(pronuncia.PADRAO.items())[:6])
    return ("<details class='pron' style='margin-top:10px'><summary><b>Pronúncia</b> (a voz falou algo errado?)</summary>"
            f"<p class='n' style='font-size:13px'>Uma regra por linha: <code>palavra = como falar</code>. Só muda o que a voz fala; a tela continua igual. "
            f"O app já corrige vários termos, como: {e(ex)}…</p>"
            "<form method='post' action='/voz/pronuncia'><textarea name='regras' rows='5' style='width:100%;max-width:560px' "
            "placeholder='Mordekaiser = Mordekáiser&#10;Nocturne = Nóctârn'>" + e(pronuncia.as_text()) + "</textarea>"
            "<div class='row' style='margin-top:6px'><button class='btn gold' style='width:auto'>Salvar pronúncia</button></div></form>"
            "<div class='row' style='margin-top:10px;flex-wrap:wrap'><input id='prontx' style='max-width:420px' "
            "value='Akali sem Flash. O jungler deles pode gankar o meio. Barão em um minuto.'>"
            "<button type='button' class='btn' id='pronplay' style='width:auto'>Ouvir como a voz fala</button></div>"
            "<script>(function(){var b=document.getElementById('pronplay');if(!b)return;b.onclick=function(){var s=document.getElementById('vozsel');"
            "b.textContent='Carregando…';fetch('/voz/exemplo?v='+encodeURIComponent(s?s.value:'')+'&t='+encodeURIComponent(document.getElementById('prontx').value)+'&_='+Date.now())"
            ".then(function(r){if(!r.ok)throw new Error('erro '+r.status);return r.blob()}).then(function(bl){var au=new Audio(URL.createObjectURL(bl));"
            "au.onended=function(){b.textContent='Ouvir como a voz fala'};au.play();b.textContent='Tocando…'})"
            ".catch(function(){b.textContent='Ouvir como a voz fala'})}})();</script></details>")


def _voice_card():
    if not CTX.get("voz_key"):
        msg = ("Falta a chave da voz (ElevenLabs): coloque em Administração." if CTX.get("is_admin")
               else "O administrador ainda não ligou a voz.")
        return f"<div class='ovl'><b>Voz dos avisos</b><span>Os avisos do overlay podem ser falados por uma voz natural. {msg}</span></div>"
    c = config_mod.Config(os.path.join(CTX["ddir"], "coach.sqlite")).load()
    cur = voice.pick(CTX["ddir"], c, CTX.get("voz") or "")
    def _prov(v, n):
        low = (v + " " + n).lower()
        return "Microsoft" if ("microsoft" in low or v.startswith(("ed:", "az:"))) else "Gemini" if ("gemini" in low or v.startswith("gm:")) else "ElevenLabs"
    groups = {}
    for v, n in voice.choices(CTX["ddir"], c):
        groups.setdefault(_prov(v, n), []).append((v, n))
    opts = "".join(f"<optgroup label='{e(g)}' data-prov='{e(g)}'>" + "".join(
        f"<option value='{e(v)}'{' selected' if cur == v else ''}>{e(n.split(' · ')[0])}</option>" for v, n in lst) + "</optgroup>"
        for g, lst in sorted(groups.items(), key=lambda kv: ["Microsoft", "Gemini", "ElevenLabs"].index(kv[0])))
    chips = ("<div class='vprov' role='group' aria-label='Empresa da voz'>" + "".join(
        f"<button type='button' data-p='{g}'>{g}{' (grátis)' if g != 'ElevenLabs' else ''} <small>{len(groups.get(g, []))}</small></button>"
        for g in ("Microsoft", "Gemini", "ElevenLabs") if groups.get(g)) + "<button type='button' data-p=''>Todas</button></div>"
             "<style>.vprov{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0}.vprov button{padding:6px 12px;border-radius:999px;border:1px solid var(--rule);"
             "background:transparent;color:#D6CCC0;font:600 12.5px var(--body);cursor:pointer}.vprov button small{opacity:.6}"
             ".vprov button.on{background:var(--gold);color:#1a1405;border-color:var(--gold)}</style>"
             "<script>(function(){var s=document.getElementById('vozsel'),B=document.querySelectorAll('.vprov button');if(!s)return;"
             "function f(p){B.forEach(function(b){b.classList.toggle('on',b.dataset.p===p)});s.querySelectorAll('optgroup').forEach(function(g){var h=p&&g.dataset.prov!==p;g.hidden=h;g.disabled=h});"
             "var o=s.options[s.selectedIndex];if(!o||o.parentNode.disabled){var v=[].slice.call(s.options).find(function(x){return !x.parentNode.disabled});if(v)s.value=v.value}"
             "try{localStorage.setItem('vprov',p)}catch(e){}}"
             "B.forEach(function(b){b.addEventListener('click',function(){f(b.dataset.p)})});var st='';try{st=localStorage.getItem('vprov')||''}catch(e){}"
             "var cur=s.options[s.selectedIndex];if(cur&&st&&cur.parentNode.dataset.prov!==st)st='';f(st)})();</script>")
    return ("<div class='ovl vozc'><b>Voz dos avisos</b><span>Uma voz natural fala os avisos durante a partida (dragão nascendo, oponente morto, ouro para o item).</span>"
            f"<form method='post' action='/voz/prefs' class='row' style='flex-wrap:wrap'>{chips}<select name='voz' id='vozsel' style='max-width:260px'>{opts}</select>"
            f"<label class='vck' style='white-space:nowrap'><input type='checkbox' name='on' value='1'{' checked' if CTX.get('voz_on') else ''}> falar os avisos</label>"
            f"<label class='n' style='display:flex;gap:6px;align-items:center;width:100%'>Voz dos avisos urgentes (perigo, Barão, caçador perto):"
            f"<select name='voz_u' style='max-width:240px'><option value=''>A mesma</option>"
            + "".join(f"<option value='{e(v)}'{' selected' if CTX.get('voz_u') == v else ''}>{e(n.split(' · ')[0])}</option>" for lst in groups.values() for v, n in lst)
            + "</select></label>"
            "<button type='button' class='btn' id='vozplay'>Ouvir exemplo</button><button class='btn gold' style='width:auto;flex:none'>Salvar</button></form>"
            "<form method='post' action='/voz/teste' class='row' style='margin-top:8px'><button class='btn'>Testar a voz pelo overlay</button>"
            "<span class='n' style='font-size:13px'>toca pelo mesmo caminho do jogo (precisa do overlay ligado)</span></form>"
            + _voice_diag() + _pron_card() +
            "<audio id='vozaud' preload='none'></audio>"
            "<script>(function(){var b=document.getElementById('vozplay');if(!b)return;b.onclick=function(){var a=document.getElementById('vozaud');"
            "b.textContent='Carregando…';window.__hold=Date.now()+25000;a.onended=function(){window.__hold=0};var m=document.getElementById('vozmsg');m.textContent='';"
            "fetch('/voz/exemplo?v='+encodeURIComponent(document.getElementById('vozsel').value)+'&_='+Date.now()).then(function(r){"
            "if(!r.ok)return r.text().then(function(t){throw new Error(t||('erro '+r.status))});return r.blob()}).then(function(bl){"
            "var u=URL.createObjectURL(bl),au=new Audio(u);au.volume=1;window.__hold=Date.now()+20000;"
            "au.onended=function(){window.__hold=0;b.textContent='Ouvir exemplo'};"
            "au.play().then(function(){b.textContent='Tocando…';m.style.color='#6BBF8A';m.innerHTML='Voz gerada ('+Math.round(bl.size/1024)+' KB). Se não ouviu nada, confira o volume do navegador no mixer do Windows. <a href=\\''+u+'\\' target=_blank>Abrir o áudio</a>'})"
            ".catch(function(err){b.textContent='Ouvir exemplo';m.innerHTML='A voz foi gerada, mas o navegador não tocou ('+err.name+'). <a href=\\''+u+'\\' target=_blank>Clique aqui para ouvir</a>'})})"
            ".catch(function(err){b.textContent='Ouvir exemplo';m.style.color='#e6a0ab';m.textContent='Não deu para gerar a voz: '+err.message})}})();</script>"
            "<p class='n' id='vozmsg' role='status' style='margin:6px 0 0;font-size:13px;color:#e6a0ab'></p></div>")


TOAST_JS = """<style>.cx-toast{position:fixed;right:22px;bottom:22px;z-index:9999;max-width:420px;padding:12px 16px;border-radius:12px;
background:#1F1817;border:1px solid #3A2C29;border-left:4px solid #6BBF8A;color:#F1E9DF;font:600 14px var(--body,sans-serif);
box-shadow:0 18px 40px -12px #000;opacity:0;transform:translateY(8px);transition:opacity .2s,transform .2s}.cx-toast.on{opacity:1;transform:none}
.cx-toast.err{border-left-color:#D9534F}</style><script>(function(){
function toast(t,err){var d=document.createElement('div');d.className='cx-toast'+(err?' err':'');d.textContent=t;document.body.appendChild(d);
requestAnimationFrame(function(){d.classList.add('on')});setTimeout(function(){d.classList.remove('on');setTimeout(function(){d.remove()},300)},3500)}
window.cxToast=toast;
document.addEventListener('submit',function(ev){var f=ev.target;var a=f.getAttribute('action')||'';
if(a!=='/selecao/importar'&&!(a.indexOf('/revisao/')===0&&a.slice(-7)==='/replay'))return;ev.preventDefault();
var b=ev.submitter,fd=new FormData(f);if(b&&b.name)fd.set(b.name,b.value);window.__hold=Date.now()+3000;
fetch(a,{method:'POST',body:new URLSearchParams(fd),headers:{'X-Requested-With':'fetch'}}).then(function(r){return r.text()})
.then(function(t){toast(t,/^N[aã]o consegui/.test(t))}).catch(function(){toast('Não consegui falar com o app.',true)})},true)})();</script>"""


KEYS_CSS = """<style>
.kbox{padding:6px 18px}
.krow{display:grid;grid-template-columns:minmax(220px,1fr) minmax(0,1.6fr) auto;gap:6px 18px;align-items:center;padding:14px 0;border-bottom:1px solid var(--rule)}
.krow:last-child{border-bottom:0}
.kname{display:flex;flex-direction:column;gap:4px}.kname b{font:700 15px var(--body)}.kname small{color:var(--mute);font-size:12px}
.kname b+small{display:inline}
.kpill{align-self:flex-start;padding:2px 10px;border-radius:999px;font:700 11.5px var(--body)}
.kpill.on{background:rgba(107,191,138,.16);color:#8FD4A8}.kpill.off{background:rgba(217,83,79,.14);color:#E8817C}
.kst{color:var(--mute);font-size:12px}
.kform{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.kf{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:0}
.kf{flex-wrap:nowrap !important}.kf input[type=password]{flex:1;min-width:180px;max-width:300px;margin:0 !important}.kf button,.kf .btn{width:auto !important;flex:none;margin:0 !important}
.khelp summary{cursor:pointer;color:#E9C46A;font:600 13px var(--body);white-space:nowrap}
.khelp[open]{grid-column:1/-1}.khelp p{margin:8px 0 0;font-size:13.5px;color:#D6CCC0;line-height:1.5}
.kmore summary{cursor:pointer;list-style:none}.kmore summary::-webkit-details-marker{display:none}
@media (max-width:1100px){.krow{grid-template-columns:1fr}}
</style>"""


PHASE_JS = """<script>(function(){if(location.pathname==='/jogo')return;var last=null;
function tick(){if(document.hidden)return setTimeout(tick,6000);fetch('/api/fase',{cache:'no-store'}).then(function(r){return r.json()}).then(function(d){
var p=d&&d.phase;if(p&&p!==last&&(p==='ChampSelect'||p==='InProgress')&&last!==null){var ae=document.activeElement;
if(!(ae&&/INPUT|TEXTAREA|SELECT/.test(ae.tagName))){location.href='/jogo';return}}last=p||last||'';setTimeout(tick,4000)}).catch(function(){setTimeout(tick,8000)})}
setTimeout(tick,1500)})();</script>"""


def _game_timeline(champ, cur, pos=None):
    """Cronograma da partida: dicas do guia do SEU campeao por fase (ou as dicas da sua rota se o guia ainda nao existe)."""
    from . import live
    phases = live.tips_for(pos or profile.position())
    data, ver = {}, None
    if champ:
        try:
            dd = _dd()
            ver = dd.version()
            data = dd.champion(champ)
            g = guides.get(CTX["ddir"], champ, ver)
            if g:
                phases = [g.get("rotas") or phases[0], g.get("meio") or phases[1], g.get("fim") or phases[2]]
        except Exception:
            pass
    return "<h2>Cronograma</h2>" + champpage.timeline(phases, data, ver, cur)


def _postgame_ready(con):
    """Faixa 'pos-jogo pronto' na tela de espera, se a ultima partida acabou de chegar (ate 30 min)."""
    from . import jobs
    for mid, st in sorted(jobs.POSTGAME.items(), key=lambda kv: -kv[1]["started"]):
        if st["state"] == "pronto" and time.time() - st["started"] < 1800 and \
                con.execute("SELECT 1 FROM matches WHERE match_id=?", (mid,)).fetchone():
            return (f"<div class='card' style='display:flex;align-items:center;justify-content:space-between;gap:16px'><span><b class='gl'>Pós-jogo pronto</b>"
                    f"<span class='n' style='display:block'>A sua última partida já chegou da Riot.</span></span><a class='btn gold' href='/partida/{e(mid)}'>Abrir pós-jogo</a></div>")
        break
    return ""


def _postgame_box(con, puuid, uid, lcu):
    """Fim de jogo: pega o id da partida no cliente, busca na Riot em segundo plano e abre o pos-jogo quando chegar."""
    from . import jobs
    last = postgame.latest_match_id(con, puuid)
    prev = f"<a class='btn ghost' href='/partida/{e(last)}'>Pós-jogo da partida anterior</a>" if last else ""
    gid = None
    try:
        gid = lcu.LCU.discover().last_game_id()
    except Exception:
        gid = None
    link = CTX.get("link")
    region = (link["region"] if link else "br1") or "br1"
    if not gid:
        return ("<div class='empty'><b>Partida terminou</b><span>Não consegui ler o número da partida no cliente. "
                "Ela entra na próxima sincronização.</span>" + prev + "</div>")
    mid = f"{region.upper()}_{gid}"
    if con.execute("SELECT 1 FROM matches WHERE match_id=?", (mid,)).fetchone():
        return ("<div class='empty'><b>Pós-jogo pronto</b><span>Abrindo a análise da partida…</span>"
                f"<a class='btn gold' href='/partida/{e(mid)}'>Abrir pós-jogo</a></div>"
                f"<script>setTimeout(function(){{location.href='/partida/{e(mid)}'}},800)</script>")
    key = config_mod.Config(os.path.join(CTX["ddir"], "coach.sqlite")).riot_key()
    if not key:
        return "<div class='empty'><b>Partida terminou</b><span>Falta a chave da Riot (Administração) para buscar a partida.</span>" + prev + "</div>"
    u = CTX.get("user")
    path, _ = userdata.user_db(CTX["ddir"], u)
    st = jobs.fetch_postgame(CTX["ddir"], path, key, region, uid, puuid, mid)
    secs = int(time.time() - st["started"])
    if st["state"] == "desistiu":
        msg = "A Riot ainda não liberou esta partida depois de 20 minutos. Ela entra na próxima sincronização automática."
    elif st["state"] == "erro":
        msg = f"Não deu para buscar a partida: {st['msg']}"
    else:
        msg = (f"Buscando a partida na Riot: tentativa {st['tries']}, há {secs // 60}:{secs % 60:02d}. A Riot costuma liberar entre 1 e 5 minutos. "
               "Pode sair desta tela ou entrar em outra fila: a busca continua e o pós-jogo fica pronto em Partidas.")
    return (f"<div class='empty'><span class='spin' style='width:28px;height:28px;display:inline-block'></span><b>Partida terminou</b><span>{e(msg)}</span>"
            + prev + "</div>")


def _gpage(title, body, **kw):
    """Paginas da Partida: levam sempre os scripts da selecao e do jogo. A tela troca sozinha de fila para selecao
    para jogo sem recarregar, e sem os scripts os paineis da selecao ficavam escondidos."""
    from . import selview
    if "selview_js" not in body:
        body += "<!--selview_js-->" + selview.JS
    if "mark_js" not in body:
        body += "<!--mark_js-->" + MARK_JS + MARK_CSS
    return page(title, body, **kw)


def p_game(con, puuid, uid):
    """Aba Partida: troca sozinha entre fila, selecao, carregamento, jogo e fim."""
    from . import lcu, live, liveview, selview
    phase = None
    try:
        phase = lcu.LCU.discover().gameflow_phase()
    except Exception:
        phase = None
    data = None if phase in ("ChampSelect", "Lobby", "Matchmaking", "ReadyCheck", "None") else live.fetch()
    if phase == "ChampSelect":      # selecao: nao espera o jogo nem carrega o resto
        out = {}
        body = selview.build(con, puuid, e, tips_html, wrap=False, snap_out=out)
        gameview.remember(uid, out.get("snap"), out.get("laner"))
        try:
            sn_ = out.get("snap") or {}
            if sn_.get("skin") and (sn_.get("me") or {}).get("champion"):
                icons.save_skin(CTX["ddir"], sn_["me"]["champion"], sn_["skin"])
        except Exception:
            pass
        return _gpage("Partida", "<div id='liveroot' data-every='2000'>" + gameview.stepper("selecao") + body + "</div>")
    games = report.my_games(con, puuid)
    tags = _tags()
    if phase == "ChampSelect" and not data:
        out = {}
        body = selview.build(con, puuid, e, tips_html, wrap=False, snap_out=out)
        gameview.remember(uid, out.get("snap"), out.get("laner"))
        return _gpage("Partida", "<div id='liveroot' data-every='3000'>" + gameview.stepper("selecao") + body + "</div>")
    if data:
        me = live._find_me(data)
        champ = liveview.champ_id(me) if me else None
        foes = [p for p in data.get("allPlayers") or [] if me and p.get("team") != me.get("team")]
        pos = profile.game_pos(me) if me else profile.position()
        lp = next((p for p in foes if p.get("position") == pos), None)
        laner = liveview.champ_id(lp) if lp else None
        gt = (data.get("gameData") or {}).get("gameTime") or 0
        hud = p_live_body(con, puuid, data)
        try:
            from . import scout
            link_ = CTX.get("link")
            scout.ensure(config_mod.Config(os.path.join(CTX["ddir"], "coach.sqlite")).riot_key(), (link_["region"] if link_ else "br1") or "br1", data, CTX["ddir"])
            hud += scout.card_html(scout.get(data), icons.champ, e)
        except Exception:
            pass
        try:
            hud += mark_card(data)
        except Exception:
            pass
        wc = live.win_condition(data, tags)
        hud += _game_timeline(champ, live.phase_now(gt), pos)
        if gt < 120:
            plan = gameview.plan_cards(con, puuid, games, champ, laner, tags, "", wc)
            return _gpage("Partida", "<div id='liveroot' data-every='3000'>" + gameview.stepper("jogo") + plan + hud + _ovl_card() + "</div>", show_title=False)
        strip = gameview.plan_cards(con, puuid, games, champ, laner, tags, "", wc, compact=True)
        return _gpage("Partida", "<div id='liveroot' data-every='3000'>" + gameview.stepper("jogo") + hud + strip + _ovl_card() + "</div>", show_title=False)
    if phase in ("GameStart", "InProgress", "Reconnect"):
        last = gameview.LAST.get(uid) or {}
        plan = gameview.plan_cards(con, puuid, games, last.get("champion"), last.get("laner"), tags)
        tl = _game_timeline(last.get("champion"), 0)
        return _gpage("Partida", "<div id='liveroot' data-every='3000'>" + gameview.stepper("carregando") + plan + tl + _ovl_card() + "</div>", show_title=False)
    if phase in ("WaitingForStats", "PreEndOfGame", "EndOfGame"):
        body = _postgame_box(con, puuid, uid, lcu)
        return _gpage("Partida", "<div id='liveroot' data-every='5000'>" + gameview.stepper("fim") + body + _ovl_card() + "</div>")
    st = missions.ensure_today(con, report.my_games(con, puuid, ""))
    sp = icons.splash(profile.champion()) if profile.champion() else ""
    waiting = ("<div class='empty'><span class='em'>🎮</span><b>" + ("Na fila…" if phase in ("Matchmaking", "ReadyCheck") else
               "Pronto para jogar") + "</b><span>Esta tela muda sozinha: na seleção aparece o coach de pick e ban; quando a partida "
               "começar, o plano de jogo e o painel ao vivo.</span></div>")
    pg = _postgame_ready(con)
    return _gpage("Partida", "<div id='liveroot' data-every='3000'>" + gameview.stepper("fila") + pg + growthview.mission_card(st, sp)
                + waiting + _ovl_card() + "</div>" + growthview.MOTION_JS, show_title=False)


# ---- servidor -------------------------------------------------------------
COOKIE = "lc_s"
PRE_COOKIE = "lc_pre"
FORM_RE = re.compile(r"(<form\b[^>]*\bmethod=['\"]?post['\"]?[^>]*>)", re.I)
FLASH = {"salvo": ("ok", "Salvo."), "senha": ("ok", "Senha trocada. Os outros aparelhos foram desconectados."),
         "vinculada": ("ok", "Conta verificada! Suas partidas já estão sendo baixadas."),
         "apagada": ("ok", "Sua conta e seus dados foram apagados."), "saiu": ("ok", "Você saiu da sua conta."),
         "aprovado": ("ok", "Conta aprovada."), "feito": ("ok", "Feito."), "chave": ("ok", "Chave salva."),
         "modo": ("ok", "Modo de cadastro salvo."), "fila": ("ok", "Colocado na fila."), "excluido": ("ok", "Usuário excluído."),
         "csrf": ("err", "A página ficou velha. Tente de novo."), "ovloff": ("err", "Ligue o overlay primeiro."), "elid": ("err", "Isso é o ID da chave, não a chave. A chave da ElevenLabs começa com sk_ e só aparece uma vez, quando é criada: crie uma nova e copie o texto inteiro."),
         "vozteste": ("ok", "Pedido enviado ao overlay: a voz deve tocar em até 5 segundos. Se não tocar, veja o diário logo abaixo."), "admin1": ("err", "Precisa existir pelo menos um administrador ativo.")}
SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "same-origin",
    "Content-Security-Policy": ("default-src 'self'; img-src 'self' data: https://ddragon.leagueoflegends.com; "
                                "style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline' https://www.youtube.com https://s.ytimg.com; connect-src 'self'; "
                                "frame-ancestors 'none'; form-action 'self'; base-uri 'none'; frame-src https://www.youtube-nocookie.com https://www.youtube.com; media-src 'self' blob:"),
}


def _flash(q):
    code = (q.get("m") or [""])[0]
    if code.startswith("replay:"):
        return ("ok", f"Abrindo o replay no cliente. Se ele não pular sozinho, vá até {code[7:]} (15 s antes do momento).")
    if code.startswith("replayerro:"):
        return ("err", "Não consegui abrir o replay: " + code[11:] + " O cliente do LoL precisa estar aberto e a partida ser recente.")
    return FLASH.get(code, (None, ""))


def adopt_legacy(acc, uid, db_path, cfg):
    """Primeira conta (o dono): herda o banco e a conta do LoL que ja estavam no app antigo, sem baixar nada de novo."""
    if not os.path.exists(db_path):
        return False
    accounts.set_user_field(acc, uid, "db_file", os.path.basename(db_path))
    con = db.connect(db_path)
    try:
        rid = cfg.load().get("riot_id") or ""
        rows = con.execute("SELECT k, v FROM meta WHERE k LIKE 'puuid:%'").fetchall() if con.execute(
            "SELECT 1 FROM sqlite_master WHERE name='meta'").fetchone() else []
    finally:
        con.close()
    pick = next((r for r in rows if r[0] == "puuid:" + rid), None) or (rows[0] if len(rows) == 1 else None)
    if not pick:
        return False
    accounts.set_link(acc, uid, pick[0][len("puuid:"):], cfg.region(), pick[1])
    accounts.mark_verified(acc, uid)
    c2 = db.connect(db_path)
    try:
        accounts.update_link_stats(acc, uid, **jobs.player_stats(c2, pick[1]))
    finally:
        c2.close()
    return True


def temp_password():
    alphabet = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789"
    return "".join(secrets.choice(alphabet) for _ in range(12))


def make_handler(db_path, _legacy=None):
    ddir = userdata.data_dir(db_path)
    cfg = config_mod.Config(db_path)
    extra = {h.strip().lower() for h in os.environ.get("COACH_HOSTS", "").split(",") if h.strip()}
    allowed_hosts = {"127.0.0.1", "localhost"} | extra
    trust_proxy = os.environ.get("COACH_TRUST_PROXY") == "1"
    if os.name == "nt":
        try:
            voice.ed_ready()        # instala a voz gratis da Microsoft em segundo plano ao abrir o app (uma vez so)
        except Exception:
            pass

    class H(BaseHTTPRequestHandler):
        server_version = "LoLCoach"
        sys_version = ""

        def log_message(self, *a):
            pass

        # -- rede / seguranca --------------------------------------------
        def _ip(self):
            if trust_proxy and self.headers.get("X-Forwarded-For"):
                return self.headers["X-Forwarded-For"].split(",")[0].strip()
            return self.client_address[0]

        def _is_local(self):
            """O navegador esta no MESMO PC do servidor (e do cliente do LoL)."""
            return self.client_address[0] in ("127.0.0.1", "::1") and not self.headers.get("X-Forwarded-For")

        def _https(self):
            return os.environ.get("COACH_HTTPS") == "1" or (trust_proxy and self.headers.get("X-Forwarded-Proto") == "https")

        def _ok_host(self):
            host = (self.headers.get("Host") or "").rsplit(":", 1)[0].strip("[]").lower()
            return host in allowed_hosts

        def _cookie(self, name):
            c = http.cookies.SimpleCookie()
            try:
                c.load(self.headers.get("Cookie") or "")
            except http.cookies.CookieError:
                return None
            return c[name].value if name in c else None

        def _cookie_hdr(self, name, value, max_age):
            return (f"{name}={value}; Path=/; HttpOnly; SameSite=Lax; Max-Age={max_age}"
                    + ("; Secure" if self._https() else ""))

        def _send(self, body, code=200, cookies=(), ctype="text/html; charset=utf-8", extra_headers=None):
            if ctype.startswith("text/html") and isinstance(body, str):
                body = icons.deemoji(body)
            if ctype.startswith("text/html") and CTX.get("csrf"):
                tok = CTX["csrf"]
                body = FORM_RE.sub(lambda m: m.group(1) + f"<input type='hidden' name='csrf' value='{tok}'>", body)
            data = body.encode("utf-8") if isinstance(body, str) else body
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            if "Cache-Control" not in (extra_headers or {}):
                self.send_header("Cache-Control", "no-store")
            for k, v in SECURITY_HEADERS.items():
                self.send_header(k, v)
            for k, v in (extra_headers or {}).items():
                self.send_header(k, v)
            for c in cookies:
                self.send_header("Set-Cookie", c)
            self.end_headers()
            self.wfile.write(data)

        def _redirect(self, to, cookies=()):
            self.send_response(303)
            self.send_header("Location", to)
            self.send_header("Cache-Control", "no-store")
            for c in cookies:
                self.send_header("Set-Cookie", c)
            self.end_headers()

        # -- contexto do usuario -------------------------------------------
        def _setup(self, acc, u, s):
            CTX.reset()
            CURRENT.reset()
            profile.CURRENT.reset()
            bg.BG.reset()
            CTX["has_key"] = bool(cfg.riot_key())
            CTX["ddir"] = ddir
            if not u:
                return
            link = accounts.link(acc, u["id"])
            kind = accounts.pref(acc, u["id"], "bg_kind")
            if kind:
                bg.BG.update(kind=kind, value=accounts.pref(acc, u["id"], "bg_value"))
            CTX.update(limite_dia=accounts.pref(acc, u["id"], "limite_dia", None), voz_tom=accounts.pref(acc, u["id"], "voz_tom", "serio"))
            CTX.update(voz_on=accounts.pref(acc, u["id"], "voz_on", "1") == "1", voz=accounts.pref(acc, u["id"], "voz", ""), voz_u=accounts.pref(acc, u["id"], "voz_urgente", ""),
                       voz_key=voice.configured(cfg.load()))
            CTX.update(user=u, uid=u["id"], is_admin=u["role"] == "admin", csrf=s["csrf"] if s else None, link=link,
                       puuid=link["puuid"] if link and link["verified_ms"] else None)

        def _user_con(self, acc, u):
            path, name = userdata.user_db(ddir, u)
            if not u["db_file"]:
                accounts.set_user_field(acc, u["id"], "db_file", name)
            return db.connect(path)

        def _user_path(self, acc, u):
            path, name = userdata.user_db(ddir, u)
            if not u["db_file"]:
                accounts.set_user_field(acc, u["id"], "db_file", name)
            return path

        def _pre(self):
            """Token contra envio forjado nas telas sem login (entrar/criar conta)."""
            tok = self._cookie(PRE_COOKIE)
            if not tok or not re.fullmatch(r"[A-Za-z0-9_-]{20,64}", tok):
                tok = secrets.token_urlsafe(24)
            return tok, [self._cookie_hdr(PRE_COOKIE, tok, 3600 * 6)]

        def _auth_page(self, title, inner, cookies=(), code=200):
            return self._send(authview.shell(title, inner, CSS), code, cookies)

        # -- GET -----------------------------------------------------------
        def do_GET(self):
            if not self._ok_host():
                return self._send("host invalido", 403, ctype="text/plain; charset=utf-8")
            u_ = urllib.parse.urlparse(self.path)
            q = urllib.parse.parse_qs(u_.query)
            path = u_.path
            if not path.startswith(("/api/", "/static/")):
                jobs.ACTIVE["t"] = time.time()          # alguem esta usando o app: o trabalho pesado de fundo espera
                try:
                    from . import mais as _m
                    _m.uso_conta(path)
                except Exception:
                    pass
            if path == "/favicon.ico":
                return self._send("", 404, ctype="text/plain")
            if path.startswith("/static/ranks/"):
                from . import ranksimg
                name = os.path.basename(path)
                tier = name[:-4].upper() if name.endswith(".png") else ""
                fp = ranksimg.path_for(tier) if tier in ranksimg.TIERS else None
                if not fp or not os.path.isfile(fp):
                    return self._send("", 404, ctype="text/plain")
                with open(fp, "rb") as fh:
                    return self._send(fh.read(), ctype="image/png", extra_headers={"Cache-Control": "public, max-age=604800"})
            if path.startswith("/static/img/") or path == "/overlay/fundo.img":
                if path == "/overlay/fundo.img":
                    fp = next((x for x in (OVERLAY_BG + ".jpg", OVERLAY_BG + ".png") if os.path.isfile(x)), None)
                else:
                    name = os.path.basename(path)
                    fp = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "img", name)
                    fp = fp if name.endswith((".jpg", ".png")) and os.path.isfile(fp) else None
                if not fp:
                    return self._send("", 404, ctype="text/plain")
                with open(fp, "rb") as fh:
                    return self._send(fh.read(), ctype="image/png" if fp.endswith(".png") else "image/jpeg",
                                      extra_headers={"Cache-Control": "public, max-age=86400"})
            if path.startswith("/static/fonts/"):
                name = os.path.basename(path)
                fp = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "fonts", name)
                if not name.endswith(".woff2") or not os.path.isfile(fp):
                    return self._send("", 404, ctype="text/plain")
                with open(fp, "rb") as fh:
                    return self._send(fh.read(), ctype="font/woff2", extra_headers={"Cache-Control": "public, max-age=31536000"})
            acc = accounts.connect(ddir)
            try:
                if path == "/api/overlay":
                    return self._overlay_json(acc, q)
                if path == "/api/overlay/voz":
                    return self._overlay_voice(acc, q)
                if path == "/api/overlay/marcar":
                    from . import overlay as _ov
                    if not self._is_local() or not hmac.compare_digest((q.get("t") or [""])[0], _ov.TOKEN):
                        return self._send("", 403, ctype="text/plain")
                    txt_ = _mark_spell(q)
                    tip_ = None
                    if (q.get("clear") or [""])[0] != "1" and txt_ and "marcad" in txt_:
                        try:
                            from . import live as _lv, spelltimers as _st
                            dd_ = _lv.fetch()
                            sp_ = (q.get("s") or [""])[0] or None
                            tip_ = _st.tip_for(dd_, _lv._find_me(dd_), int((q.get("slot") or ["0"])[0] or 0),
                                               "r" if (q.get("k") or ["f"])[0] == "r" else "f", sp_ if sp_ in _st.SPELL_CD else None)
                        except Exception:
                            tip_ = None
                    return self._send(json.dumps({"t": txt_, "v": tip_}, ensure_ascii=False), ctype="application/json; charset=utf-8")
                user, sess = accounts.session_user(acc, self._cookie(COOKIE))
                self._setup(acc, user, sess)
                CURRENT["path"] = path
                kind, msg = _flash(q)
                if path == "/voz/exemplo" and user:
                    c = cfg.load()
                    if not voice.configured(c):
                        return self._send("", 404, ctype="text/plain")
                    try:
                        txt_ = ((q.get("t") or [""])[0] or "").strip()[:200]
                        wav = voice.say(ddir, c, (q.get("v") or [""])[0], txt_ or voice.SAMPLE)
                    except Exception as ex:
                        return self._send(str(ex), 502, ctype="text/plain")
                    return self._send(wav, ctype=voice.audio_type(wav))
                if path == "/guia" and not user:
                    from . import guia
                    return self._auth_page("Como usar o Carry", guia.page_html() + "<p class='alt'><a href='/entrar'>Entrar ou criar conta</a></p>")
                if path in ("/entrar", "/cadastro") or (path == "/privacidade" and not user):
                    if path == "/privacidade":
                        return self._auth_page("Privacidade", "<h3>Privacidade</h3>" + authview.privacy_body() + "<p class='alt'><a href='/entrar'>Voltar</a></p>")
                    if user:
                        return self._redirect("/")
                    pre, ck = self._pre()
                    first = accounts.user_count(acc) == 0
                    if path == "/entrar":
                        if first:
                            return self._redirect("/cadastro")
                        return self._auth_page("Entrar", authview.login_form(info=msg if kind == "ok" else "", pre=pre), ck)
                    return self._auth_page("Criar conta", authview.signup_form(accounts.signup_mode(acc), pre=pre, first=first), ck)
                if not user:
                    if path == "/api/jobs":
                        return self._send("", 401)
                    return self._redirect("/entrar")
                if user["status"] == "pending":
                    return self._auth_page("Aguardando aprovação", authview.pending_box(user["name"]))
                if path == "/api/jobs":
                    return self._send(job_area_html())
                if path == "/api/fase":       # fase do cliente (fila, selecao, jogo): as telas pulam sozinhas para a Partida
                    ph = None
                    if self._is_local():
                        try:
                            from . import lcu as _l
                            ph = _l.LCU.discover().gameflow_phase()
                        except Exception:
                            ph = None
                    return self._send(json.dumps({"phase": ph}), ctype="application/json")
                if path.startswith("/fundos/"):
                    nm = os.path.basename(urllib.parse.unquote(path))
                    if not nm.startswith(f"u{user['id']}_"):
                        return self._send("", 404, ctype="text/plain")
                    return self._send_video(nm)
                if path == "/privacidade":
                    return self._send(page("Privacidade", authview.privacy_body()))
                if path == "/guia":
                    from . import guia
                    return self._send(page("Como usar o Carry", guia.page_html()))
                if path == "/conta":
                    return self._send(page("Minha conta", authview.account_body(user, CTX["link"], *((msg, "") if kind == "err" else ("", msg)))
                                           + self._bg_card(acc, user, (q.get("campeao") or [None])[0])))
                if path == "/conta/exportar":
                    return self._send_export(acc, user)
                if path == "/vincular":
                    err = (q.get("e") or [""])[0][:300]
                    return self._send(page("Conta do LoL", authview.link_body(CTX["link"], CTX["has_key"], region_select, err=err, info=msg if kind == "ok" else "")))
                if path == "/admin":
                    if not CTX["is_admin"]:
                        return self._send(page("Não encontrado", "<p>Página inexistente.</p>"), 404)
                    return self._send(self._admin_page(acc, user, msg if kind == "ok" else ""))
                if not CTX["puuid"]:
                    return self._redirect("/vincular")
                con = self._user_con(acc, user)
                try:
                    puuid = CTX["puuid"]
                    profile.set_for(con, puuid)
                    mf_, rf_ = accounts.pref(acc, user["id"], "main_fixo"), accounts.pref(acc, user["id"], "role_fixo")
                    if mf_:
                        profile.CURRENT["champion"] = mf_
                    if rf_:
                        profile.CURRENT["position"] = rf_
                    CTX["main_champ"] = profile.CURRENT["champion"]
                    CTX["main_ok"] = accounts.pref(acc, user["id"], "main_ok") == "1"
                    CTX["onb_ok"] = accounts.pref(acc, user["id"], "onb_ok") == "1"
                    icons.load_skin(CTX["ddir"])
                    if bg.BG.get("kind") == "auto":      # fundo que acompanha o campeao da partida (ou o da ultima)
                        try:
                            from . import overlay as _ov
                            ch = _ov.STATE.get("cur_champ") if time.time() - _ov.STATE.get("cur_at", 0) < 120 else None
                            if not ch:
                                r_ = con.execute("""SELECT p.champion FROM participants p JOIN matches m USING (match_id)
                                                    WHERE p.puuid=? ORDER BY m.started_ms DESC LIMIT 1""", (puuid,)).fetchone()
                                ch = r_[0] if r_ else None
                            if ch:
                                bg.BG.update(value=f"{ch}:0")
                        except Exception:
                            pass
                    return self._route_get(con, acc, user, puuid, path, q)
                finally:
                    con.close()
            finally:
                acc.close()

        def _route_get(self, con, acc, user, puuid, path, q):
            if path == "/":
                return self._send(p_home(con, puuid))
            if path == "/campeoes":
                return self._send(p_champs(con, puuid, (q.get("r") or [""])[0]))
            if path.startswith("/campeao/"):
                res = p_champ(con, puuid, urllib.parse.unquote(path.split("/", 2)[2]))
                return self._send(*res) if isinstance(res, tuple) else self._send(res)
            if path == "/coach":
                left = max(0, coachbot.DAILY_LIMIT - coachbot.used_today(con))
                pre = (q.get("q") or [""])[0][:200]
                body = coachbot.page_body(coachbot.history(con), bool(self._ai_key()), CTX.get("csrf"), left, _coach_side(con, puuid))
                if pre:
                    body += f"<script>(function(){{var q=document.getElementById('q');if(q){{q.value={json.dumps(pre)};q.focus()}}}})();</script>"
                return self._send(page("Coach IA", body))
            if path == "/perfil":
                return self._send(p_profile(con, acc, user, puuid, _flash(q)[1] if _flash(q)[0] == 'ok' else ''))
            if path == "/sincronizar":
                return self._send(p_data(con, puuid))
            if path == "/partidas":
                return self._send(p_games(con, puuid))
            if path.startswith("/partida/"):
                return self._send(p_postgame(con, puuid, path.split("/")[2]))
            if path.startswith("/revisao/"):
                return self._send(p_review(con, puuid, path.split("/")[2]))
            if path in ("/duelos", "/tierlist", "/patch"):
                try:
                    userdata.import_top(ddir, con)
                except Exception:
                    pass
            if path == "/duelos":
                return self._send(p_duel(con, puuid, (q.get("a") or [""])[0].strip(), (q.get("b") or [""])[0].strip()))
            if path == "/tierlist":
                return self._send(p_tierlist(con, puuid, (q.get("pos") or [""])[0]))
            if path == "/calendario":
                try:
                    champs_ = _dd().champions()
                except Exception:
                    champs_ = {}
                return self._send(page("Calendário de partidas", pages4.calendar_full(
                    con, report.my_games(con, puuid, ""), (q.get("vista") or ["dia"])[0], (q.get("c") or [""])[0], (q.get("fila") or [""])[0], champs_)))
            if path == "/pdl":
                per_ = (q.get("periodo") or ["tudo"])[0]
                try:
                    de_, ate_ = int((q.get("de") or ["0"])[0]), int((q.get("ate") or ["0"])[0])
                except ValueError:
                    de_ = ate_ = 0
                return self._send(p_pdl(con, puuid, per_ if per_ in ("7", "30", "90", "temporada", "tudo") else "tudo", de_ or None, ate_ or None))
            if path == "/selecao/opcoes":          # pedaco de pagina: todas as opcoes de build (seleção de campeões)
                from . import builds, champpage
                cid_ = (q.get("c") or [""])[0]
                pos_ = (q.get("p") or ["MIDDLE"])[0]
                try:
                    dd_ = _dd()
                    data_ = dd_.champion(cid_)
                    userdata.import_top(CTX["ddir"], con)
                    from . import profile as _pf
                    rows_ = builds.top_rows(con, cid_, _pf.resolve_pos(pos_, cid_))
                    html_ = statsui.build_explorer(con, rows_, dd_, data_) if rows_ else None
                    if html_:
                        try:
                            html_ += statsui.rune_options(con, rows_, dd_)
                        except Exception:
                            pass
                        sk_ = champview.skill_order(con, rows_)
                        html_ += champpage.skill_grid(sk_, data_, dd_.version()) if sk_ else ""
                    html_ = html_ or "<p class='n'>Ainda sem partidas dos melhores com este campeão nesta rota.</p>"
                except Exception as ex:
                    html_ = f"<p class='n'>Não deu para carregar ({e(type(ex).__name__)}).</p>"
                return self._send(html_.replace(statsui.BX_JS, ""))
            if path == "/graficos":
                from . import graficos
                fila_ = (q.get("fila") or ["solo"])[0]
                per_ = (q.get("periodo") or ["90"])[0]
                return self._send(page("Gráficos", graficos.page_html(con, puuid, CTX["ddir"], icons.champ, CTX.get("link"),
                                                                    fila_ if fila_ in ("solo", "todas") else "solo", per_ if per_ in ("30", "90", "180", "tudo") else "90")))
            if path in ("/hoje", "/dia"):
                from . import dia
                return self._send(page("Resumo do dia", dia.page_html(con, puuid, icons.champ, (q.get("d") or [None])[0])))
            if path in ("/desempenho", "/melhorar"):
                return self._send(p_desempenho(con, puuid, (q.get("modo") or ["solo"])[0]))
            if path == "/aprender":
                return self._redirect("/campeoes")
            if path == "/patch":
                return self._send(p_patch(con, puuid, bool(q.get("tudo"))))
            if path == "/selva":
                try:
                    userdata.import_top(ddir, con)
                except Exception:
                    pass
                return self._send(p_jungle(con, puuid, (q.get("c") or [""])[0].strip()))
            if path == "/erros":
                return self._redirect("/diagnostico#erros")
            if path == "/modelo":
                from . import modelo
                c_, o_, p_ = (q.get("c") or [""])[0], (q.get("o") or [""])[0], (q.get("p") or [""])[0] or None
                try:
                    userdata.import_top(ddir, con)
                except Exception:
                    pass
                try:
                    items_ = _dd().items()
                except Exception:
                    items_ = {}
                from . import profile as _pf
                return self._send(page(f"Partida modelo: {c_} contra {o_}",
                                       modelo.page_html(con, puuid, c_, o_, p_ or _pf.position(), items_)))
            if path == "/launcher":
                return self._send(_launcher_page(con, puuid, user, (q.get("m") or [None])[0]))
            if path == "/status":
                return self._send(page("Status dos serviços", _safe(lambda: extras.status_html(extras.status_checks(ddir)))
                                       + "<p><a class='btn' href='/reportar'>Reportar um problema</a></p>"))
            if path == "/reportar":
                from . import saude
                ult = saude.ultimas(10)
                from . import mais
                hist = mais.uso_html() + ("<div class='card'><b class='gl'>Saúde do app</b>" + ("".join(f"<p class='n' style='font-size:13px'>{e(x)}</p>" for x in ult)
                        if ult else "<p class='n'>Nenhum problema registrado: o overlay não fechou nem travou.</p>") + "</div>")
                return self._send(page("Reportar um problema", (
                    "<p><a class='btn ghost' href='/status' style='width:auto'>Ver o status dos serviços (Riot, imagens, IA, voz)</a></p>"
                    "<div class='card'><p>Conte o que aconteceu (o que você estava fazendo e o que esperava). O Carry junta os diários dele "
                    "<b>sem chaves, senhas nem as suas partidas</b> num arquivo .zip. Mande esse arquivo para quem cuida do app.</p>"
                    "<form method='post' action='/reportar'><textarea name='desc' rows='5' style='width:100%' "
                    "placeholder='Ex.: no meio da partida o balão sumiu por uns 2 minutos e depois voltou'></textarea>"
                    "<div class='row' style='margin-top:8px'><button class='btn gold' style='width:auto'>Gerar o arquivo do problema</button></div></form></div>" + hist)))
            if path == "/semana":
                from . import semana
                from . import evolucao2
                from . import mais
                gs_ = report.my_games(con, puuid, "")
                def _carta():
                    now_ = time.time() * 1000
                    wk = [g for g in gs_ if (g.get("started_ms") or 0) >= now_ - 7 * 86400000]
                    pv = [g for g in gs_ if now_ - 14 * 86400000 <= (g.get("started_ms") or 0) < now_ - 7 * 86400000]
                    t_ = extras.weekly_letter(wk, pv, (CTX["link"]["riot_id"] or "Você").split("#")[0] if CTX.get("link") else "Você")
                    return f"<div class='card cbox'><h3>Carta do coach da semana</h3><p>{e(t_)}</p></div>" if t_ else ""
                return self._send(page("Resumo da semana", _safe(_carta) + semana.html_page(semana.build(con, puuid))
                                       + evolucao2.season_card(gs_) + _safe(lambda: mais.janela_html(gs_))))
            if path == "/treino":
                from . import mais
                try:
                    userdata.import_top(ddir, con)
                except Exception:
                    pass
                return self._send(page("Treino de decisão", "<p class='n'>Uma situação real de uma partida sua. Escolha o que faria e compare com o que os melhores fazem nesse minuto.</p>"
                                       + _safe(lambda: mais.treino_html(mais.treino_situacao(con, puuid)))))
            if path == "/exercicios":
                from . import mais
                return self._send(page("Exercícios do modo de treino", mais.exercicios_html()))
            if path == "/derrotas":
                from . import derrotas
                return self._send(page("Derrotas: quanto está na sua mão",
                                       "<p class='n'>Pelo placar final de cada jogador das suas partidas (15 min ou mais). "
                                       "Responde a pergunta de sempre: foi o time ou fui eu?</p>" + derrotas.html_card(derrotas.breakdown(con, puuid))
                                       + derrotas.jungler_card(con, puuid)
                                       + _fatigue_html(con, puuid) + _safe(lambda: _mais().duo_card(con, puuid))))
            if path == "/rotas":
                try:
                    userdata.import_top(ddir, con)
                except Exception:
                    pass
                try:
                    champs_ = _dd().champions()
                except Exception:
                    champs_ = {}
                r_ = (q.get("r") or [""])[0] or profile.position()
                jg_ = ("<a class='card' href='/selva' style='display:flex;align-items:center;justify-content:space-between;gap:12px;text-decoration:none;margin-bottom:14px;"
                       "border-color:rgba(233,196,106,.45)'><span><b class='gl'>Modo caçador</b><br><span class='n'>Rota de acampamentos, ganks, caranguejo e objetivos para o seu caçador.</span></span>"
                       "<span class='btn gold' style='width:auto'>Abrir</span></a>") if r_ == "JUNGLE" else ""
                return self._send(page("Rotas", jg_ + lanes.page_html(report.my_games(con, puuid, ""), r_, lambda p_: pages4.tier_rows(con, p_), champs_)))
            if path == "/iniciante":
                lvk = accounts.pref(acc, user["id"], "nivel", None)
                if not lvk:
                    return self._send(page("Aprender a jogar", learn.quiz_html()))
                try:
                    done = set(json.loads(accounts.pref(acc, user["id"], "aulas", "[]") or "[]"))
                except ValueError:
                    done = set()
                return self._send(page("Aprender a jogar", learn.page_html(lvk, int(accounts.pref(acc, user["id"], "nivel_pts", "0") or 0), done,
                                                                           accounts.pref(acc, user["id"], "novato_voz", "0") == "1")))
            if path == "/estatisticas":
                try:
                    champs_ = _dd().champions()
                except Exception:
                    champs_ = {}
                gs_ = report.my_games(con, puuid, "")
                xb_ = _safe(lambda: extras.best_html(extras.best_games(gs_))) + _safe(lambda: extras.types_html(extras.by_opp_type(gs_, champs_), extras.by_ally_jungler_type(con, puuid)))
                return self._send(page("Estatísticas por campeão", champstats.page_html(con, gs_, champs_) + xb_))
            if path == "/padroes":
                return self._redirect("/diagnostico#padroes")
            if path == "/matchups":
                op_ = (q.get("op") or [None])[0]
                if not op_ and (q.get("ver") or [""])[0] == "grade":
                    from . import evolucao2
                    try:
                        champs_ = _dd().champions()
                    except Exception:
                        champs_ = {}
                    from . import mais
                    try:
                        seg_ = mais.segundo_html(mais.segundo_campeao(con, puuid, profile.position(), champs_), champs_)
                    except Exception:
                        seg_ = ""
                    return self._send(page("Seus confrontos", evolucao2.matchups_page(con, puuid, profile.position(), champs_) + seg_))
                return self._send(p_matchups(con, puuid, op_, (q.get("ordem") or ["melhor"])[0]))
            if path == "/topo":
                try:
                    userdata.import_top(ddir, con)
                except Exception:
                    pass
                if (q.get("modo") or ["elo"])[0] == "elo" and not q.get("c"):
                    return self._send(p_elo(con, puuid, (q.get("t") or [None])[0]))
                return self._send(p_top(con, puuid, (q.get("c") or [None])[0]))
            if path == "/habitos":
                return self._send(p_habits(con, puuid))
            if path == "/diagnostico":
                return self._send(p_analise(con, puuid))
            if path in ("/selecao", "/aovivo"):
                return self._redirect("/jogo")
            if path == "/overlay":
                from . import overlay, overlayui
                if not self._is_local():
                    return self._send(page("Editar overlay", authview.companion_body()))
                mc = (CTX.get("link") or {})
                mc = mc["main_champ"] if mc and "main_champ" in mc.keys() else None
                return self._send(page("Editar overlay", overlayui.body(overlay.ui_settings(), overlay.running(), premium.accent(mc), icons.version(),
                                                                   next((int(os.path.getmtime(x)) for x in (OVERLAY_BG + ".jpg", OVERLAY_BG + ".png") if os.path.exists(x)), None),
                                                                   CTX.get("csrf"))))
            if path == "/jogo":
                if not self._is_local():
                    return self._send(page("Partida", authview.companion_body()))
                return self._send(p_game(con, puuid, user["id"]))
            return self._send(page("Não encontrado", "<p>Página inexistente.</p>"), 404)

        @staticmethod
        def _run_analysis(upath, puuid, mid, key, model, log):
            c = db.connect(upath)
            try:
                analysis.generate(c, puuid, mid, key, model)
                log("Análise pronta.")
            except RuntimeError as ex:
                raise jobs.RiotError(str(ex))
            finally:
                c.close()

        def _back_to(self, default):
            ref = urllib.parse.urlparse(self.headers.get("Referer") or "")
            path_ = ref.path or ""
            return path_ if path_.startswith("/") and not path_.startswith("//") else default

        def _ai_key(self):
            return ai.pick(cfg.load())[0]

        def _coach_post(self, acc, raw):
            j = lambda d, code=200: self._send(json.dumps(d, ensure_ascii=False), code, ctype="application/json; charset=utf-8")
            user, sess = accounts.session_user(acc, self._cookie(COOKIE))
            if not user or user["status"] != "active":
                return j({"error": "Entre de novo."}, 401)
            if not accounts.check_csrf(sess, self.headers.get("X-CSRF") or ""):
                return j({"error": "A página ficou velha. Recarregue."}, 403)
            self._setup(acc, user, sess)
            if not CTX.get("puuid"):
                return j({"error": "Vincule a sua conta do LoL primeiro."}, 400)
            key = self._ai_key()
            if not key:
                return j({"error": "O coach IA ainda não está ligado: coloque a chave do Gemini (grátis) em Administração."}, 400)
            try:
                msg = (json.loads(raw.decode("utf-8")).get("msg") or "").strip()[:1200]
            except ValueError:
                msg = ""
            if not msg:
                return j({"error": "Escreva uma pergunta."}, 400)
            con = self._user_con(acc, user)
            try:
                profile.set_for(con, CTX["puuid"])
                if coachbot.used_today(con) >= coachbot.DAILY_LIMIT:
                    return j({"error": f"Limite de {coachbot.DAILY_LIMIT} perguntas por dia atingido. Volte amanhã."}, 429)
                link = CTX["link"]
                tg = None
                try:
                    tg = tiers.games(ddir, tiers.next_tier(link["tier"], user["goal"]), profile.position()) or None
                except Exception:
                    tg = None
                try:
                    reply = coachbot.ask(con, CTX["puuid"], link, key, cfg.load().get("anthropic_model") or coachbot.DEFAULT_MODEL, msg, tg)
                except RuntimeError as ex:
                    return j({"error": str(ex)}, 502)
                accounts.audit(acc, "coach_ia", user["id"], detail=f"{len(msg)} caracteres", ip=self._ip())
                return j({"html": coachbot.render(reply)})
            finally:
                con.close()

        def _overlay_voice(self, acc, q):
            from . import overlay
            if not self._is_local() or not hmac.compare_digest((q.get("t") or [""])[0], overlay.TOKEN):
                return self._send("", 403, ctype="text/plain")
            uid = overlay.STATE.get("owner")
            c = cfg.load()
            if not uid or not voice.configured(c) or accounts.pref(acc, uid, "voz_on", "1") != "1":
                return self._send("", 204, ctype="text/plain")
            try:
                txt_ = (q.get("txt") or [""])[0]
                vz = accounts.pref(acc, uid, "voz", "")
                vu = accounts.pref(acc, uid, "voz_urgente", "")
                if vu and extras.urgent_text(txt_):          # voz diferente para o que e urgente (ideia 91)
                    vz = vu
                wav = voice.say(ddir, c, vz, txt_)
            except Exception as ex:
                return self._send(str(ex), 502, ctype="text/plain; charset=utf-8")
            return self._send(wav, ctype=voice.audio_type(wav))

        def _overlay_bg_upload(self, length):
            """Print do jogo do proprio jogador como fundo da previa do overlay (so neste PC)."""
            j = lambda d, code=200: self._send(json.dumps(d, ensure_ascii=False), code, ctype="application/json; charset=utf-8")
            acc = accounts.connect(ddir)
            try:
                user, sess = accounts.session_user(acc, self._cookie(COOKIE))
                if not user or not accounts.check_csrf(sess, self.headers.get("X-CSRF") or ""):
                    return j({"erro": "Recarregue a página."}, 403)
            finally:
                acc.close()
            if not self._is_local():
                return j({"erro": "só no PC do app"}, 403)
            if length <= 0:
                for x in (OVERLAY_BG + ".jpg", OVERLAY_BG + ".png"):
                    if os.path.exists(x):
                        os.remove(x)
                return j({"ok": True})
            if length > 15_000_000:
                return j({"erro": "imagem grande demais (máximo 15 MB)"}, 400)
            data = self.rfile.read(length)
            ext = ".png" if data[:8] == b"\x89PNG\r\n\x1a\n" else ".jpg" if data[:3] == b"\xff\xd8\xff" else None
            if not ext:
                return j({"erro": "use um print em PNG ou JPG"}, 400)
            for x in (OVERLAY_BG + ".jpg", OVERLAY_BG + ".png"):
                if os.path.exists(x):
                    os.remove(x)
            with open(OVERLAY_BG + ext, "wb") as fh:
                fh.write(data)
            return j({"ok": True})

        def _mic_api(self, length):
            """Teste do microfone pelo Editar overlay: a pagina pede, o overlay grava 3 s e manda; o app mede o volume e transcreve."""
            from . import overlay
            j = lambda d, code=200: self._send(json.dumps(d, ensure_ascii=False), code, ctype="application/json; charset=utf-8")
            path_ = urllib.parse.urlparse(self.path).path
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if not self._is_local():
                return j({"erro": "proibido"}, 403)
            if path_.startswith("/api/"):
                if not hmac.compare_digest((q.get("t") or [""])[0], overlay.TOKEN) or length > 6_000_000:
                    return j({"erro": "proibido"}, 403)
                body = self.rfile.read(length) if length > 0 else b""
                if path_ == "/api/overlay/mics":
                    try:
                        overlay.STATE["mics"] = [str(x)[:80] for x in json.loads(body.decode("utf-8"))][:16]
                    except ValueError:
                        pass
                    return j({"ok": True})
                mt = overlay.STATE.get("mictest") or {}
                lvl = voice.wav_level(body) if body else None
                res = {"state": "pronto", "level": round((lvl or 0) * 100, 1), "text": "", "mic": (q.get("mic") or [""])[0][:80]}
                if lvl is not None and lvl >= 0.003:
                    gk = voice.gm_key(cfg.load())
                    if gk:
                        try:
                            res["text"] = voice.gm_stt(gk, body)
                        except Exception as ex:
                            res["text"] = f"(não transcreveu: {str(ex)[:80]})"
                mt.update(res)
                overlay.STATE["mictest"] = mt
                return j({"ok": True, **res})
            acc = accounts.connect(ddir)
            try:
                user, sess = accounts.session_user(acc, self._cookie(COOKIE))
                if not user or not accounts.check_csrf(sess, self.headers.get("X-CSRF") or ""):
                    return j({"erro": "Recarregue a página."}, 403)
            finally:
                acc.close()
            if path_ == "/overlay/microfone/testar":
                if not overlay.running():
                    return j({"erro": "Ligue o overlay primeiro (botão Ligar overlay no topo da página)."})
                overlay.STATE["mictest"] = {"id": time.time(), "state": "pedido"}
                return j({"ok": True})
            mt = dict(overlay.STATE.get("mictest") or {})
            if mt.get("state") == "pedido" and time.time() - mt.get("id", 0) > 25:
                mt = {"state": "sem_resposta"}
            return j({**mt, "mics": overlay.STATE.get("mics") or []})

        def _overlay_question(self, length):
            """Pergunta falada no jogo: audio -> texto (ElevenLabs) -> resposta curta da IA com o placar -> o overlay fala."""
            from . import overlay, live
            j = lambda d, code=200: self._send(json.dumps(d, ensure_ascii=False), code, ctype="application/json; charset=utf-8")
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if not self._is_local() or not hmac.compare_digest((q.get("t") or [""])[0], overlay.TOKEN):
                return j({"erro": "proibido"}, 403)
            if length <= 0 or length > 6_000_000:
                return j({"erro": "áudio vazio ou grande demais"}, 400)
            wav = self.rfile.read(length)
            c = cfg.load()
            el, _ = voice.keys(c)
            gk = voice.gm_key(c)
            ai_key = ai.pick(c)[0]
            if not ai_key:
                return j({"erro": "o Coach IA ainda não tem chave. Coloque a do Gemini (grátis) em Administração"})
            lvl = voice.wav_level(wav)
            if lvl is not None and lvl < 0.003:
                return j({"erro": "não chegou som do microfone. Confira o microfone padrão do Windows (Configurações > Sistema > Som > Entrada) e se ele não está mudo"})
            text, err = "", None
            data0 = live.fetch()
            ctx = {p.get("championName") or "" for p in (data0 or {}).get("allPlayers") or []} - {""}
            sel_txt, all_names = "", []
            try:
                from .ddragon import DataDragon
                dd_ = DataDragon(cache_dir=os.path.join(ddir, "cache"))
                champs_ = dd_.champions()
                all_names = [v["name"] for v in champs_.values()]
                if not data0:                       # na selecao de campeoes: usa os campeoes de la
                    from . import champselect, lcu
                    cl_ = lcu.LCU.discover()
                    if cl_.gameflow_phase() == "ChampSelect":
                        sn = champselect.snapshot(cl_.champ_select_session(), dd_.champion_by_key()) or {}
                        nm_ = lambda k: (champs_.get(k) or {}).get("name") or k
                        meu = (sn.get("me") or {}).get("champion")
                        al_ = [nm_(p["champion"]) for p in sn.get("my_team") or [] if p.get("champion")]
                        en_ = [nm_(p["champion"]) for p in sn.get("enemy_team") or [] if p.get("champion")]
                        bans_ = [nm_(b) for b in (sn.get("my_bans") or []) + (sn.get("their_bans") or [])]
                        ctx |= set(al_ + en_ + bans_)
                        sel_txt = ("Seleção de campeões (a partida ainda não começou). "
                                   f"Meu campeão: {nm_(meu) if meu else 'ainda não escolhi'}"
                                   + (f" ({(sn.get('me') or {}).get('position')})" if (sn.get('me') or {}).get('position') else "")
                                   + f". Meu time: {', '.join(al_) or '-'}. Inimigos: {', '.join(en_) or 'ainda escondidos'}. "
                                   + (f"Banidos: {', '.join(bans_)}." if bans_ else ""))
            except Exception:
                pass
            hint = ", ".join(sorted(ctx))
            # 1) ElevenLabs (entende melhor portugues), se a chave tiver permissao e credito; 2) Gemini (gratis, a mesma chave da IA)
            el_ok = el and not voice.el_out_of_credits(ddir) and not os.path.exists(os.path.join(ddir, "cache", "el_sem_stt.txt"))
            if el_ok:
                try:
                    text = voice.el_stt(el, wav)
                except Exception as ex:
                    m_ = str(ex)
                    if "quota" in m_.lower() or "credits" in m_.lower():
                        voice._mark_out_of_credits(ddir)
                    if "permission" in m_.lower() or "(401)" in m_:
                        try:
                            open(os.path.join(ddir, "cache", "el_sem_stt.txt"), "w").write("1")
                        except OSError:
                            pass
                    text = ""
            if not text and gk:
                try:
                    text = voice.gm_stt(gk, wav, hint)
                except Exception as ex:
                    err = str(ex)
            if not text and el and not el_ok and not voice.el_out_of_credits(ddir) and not os.path.exists(os.path.join(ddir, "cache", "el_sem_stt.txt")):
                try:
                    text = voice.el_stt(el, wav)
                except Exception as ex:
                    m = str(ex)
                    if "quota" in m.lower() or "credits" in m.lower():
                        voice._mark_out_of_credits(ddir)
                    if "permission" in m.lower() or "(401)" in m:      # chave sem permissao de transcrever: nao tenta mais
                        try:
                            open(os.path.join(ddir, "cache", "el_sem_stt.txt"), "w").write("1")
                        except OSError:
                            pass
                    else:
                        err = err or m
            if not text and not gk and not el:
                return j({"erro": "para entender a pergunta falada, coloque a chave do Gemini (grátis) em Administração"})
            if not text and err:
                return j({"erro": err[:200]})
            if not text:
                return j({"erro": "não entendi a pergunta, tente de novo falando perto do microfone"})
            try:
                text = voice.fix_champs(text, ctx, all_names)
            except Exception:
                pass
            data = live.fetch()
            if data:          # "Zed usou flash", "o mid sem ult": marca o tempo em vez de perguntar para a IA
                try:
                    from . import spelltimers
                    me_ = live._find_me(data)
                    hit = spelltimers.parse_spoken(text, data, me_)
                    if hit:
                        ans = spelltimers.mark(data, me_, hit[0], hit[1], ddir, hit[2])
                        if ans:
                            return j({"q": text, "a": ans})
                except Exception:
                    pass
            items = {}
            try:
                from .ddragon import DataDragon
                items = DataDragon(cache_dir=os.path.join(ddir, "cache")).items()
            except Exception:
                pass
            snap = overlay.live_snapshot(data, items, ddir) if data else (sel_txt or "Fora de partida.")
            try:
                ans = coachbot.ask_live(ai_key, None, text, snap)
            except Exception as ex:
                return j({"q": text, "erro": str(ex)[:200]})
            return j({"q": text, "a": ans or "Não consegui responder agora."})

        def _postgame_voice(self, con, puuid, data, d):
            """Guarda o ultimo retrato do placar e, quando a partida acaba, fala um resumo de 20 s."""
            from . import live, overlay, voicecues
            lg = overlay.STATE.get("lastgame")
            if data:
                me = live._find_me(data) or {}
                gt = (data.get("gameData") or {}).get("gameTime") or 0
                if gt < 300:            # remake ou partida que nem comecou: sem resumo falado
                    return
                sc = me.get("scores") or {}
                ev = (data.get("events") or {}).get("Events") or []
                nm = live._name(me)
                res = next((x.get("Result") for x in ev if x.get("EventName") == "GameEnd"), None)
                key = int(time.time() - gt) // 30
                spoken = bool(lg and lg.get("spoken") and abs(lg.get("key", 0) - key) <= 1)
                lg = overlay.STATE["lastgame"] = {
                    "k": int(sc.get("kills") or 0), "d": int(sc.get("deaths") or 0), "a": int(sc.get("assists") or 0),
                    "cs": int(sc.get("creepScore") or 0), "ward": float(sc.get("wardScore") or 0), "gt": gt, "result": res,
                    "d10": sum(1 for x in ev if x.get("EventName") == "ChampionKill" and x.get("VictimName") == nm and (x.get("EventTime") or 0) < 600),
                    "seen": time.time(), "spoken": spoken, "key": key}
                if not res:          # partida rolando: so guarda; com o fim (nexus caiu), fala o resumo ja
                    return
            if lg and not lg.get("spoken") and time.time() - lg["seen"] < 600 and not d.get("loading"):
                lg["spoken"] = True
                try:
                    lg["avg_cspm"] = voicecues.profile_stats(con, puuid).get("cspm")
                except Exception:
                    pass
                from . import postmore
                txt = postmore.spoken_summary(lg)
                if txt:
                    d["speak"] = (d.get("speak") or []) + [{"k": f"post_{lg['key']}", "t": "Resumo · " + txt, "v": txt}]

        def _guide_soon(self, cid, dd):
            """Campeao travado sem guia por IA: gera em segundo plano (as dicas do campeao no jogo usam o guia)."""
            import threading
            if not cid or cid in _GUIDE_TRIED:
                return
            _GUIDE_TRIED.add(cid)
            from . import guides, icons
            ver = icons.version() or ""
            if guides.get(ddir, cid, None):
                return
            cfgx = config_mod.Config(os.path.join(ddir, "coach.sqlite")).load()
            key, mdl = ai.pick(cfgx)
            if not key:
                return
            data = dd.champion(cid)
            threading.Thread(target=lambda: guides.generate(ddir, key, mdl or coachbot.DEFAULT_MODEL, cid, data, ver, lambda *a: None),
                             daemon=True).start()

        def _select_speak(self, con, puuid, lim=None):
            """Falas da selecao de campeoes (le o cliente; nada de jogo)."""
            from . import champselect, lcu, voicecues
            try:
                client = lcu.LCU.discover()
                ph = client.gameflow_phase()
                if ph not in ("InProgress", "GameStart", "Reconnect") and time.time() - _RANKSNAP.get(puuid, 0) > 30:
                    # foto do elo pelo cliente a cada 30 s fora de partida: com um ponto antes e outro depois de cada jogo,
                    # o PDL de cada partida e o real (inclusive PDL em dobro), nao uma estimativa
                    _RANKSNAP[puuid] = time.time()
                    try:
                        rs = client.ranked_solo()
                        if rs and rs.get("lp") is not None:
                            from . import ranks
                            ranks.record(con, rs["tier"], rs["division"], rs["lp"], rs["wins"], rs["losses"])
                    except Exception:
                        pass
                if ph == "ReadyCheck":           # aceitar a fila sozinho (opcao em Editar overlay, desligada por padrao)
                    try:
                        from . import overlay as _ov
                        if _ov.ui_settings().get("auto_aceitar", 0) and time.time() - _ACCEPTED.get("t", 0) > 8:
                            _ACCEPTED["t"] = time.time()
                            client.request("POST", "/lol-matchmaking/v1/ready-check/accept")
                    except Exception:
                        pass
                if ph in ("Lobby", "Matchmaking", "ReadyCheck"):
                    from . import pregame
                    out_ = pregame.lobby_cues(con, puuid, lim)
                    try:            # pausa a cada 2 h, sequencia boa e modo so uma (ideias 77, 78 e 80)
                        so_ = _SOUMA.get("dia") == time.strftime("%Y%m%d")
                        for k_, t_ in extras.routine_cues(con, puuid, pregame.today(con, puuid, lim), so_):
                            out_.append({"k": k_, "t": t_})
                    except Exception:
                        pass
                    return out_
                if ph != "ChampSelect":
                    return []
                from .ddragon import DataDragon
                dd = DataDragon(cache_dir=os.path.join(ddir, "cache"))
                snap = champselect.snapshot(client.champ_select_session(), dd.champion_by_key())
                try:
                    if snap and snap.get("skin") and (snap.get("me") or {}).get("champion"):
                        icons.save_skin(ddir, snap["me"]["champion"], snap["skin"])
                except Exception:
                    pass
                try:
                    items = dd.items()
                except Exception:
                    items = {}
                out = voicecues.select_cues(con, puuid, snap, dd.champions(), items, ddir)
                try:
                    from . import overlay as _ov, profile
                    if _ov.ui_settings().get("runas_auto", 1):
                        me_s = snap.get("me") or {}
                        pos_ = profile.resolve_pos(me_s.get("position"), me_s.get("champion"), me_s.get("spells"))
                        cue = champselect.auto_runes(con, client, snap, dd, pos_)
                        self._guide_soon((snap.get("me") or {}).get("champion"), dd)
                        if cue:
                            out.append(cue)
                except Exception as ex:
                    try:
                        from . import overlay as _ov
                        _ov.log(f"runas automáticas: {type(ex).__name__}: {ex}")
                    except Exception:
                        pass
                return out
            except Exception:
                return []

        def _overlay_json(self, acc, q):
            from .ddragon import NOFETCH
            NOFETCH.on = True          # o overlay nunca espera download (a tela da selecao e o aquecimento baixam)
            try:
                return self._overlay_json2(acc, q)
            finally:
                NOFETCH.on = False

        def _overlay_json2(self, acc, q):
            from . import live, overlay
            j = lambda d, code=200: self._send(json.dumps(d, ensure_ascii=False), code, ctype="application/json; charset=utf-8")
            if not self._is_local() or not hmac.compare_digest((q.get("t") or [""])[0], overlay.TOKEN):
                return j({"error": "proibido"}, 403)
            uid = overlay.STATE.get("owner")
            u = accounts.get_user(acc, uid) if uid else None
            link = accounts.link(acc, uid) if u else None
            if not u or not link or not link["verified_ms"]:
                return j({"in_game": False})
            self._setup(acc, u, None)
            con = self._user_con(acc, u)
            try:
                profile.set_for(con, link["puuid"])
                data = live.fetch()
                items = {}
                if data:
                    try:
                        from .ddragon import DataDragon
                        items = DataDragon(cache_dir=os.path.join(ddir, "cache")).items()
                    except Exception:
                        items = {}
                d = overlay.data_for(con, link["puuid"], data, items, _tags() if data else {}, None)
                if data and d.get("in_game"):
                    try:          # espiar os inimigos (elo, maestria, duo) uma vez por partida, em segundo plano
                        from . import scout
                        scout.ensure(cfg.riot_key(),
                                     link["region"] or "br1", data, ddir)
                        st_ = scout.get(data)
                        if st_ and st_["state"] == "pronto" and not st_.get("spoken"):
                            st_["spoken"] = True
                            txt_ = scout.speech(st_["rows"], d.get("pos"))
                            try:
                                hv = extras.history_vs(con, link["puuid"], st_["rows"])
                                if hv:
                                    txt_ = ((txt_ or "") + " " + " ".join(hv)).strip()
                            except Exception:
                                pass
                            if txt_:
                                d.setdefault("alerts", []).append({"k": f"scout_{int(st_['at'])}", "t": txt_})
                        if st_ and st_["state"] == "pronto" and not st_.get("jgside"):
                            jc = extras.jungle_side_cue(st_["rows"], d.get("pos"), (data.get("gameData") or {}).get("gameTime") or 0)
                            if jc:
                                st_["jgside"] = True
                                d.setdefault("alerts", []).append({"k": f"scout_jgside_{int(st_['at'])}", "t": jc})
                    except Exception:
                        pass
                try:
                    self._postgame_voice(con, link["puuid"], data, d)
                except Exception:
                    pass
                d["voice"] = voice.configured(cfg.load()) and accounts.pref(acc, uid, "voz_on", "1") == "1"
                if not d.get("in_game") and time.time() < overlay.STATE.get("demo_until", 0):
                    try:
                        from .ddragon import DataDragon
                        items = items or DataDragon(cache_dir=os.path.join(ddir, "cache")).items()
                    except Exception:
                        pass
                    d = overlay.demo_data(items)
                    d["ver"] = icons.version()
                    d["voice"] = (time.time() < overlay.STATE.get("demo_voice", 0) and voice.configured(cfg.load())
                                  and accounts.pref(acc, uid, "voz_on", "1") == "1")
                if not d.get("in_game") and not d.get("demo"):
                    d["speak"] = (d.get("speak") or []) + ([] if d.get("loading") else self._select_speak(con, link["puuid"], accounts.pref(acc, uid, "limite_dia", None)))
                if data and d.get("in_game") and accounts.pref(acc, uid, "novato_voz", "0") == "1":
                    try:
                        me_ = live._find_me(data) or {}
                        d["alerts"] = (d.get("alerts") or []) + learn.live_cues(data, me_, (data.get("gameData") or {}).get("gameTime") or 0)
                    except Exception:
                        pass
                if accounts.pref(acc, uid, "voz_tom", "serio") == "divertido":
                    from . import voicecues
                    for lst in (d.get("alerts") or [], d.get("speak") or []):
                        for a_ in lst:
                            a_["v"] = voicecues.fun(a_.get("v") or a_["t"], a_["k"])
                if d.get("champion") and d.get("in_game") and not d.get("demo"):
                    try:
                        from . import liveview
                        overlay.STATE["cur_champ"] = liveview.champ_id(live._find_me(data)) if data else None
                        overlay.STATE["cur_at"] = time.time()
                    except Exception:
                        pass
                sy = overlay.STATE.get("say")
                if sy and time.time() - sy["id"] < 20:
                    d["say"] = sy
                mt = overlay.STATE.get("mictest")
                if mt and mt.get("state") == "pedido" and time.time() - mt["id"] < 20:
                    d["mictest"] = mt["id"]
                ui = overlay.ui_settings()
                ui["ac"] = premium.accent(link["main_champ"] if "main_champ" in link.keys() else None)
                if ui.get("accent") == "game" and d.get("champion"):
                    from . import liveview
                    try:
                        ui["ac"] = premium.accent(liveview.champ_id(live._find_me(data))) if data else ui["ac"]
                    except Exception:
                        pass
                d["ui"] = ui
                return j(d)
            except Exception as ex:
                return j({"in_game": False, "error": str(ex)[:200]})
            finally:
                con.close()

        def _upload_video(self, length):
            """Recebe um video do usuario (multipart simples, sem bibliotecas) e vira o fundo dele."""
            acc = accounts.connect(ddir)
            try:
                user, sess = accounts.session_user(acc, self._cookie(COOKIE))
                if not user or user["status"] != "active":
                    return self._redirect("/entrar")
                if length > 80 * 1024 * 1024:
                    return self._send(page("Fundo", "<div class='alert err'>Vídeo grande demais (máximo 80 MB).</div><p><a class='btn' href='/conta'>Voltar</a></p>"), 413)
                ct = self.headers.get("Content-Type") or ""
                m = re.search(r"boundary=(?:\"([^\"]+)\"|([^;]+))", ct)
                if not m:
                    return self._send("formato inválido", 400, ctype="text/plain; charset=utf-8")
                data = self.rfile.read(length)
                bnd = ("--" + (m.group(1) or m.group(2)).strip()).encode()
                csrf_ok, video, ext = False, None, None
                for part in data.split(bnd):
                    if b"\r\n\r\n" not in part:
                        continue
                    head, body = part.split(b"\r\n\r\n", 1)
                    body = body[:-2] if body.endswith(b"\r\n") else body
                    h = head.decode("utf-8", "replace")
                    if 'name="csrf"' in h:
                        csrf_ok = accounts.check_csrf(sess, body.decode("utf-8", "replace").strip())
                    elif 'name="video"' in h:
                        fn = re.search(r'filename="([^"]*)"', h)
                        name = (fn.group(1) if fn else "").lower()
                        ext = ".webm" if name.endswith(".webm") or body[:4] == b"\x1a\x45\xdf\xa3" else ".mp4"
                        if body[4:8] == b"ftyp" or body[:4] == b"\x1a\x45\xdf\xa3":  # confere o tipo pelo conteudo
                            video = body
                if not csrf_ok:
                    return self._redirect("/conta?m=csrf")
                if not video:
                    return self._send(page("Fundo", "<div class='alert err'>Não reconheci o arquivo como vídeo mp4 ou webm.</div><p><a class='btn' href='/conta'>Voltar</a></p>"), 400)
                for old in bg.local_videos(ddir):
                    if old.startswith(f"u{user['id']}_"):
                        try:
                            os.remove(os.path.join(bg.folder(ddir), old))
                        except OSError:
                            pass
                name = f"u{user['id']}_{secrets.token_hex(4)}{ext}"
                with open(os.path.join(bg.folder(ddir), name), "wb") as fh:
                    fh.write(video)
                accounts.set_pref(acc, user["id"], "bg_kind", "file")
                accounts.set_pref(acc, user["id"], "bg_value", name)
                return self._redirect("/conta?m=salvo")
            finally:
                acc.close()

        def _send_video(self, name):
            fp = os.path.join(bg.folder(ddir), name)
            if not name.lower().endswith(bg.VIDEO_EXT) or not os.path.isfile(fp):
                return self._send("", 404, ctype="text/plain")
            size = os.path.getsize(fp)
            ctype = "video/webm" if name.lower().endswith(".webm") else "video/mp4"
            rng = re.match(r"bytes=(\d*)-(\d*)", self.headers.get("Range") or "")
            start, end = 0, size - 1
            if rng:
                if rng.group(1):
                    start = int(rng.group(1))
                    end = int(rng.group(2)) if rng.group(2) else min(size - 1, start + 4 * 1024 * 1024 - 1)
                elif rng.group(2):
                    start = max(0, size - int(rng.group(2)))
            end = min(end, size - 1)
            with open(fp, "rb") as fh:
                fh.seek(start)
                chunk = fh.read(end - start + 1)
            self.send_response(206 if rng else 200)
            self.send_header("Content-Type", ctype)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(len(chunk)))
            if rng:
                self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            self.send_header("Cache-Control", "private, max-age=3600")
            self.end_headers()
            self.wfile.write(chunk)

        def _bg_card(self, acc, user, champ_q=None):
            from .ddragon import DataDragon
            link = CTX.get("link")
            champ = champ_q or (link["main_champ"] if link else None) or "Zed"
            dd = DataDragon(cache_dir=os.path.join(ddir, "cache"))
            try:
                names = dd.champions()
                by_lower = {k.lower(): k for k in names}
                by_name = {v["name"].lower(): k for k, v in names.items()}
                champ = by_lower.get(champ.lower()) or by_name.get(champ.lower()) or champ
                skins = dd.skins(champ)
            except Exception:
                skins, names = [], {}
            cur = (bg.BG.get("kind"), bg.BG.get("value"))
            ver_ok = bool(icons.version())
            grid = ""
            for num, nm in skins:
                val = f"{champ}:{num}"
                thumb = f"{icons.CDN}/cdn/img/champion/loading/{e(champ)}_{num}.jpg" if ver_ok else ""
                grid += (f"<form method='post' action='/conta/fundo' class='skin{' on' if cur == ('skin', val) else ''}'>"
                         f"<input type='hidden' name='kind' value='skin'><input type='hidden' name='value' value='{e(val)}'>"
                         f"<button style=\"--img:url('{thumb}');background-image:url('{thumb}')\" title='{e(nm)}' aria-label='{e(nm)}'></button><small>{e(nm)}</small></form>")
            vids = []
            vopts = "".join(f"<option value='{e(v)}'{' selected' if cur == ('file', v) else ''}>{e(v)}</option>" for v in vids)
            opts = "".join(f"<option value='{e(k)}'>" for k in sorted(names))
            prev = f"<div style=\"background-image:url('{icons.splash(champ)}')\"></div>" + (bg.art("", icons.splash(champ)) if bg.active() else "")
            return ("<h2>Fundo do app</h2><div class='card'><p class='n'>Escolha a arte que aparece no topo das telas. "
                    "Sem escolha, o app usa a arte do seu campeão principal (com movimento).</p>"
                    f"<div class='bgprev'>{prev}</div>"
                    "<form method='get' action='/conta' class='row'><input name='campeao' list='bgch' placeholder='Ver skins de outro campeão (ex.: Renekton)'>"
                    f"<datalist id='bgch'>{opts}</datalist><button class='btn ghost'>Ver skins</button></form>"
                    f"<b class='gl' style='display:block;margin-top:14px'>Skins de {e(names.get(champ, {}).get('name', champ))}</b>"
                    f"<div class='skins'>{grid or '<p class=n>Não consegui carregar as skins agora.</p>'}</div>"
                    "<b class='gl' style='display:block;margin-top:18px'>Fundo animado</b>"
                    "<form method='post' action='/conta/fundo' class='row' style='flex-wrap:wrap'><input type='hidden' name='kind' value='youtube'>"
                    "<input name='value' placeholder='Link do YouTube (ex.: https://www.youtube.com/watch?v=...)' style='max-width:420px'>"
                    "<button>Usar vídeo do YouTube</button></form>"
                    "<form method='post' action='/conta/fundo/enviar' enctype='multipart/form-data' class='row' style='flex-wrap:wrap'>"
                    "<input type='file' name='video' accept='video/mp4,video/webm' required style='max-width:420px'>"
                    "<button>Enviar vídeo (mp4 ou webm, até 80 MB)</button></form>"
                    + "<form method='post' action='/conta/fundo' class='row' style='flex-wrap:wrap'><input type='hidden' name='kind' value='auto'>"
                    "<button class='btn gold'>Automático: o campeão que estou jogando</button><span class='n'>troca sozinho para a arte do campeão da partida (ou da última partida)</span></form>"
                    "<form method='post' action='/conta/fundo' class='row'><input type='hidden' name='kind' value=''>"
                    "<button class='btn ghost'>Voltar ao padrão (meu main)</button></form></div>")

        def _send_export(self, acc, user):
            u = {k: user[k] for k in user.keys() if k != "pass_hash"}
            link = accounts.link(acc, user["id"])
            data = {"conta": u, "conta_do_lol": dict(link) if link else None,
                    "auditoria": [dict(r) for r in acc.execute("SELECT at_ms, action, detail, ip FROM audit WHERE user_id=? ORDER BY id DESC LIMIT 500", (user["id"],))]}
            body = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
            return self._send(body, ctype="application/json; charset=utf-8",
                              extra_headers={"Content-Disposition": "attachment; filename=meus-dados-lol-coach.json"})

        def _admin_page(self, acc, me, notice="", secret=None):
            users = accounts.list_users(acc)
            audit_rows = acc.execute("SELECT * FROM audit ORDER BY id DESC LIMIT 60").fetchall()
            k = self._ai_key()
            c_ = cfg.load()
            gk_on = bool((c_.get("gemini_api_key") or "").strip())
            ak_on = bool((c_.get("anthropic_api_key") or "").strip())
            prov = "Gemini (Google, grátis)" if ai.is_gemini(k) else ("Claude (Anthropic)" if k else "nenhum")
            el_on, az_on = (bool(x) for x in voice.keys(c_))
            pill = lambda ok, yes="ok", no="sem chave": f"<span class='kpill {'on' if ok else 'off'}'>{yes if ok else no}</span>"

            def krow(name, status, form, help_html, opt=False):
                return (f"<div class='krow'><div class='kname'><b>{name}</b>{' <small>opcional</small>' if opt else ''}{status}</div>"
                        f"<div class='kform'>{form}</div><details class='khelp'><summary>Como pegar?</summary>{help_html}</details></div>")
            riot_ok = bool(cfg.riot_key())
            keys = ("<h2>Chaves</h2><div class='card kbox'>"
                    + krow("Riot", pill(riot_ok, "salva", "falta") + f"<small class='kst'>{e(cfg.key_status())}</small>",
                           "<form method='post' action='/admin/chave' class='kf'><input type='password' name='key' autocomplete='off' placeholder='RGAPI-...'><button>Salvar</button></form>"
                           "<form method='post' action='/admin/testar' class='kf'><button class='btn ghost'>Testar</button></form>",
                           "<p>Entre em <a href='https://developer.riotgames.com/' target='_blank' rel='noopener noreferrer'>developer.riotgames.com</a>, faça login e clique em "
                           "<b>Regenerate API Key</b>. A chave de desenvolvimento vence a cada 24 horas: quando o app avisar, gere outra e cole aqui.</p>")
                    + krow("Coach IA (Gemini)", pill(gk_on) + f"<small class='kst'>em uso: {e(prov)}</small>",
                           "<form method='post' action='/admin/ia' class='kf'><input type='password' name='gkey' autocomplete='off' placeholder='AIza...'><button>Salvar</button></form>",
                           "<p>Grátis e sem cartão: entre em <a href='https://aistudio.google.com/app/apikey' target='_blank' rel='noopener noreferrer'>aistudio.google.com</a>, "
                           "clique em <b>Create API key</b> e cole aqui. Serve para a análise das partidas, o Coach IA e a pergunta falada no jogo.</p>")
                    + krow("Voz dos avisos", "<span class='kpill on'>grátis ativa</span><small class='kst'>Francisca/Antonio da Microsoft, sem chave</small>",
                           "<span class='n'>Escolha a voz em Partida ao vivo.</span>",
                           "<p>Não precisa de nada. Se quiser vozes ainda mais naturais, coloque uma chave da ElevenLabs abaixo (opcional).</p>")
                    + krow("ElevenLabs", pill(el_on),
                           "<form method='post' action='/admin/voz' class='kf'><input type='hidden' name='svc' value='el'><input type='password' name='key' autocomplete='off' placeholder='sk_...'><button>Salvar</button>"
                           + ("<button name='apagar' value='1' class='btn ghost'>Remover</button>" if el_on else "") + "</form>",
                           "<p>Em <a href='https://elevenlabs.io/app/developers/api-keys' target='_blank' rel='noopener noreferrer'>elevenlabs.io</a> &gt; Developers &gt; API Keys, crie uma chave "
                           "com permissão de <b>Text to Speech</b> e <b>Voices (leitura)</b>. O plano grátis tem cerca de 10 mil caracteres por mês; quando acaba, o app volta para a voz grátis.</p>", True)
                    + krow("Claude (Anthropic)", pill(ak_on),
                           "<form method='post' action='/admin/ia' class='kf'><input type='password' name='key' autocomplete='off' placeholder='sk-ant-...'><button>Salvar</button></form>",
                           "<p>Pago por uso, em <a href='https://platform.claude.com/' target='_blank' rel='noopener noreferrer'>platform.claude.com</a>. "
                           "Se ele falhar (sem crédito, chave recusada), o app usa o Gemini sozinho.</p>", True)
                    + "</div>")
            more = ("<details class='card kmore'><summary><b class='gl'>Mais opções</b> <span class='n'>IA preferida, Azure, base de alto elo, especialistas</span></summary>"
                    "<form method='post' action='/admin/ia' class='kf' style='margin-top:12px'><label class='n'>IA preferida</label>"
                    "<select name='prov' style='max-width:260px'><option value='gemini'" + (" selected" if (c_.get("ai_provider") or "gemini") == "gemini" else "") + ">Gemini (grátis)</option>"
                    "<option value='anthropic'" + (" selected" if c_.get("ai_provider") == "anthropic" else "") + ">Claude (pago)</option></select>"
                    f"<input name='model' value='{e(c_.get('anthropic_model') or coachbot.DEFAULT_MODEL)}' style='max-width:200px' title='Modelo do Claude'><button>Salvar</button></form>"
                    "<p class='n' style='margin-top:14px'><b>Microsoft Azure (opcional)</b>: chave do recurso Speech (Free F0).</p>"
                    "<form method='post' action='/admin/voz' class='kf'><input type='hidden' name='svc' value='az'><input type='password' name='key' autocomplete='off' placeholder='Chave 1 do recurso Speech'>"
                    f"<input name='region' value='{e(c_.get('azure_speech_region') or 'brazilsouth')}' style='max-width:160px' title='Região'><button>Salvar</button>"
                    + ("<button name='apagar' value='1' class='btn ghost'>Remover</button>" if az_on else "") + "</form>"
                    + "<p class='n' style='margin-top:14px'><b>Base geral de alto elo</b>: com o app aberto e a fila parada, ele baixa sozinho partidas dos melhores. "
                    + "Agora: {} partidas, {} campeões com 10 jogos ou mais.</p>".format(*jobs.general_status(ddir))
                    + "<form method='post' action='/admin/especialistas' class='kf'><button class='btn ghost'>Atualizar especialistas do servidor</button>"
                    "<span class='n'>quem mais joga cada campeão (uns 12 min)</span></form></details>")
            ia = more
            return page("Administração", authview.admin_body(acc, me, users, cfg.key_status(), bool(cfg.riot_key()),
                                                             jobs.MANAGER.overview(), audit_rows, accounts.signup_mode(acc), notice, secret).replace(
                "<!--CHAVES-->", keys, 1).replace("<h2>Usuários</h2>", ia + "<h2>Usuários</h2>", 1) + KEYS_CSS)

        # -- POST ----------------------------------------------------------
        def do_POST(self):
            if not self._ok_host():
                return self._send("host invalido", 403, ctype="text/plain; charset=utf-8")
            origin = self.headers.get("Origin")
            if origin and origin != "null" and (urllib.parse.urlparse(origin).hostname or "").lower() not in allowed_hosts:
                return self._send("origem invalida", 403, ctype="text/plain; charset=utf-8")
            length = int(self.headers.get("Content-Length") or 0)
            if urllib.parse.urlparse(self.path).path == "/conta/fundo/enviar":
                return self._upload_video(length)
            if urllib.parse.urlparse(self.path).path == "/api/overlay/pergunta":
                return self._overlay_question(length)
            if urllib.parse.urlparse(self.path).path in ("/api/overlay/mics", "/api/overlay/mictest", "/overlay/microfone/testar", "/overlay/microfone/estado"):
                return self._mic_api(length)
            if urllib.parse.urlparse(self.path).path == "/overlay/fundo/enviar":
                return self._overlay_bg_upload(length)
            if urllib.parse.urlparse(self.path).path == "/coach/enviar":
                if length > 20000:
                    return self._send("grande demais", 413, ctype="text/plain; charset=utf-8")
                acc = accounts.connect(ddir)
                try:
                    return self._coach_post(acc, self.rfile.read(length))
                finally:
                    acc.close()
            if length > 100000:
                return self._send("grande demais", 413, ctype="text/plain; charset=utf-8")
            form = urllib.parse.parse_qs(self.rfile.read(length).decode("utf-8", "replace"))
            val = lambda k: (form.get(k) or [""])[0]
            path = urllib.parse.urlparse(self.path).path
            acc = accounts.connect(ddir)
            try:
                user, sess = accounts.session_user(acc, self._cookie(COOKIE))
                self._setup(acc, user, sess)
                CURRENT["path"] = path
                if path in ("/entrar", "/cadastro"):
                    return self._post_auth(acc, path, val)
                if not user:
                    return self._redirect("/entrar")
                if not accounts.check_csrf(sess, val("csrf")):
                    ref = urllib.parse.urlparse(self.headers.get("Referer") or "").path or "/"
                    return self._redirect((ref if ref.startswith("/") and not ref.startswith("//") else "/") + "?m=csrf")
                if path == "/sair":
                    accounts.end_session(acc, self._cookie(COOKIE))
                    accounts.audit(acc, "saiu", user["id"], ip=self._ip())
                    return self._redirect("/entrar?m=saiu", [self._cookie_hdr(COOKIE, "", 0)])
                if user["status"] == "pending":
                    return self._redirect("/")
                if path.startswith("/conta") or path.startswith("/voz/") or path.startswith("/iniciante/") or path == "/perfil/main":
                    return self._post_account(acc, user, path, val)
                if path.startswith("/vincular"):
                    return self._post_link(acc, user, path, val)
                if path.startswith("/admin") or path == "/reiniciar":
                    if not CTX["is_admin"]:
                        return self._send("proibido", 403, ctype="text/plain; charset=utf-8")
                    return self._post_admin(acc, user, path, val)
                if not CTX["puuid"]:
                    return self._redirect("/vincular")
                return self._post_user(acc, user, path, val)
            finally:
                acc.close()

        def _post_auth(self, acc, path, val):
            pre = self._cookie(PRE_COOKIE)
            first = accounts.user_count(acc) == 0
            ip = self._ip()
            new_pre, ck = self._pre()
            if not pre or not hmac.compare_digest(pre, val("pre")):
                inner = (authview.login_form("A página ficou velha. Tente de novo.", pre=new_pre) if path == "/entrar"
                         else authview.signup_form(accounts.signup_mode(acc), "A página ficou velha. Tente de novo.", pre=new_pre, first=first))
                return self._auth_page("Entrar", inner, ck, 400)
            if path == "/entrar":
                u, err = accounts.authenticate(acc, val("email"), val("password"), ip)
                if err:
                    return self._auth_page("Entrar", authview.login_form(err, email=val("email"), pre=pre), code=401)
                tok = accounts.new_session(acc, u["id"], ip, self.headers.get("User-Agent"))
                accounts.audit(acc, "entrou", u["id"], ip=ip)
                return self._redirect("/", [self._cookie_hdr(COOKIE, tok, accounts.SESSION_DAYS * 86400)])
            mode = accounts.signup_mode(acc)
            v = {k: val(k) for k in ("name", "email", "pref_role", "goal", "discord", "source")}
            if mode == "fechado" and not first:
                return self._auth_page("Criar conta", authview.signup_form(mode, pre=pre), code=403)
            if accounts.locked(acc, "signup", ip):
                return self._auth_page("Criar conta", authview.signup_form(mode, "Muitas tentativas. Espere alguns minutos.", v, pre, first), code=429)
            if val("password") != val("password2"):
                return self._auth_page("Criar conta", authview.signup_form(mode, "As duas senhas não são iguais.", v, pre, first), code=400)
            if val("consent") != "1":
                return self._auth_page("Criar conta", authview.signup_form(mode, "Marque que concorda com o uso dos dados.", v, pre, first), code=400)
            uid, err = accounts.create_user(acc, v["email"], v["name"], val("password"), pref_role=v["pref_role"], goal=v["goal"],
                                            discord=v["discord"], source=v["source"])
            if err:
                return self._auth_page("Criar conta", authview.signup_form(mode, err, v, pre, first), code=400)
            acc.execute("INSERT INTO login_fails VALUES (?,?)", ("signup|" + ip, accounts.now_ms()))  # freia robos de cadastro
            acc.commit()
            accounts.audit(acc, "cadastro", uid, detail=v["email"], ip=ip)
            if first:
                adopt_legacy(acc, uid, db_path, cfg)
            tok = accounts.new_session(acc, uid, ip, self.headers.get("User-Agent"))
            return self._redirect("/", [self._cookie_hdr(COOKIE, tok, accounts.SESSION_DAYS * 86400)])

        def _post_account(self, acc, user, path, val):
            ip = self._ip()
            if path == "/conta":
                accounts.update_profile(acc, user["id"], name=val("name"), discord=val("discord"), goal=val("goal"), pref_role=val("pref_role"))
                return self._redirect("/conta?m=salvo")
            if path == "/conta/onboarding":
                accounts.set_pref(acc, user["id"], "onb_ok", "1")
                return self._redirect("/")
            if path == "/perfil/main":
                if val("depois") == "1":
                    accounts.set_pref(acc, user["id"], "main_ok", "1")
                    return self._redirect(self._back_to("/"))
                try:
                    champs_ = _dd().champions()
                except Exception:
                    champs_ = {}
                ch = val("outro") or val("champ")
                rl = val("role")
                if ch in champs_ and rl in ("TOP", "JUNGLE", "MIDDLE", "BOTTOM", "UTILITY"):
                    accounts.set_pref(acc, user["id"], "main_fixo", ch)
                    accounts.set_pref(acc, user["id"], "role_fixo", rl)
                    accounts.set_pref(acc, user["id"], "main_ok", "1")
                    accounts.update_link_stats(acc, user["id"], main_champ=ch, main_role=rl)
                return self._redirect(self._back_to("/") + ("?m=salvo" if "?" not in self._back_to("/") else ""))
            if path == "/partida/marcar":
                txt = _mark_spell({"slot": [val("slot")], "k": [val("k")]})
                return self._send(json.dumps({"t": txt}, ensure_ascii=False), ctype="application/json; charset=utf-8")
            if path == "/voz/teste":
                from . import overlay
                if not overlay.running():
                    return self._redirect("/jogo?m=ovloff")
                overlay.STATE["say"] = {"id": time.time(), "t": "Teste de voz do Carry. Se você está ouvindo isso, está tudo certo."}
                return self._redirect("/jogo?m=vozteste")
            if path == "/iniciante/nivel":
                ans = {k: (val(k) if val(k).isdigit() else "0") for k, _, _ in learn.QUESTIONS}
                tot = learn.score(ans)
                lv = learn.level_of(tot)
                accounts.set_pref(acc, user["id"], "nivel", lv[1])
                accounts.set_pref(acc, user["id"], "nivel_pts", str(tot))
                accounts.set_pref(acc, user["id"], "novato_voz", "1" if lv[1] in ("iniciante", "basico") else "0")
                return self._redirect("/iniciante")
            if path == "/iniciante/aula":
                try:
                    done = set(json.loads(accounts.pref(acc, user["id"], "aulas", "[]") or "[]"))
                except ValueError:
                    done = set()
                k = val("k")
                if k in {l[0] for l in learn.LESSONS}:
                    (done.add if val("v") == "1" else done.discard)(k)
                accounts.set_pref(acc, user["id"], "aulas", json.dumps(sorted(done)))
                return self._redirect(f"/iniciante#a-{k}")
            if path == "/iniciante/voz":
                accounts.set_pref(acc, user["id"], "novato_voz", "1" if val("v") == "1" else "0")
                return self._redirect("/iniciante")
            if path == "/iniciante/refazer":
                accounts.set_pref(acc, user["id"], "nivel", None)
                return self._redirect("/iniciante")
            if path == "/conta/limite":
                try:
                    n = max(1, min(30, int(val("n"))))
                except ValueError:
                    n = 5
                accounts.set_pref(acc, user["id"], "limite_dia", str(n))
                return self._redirect("/")
            if path == "/voz/pronuncia":
                from . import pronuncia
                pronuncia.save(ddir, val("regras"))
                return self._redirect("/jogo")
            if path == "/voz/prefs":
                v = val("voz")
                c = cfg.load()
                accounts.set_pref(acc, user["id"], "voz", voice.pick(ddir, c, v))
                accounts.set_pref(acc, user["id"], "voz_on", "1" if val("on") == "1" else "0")
                accounts.set_pref(acc, user["id"], "voz_urgente", voice.pick(ddir, c, val("voz_u")) if val("voz_u") else "")
                if val("tom") in ("serio", "divertido"):
                    accounts.set_pref(acc, user["id"], "voz_tom", val("tom"))
                return self._redirect("/jogo")
            if path == "/conta/fundo":
                k, v = val("kind"), val("value").strip()
                if k == "youtube":
                    v = bg.youtube_id(v)
                    if not v:
                        return self._redirect("/conta?m=csrf")
                elif k == "file":
                    if v not in bg.local_videos(ddir) or not v.startswith(f"u{user['id']}_"):
                        return self._redirect("/conta")
                elif k == "skin":
                    if not re.fullmatch(r"[A-Za-z0-9]{2,30}:\d{1,4}", v):
                        return self._redirect("/conta")
                elif k == "auto":
                    v = ""
                else:
                    k, v = None, None
                accounts.set_pref(acc, user["id"], "bg_kind", k)
                accounts.set_pref(acc, user["id"], "bg_value", v)
                return self._redirect("/conta?m=salvo")
            if path == "/conta/senha":
                if not accounts.check_password(val("current"), user["pass_hash"]):
                    return self._send(page("Minha conta", authview.account_body(user, CTX["link"], err="A senha atual não confere.")), 400)
                prob = accounts.password_problem(val("new"))
                if prob:
                    return self._send(page("Minha conta", authview.account_body(user, CTX["link"], err=prob)), 400)
                accounts.set_password(acc, user["id"], val("new"))
                accounts.audit(acc, "trocou_senha", user["id"], ip=ip)
                tok = accounts.new_session(acc, user["id"], ip, self.headers.get("User-Agent"))
                return self._redirect("/conta?m=senha", [self._cookie_hdr(COOKIE, tok, accounts.SESSION_DAYS * 86400)])
            if path == "/conta/apagar":
                if not accounts.check_password(val("password"), user["pass_hash"]) or val("confirm").strip().upper() != "APAGAR":
                    return self._send(page("Minha conta", authview.account_body(user, CTX["link"], err="Senha errada ou não digitou APAGAR.")), 400)
                if user["role"] == "admin" and accounts.admins(acc) <= 1 and accounts.user_count(acc) > 1:
                    return self._send(page("Minha conta", authview.account_body(
                        user, CTX["link"], err="Você é o único administrador. Torne outra pessoa admin antes de apagar a sua conta.")), 400)
                self._wipe_user(acc, user)
                accounts.audit(acc, "apagou_conta", None, detail=user["email"], ip=ip)
                return self._redirect("/entrar?m=apagada", [self._cookie_hdr(COOKIE, "", 0)])
            return self._send("não encontrado", 404, ctype="text/plain; charset=utf-8")

        def _wipe_user(self, acc, u):
            if u["db_file"]:
                p = os.path.join(ddir, u["db_file"])
                for ext in ("", "-wal", "-shm", "-journal"):
                    try:
                        os.remove(p + ext)
                    except OSError:
                        pass
            accounts.delete_user(acc, u["id"])

        def _post_link(self, acc, user, path, val):
            ip = self._ip()
            key = cfg.riot_key()
            back = lambda err: self._redirect("/vincular?e=" + urllib.parse.quote(err))
            if not key:
                return back("O app ainda não tem a chave da Riot. Fale com o administrador.")
            from .riot import REGIONS, RiotClient, RiotError
            if path == "/vincular":
                rid = re.sub(r"\s*#\s*", "#", val("riot_id").strip())
                region = val("region").strip().lower()
                if region not in REGIONS:
                    region = "br1"
                if not accounts.RIOT_ID_RE.match(rid):
                    return back("Use o formato Nome#TAG (ex.: Jogador#BR1).")
                try:
                    cl = RiotClient(key, region=region, max_wait=8)
                    name, tag = rid.split("#", 1)
                    puuid = cl.puuid_by_riot_id(name, tag)
                    summ = cl.summoner_by_puuid(puuid)
                except RiotError as ex:
                    return back(str(ex))
                if not summ:
                    return back(f"Achei {rid}, mas não no servidor {REGIONS[region][0]}. Confira o servidor.")
                if accounts.puuid_taken(acc, puuid, user["id"]):
                    return back("Essa conta do LoL já está vinculada a outro usuário do app.")
                accounts.set_link(acc, user["id"], rid, region, puuid)
                accounts.update_link_stats(acc, user["id"], level=summ.get("summonerLevel"))
                accounts.new_challenge(acc, user["id"], summ.get("profileIconId"))
                accounts.audit(acc, "vinculo_iniciado", user["id"], detail=rid, ip=ip)
                return self._redirect("/vincular")
            if path == "/vincular/verificar":
                link = accounts.link(acc, user["id"])
                if not link or link["challenge_icon"] is None:
                    return self._redirect("/vincular")
                if accounts.now_ms() - (link["challenge_ms"] or 0) > 30 * 60000:
                    accounts.new_challenge(acc, user["id"], link["icon"])
                    return back("O pedido de troca de ícone venceu (30 min). Sorteei um ícone novo.")
                try:
                    summ = RiotClient(key, region=link["region"], max_wait=8).summoner_by_puuid(link["puuid"]) or {}
                except RiotError as ex:
                    return back(str(ex))
                if summ.get("profileIconId") != link["challenge_icon"]:
                    return back(f"Ainda vejo outro ícone na sua conta. Troque para o ícone pedido, salve no cliente e espere 1 minuto.")
                accounts.mark_verified(acc, user["id"])
                accounts.update_link_stats(acc, user["id"], icon=summ.get("profileIconId"), level=summ.get("summonerLevel"))
                accounts.audit(acc, "conta_verificada", user["id"], detail=link["riot_id"], ip=ip)
                self._queue_sync(acc, user, 100)
                return self._redirect("/perfil?m=vinculada")
            return self._send("não encontrado", 404, ctype="text/plain; charset=utf-8")

        def _queue_sync(self, acc, u, count):
            link = accounts.link(acc, u["id"])
            if not link or not link["verified_ms"]:
                return False
            path = self._user_path(acc, accounts.get_user(acc, u["id"]))
            key = cfg.riot_key()
            return jobs.MANAGER.submit(u["id"], "sync", lambda log: jobs.run_sync(
                ddir, path, key, link["region"], u["id"], link["puuid"], count, log))

        def _post_admin(self, acc, me, path, val):
            ip = self._ip()
            if path == "/reiniciar":
                accounts.audit(acc, "reiniciou_app", me["id"], ip=ip)
                self._send(p_restarting())
                return restart_app()
            if path == "/admin/chave":
                import re as _re
                k = "".join(val("key").split())          # tira espacos e quebras de linha coladas junto
                if not k:
                    return self._redirect("/admin")
                if not _re.fullmatch(r"RGAPI-[0-9a-fA-F-]{36}", k):
                    return self._send(self._admin_page(acc, me, "Isso não parece uma chave da Riot. Ela começa com RGAPI- e tem 42 caracteres: "
                                                               "copie pelo botão de copiar ao lado da chave em developer.riotgames.com."))
                cfg.save(riot_api_key=k)
                accounts.audit(acc, "chave_trocada", None, me["id"], ip=ip)
                CTX["has_key"] = True
                # testa NA HORA a chave nova e mostra o resultado de verdade (antes aparecia o erro do teste antigo)
                from .riot import quick_test
                try:
                    jobs.MANAGER.clear_last(me["id"])
                except Exception:
                    pass
                ok, code, msg = quick_test(k, cfg.region())
                if ok:
                    note = "Chave salva e testada: a Riot aceitou. Pode sincronizar."
                elif code in (401, 403):
                    jobs.MANAGER.submit(me["id"], "teste", lambda log: jobs.run_key_watch(k, cfg.region(), log))
                    note = (f"Chave salva. A Riot ainda não aceitou (código {code}{': ' + msg if msg else ''}). Chave recém-gerada às vezes "
                            "demora 1 a 3 minutos para valer: o app vai testar de novo sozinho a cada 30 segundos e avisa aqui em cima quando funcionar.")
                else:
                    note = f"Chave salva, mas não deu para testar agora ({msg or code})."
                return self._send(self._admin_page(acc, me, note))
            if path == "/admin/ia":
                gk = val("gkey").strip()
                if gk:
                    cfg.save(gemini_api_key=gk)
                    accounts.audit(acc, "chave_gemini_trocada", None, me["id"], ip=ip)
                if val("prov") in ("gemini", "anthropic"):
                    cfg.save(ai_provider=val("prov"))
                k = val("key").strip()
                if k:
                    cfg.save(anthropic_api_key=k)
                    accounts.audit(acc, "chave_ia_trocada", None, me["id"], ip=ip)
                if val("model").strip():
                    cfg.save(anthropic_model=val("model").strip()[:60])
                return self._redirect("/admin?m=chave")
            if path == "/admin/voz":
                k = val("key").strip()
                field = "elevenlabs_key" if val("svc") == "el" else "azure_speech_key"
                if field == "elevenlabs_key" and k and not k.startswith("sk_") and val("apagar") != "1":
                    return self._redirect("/admin?m=elid")
                if val("apagar") == "1":
                    cfg.save(**{field: ""})
                    accounts.audit(acc, "chave_voz_removida", None, me["id"], ip=ip)
                elif k:
                    cfg.save(**{field: k})
                    accounts.audit(acc, "chave_voz_trocada", None, me["id"], ip=ip)
                    if field == "elevenlabs_key":
                        voice.el_voices(ddir, k, force=True)
                r = val("region").strip().lower()
                if re.fullmatch(r"[a-z0-9]{3,30}", r or ""):
                    cfg.save(azure_speech_region=r)
                return self._redirect("/admin?m=chave")
            if path == "/admin/especialistas":
                key = cfg.riot_key()
                link = accounts.link(acc, me["id"])
                region = link["region"] if link else "br1"
                jobs.MANAGER.submit(me["id"], "experts", lambda log: jobs.run_experts(ddir, key, region, log))
                return self._redirect("/admin?m=fila")
            if path == "/admin/testar":
                from .riot import quick_test
                key = cfg.riot_key()
                ok, code, msg = quick_test(key, cfg.region()) if key else (False, 0, "nenhuma chave salva")
                try:
                    jobs.MANAGER.clear_last(me["id"])
                except Exception:
                    pass
                return self._send(self._admin_page(acc, me, "Chave funcionando: a Riot aceitou." if ok else
                                                   f"A Riot recusou a chave salva (código {code}{': ' + msg if msg else ''})."))
            if path == "/admin/modo":
                if val("mode") in accounts.SIGNUP_MODES:
                    accounts.set_setting(acc, "signup_mode", val("mode"))
                    accounts.audit(acc, "modo_cadastro", None, me["id"], detail=val("mode"), ip=ip)
                return self._redirect("/admin?m=modo")
            if path == "/admin/criar":
                pw = temp_password()
                uid, err = accounts.create_user(acc, val("email"), val("name"), pw, status="active")
                if err:
                    return self._send(page("Administração", "<div class='alert err'>" + e(err) + "</div><p><a class='btn' href='/admin'>Voltar</a></p>"), 400)
                accounts.audit(acc, "admin_criou", uid, me["id"], detail=val("email"), ip=ip)
                return self._send(self._admin_page(acc, me, "Conta criada.", (val("email"), pw)))
            m = re.fullmatch(r"/admin/u/(\d+)/([a-z]+)", path)
            if not m:
                return self._send("não encontrado", 404, ctype="text/plain; charset=utf-8")
            uid, act = int(m.group(1)), m.group(2)
            u = accounts.get_user(acc, uid)
            if not u:
                return self._redirect("/admin")
            is_me = uid == me["id"]
            if act == "aprovar":
                accounts.set_user_field(acc, uid, "status", "active")
            elif act == "bloquear" and not is_me:
                accounts.set_user_field(acc, uid, "status", "blocked")
            elif act == "desbloquear":
                accounts.set_user_field(acc, uid, "status", "active")
            elif act == "promover":
                accounts.set_user_field(acc, uid, "role", "admin")
            elif act == "rebaixar" and not is_me:
                if accounts.admins(acc) <= 1:
                    return self._redirect("/admin?m=admin1")
                accounts.set_user_field(acc, uid, "role", "user")
            elif act == "verificar":
                if accounts.link(acc, uid):
                    accounts.mark_verified(acc, uid)
                    self._queue_sync(acc, u, 100)
            elif act == "sincronizar":
                self._queue_sync(acc, u, 50)
            elif act == "senha":
                pw = temp_password()
                accounts.set_password(acc, uid, pw)
                accounts.audit(acc, "admin_nova_senha", uid, me["id"], ip=ip)
                if is_me:
                    tok = accounts.new_session(acc, me["id"], ip, self.headers.get("User-Agent"))
                    self._send(self._admin_page(acc, me, "Senha trocada.", (u["email"], pw)),
                               cookies=[self._cookie_hdr(COOKIE, tok, accounts.SESSION_DAYS * 86400)])
                    return
                return self._send(self._admin_page(acc, me, "Senha trocada.", (u["email"], pw)))
            elif act == "excluir" and not is_me:
                if val("confirm").strip().upper() != "EXCLUIR":
                    return self._send(page("Administração", "<div class='alert err'>Para excluir, digite EXCLUIR no campo ao lado do botão.</div>"
                                           "<p><a class='btn' href='/admin'>Voltar</a></p>"), 400)
                if u["db_file"] and os.path.basename(u["db_file"]) == os.path.basename(db_path):
                    pass  # nunca apaga o banco antigo compartilhado por engano
                else:
                    self._wipe_user(acc, u)
                accounts.delete_user(acc, uid)
                accounts.audit(acc, "admin_excluiu", None, me["id"], detail=u["email"], ip=ip)
                return self._redirect("/admin?m=excluido")
            else:
                return self._redirect("/admin")
            accounts.audit(acc, "admin_" + act, uid, me["id"], ip=ip)
            return self._redirect("/admin?m=feito")

        def _post_user(self, acc, user, path, val):
            puuid = CTX["puuid"]
            link = CTX["link"]
            if path == "/coach/limpar":
                c2 = self._user_con(acc, user)
                try:
                    coachbot.clear(c2)
                finally:
                    c2.close()
                return self._redirect("/coach")
            if path == "/launcher/jogar":
                from . import overlay, launcher
                msg_ = []
                if self._is_local():
                    if not overlay.running():
                        overlay.launch(user["id"], self.server.server_address[1])
                        try:
                            json.dump({"owner": user["id"]}, open(AUTOSTART, "w", encoding="utf-8"))
                            if os.path.exists(OVERLAY_OFF):
                                os.remove(OVERLAY_OFF)
                        except OSError:
                            pass
                        msg_.append("Overlay ligado.")
                    st_, _ = launcher.client_state()
                    ok_, m_ = launcher.abrir_lol()
                    if not ok_:              # nao achou o cliente: fica no launcher mostrando o motivo
                        return self._redirect("/launcher?m=" + urllib.parse.quote(m_))
                    # JOGAR leva direto para o app (com partida rolando, para o Ao vivo)
                    return self._redirect("/aovivo" if st_ == "partida" else "/")
                return self._redirect("/")
            if path == "/overlay/abrir":
                from . import overlay
                if self._is_local():
                    overlay.launch(user["id"], self.server.server_address[1])
                    try:      # fica ligado: se o app reiniciar, o overlay volta sozinho
                        json.dump({"owner": user["id"]}, open(AUTOSTART, "w", encoding="utf-8"))
                        if os.path.exists(OVERLAY_OFF):
                            os.remove(OVERLAY_OFF)
                    except OSError:
                        pass
                return self._redirect("/overlay" if val("volta") == "/overlay" else "/jogo")
            if path == "/overlay/fechar":
                from . import overlay
                try:
                    open(OVERLAY_OFF, "w").write("desligado no site")
                except OSError:
                    pass
                overlay.stop()
                return self._redirect("/jogo")
            if path == "/overlay/perfil":
                from . import overlay
                pf = extras.PROFILES.get(val("p"))
                if pf and self._is_local():
                    u_ = dict(overlay.ui_settings())
                    u_.update(pf[1])
                    u_["perfil"] = val("p")
                    overlay.save_cfg(ui=u_)
                return self._redirect("/overlay?m=" + urllib.parse.quote(f"Perfil {pf[0] if pf else ''} aplicado."))
            if path == "/overlay/teste":
                from . import overlay
                if self._is_local():
                    overlay.STATE["demo_until"] = time.time() + 60
                    overlay.STATE["demo_voice"] = time.time() + 60
                return self._redirect("/overlay?m=" + urllib.parse.quote("Teste começou: 60 segundos de partida simulada, com voz."))
            if path in ("/overlay/salvar", "/overlay/padrao", "/overlay/previa"):
                from . import overlay
                if not self._is_local():
                    return self._redirect("/jogo")
                if path == "/overlay/salvar":
                    overlay.save_cfg(ui=overlay.clean_ui({k: val(k) for k in overlay.DEFAULT_UI}))
                    if self.headers.get("X-Auto"):
                        return self._send("ok", ctype="text/plain")
                elif path == "/overlay/padrao":
                    overlay.save_cfg(ui=dict(overlay.DEFAULT_UI))
                else:
                    overlay.STATE["demo_until"] = time.time() + 30
                return self._redirect("/overlay")
            if path == "/reportar":
                from . import atualizar, saude
                data_ = saude.pacote(val("desc"), atualizar.atual())
                self.send_response(200)
                self.send_header("Content-Type", "application/zip")
                self.send_header("Content-Disposition", f"attachment; filename=carry-problema-{time.strftime('%Y%m%d-%H%M')}.zip")
                self.send_header("Content-Length", str(len(data_)))
                self.end_headers()
                self.wfile.write(data_)
                return
            if path == "/uso":
                from . import mais
                mais.uso_alternar()
                return self._redirect("/reportar")
            if path == "/novidades/ok":
                from . import atualizar
                atualizar.novidades_ok()
                return self._redirect("/")
            if path == "/nota-confronto":
                from . import ficha
                c2 = self._user_con(acc, user)          # antes usava 'con', que nao existe aqui: salvar a nota dava erro
                try:
                    ficha.note_save(c2, val("c"), val("o"), val("nota"))
                finally:
                    c2.close()
                back = val("back") or "/"
                return self._redirect(back if back.startswith("/") and not back.startswith("//") else "/")
            if path == "/atualizar":
                from . import atualizar, live
                try:
                    if live.fetch():
                        return self._send(page("Atualização", "<div class='card'><p>Termine a partida primeiro: o Carry nunca se atualiza no meio de um jogo.</p></div>"))
                except Exception:
                    pass
                ok_, msg_ = atualizar.aplicar()
                if ok_:
                    return self._send(page("Atualizando", (
                        f"<div class='empty'><span class='em'>↻</span><b>{e(msg_)}</b><span>Esta tela volta sozinha com a versão nova.</span></div>"
                        "<script>setTimeout(function t(){fetch('/',{cache:'no-store'}).then(function(r){if(r.ok)location.href='/';else setTimeout(t,1500)})"
                        ".catch(function(){setTimeout(t,1500)})},9000);</script>"), show_title=False))
                return self._send(page("Atualização", f"<div class='card'><p>{e(msg_)}</p></div>"))
            if path == "/sincronizar/iniciar":
                kind = val("kind")
                key = cfg.riot_key()
                if not key:
                    return self._redirect("/sincronizar")
                upath = self._user_path(acc, user)
                if kind == "sync":
                    try:
                        cnt = min(max(int(val("count") or 100), 1), 100)
                    except ValueError:
                        cnt = 50
                    jobs.MANAGER.submit(user["id"], "sync", lambda log: jobs.run_sync(ddir, upath, key, link["region"], user["id"], puuid, cnt, log))
                elif kind == "top":
                    try:
                        g = min(max(int(val("games") or 30), 1), 100)
                    except ValueError:
                        g = 30
                    ch = val("champion")[:30]
                    jobs.MANAGER.submit(user["id"], "top", lambda log: jobs.run_top(ddir, upath, key, link["region"], ch, g, log, puuid))
                elif kind == "ano":
                    jobs.MANAGER.submit(user["id"], "sync", lambda log: jobs.run_sync_year(ddir, upath, key, link["region"], user["id"], puuid, log))
                elif kind == "topall":
                    _c = db.connect(upath)
                    try:
                        profile.set_for(_c, puuid)
                        mains = _mains(_c, puuid)
                    finally:
                        _c.close()
                    if mains:
                        jobs.MANAGER.submit(user["id"], "top", lambda log: jobs.run_top_many(ddir, upath, key, link["region"], mains, 20, log, puuid))
                elif kind == "tier":
                    t = val("tier") if val("tier") in tiers.TIERS else "GOLD"
                    _c = db.connect(upath)
                    try:
                        pos = profile.compute(_c, puuid)[0]
                    finally:
                        _c.close()
                    jobs.MANAGER.submit(user["id"], "tier", lambda log: jobs.run_tier(ddir, key, link["region"], t, pos, 40, log))
                ref_full = urllib.parse.urlparse(self.headers.get("Referer") or "")
                ref = ref_full.path + (("?" + ref_full.query) if ref_full.query else "")
                return self._redirect(ref if val("back") and ref.startswith("/") and not ref.startswith("//") else "/sincronizar")
            con = self._user_con(acc, user)
            try:
                profile.set_for(con, puuid)
                if path == "/foco":
                    sug = habits.suggest_focus(report.my_games(con, puuid))
                    if sug and sug["metric"] == val("metric"):
                        habits.set_focus(con, sug["text"], sug["metric"], sug["op"], sug["target"])
                    return self._redirect("/")
                if path == "/selecao/pool":
                    from . import champselect
                    try:
                        from .ddragon import DataDragon
                        valid = list(DataDragon(cache_dir=os.path.join(ddir, "cache")).champions())
                    except Exception:
                        valid = list({g["champion"] for g in report.my_games(con, puuid)})
                    champselect.pool_change(con, val("champion"), val("op") == "add", valid)
                    return self._redirect("/jogo")
                if path == "/selecao/importar" or (path.startswith("/revisao/") and path.endswith("/replay")):
                    if not self._is_local():
                        return self._send(page("Cliente do LoL", authview.companion_body()), 400)
                    from . import champselect, lcu
                    if path == "/selecao/importar":
                        try:
                            msg = champselect.do_import(con, val("champion"), val("what"), page=val("pagina"))
                        except Exception as ex:  # cliente fechado, formato novo, rede
                            msg = f"Não consegui importar: {ex}"
                        if self.headers.get("X-Requested-With") == "fetch":      # aviso rapido na propria tela
                            return self._send(msg, ctype="text/plain; charset=utf-8")
                        return self._redirect(self._back_to("/jogo"))
                    mid = path.split("/")[2]
                    try:
                        lcu.LCU.discover().watch_replay(mid.split("_")[-1])
                        msg = "Pedi ao cliente para abrir o replay. Confira o cliente do LoL."
                    except Exception as ex:
                        msg = f"Não consegui abrir o replay: {ex}"
                    if self.headers.get("X-Requested-With") == "fetch":
                        return self._send(msg, ctype="text/plain; charset=utf-8")
                    return self._redirect(self._back_to(f"/revisao/{mid}"))
                if path.startswith("/revisao/") and path.endswith("/ia"):
                    mid = path.split("/")[2]
                    key, model = _ai_cfg()
                    if not key:
                        return self._send("Ligue o Coach IA em Administração (chave do Gemini, grátis).", ctype="text/plain; charset=utf-8")
                    try:
                        t_ms = int(val("t_ms") or 0)
                        ms, G = vod.moments(con, puuid, mid)
                        m = next((x for x in ms if x["t_ms"] == t_ms), None)
                        a = review.answers(con, mid).get((t_ms, m["kind"])) if m else None
                        txt = vod.ai_read(key, model, m, (a or {}).get("thought"), G.me["champion"], G.opp["champion"] if G.opp else "?") if m else "Lance não encontrado."
                        if m and txt:
                            vod.ai_save(con, mid, t_ms, txt)
                    except Exception as ex:
                        txt = f"Não consegui analisar agora: {str(ex)[:160]}"
                    return self._send(txt, ctype="text/plain; charset=utf-8")
                if path.startswith("/revisao/"):
                    mid = path.split("/")[2]
                    tipo = val("tipo")
                    cause = val("cause_good") if tipo == "acerto" else val("cause_bad") if tipo == "erro" else ("Z" if tipo == "neutro" else val("cause"))
                    review.save_answer(con, mid, val("t_ms") or 0, val("kind"), val("thought"), cause, val("knew"))
                    if self.headers.get("X-Requested-With") == "fetch":
                        try:
                            ms_, _g = vod.moments(con, puuid, mid)
                            m_ = next((x for x in ms_ if x["t_ms"] == int(val("t_ms") or 0)), None)
                            frag = vod.reveal_html(mid, m_, vod.ai_get(con, mid), bool(_ai_cfg()[0])) if m_ else "ok"
                        except Exception:
                            frag = "ok"
                        return self._send(frag, ctype="text/html; charset=utf-8")
                    return self._redirect(f"/revisao/{urllib.parse.quote(mid)}#m{val('t_ms')}")
                if path.startswith("/partida/") and path.endswith("/analisar"):
                    mid = path.split("/")[2]
                    key, model = _ai_cfg()
                    if key:
                        upath = self._user_path(acc, user)
                        jobs.MANAGER.submit(user["id"], "analise", lambda log: self._run_analysis(upath, puuid, mid, key, model, log))
                    back = "/revisao/" if val("back") == "revisao" else "/partida/"
                    return self._redirect(f"{back}{urllib.parse.quote(mid)}")
                if path.startswith("/partida/") and path.endswith("/replay"):
                    mid = urllib.parse.unquote(path[len("/partida/"):-len("/replay")])
                    try:
                        t_ms = int(val("t") or 0)
                    except ValueError:
                        t_ms = 0
                    msg = _open_replay(mid, t_ms)
                    return self._redirect(f"/partida/{urllib.parse.quote(mid)}?m=" + urllib.parse.quote(msg))
                if path.startswith("/partida/") and path.endswith("/azar"):
                    mid = path.split("/")[2]
                    try:
                        t_ = int(val("t") or 0)
                        if extras.death_tags(con, mid).get(t_) == "azar":
                            con.execute("DELETE FROM death_tags WHERE match_id=? AND t_ms=?", (mid, t_))
                            con.commit()
                        else:
                            extras.mark_death(con, mid, t_, "azar")
                    except Exception:
                        pass
                    return self._redirect(f"/partida/{urllib.parse.quote(mid)}")
                if path == "/souma":
                    hoje_ = time.strftime("%Y%m%d")
                    _SOUMA["dia"] = None if _SOUMA.get("dia") == hoje_ else hoje_
                    try:
                        with open(_SOUMA_F, "w") as fh_:
                            fh_.write(_SOUMA["dia"] or "")
                    except OSError:
                        pass
                    return self._redirect("/?m=" + urllib.parse.quote("Modo só uma ligado: uma partida e pronto." if _SOUMA["dia"] else "Modo só uma desligado."))
                if path == "/humor":
                    try:
                        extras.mood_save(con, val("k") or "antes", val("v") or "", val("mid") or None)
                    except Exception:
                        pass
                    back = val("mid")
                    return self._redirect(f"/partida/{urllib.parse.quote(back)}?m=" + urllib.parse.quote("Anotado.") if back else "/?m=" + urllib.parse.quote("Anotado. Boa partida."))
                if path.startswith("/partida/") and path.endswith("/nota"):
                    mid = path.split("/")[2]
                    review.save_notes(con, mid, val("do_different"), val("feeling"))
                    return self._redirect(f"/partida/{urllib.parse.quote(mid)}")
                return self._send("não encontrado", 404, ctype="text/plain; charset=utf-8")
            finally:
                con.close()
    return H


def _launcher_page(con, puuid, user, msg=None):
    from . import launcher, caminho, missions, pregame, overlay, atualizar, ranks
    link = CTX.get("link")
    ctx = {"versao": atualizar.atual(), "overlay": overlay.running(), "client": launcher.client_state()}
    try:
        icons.load_skin(CTX["ddir"])
    except Exception:
        pass
    games = report.my_games(con, puuid, "") if puuid else []
    cnt = {}
    for g in games[:100]:
        cnt[g["champion"]] = cnt.get(g["champion"], 0) + 1
    top = sorted(cnt, key=cnt.get, reverse=True)
    main = (link["main_champ"] if link and "main_champ" in link.keys() and link["main_champ"] else None) or (top[0] if top else "Zed")
    others = [c for c in top if c != main]
    ctx["art"] = icons.splash(main)
    ctx["art2"] = icons.splash(others[0]) if others else None
    ctx["art3"] = icons.splash(others[1]) if len(others) > 1 else None
    if link:
        ctx.update(tier=link["tier"], division=link["division"], lp=link["lp"], who=(link["riot_id"] or "").split("#")[0])
        try:
            tg = caminho.target(link["tier"])
            if tg:
                ctx["falta"] = ranks.ladder(tg, "IV", 0) - ranks.ladder(link["tier"], link["division"], link["lp"])
                ctx["alvo"] = {"MASTER": "Mestre", "GRANDMASTER": "Grão-Mestre", "CHALLENGER": "Desafiante"}.get(tg, launcher.TIER_PT.get(tg, tg).capitalize())
        except Exception:
            pass
    try:
        st_ = missions.ensure_today(con, games)
        ok_ = sum(1 for c in st_["checks"] if c["ok"])
        ctx.update(missao=st_["mission"]["text"], missao_sub=f"{ok_} de {len(st_['checks'])} hoje",
                   missao_txt=f"Sequência: {st_['streak']} dia(s) seguidos cumprindo a missão.")
    except Exception:
        pass
    try:
        lim_ = None
        try:
            acc_ = accounts.connect(CTX["ddir"])
            lim_ = accounts.pref(acc_, user["id"], "limite_dia", None)
            acc_.close()
        except Exception:
            pass
        ctx["hoje"] = pregame.today(con, puuid, lim_)["msg"]
    except Exception:
        pass
    try:
        inf_ = atualizar.STATE.get("info")
        if inf_ and inf_.get("versao") and inf_["versao"] != ctx["versao"]:
            ctx["update"] = inf_["versao"]
    except Exception:
        pass
    from . import rotk
    return rotk.apply(launcher.page_html(ctx, premium.mark, msg))


_RANKSNAP = {}
_SOUMA = {}
_SOUMA_F = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "cache", "so_uma.txt")
try:
    _SOUMA["dia"] = open(_SOUMA_F).read().strip() or None
except OSError:
    pass


AUTOSTART = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "overlay.autostart")


OVERLAY_BG = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "overlay_fundo")
OVERLAY_OFF = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "overlay.off")


def _overlay_owner(ddir):
    try:
        o = json.load(open(AUTOSTART, encoding="utf-8")).get("owner")
        if o:
            return o
    except Exception:
        pass
    acc = accounts.connect(ddir)
    try:
        links = accounts.verified_links(acc)
        admin = [l for l in links if (accounts.get_user(acc, l["user_id"]) or {"role": ""})["role"] == "admin"]
        return (admin or links or [{"user_id": None}])[0]["user_id"]
    except Exception:
        return None
    finally:
        acc.close()


def _overlay_autostart(ddir, port):
    """Overlay ligado por padrao: abre junto com o app e volta sozinho se fechar (so para quando a pessoa desliga no site)."""
    import threading
    from . import overlay

    def keep():
        """Monitor de saude: overlay fechado -> abre de novo; overlay travado (sem sinal de vida) -> reinicia. Anota o motivo."""
        from . import saude
        time.sleep(3)
        fails, last_ok = 0, time.time()
        while True:
            try:
                p_ = overlay.STATE.get("proc")
                if not os.path.exists(OVERLAY_OFF):
                    if p_ is not None and p_.poll() is not None:
                        saude.anota(f"overlay fechou sozinho (código {p_.returncode})", saude.erro_tail())
                        overlay.STATE["proc"] = None
                    if overlay.running():
                        age = saude.vivo_idade()
                        if age is not None and age > 45 and time.time() - overlay.STATE.get("started", 0) > 60:
                            saude.anota(f"overlay travado: {int(age)} s sem sinal de vida; reiniciado")
                            overlay.stop()
                            time.sleep(2)
                    if not overlay.running() and fails < 8:
                        owner = _overlay_owner(ddir)
                        if owner:
                            overlay.launch(owner, port)
                            time.sleep(8)
                            fails = 0 if overlay.running() else fails + 1
                    if overlay.running():
                        last_ok = time.time()
                    elif time.time() - last_ok > 900:
                        fails = 0               # tenta de novo a cada 15 min
                        last_ok = time.time()
            except Exception as ex:
                fails += 1
                try:
                    saude.anota(f"monitor: {type(ex).__name__}: {ex}")
                except Exception:
                    pass
            time.sleep(15)
    threading.Thread(target=keep, daemon=True).start()


def _watch_code(stop):
    """Atualizacao sem precisar fechar nada: quando os arquivos do app mudam, reinicia sozinho (overlay junto)."""
    import glob
    here = os.path.dirname(os.path.abspath(__file__))
    snap = lambda: {f: os.path.getmtime(f) for f in glob.glob(os.path.join(here, "*.py"))}
    base = snap()
    while not stop.wait(4):
        try:
            cur = snap()
        except OSError:
            continue
        if cur == base:
            continue
        stop.wait(4)                       # espera todos os arquivos chegarem
        if snap() != cur:
            continue
        def in_game():
            try:
                from . import live
                return bool(live.fetch())
            except Exception:
                return False
        while (not jobs.MANAGER.only_background() or in_game()) and not stop.wait(10):   # nunca reinicia no meio da partida
            pass
        from . import overlay
        if overlay.running():
            try:
                json.dump({"owner": overlay.STATE.get("owner")}, open(AUTOSTART, "w", encoding="utf-8"))
            except OSError:
                pass
            overlay.stop()
        print("Arquivos do app atualizados: reiniciando.")
        restart_app()
        return


def restart_app():
    """Abre uma copia nova do app (ela espera a porta liberar) e fecha esta. So no Windows/pythonw ou python comum."""
    import subprocess
    import sys
    import threading
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    launcher = os.path.join(root, "LoL Coach.pyw")
    exe = sys.executable
    w = os.path.join(os.path.dirname(exe), "pythonw.exe")
    if os.name == "nt" and os.path.exists(w):
        exe = w
    flags = 0x00000008 | 0x00000200 | 0x08000000 if os.name == "nt" else 0  # destacado, sem janela
    subprocess.Popen([exe, launcher, "--aguardar", "--fundo"], cwd=root, close_fds=True,
                     **({"creationflags": flags} if os.name == "nt" else {}))
    threading.Timer(0.8, lambda: os._exit(0)).start()


def p_restarting():
    return page("Reiniciando", (
        "<div class='empty'><span class='em'>↻</span><b>Reiniciando o app…</b>"
        "<span>Em alguns segundos esta tela volta sozinha com a versão nova.</span></div>"
        "<script>(function t(){fetch('/',{cache:'no-store'}).then(function(r){if(r.ok)location.href='/';else setTimeout(t,800)})"
        ".catch(function(){setTimeout(t,800)})})();</script>"), show_title=False)


def serve(db_path, _puuid=None, port=8765, open_browser=True, host=None):
    """Sobe o site. Padrao: so neste PC (127.0.0.1). Para outras pessoas acessarem: COACH_BIND=0.0.0.0 e COACH_HOSTS=seu.dominio."""
    import threading
    from http.server import ThreadingHTTPServer
    host = host or os.environ.get("COACH_BIND", "127.0.0.1")
    ddir = userdata.data_dir(db_path)
    try:
        from . import ranksimg
        ranksimg.ensure(ddir)
    except Exception:
        pass
    try:
        userdata.seed_top_from(ddir, db_path)
    except Exception as ex:
        print(f"Amostra antiga do topo não copiada: {ex}")
    ThreadingHTTPServer.daemon_threads = True
    # No Windows, "reuse address" deixa DOIS apps ouvirem a mesma porta (e o antigo continua respondendo). Desliga.
    ThreadingHTTPServer.allow_reuse_address = os.name != "nt"
    srv = ThreadingHTTPServer((host, port), make_handler(db_path))
    try:
        with open(os.path.join(ddir, "coach.pid"), "w") as fh:
            fh.write(str(os.getpid()))
    except OSError:
        pass
    url = f"http://127.0.0.1:{port}/"
    print(f"Carry aberto em {url}  (Ctrl+C para fechar)")
    stop = threading.Event()
    def _prepare_dbs():
        """Na primeira abertura depois da atualizacao cria os indices novos e o ANALYZE (uma vez, em segundo plano)."""
        import glob
        paths = [db_path, userdata.top_path(ddir)] + glob.glob(os.path.join(ddir, "*.sqlite")) + glob.glob(os.path.join(ddir, "users", "*.sqlite"))
        for p_ in dict.fromkeys(paths):
            if p_ and os.path.exists(p_) and not p_.endswith(("accounts.sqlite", "guides.sqlite", "tiers.sqlite")):
                try:
                    db.connect(p_).close()
                except Exception:
                    pass
    def _upd_loop():              # confere se tem versao nova (agora e de hora em hora)
        from . import atualizar
        while True:
            try:
                atualizar.checar()
            except Exception:
                pass
            time.sleep(3600)
    threading.Thread(target=_upd_loop, daemon=True).start()
    try:                          # atalho "Carry" na area de trabalho sempre certo (refaz se estiver quebrado)
        from . import janela as _jan
        _jan.criar_atalho()
    except Exception:
        pass
    try:                          # replay fechado com o app desligado: devolve o modo de tela do jogo
        from . import lcu as _lcu
        _lcu.replay_windowed_restore(wait=False)
    except Exception:
        pass
    threading.Thread(target=_prepare_dbs, daemon=True).start()
    try:
        from . import pronuncia
        pronuncia.load(ddir)
    except Exception:
        pass
    threading.Thread(target=jobs.auto_sync_loop, args=(ddir, config_mod.Config(db_path), stop), daemon=True).start()
    threading.Thread(target=jobs.auto_collect_loop, args=(ddir, config_mod.Config(db_path), stop), daemon=True).start()
    threading.Thread(target=_watch_code, args=(stop,), daemon=True).start()
    _overlay_autostart(ddir, port)
    if open_browser:
        try:
            from . import janela
            janela.abrir(url.rstrip("/") + (os.environ.get("CARRY_OPEN_PATH") or "/launcher"))
        except Exception:
            webbrowser.open(url.rstrip("/") + (os.environ.get("CARRY_OPEN_PATH") or "/launcher"))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("Fechado.")
    finally:
        stop.set()
    return srv
