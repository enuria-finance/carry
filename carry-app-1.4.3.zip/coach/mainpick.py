"""Seu main: o app sugere (maestria e partidas) e a pessoa confirma ou troca. A escolha vale para o fundo, as cores,
a build sugerida, a rota padrao das paginas e o pool da selecao."""
import html

from . import icons

e = lambda x: html.escape("" if x is None else str(x))
ROLES = [("TOP", "Topo"), ("JUNGLE", "Selva"), ("MIDDLE", "Meio"), ("BOTTOM", "Atirador"), ("UTILITY", "Suporte")]

CSS = """
.mp{display:block !important;border:1px solid rgba(233,196,106,.45);border-radius:18px;padding:18px 20px;margin:0 0 16px;
background:radial-gradient(700px 220px at 0 0,rgba(233,196,106,.09),transparent 70%),linear-gradient(180deg,rgba(32,24,23,.92),rgba(18,13,13,.96))}
.mp h2{margin:0;font:700 22px var(--head);color:#fff}.mp p.s{margin:4px 0 14px;color:#C9BDB0;font-size:13.5px}
.mp-g{display:flex;gap:10px;flex-wrap:wrap}.mp-c{position:relative}.mp-c input{position:absolute;opacity:0}
.mp-c span{display:flex;flex-direction:column;align-items:center;gap:6px;width:96px;padding:10px 6px;border-radius:14px;border:1px solid var(--rule);cursor:pointer;
background:rgba(255,255,255,.02);transition:border-color .15s,transform .15s}
.mp-c span img,.mp-c span .cic{border-radius:12px}.mp-c span b{font:700 12.5px var(--body);color:#fff;text-align:center}.mp-c span small{color:var(--mute);font-size:11px}
.mp-c input:checked+span{border-color:var(--gold);box-shadow:0 0 0 3px rgba(233,196,106,.2);transform:translateY(-2px)}
.mp-r{display:flex;gap:6px;flex-wrap:wrap;margin:14px 0}.mp-r label{position:relative}.mp-r input{position:absolute;opacity:0}
.mp-r span{display:inline-block;padding:8px 14px;border-radius:999px;border:1px solid var(--rule);color:#D6CCC0;font:600 13px var(--body);cursor:pointer}
.mp-r input:checked+span{background:var(--gold);color:#1a1405;border-color:var(--gold)}
.mp-f{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.mp-f select{max-width:260px}
"""


def suggestions(con, champs_by_key, games_by_champ):
    """Ate 6 campeoes: maestria primeiro (funciona antes de sincronizar), depois os mais jogados."""
    out = []
    try:
        for r in con.execute("SELECT champion_id, points FROM mastery_me ORDER BY points DESC LIMIT 6"):
            nm = champs_by_key.get(int(r[0]))
            if nm and nm not in [o[0] for o in out]:
                out.append((nm, f"{(r[1] or 0) // 1000} mil de maestria"))
    except Exception:
        pass
    for c, n in sorted(games_by_champ.items(), key=lambda kv: -kv[1]):
        if len(out) >= 6:
            break
        if c not in [o[0] for o in out]:
            out.append((c, f"{n} partidas"))
    return out[:6]


def html_block(con, champs, games, cur_champ, cur_role, csrf, first=False):
    by_key = {v["key"]: k for k, v in champs.items()}
    gbc = {}
    pos_count = {}
    for g in games:
        gbc[g["champion"]] = gbc.get(g["champion"], 0) + 1
        if g.get("position"):
            pos_count[g["position"]] = pos_count.get(g["position"], 0) + 1
    sug = suggestions(con, by_key, gbc)
    cur_champ = cur_champ or (sug[0][0] if sug else None)
    cur_role = cur_role or (max(pos_count, key=pos_count.get) if pos_count else "MIDDLE")
    cards = "".join(f"<label class='mp-c'><input type='radio' name='champ' value='{e(c)}'{' checked' if c == cur_champ else ''}>"
                    f"<span>{icons.champ(c, 56)}<b>{e(champs.get(c, {}).get('name', c))}</b><small>{e(why)}</small></span></label>" for c, why in sug)
    others = "".join(f"<option value='{e(k)}'{' selected' if k == cur_champ and k not in [s[0] for s in sug] else ''}>{e(v['name'])}</option>"
                     for k, v in sorted(champs.items(), key=lambda kv: kv[1]["name"]))
    roles = "".join(f"<label><input type='radio' name='role' value='{k}'{' checked' if k == cur_role else ''}><span>{n}</span></label>" for k, n in ROLES)
    head = ("<h2>Qual é o seu main?</h2><p class='s'>O app sugeriu pela sua maestria e pelas suas partidas. Confirme ou troque: "
            "a escolha muda o fundo, as builds sugeridas, a rota padrão das páginas e o seu pool na seleção.</p>") if first else (
        "<h2>Seu main</h2><p class='s'>Vale para o fundo, as builds sugeridas, a rota padrão das páginas e o pool da seleção.</p>")
    return (f"<style>{CSS}</style><form method='post' action='/perfil/main' class='mp' id='main'>{head}"
            f"<div class='mp-g'>{cards}</div>"
            f"<div class='mp-r' role='group' aria-label='Rota principal'>{roles}</div>"
            "<div class='mp-f'><select name='outro' aria-label='Outro campeão'><option value=''>Outro campeão…</option>" + others + "</select>"
            "<button class='btn gold' style='width:auto'>Salvar meu main</button>"
            + ("<button class='btn ghost' style='width:auto' name='depois' value='1'>Agora não</button>" if first else "") + "</div></form>")
