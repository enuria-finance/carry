"""Dados oficiais do jogo (Data Dragon da Riot): campeoes, itens e runas.

Baixa uma vez por versao e guarda em cache/ ao lado do banco. Fonte oficial,
sem raspagem de sites.
"""
import json
import os
import urllib.request

BASE = "https://ddragon.leagueoflegends.com"
UA = "lol-coach/0.1 (app pessoal de estudo)"


def _default_fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode("utf-8"))


def clean(text):
    """Tira as marcas do cliente (<lol-uikit-...>, <br>, <b>...) dos textos do Data Dragon."""
    import re
    t = re.sub(r"<br\s*/?>", " ", text or "")
    t = re.sub(r"<[^>]+>", "", t)
    return re.sub(r"\s+", " ", t).strip()


import threading as _th
NOFETCH = _th.local()       # NOFETCH.on = True: nesta thread, so le o que ja esta no disco (o overlay nao espera download)


class DataDragon:
    def __init__(self, cache_dir="cache", fetch=_default_fetch, version=None):
        self.cache_dir = cache_dir
        self._fetch = fetch
        self._version = version
        self._mem = {}

    _SHARED = {}    # arquivos ja lidos (por pasta, versao e nome)
    _VER = {}       # versao atual guardada por 1 hora para todo o app (antes, cada tela perguntava a internet de novo)

    def version(self):
        if not self._version:
            import time
            hit = DataDragon._VER.get("v")
            if hit and time.time() - hit[0] < 3600:
                self._version = hit[1]
            else:
                try:
                    self._version = self._fetch(f"{BASE}/api/versions.json")[0]
                    DataDragon._VER["v"] = (time.time(), self._version)
                except Exception:
                    local = self._newest_local()
                    if not local:
                        raise
                    self._version = local
                    DataDragon._VER["v"] = (time.time() - 3300, local)     # sem internet: tenta de novo em 5 min
        return self._version

    def _newest_local(self):
        try:
            vs = [f.split("_", 1)[0] for f in os.listdir(self.cache_dir) if f.endswith("_champion.json")]
        except OSError:
            return None
        key = lambda v: tuple(int(x) if x.isdigit() else 0 for x in v.split("."))
        return max(vs, key=key) if vs else None

    def _get(self, name, path):
        if name in self._mem:
            return self._mem[name]
        os.makedirs(self.cache_dir, exist_ok=True)
        self.version()
        sk = (os.path.abspath(self.cache_dir), self._version, name)
        if sk in DataDragon._SHARED:
            self._mem[name] = DataDragon._SHARED[sk]
            return self._mem[name]
        f = os.path.join(self.cache_dir, f"{self._version or 'v'}_{name}.json")
        if self._version and os.path.exists(f):
            with open(f, encoding="utf-8") as fh:
                self._mem[name] = DataDragon._SHARED[sk] = json.load(fh)
                return self._mem[name]
        if getattr(NOFETCH, "on", False):
            raise RuntimeError(f"{name} ainda não baixado")
        data = self._fetch(f"{BASE}/cdn/{self.version()}/data/pt_BR/{path}")
        f = os.path.join(self.cache_dir, f"{self.version()}_{name}.json")
        with open(f, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
        self._mem[name] = data
        return data

    def champions(self):
        """{'Zed': {'key': 238, 'name': 'Zed'}, ...} (chave = ID do Data Dragon)."""
        raw = self._get("champion", "champion.json")["data"]
        return {k: {"key": int(v["key"]), "name": v["name"], "tags": v.get("tags", []), "info": v.get("info", {})}
                for k, v in raw.items()}

    def champion(self, champ_id):
        """Ficha completa: titulo, historia curta, dicas oficiais, habilidades e passiva."""
        data = self._get(f"champ_{champ_id}", f"champion/{champ_id}.json")["data"]
        return data.get(champ_id) or next(iter(data.values()))

    def skins(self, champ_id):
        """[(num, nome)] das skins de um campeao (inclui a padrao, num 0)."""
        data = self._get(f"champ_{champ_id}", f"champion/{champ_id}.json")["data"]
        c = data.get(champ_id) or next(iter(data.values()))
        return [(int(sk["num"]), sk["name"] if sk["num"] else "Padrão") for sk in c.get("skins", [])
                if "parentSkin" not in sk and not (sk["num"] and "(" in sk["name"] and sk["name"].endswith(")"))]  # sem chromas

    def champion_by_key(self):
        return {v["key"]: k for k, v in self.champions().items()}

    def items(self):
        return self._get("item", "item.json")["data"]

    def runes(self):
        return self._get("runes", "runesReforged.json")

    def rune_names(self):
        """{id: nome} para estilos e runas."""
        names = {}
        for style in self.runes():
            names[style["id"]] = style["name"]
            for slot in style["slots"]:
                for r in slot["runes"]:
                    names[r["id"]] = r["name"]
        return names

    def spells(self):
        """{numero: {'id': 'SummonerFlash', 'name': 'Salto Cintilante'}} (feiticos de invocador)."""
        raw = self._get("summoner", "summoner.json")["data"]
        return {int(v["key"]): {"id": v["id"], "name": v["name"]} for v in raw.values()}

    def rune_info(self):
        """{id: {'name', 'icon', 'desc'}} para estilos e runas (icon = caminho no CDN)."""
        info = {}
        for style in self.runes():
            info[style["id"]] = {"name": style["name"], "icon": style.get("icon"), "desc": ""}
            for slot in style["slots"]:
                for r in slot["runes"]:
                    info[r["id"]] = {"name": r["name"], "icon": r.get("icon"), "desc": clean(r.get("shortDesc", ""))}
        return info
