"""Acabamento do visual (vem por ultimo): menos "duro", mais leve e profissional.

- cantos arredondados, bordas finas e sombras suaves (sem moldura dupla em tudo)
- Cinzel so nos titulos grandes; o resto em Inter Tight, sem caixa-alta forcada
- marcas dado/regra/hipotese pequenas e discretas; avisos de amostra em tom baixo
- sem inclinacao 3D nos cartoes; movimento so onde explica algo
- dicas flutuantes (tooltip) em itens, runas e habilidades: [data-tip]
"""

CSS = """
/* ========= POLISH ========= */
:root{--head:"Inter Tight","Segoe UI",system-ui,sans-serif;--title:"Cinzel","Times New Roman",serif;--r-card:12px;--r-btn:8px;--line-soft:rgba(200,170,110,.14);--line-hover:rgba(200,170,110,.38);
--panel-a:rgba(18,28,42,.78);--panel-b:rgba(9,17,28,.86)}
.card,.kpi,.trend,.lv-card,.ccol,.gp-card,.dcard2,.drawer,.lchip,.urow,.pchamp,.mst,.thr,.vsc,.tile,.gcard,.dcard,.mcard,.sstat,.eloh,.coach,.gplan,
.lv-top,.arena,.dmore,.rankbox,.ab2,.combo,.tline,.aian,.aian-cta,.chc,.itrow,.ovl,.empty,.alert,.jobbar,.gp-mini,.lv-step,.lv-now,.cidea,.tl-c,.pico,.exr,
.mrow,.step,.pcard,.met,.slot,.hst,.phero,.pk,.chero,.banner,.mhero,.dhero,.phero2,.maincard,.hero,.tip,.urow,.qrow{border-radius:var(--r-card) !important}
.card,.kpi,.trend,.lv-card,.ccol,.gp-card,.dcard2,.drawer,.lchip,.urow,.pchamp,.mst,.thr,.vsc,.tile,.gcard,.dcard,.mcard,.sstat,.eloh,.coach,.gplan,
.lv-top,.arena,.dmore,.rankbox,.ab2,.combo,.tline{border:1px solid var(--line-soft) !important;
background:linear-gradient(180deg,var(--panel-a),var(--panel-b)) !important;box-shadow:0 10px 30px rgba(0,0,0,.22) !important}
a.card:hover,a.mcard:hover,a.dcard:hover,a.pchamp:hover,a.tile:hover,a.gcard:hover,.chc:hover,a.mrow:hover{border-color:var(--line-hover) !important}
.banner,.mhero,.dhero,.phero2,.chero{border:1px solid rgba(200,170,110,.32) !important;box-shadow:0 20px 50px rgba(0,0,0,.4) !important;overflow:hidden}
.banner::before,.mhero::before,.dhero::after,.phero2::after{opacity:.65}
.pill,.badge,.chip,.gstep,.m-k,.mchk{border-radius:999px !important}
.tip{background:rgba(9,17,28,.6) !important;border:1px solid var(--line-soft) !important;border-left:2px solid var(--line-soft) !important}
/* tipografia: Cinzel so na marca e nos titulos curtos; frases em Inter Tight */
.brand,.auth-box .brand,.banner h1,.ch-n,.pname b{font-family:var(--title) !important}
.m-t,.dh-t{font-weight:800 !important;letter-spacing:-.02em !important}
.dcard2 header b{font-weight:700 !important;font-size:19px !important}
/* tipografia mais leve */
h2{font:600 16px/1.3 var(--body) !important;letter-spacing:0 !important;color:#eadfc6 !important;text-transform:none !important}
h2::before{width:7px;height:7px;opacity:.8}
.gl,b.gl{font:600 13.5px var(--body) !important;letter-spacing:.01em !important;color:var(--gold) !important;text-transform:none !important}
.kl,.kpi small.kl{font:500 12.5px var(--body) !important;letter-spacing:0 !important;text-transform:none !important;color:#9aa4b8 !important}
.kv,.kpi b,.trend b,.gapn,.lv-clock b,.cscore,.dh-gap,.hst b,.m-streak>b{font-family:var(--body) !important;font-weight:700 !important;font-variant-numeric:tabular-nums;letter-spacing:-.01em}
.bn-k,.dh-k,.pname small,.gp-head small,.ch-in>small{font:600 12px var(--body) !important;letter-spacing:.12em !important}
.n{color:#8f99ad}.tag{font:600 10px var(--body) !important;letter-spacing:.06em !important;opacity:.85}
.tip{display:block !important;padding:10px 14px !important}.tip .tag{display:inline-flex !important;margin:0 8px 2px 0;padding:0 !important;vertical-align:1px}
.tip>div{display:inline}
/* botoes: sem caixa-alta e mais macios */
button,.btn{border-radius:var(--r-btn) !important;font:600 13.5px var(--body) !important;letter-spacing:.01em !important;text-transform:none !important;padding:10px 16px !important}
.btn.gold,button.btn.gold{font-weight:700 !important}
.syncbtn{border-radius:var(--r-btn) !important}
.ctab{padding:12px 16px !important}.rtabs .tb{padding:8px 10px !important}.rolef{padding:7px 12px !important}.sug{padding:7px 12px !important}
input,select,textarea{border-radius:var(--r-btn) !important}
/* menu */
.rail a{border-radius:8px !important}
/* sem inclinacao 3D: so um leve brilho */
.kpi,.champ,.pk,.pcard,.vsc,.mcard,.thr,.step,.dcard{transform:none !important}
/* dica flutuante */
.tipbox{position:fixed;z-index:9999;max-width:320px;padding:12px 14px;border-radius:10px;background:rgba(5,12,20,.97);border:1px solid rgba(200,170,110,.45);
box-shadow:0 16px 40px rgba(0,0,0,.55);color:#EEE6DB;font:13px/1.5 var(--body);pointer-events:none;opacity:0;transform:translateY(4px);transition:opacity .12s,transform .12s}
.tipbox.on{opacity:1;transform:none}.tipbox b{display:block;color:#fff;font-size:14px;margin-bottom:2px}.tipbox em{display:block;font-style:normal;color:var(--gold);font-size:12px;margin-bottom:6px}
[data-tip]{cursor:help}
"""

JS = r"""<script>(function(){if(window.__tipbox)return;window.__tipbox=1;var box=document.createElement('div');box.className='tipbox';document.body.appendChild(box);
var cur=null;function place(ev){var w=box.offsetWidth,h=box.offsetHeight,x=ev.clientX+16,y=ev.clientY+16;if(x+w>innerWidth-8)x=ev.clientX-w-16;if(y+h>innerHeight-8)y=ev.clientY-h-16;box.style.left=x+'px';box.style.top=y+'px'}
document.addEventListener('mouseover',function(ev){var t=ev.target.closest&&ev.target.closest('[data-tip]');if(t===cur)return;cur=t;if(!t){box.classList.remove('on');return}
box.innerHTML=t.getAttribute('data-tip');box.classList.add('on');place(ev)});
document.addEventListener('mousemove',function(ev){if(cur)place(ev)});document.addEventListener('scroll',function(){box.classList.remove('on');cur=null},true)})();</script>"""


def tip_attr(title, sub="", body=""):
    """Atributo data-tip seguro (o conteudo vai escapado; o navegador monta a dica)."""
    import html
    inner = f"<b>{html.escape(title or '')}</b>" + (f"<em>{html.escape(sub)}</em>" if sub else "") + (html.escape(body) if body else "")
    return f" data-tip=\"{html.escape(inner, quote=True)}\""
