"""Pecas de interface "de site de stats": tabelas que ordenam ao clicar, abas, filtros, barras.

- match_list: lista de partidas estilo deeplol (cor por resultado, itens, feiticos, runas, 10 jogadores, filtros)
- champ_table: seus campeoes em tabela ordenavel (jogos, vitoria, KDA, CS/min, ouro/min)
- rank_track: trilha das divisoes ate o proximo elo
- build_explorer: nucleo runa+item clicavel; runas, feiticos, iniciais, botas, ordem de habilidades e builds de 2 a 5 itens
- otp_table: especialistas (OTPs) do servidor em tabela ordenavel
- counters: 3 colunas (melhores escolhas, piores escolhas, quem ganha a rota no ouro aos 15) com "ver mais"

Tudo vem das partidas oficiais guardadas pelo app. Cada numero mostra quantos jogos tem por tras.
"""
import html
import json
import os
import sqlite3
import time
from collections import Counter

from . import builds, champview, db, icons
from .ddragon import clean
from .polish import tip_attr

e = lambda x: html.escape("" if x is None else str(x))
QUEUE = {420: "Ranqueada Solo", 440: "Ranqueada Flex", 400: "Normal", 430: "Normal", 450: "ARAM", 490: "Partida rápida", 1700: "Arena"}
ROLE_PT = champview.ROLE_PT
KEYS = ["Q", "W", "E", "R"]
_RAW = {}


# ---------------------------------------------------------------- utilidades
def _img(url, size, cls="", tip=""):
    if not url:
        return f"<span class='sx ph {cls}' style='width:{size}px;height:{size}px'></span>"
    return f"<img class='sx {cls}' src='{e(url)}' width='{size}' height='{size}' alt='' loading='lazy'{tip}>"


def item_img(ver, i, items, size=30):
    if not i:
        return f"<span class='sx ph it' style='width:{size}px;height:{size}px'></span>"
    it = items.get(str(i)) or {}
    cost = (it.get("gold") or {}).get("total")
    tip = tip_attr(it.get("name", str(i)), f"{cost} de ouro" if cost else "", clean(it.get("description") or it.get("plaintext") or "")[:360])
    return _img(f"{icons.CDN}/cdn/{ver}/img/item/{int(i)}.png" if ver else "", size, "it", tip)


def spell_img(ver, s, spells, size=22):
    sp = spells.get(s) or spells.get(str(s)) or {}
    return _img(f"{icons.CDN}/cdn/{ver}/img/spell/{sp['id']}.png" if ver and sp.get("id") else "", size, "sp", tip_attr(sp.get("name", "Feitiço")))


def rune_img(rid, info, size=22, cls="rn"):
    d = info.get(rid) or info.get(str(rid)) or {}
    return _img(f"{icons.CDN}/cdn/img/{d['icon']}" if d.get("icon") else "", size, cls, tip_attr(d.get("name", "Runa"), "", d.get("desc") or ""))


def ago(ms):
    s = max(0, time.time() - (ms or 0) / 1000)
    if s < 3600:
        return f"há {max(1, int(s // 60))} min"
    if s < 86400:
        return f"há {int(s // 3600)} h"
    d = int(s // 86400)
    return "ontem" if d == 1 else f"há {d} dias"


def wr_cls(p):
    return "hi" if p >= 55 else "ok" if p >= 50 else "lo"


def kda_cls(k):
    return "k5" if k >= 5 else "k3" if k >= 3 else "k2" if k >= 2 else "k1"


def _raw(con, mid):
    if mid in _RAW:
        return _RAW[mid]
    try:
        m = db.load_raw(con, mid, "match")
    except Exception:
        m = None
    if len(_RAW) > 600:
        _RAW.clear()
    _RAW[mid] = m
    return m


# ---------------------------------------------------------------- partidas
def match_list(con, puuid, games, dd):
    try:
        ver, items, spells, info = dd.version(), dd.items(), dd.spells(), dd.rune_info()
    except Exception:
        ver, items, spells, info = None, {}, {}, {}
    if not games:
        return "<div class='empty'><b>Nenhuma partida ainda</b><span>Clique em Sincronizar agora.</span></div>"
    last = games[:20]
    n, w = len(last), sum(1 for g in last if g["win"])
    k = sum(g["kills"] for g in last) / n
    d = sum(g["deaths"] for g in last) / n
    a = sum(g["assists"] for g in last) / n
    kd = (k + a) / max(d, 1)
    pct = round(100 * w / n)
    donut = (f"<svg viewBox='0 0 42 42' class='donut'><circle cx='21' cy='21' r='15.9' class='dn-b'/>"
             f"<circle cx='21' cy='21' r='15.9' class='dn-f' stroke-dasharray='{pct} {100 - pct}' stroke-dashoffset='25'/>"
             f"<text x='21' y='23.5'>{pct}%</text></svg>")
    by = {}
    for g in last:
        by.setdefault(g["champion"], []).append(g)
    top3 = sorted(by.items(), key=lambda kv: -len(kv[1]))[:3]
    champs = ""
    for c, gs in top3:
        cw = sum(1 for g in gs if g["win"])
        ck = sum(g["kills"] + g["assists"] for g in gs) / max(1, sum(g["deaths"] for g in gs))
        p = round(100 * cw / len(gs))
        champs += (f"<div class='mh-c'>{icons.champ(c, 30)}<span><b class='{wr_cls(p)}'>{p}%</b> <small>({cw}V {len(gs) - cw}D)</small>"
                   f"<em class='{kda_cls(ck)}'>{ck:.2f} KDA</em></span></div>")
    roles = Counter(g.get("position") for g in last if g.get("position"))
    rmax = max(roles.values()) if roles else 1
    rbars = "".join(f"<div class='mh-r'{tip_attr(ROLE_PT.get(r, r), f'{roles.get(r, 0)} jogos')}><i style='height:{100 * roles.get(r, 0) / rmax:.0f}%'></i><small>{e(ROLE_PT.get(r, r)[:3])}</small></div>"
                    for r in ("TOP", "JUNGLE", "MIDDLE", "BOTTOM", "UTILITY"))
    head = (f"<div class='mhead'><div class='mh-box mh-sum'>{donut}<div><b>{n} jogos</b><small>{w}V {n - w}D</small>"
            f"<span class='{kda_cls(kd)}'>{kd:.2f} KDA</span><small>{k:.1f} / <i class='loss'>{d:.1f}</i> / {a:.1f}</small></div></div>"
            f"<div class='mh-box'><small class='mh-l'>Campeões jogados</small>{champs}</div>"
            f"<div class='mh-box'><small class='mh-l'>Posições</small><div class='mh-rs'>{rbars}</div></div></div>")
    allc = sorted({g["champion"] for g in games})
    filt = ("<div class='mfilt'><div class='seg' data-f='res'><button type='button' class='on' data-v=''>Todas</button>"
            "<button type='button' data-v='1'>Vitórias</button><button type='button' data-v='0'>Derrotas</button></div>"
            "<select class='mf-c'><option value=''>Todos os campeões</option>"
            + "".join(f"<option value='{e(c)}'>{e(c)}</option>" for c in allc) + "</select><span class='n mf-n'></span></div>")
    rows, cur_day = "", None
    days = {}
    for g in games:
        dk = time.strftime("%Y-%m-%d", time.localtime((g["started_ms"] or 0) / 1000))
        days.setdefault(dk, []).append(g)
    for g in games:
        mid = g["match_id"]
        dk = time.strftime("%Y-%m-%d", time.localtime((g["started_ms"] or 0) / 1000))
        if dk != cur_day:
            cur_day = dk
            dg = days[dk]
            dw = sum(1 for x in dg if x["win"])
            rows += (f"<div class='mday' data-d='{dk}'><b>{ago(g['started_ms'])}</b><span>{len(dg)} jogos · {dw}V {len(dg) - dw}D</span>"
                     f"<span class='{wr_cls(round(100 * dw / len(dg)))}'>{round(100 * dw / len(dg))}%</span></div>")
        m = _raw(con, mid)
        info_m = (m or {}).get("info") or {}
        parts = info_m.get("participants") or []
        me = next((p for p in parts if p.get("puuid") == puuid), {})
        lvl = me.get("champLevel")
        its = [me.get(f"item{i}") for i in range(7)] if me else []
        ex = con.execute("SELECT items, perks, spells FROM participant_extra WHERE match_id=? AND participant_id=?", (mid, g["participant_id"])).fetchone()
        if not its and ex:
            its = (json.loads(ex["items"] or "[]") + [0] * 7)[:7]
        sps = [me.get("summoner1Id"), me.get("summoner2Id")] if me else (json.loads(ex["spells"] or "[]") if ex else [])
        perks = me.get("perks") if me else (json.loads(ex["perks"] or "{}") if ex else {})
        pg = builds.page_from_perks(perks or {})
        runes = (rune_img(pg[2][0], info, 24, "rk") + rune_img(pg[1], info, 18, "rs")) if pg else ""
        mins, secs = divmod(g["duration_s"] or 0, 60)
        kdr = (g["kills"] + g["assists"]) / max(g["deaths"], 1)
        kdtxt = "Perfeito" if g["deaths"] == 0 else f"{kdr:.2f} KDA"
        csm = g.get("cs_per_min") or 0
        kp = g.get("kp")
        q = QUEUE.get(info_m.get("queueId"), "Ranqueada")
        teams = {100: [], 200: []}
        for p in parts:
            nm = p.get("riotIdGameName") or p.get("summonerName") or ""
            teams.setdefault(p.get("teamId"), []).append(
                f"<span class='mp{' me' if p.get('puuid') == puuid else ''}'>{icons.champ(p.get('championName'), 16)}<em>{e(nm)}</em></span>")
        ppl = (f"<div class='mppl'><div>{''.join(teams.get(100, []))}</div><div>{''.join(teams.get(200, []))}</div></div>") if parts else "<div class='mppl'></div>"
        lvlb = f"<b class='mlv'>{lvl}</b>" if lvl else ""
        rows += (f"<div class='mrow2 {'v' if g['win'] else 'd'}' data-w='{1 if g['win'] else 0}' data-c='{e(g['champion'])}' data-d='{dk}'>"
                 f"<div class='ml-q'><b>{e(q)}</b><small>{ago(g['started_ms'])}</small><span class='ml-res'>{'Vitória' if g['win'] else 'Derrota'}</span>"
                 f"<small>{mins}:{secs:02d}</small></div>"
                 f"<div class='ml-ch'><a class='ml-ci' href='/campeao/{e(icons.champ_id(g['champion']))}'>{icons.champ(g['champion'], 52)}{lvlb}</a>"
                 f"<div class='ml-ss'>{''.join(spell_img(ver, s, spells) for s in sps[:2])}</div><div class='ml-rr'>{runes}</div></div>"
                 f"<div class='ml-k'><b>{g['kills']} / <i class='loss'>{g['deaths']}</i> / {g['assists']}</b><span class='{kda_cls(kdr)}'>{kdtxt}</span>"
                 f"<small>vs {icons.champ(g.get('opp_champion'), 16) if g.get('opp_champion') else ''} {e(g.get('opp_champion') or '')}</small></div>"
                 f"<div class='ml-it'>{''.join(item_img(ver, i, items, 28) for i in its[:6])}{item_img(ver, its[6] if len(its) > 6 else 0, items, 28)}</div>"
                 f"<div class='ml-st'><span><small>CS</small><b>{g['cs']} <i>({csm:.1f}/min)</i></b></span>"
                 f"<span><small>Part. abates</small><b>{'–' if kp is None else str(round(100 * kp)) + '%'}</b></span><span><small>Visão</small><b>{g['vision_score']}</b></span></div>"
                 f"{ppl}<div class='ml-act'><a href='/partida/{e(mid)}'>Pós-jogo</a><a href='/revisao/{e(mid)}'>Revisão</a></div></div>")
    js = """<script>(function(){var res='',ch='';var sel=document.querySelector('.mf-c');function f(){var n=0,w=0;var vis={};
document.querySelectorAll('.mrow2').forEach(function(r){var ok=(!res||r.dataset.w===res)&&(!ch||r.dataset.c===ch);r.hidden=!ok;if(ok){n++;w+=+r.dataset.w;vis[r.dataset.d]=1}});
document.querySelectorAll('.mday').forEach(function(d){d.hidden=!vis[d.dataset.d]});var o=document.querySelector('.mf-n');if(o)o.textContent=n?(n+' jogos · '+Math.round(100*w/n)+'% de vitória'):'nenhum jogo'}
document.querySelectorAll('.seg[data-f=res] button').forEach(function(b){b.onclick=function(){res=b.dataset.v;b.parentNode.querySelectorAll('button').forEach(function(x){x.classList.toggle('on',x===b)});f()}});
if(sel)sel.onchange=function(){ch=sel.value;f()};f()})();</script>"""
    return head + filt + f"<div class='mlist'>{rows}</div>" + js


# ---------------------------------------------------------------- perfil
def champ_table(games):
    by = {}
    for g in games:
        by.setdefault(g["champion"], []).append(g)
    if not by:
        return ""
    mx = max(len(v) for v in by.values())
    rows = ""
    for idx, (c, gs) in enumerate(sorted(by.items(), key=lambda kv: -len(kv[1]))):
        n = len(gs)
        w = sum(1 for g in gs if g["win"])
        k = sum(g["kills"] for g in gs) / n
        d = sum(g["deaths"] for g in gs) / n
        a = sum(g["assists"] for g in gs) / n
        kda = (k + a) / max(d, 0.1)
        csm = [g["cs_per_min"] for g in gs if g.get("cs_per_min")]
        gpm = [g["gold"] / (g["duration_s"] / 60) for g in gs if g.get("duration_s") and g.get("gold")]
        csv = sum(csm) / len(csm) if csm else 0
        gv = sum(gpm) / len(gpm) if gpm else 0
        p = round(100 * w / n)
        rows += (f"<tr{' class=xtra' if idx >= 10 else ''}><td data-v='{e(c)}'><a class='ct-c' href='/campeao/{e(icons.champ_id(c))}'>{icons.champ(c, 34)}<b>{e(c)}</b></a></td>"
                 f"<td data-v='{n}'><div class='ct-b'><span><i style='width:{100 * n / mx:.0f}%'></i></span><b>{n}</b></div></td>"
                 f"<td data-v='{p}'><div class='ct-b wr'><span><i class='{wr_cls(p)}' style='width:{p}%'></i></span><b class='{wr_cls(p)}'>{p}%</b></div><small>{w}V {n - w}D</small></td>"
                 f"<td data-v='{kda:.3f}'><b class='{kda_cls(kda)}'>{kda:.2f}</b><small><i class='win'>{k:.1f}</i> / <i class='loss'>{d:.1f}</i> / <i class='gold'>{a:.1f}</i></small></td>"
                 f"<td data-v='{csv:.2f}'>{csv:.1f}</td><td data-v='{gv:.0f}'>{gv:.0f}</td></tr>")
    return (f"<div class='card ctab-w'><table class='st ctbl'><thead><tr><th data-k='s'>Campeão</th><th data-k='n' class='desc'>Jogos</th>"
            f"<th data-k='n'>Vitória</th><th data-k='n'>KDA</th><th data-k='n'>CS/min</th><th data-k='n'>Ouro/min</th></tr></thead>"
            f"<tbody>{rows}</tbody></table>" + (f"<button type='button' class='cnt-more' onclick=\"var w=this.closest('.ctab-w');this.textContent=w.classList.toggle('open')?'Ver menos':'Ver todos os {len(by)} campeões'\">Ver todos os {len(by)} campeões</button>" if len(by) > 10 else "")
            + "<p class='n'>Clique no título de uma coluna para ordenar.</p></div>")


TIERS = ["IRON", "BRONZE", "SILVER", "GOLD", "PLATINUM", "EMERALD", "DIAMOND", "MASTER", "GRANDMASTER", "CHALLENGER"]
TIER_PT = {"IRON": "Ferro", "BRONZE": "Bronze", "SILVER": "Prata", "GOLD": "Ouro", "PLATINUM": "Platina", "EMERALD": "Esmeralda",
           "DIAMOND": "Diamante", "MASTER": "Mestre", "GRANDMASTER": "Grão-Mestre", "CHALLENGER": "Desafiante"}
DIVS = ["IV", "III", "II", "I"]


def rank_track(tier, division, lp):
    """Trilha 4 divisoes do elo atual + a primeira do proximo, com o PDL atual."""
    if not tier or tier not in TIERS or tier in ("MASTER", "GRANDMASTER", "CHALLENGER"):
        return ""
    nxt = TIERS[TIERS.index(tier) + 1]
    di = DIVS.index(division) if division in DIVS else 0
    steps = [(TIER_PT[tier][0] + str(4 - i), i < di, i == di) for i in range(4)] + [(TIER_PT[nxt][0] + ("4" if nxt not in ("MASTER",) else ""), False, False)]
    dots = ""
    for i, (lab, done, cur) in enumerate(steps):
        dots += f"<div class='rt-s{' done' if done else ''}{' cur' if cur else ''}'><i></i><small>{e(lab)}</small></div>"
    fill = (di + min(100, lp or 0) / 100) / 4 * 100
    return (f"<div class='rtrack'><div class='rt-h'><b>{e(TIER_PT[tier])} {e(division)}</b><span>{lp or 0} PDL</span>"
            f"<small>faltam {max(0, 100 - (lp or 0))} PDL para a próxima divisão</small></div>"
            f"<div class='rt-line'><span style='width:{fill:.1f}%'></span></div><div class='rt-ss'>{dots}</div></div>")


# ---------------------------------------------------------------- build
def _row_facts(con, r, items_data):
    buys = builds._purchases(con, r["match_id"], r["participant_id"])
    seen, boots, legend = [], None, []
    for t, i in buys:
        if t >= builds.START_MS and builds.is_complete(items_data, i) and i not in seen:
            seen.append(i)
            if "Boots" in items_data.get(str(i), {}).get("tags", []):
                boots = boots or i
            else:
                legend.append(i)
    perks = json.loads(r["perks"] or "{}")
    pg = builds.page_from_perks(perks)
    try:
        sp = tuple(sorted(x for x in json.loads(r.get("spells") or "[]") if x))
    except ValueError:
        sp = ()
    seq = [json.loads(dd).get("skillSlot") for (dd,) in con.execute(
        "SELECT data FROM events WHERE match_id=? AND pid=? AND type='SKILL_LEVEL_UP' ORDER BY t_ms", (r["match_id"], r["participant_id"]))]
    seq = [s for s in seq if s in (1, 2, 3, 4)]
    cnt, order = Counter(), []
    for s in seq:
        if s != 4:
            cnt[s] += 1
            if cnt[s] == 5 and s not in order:
                order.append(s)
    for s in (1, 2, 3):
        if s not in order:
            order.append(s)
    return {"win": r["win"], "page": pg, "start": builds.start_inventory(con, r["match_id"], r["participant_id"]) if buys else (),
            "legend": legend, "boots": boots, "spells": sp if len(sp) == 2 else None,
            "seq": tuple(seq[:11]) if len(seq) >= 11 else None, "max": tuple(order[:3]) if len(seq) >= 9 else None}


def _top(facts, keyf, k=3):
    c, w = Counter(), Counter()
    for f in facts:
        key = keyf(f)
        if key:
            c[key] += 1
            w[key] += f["win"]
    return [(key, n, w[key]) for key, n in c.most_common(k)]


def _wr(n, w):
    p = round(100 * w / n) if n else 0
    return f"<td class='num'>{n}</td><td class='num {wr_cls(p)}'>{p}%</td>"


def _pane(facts, ver, items, spells, info, data):
    if not facts:
        return "<p class='n'>Sem partidas.</p>"
    runes = _top(facts, lambda f: (f["page"][0], f["page"][1], tuple(f["page"][2][:6])) if f["page"] else None, 3)
    rt = "".join(f"<tr><td><div class='bx-rp'>{''.join(rune_img(i, info, 30 if j == 0 else 24, 'rk' if j == 0 else 'rn') for j, i in enumerate(sel[:4]))}"
                 f"<span class='bx-sep'></span>{''.join(rune_img(i, info, 24) for i in sel[4:6])}</div></td>{_wr(n, w)}</tr>"
                 for (p, s, sel), n, w in runes)
    sp = _top(facts, lambda f: f["spells"], 2)
    st = _top(facts, lambda f: f["start"] or None, 2)
    bo = _top(facts, lambda f: f["boots"], 2)
    tbl = lambda title, rows: (f"<div class='bx-t'><table class='bxt'><thead><tr><th>{title}</th><th>Jogos</th><th>Vitória</th></tr></thead><tbody>{rows}</tbody></table></div>")
    sp_rows = "".join(f"<tr><td>{''.join(spell_img(ver, s, spells, 30) for s in pair)}</td>{_wr(n, w)}</tr>" for pair, n, w in sp)
    st_rows = "".join(f"<tr><td>{''.join(item_img(ver, i, items, 30) for i in ids)}</td>{_wr(n, w)}</tr>" for ids, n, w in st)
    bo_rows = "".join(f"<tr><td>{item_img(ver, i, items, 30)}</td>{_wr(n, w)}</tr>" for i, n, w in bo)
    right = tbl("Feitiços", sp_rows or "<tr><td colspan=3 class='n'>–</td></tr>") + tbl("Itens iniciais", st_rows or "<tr><td colspan=3 class='n'>–</td></tr>") \
        + tbl("Botas", bo_rows or "<tr><td colspan=3 class='n'>–</td></tr>")
    # ordem de habilidades
    skl = _top(facts, lambda f: f["max"], 1)
    seqs = _top(facts, lambda f: f["seq"], 1)
    spl = data.get("spells") or [{}] * 4
    abi = lambda s, size=30: (f"<span class='bx-ab'>{_img(f'{icons.CDN}/cdn/{ver}/img/spell/' + ((spl[s - 1].get('image') or {}).get('full') or '') if ver and (spl[s - 1].get('image') or {}).get('full') else '', size)}<b>{KEYS[s - 1]}</b></span>")
    skill = ""
    if skl:
        (mx, n, w) = skl[0]
        chips = ""
        if seqs and seqs[0][1] >= 2:
            chips = "".join(f"<i class='k{s}'>{KEYS[s - 1]}</i>" for s in seqs[0][0])
        skill = (f"<div class='bx-sk'><div class='bx-h'>Ordem de habilidades</div><div class='bx-skr'><div class='bx-mx'>{'<em>›</em>'.join(abi(s) for s in mx)}</div>"
                 f"<div class='bx-seq'>{chips}</div><table class='bxt mini'><tr>{_wr(n, w)}</tr></table></div></div>")
    # builds de 2 a 5 itens
    tabs, panes = "", ""
    for k in (2, 3, 4, 5):
        tops = _top(facts, lambda f: tuple(f["legend"][:k]) if len(f["legend"]) >= k else None, 3)
        on = " on" if k == 3 else ""
        tabs += f"<button type='button' class='bx-tb{on}' data-k='{k}'>{k} itens</button>"
        body = "".join(f"<tr><td><div class='bx-ib'>{'<em>›</em>'.join(item_img(ver, i, items, 32) for i in ids)}</div></td>{_wr(n, w)}</tr>" for ids, n, w in tops) \
            or "<tr><td colspan=3 class='n'>Poucas partidas chegaram a esse número de itens.</td></tr>"
        panes += f"<table class='bxt bx-kp' data-k='{k}'{'' if on else ' hidden'}><thead><tr><th>Sequência de itens</th><th>Jogos</th><th>Vitória</th></tr></thead><tbody>{body}</tbody></table>"
    return (f"<div class='bx-g'><div class='bx-t'><table class='bxt'><thead><tr><th>Runas (primária · secundária)</th><th>Jogos</th><th>Vitória</th></tr></thead>"
            f"<tbody>{rt}</tbody></table></div><div class='bx-side'>{right}</div></div>{skill}"
            f"<div class='bx-items'><div class='bx-tbs'>{tabs}</div>{panes}</div>")


BX_JS = """<script>(function(){document.addEventListener('click',function(ev){var c=ev.target.closest('.bx-core');if(c){var x=c.closest('.bx');
x.querySelectorAll('.bx-core').forEach(function(b){b.classList.toggle('on',b===c)});x.querySelectorAll('.bx-pane').forEach(function(p){p.hidden=p.dataset.p!==c.dataset.p});return}
var t=ev.target.closest('.bx-tb');if(t){var p=t.closest('.bx-items');p.querySelectorAll('.bx-tb').forEach(function(b){b.classList.toggle('on',b===t)});
p.querySelectorAll('.bx-kp').forEach(function(q){q.hidden=q.dataset.k!==t.dataset.k})}})})();</script>"""


def build_explorer(con, rows, dd, data):
    if not rows:
        return None
    try:
        ver, info, items, spells = dd.version(), dd.rune_info(), dd.items(), dd.spells()
    except Exception:
        ver, info, items, spells = None, {}, {}, {}
    facts = [_row_facts(con, r, items) for r in rows]
    cores = _top(facts, lambda f: (f["page"][2][0], f["legend"][0]) if f["page"] and f["legend"] else None, 5)
    cores = [c for c in cores if c[1] >= 2] or cores[:2]
    n_all = len(facts)
    w_all = sum(f["win"] for f in facts)
    left = (f"<button type='button' class='bx-core on' data-p='0'><span class='bx-ci'>Resumo</span>{_wr(n_all, w_all).replace('td', 'span')}</button>")
    panes = f"<div class='bx-pane' data-p='0'>{_pane(facts, ver, items, spells, info, data)}</div>"
    for j, ((ks, it), n, w) in enumerate(cores, 1):
        sub = [f for f in facts if f["page"] and f["legend"] and f["page"][2][0] == ks and f["legend"][0] == it]
        left += (f"<button type='button' class='bx-core' data-p='{j}'><span class='bx-ci'>{rune_img(ks, info, 30, 'rk')}{item_img(ver, it, items, 30)}</span>"
                 f"{_wr(n, w).replace('td', 'span')}</button>")
        panes += f"<div class='bx-pane' data-p='{j}' hidden>{_pane(sub, ver, items, spells, info, data)}</div>"
    js = BX_JS
    return (f"<div class='bx'><div class='bx-left'><div class='bx-h'>Núcleo runa + 1º item</div><div class='bx-lh'><span>Jogos</span><span>Vitória</span></div>{left}"
            f"<p class='n'>Clique num núcleo para ver a build de quem joga assim.</p></div><div class='bx-main'>{panes}</div></div>"
            f"<p class='n'><span class='tag dado'>dado</span> {n_all} partidas dos melhores do servidor com este campeão nesta posição.</p>{js}")


# ---------------------------------------------------------------- OTPs
def otp_table(ddir, champ_key, champ_name, limit=25):
    p = os.path.join(ddir, "top.sqlite")
    if not os.path.exists(p):
        return ""
    con = sqlite3.connect(p)
    con.row_factory = sqlite3.Row
    try:
        if not con.execute("SELECT 1 FROM sqlite_master WHERE name='top_mastery'").fetchone():
            return ""
        rows = con.execute(
            """SELECT m.puuid, m.points, n.riot_id, t.tier, t.lp,
                      (SELECT champion_id FROM top_mastery x WHERE x.puuid=m.puuid ORDER BY points DESC LIMIT 1) AS best,
                      (SELECT SUM(points) FROM top_mastery x WHERE x.puuid=m.puuid) AS allp
               FROM top_mastery m LEFT JOIN top_names n USING(puuid) LEFT JOIN top_players t USING(puuid)
               WHERE m.champion_id=? ORDER BY m.points DESC LIMIT ?""", (int(champ_key), limit)).fetchall()
        stats = {}
        for r in con.execute("""SELECT puuid, COUNT(*) n, SUM(win) w, SUM(kills) k, SUM(deaths) d, SUM(assists) a FROM participants
                                WHERE champion=? GROUP BY puuid""", (champ_name,)):
            stats[r["puuid"]] = r
    except sqlite3.Error:
        return ""
    finally:
        con.close()
    if not rows:
        return ""
    from . import ranksimg
    out = ""
    for i, r in enumerate(rows, 1):
        rid = r["riot_id"] or "jogador do topo"
        nm, _, tag = rid.partition("#")
        tier = (r["tier"] or "").upper()
        emb = f"<img src='/static/ranks/{tier.lower()}.png' width='22' height='22' alt=''>" if tier and ranksimg.available(tier) else ""
        share = round(100 * r["points"] / r["allp"]) if r["allp"] else 0
        s = stats.get(r["puuid"])
        gw = f"<td class='num' data-v='{s['n']}'>{s['n']}</td>" if s else "<td class='num n' data-v='0'>–</td>"
        if s and s["n"]:
            p = round(100 * s["w"] / s["n"])
            kda = (s["k"] + s["a"]) / max(s["d"], 1)
            gw += f"<td class='num {wr_cls(p)}' data-v='{p}'>{p}%</td><td class='num {kda_cls(kda)}' data-v='{kda:.2f}'>{kda:.2f}</td>"
        else:
            gw += "<td class='num n' data-v='-1'>–</td><td class='num n' data-v='-1'>–</td>"
        out += (f"<tr data-mono='{1 if r['best'] == int(champ_key) else 0}'><td class='num' data-v='{i}'>{i}</td>"
                f"<td data-v='{e(nm.lower())}'><div class='otp-n'>{icons.champ(champ_name, 28)}<span><b>{e(nm)}</b><small>#{e(tag)}</small></span>"
                + ("<em class='mono'>Mono</em>" if r["best"] == int(champ_key) else "") + "</div></td>"
                f"<td data-v='{TIERS.index(tier) * 10000 + (r['lp'] or 0) if tier in TIERS else 0}'><span class='otp-t'>{emb}<b>{(r['lp'] or 0):,}</b> PDL</span></td>".replace(",", ".")
                + f"<td class='num' data-v='{r['points']}'>{r['points']:,}</td>".replace(",", ".")
                + f"<td data-v='{share}'><div class='ct-b'><span><i style='width:{share}%'></i></span><b>{share}%</b></div></td>{gw}</tr>")
    return (f"<div class='card otp'><div class='otp-h'><div class='seg' data-f='otp'><button type='button' class='on' data-v=''>Todos</button>"
            f"<button type='button' data-v='1'>Só monos</button></div><small class='n'>Brasil · Mestre ao Desafiante</small></div>"
            f"<table class='st otbl'><thead><tr><th data-k='n' class='asc'>#</th><th data-k='s'>Jogador</th><th data-k='n'>Elo</th><th data-k='n'>Maestria</th>"
            f"<th data-k='n'{tip_attr('Uso do campeão', '', 'Parte da maestria total do jogador que é com este campeão.')}>Uso</th>"
            f"<th data-k='n'>Jogos*</th><th data-k='n'>Vitória*</th><th data-k='n'>KDA*</th></tr></thead><tbody>{out}</tbody></table>"
            f"<p class='n'>* nas partidas que o app guardou desse jogador com {e(champ_name)}. Clique no título para ordenar.</p></div>"
            """<script>(function(){document.querySelectorAll('.seg[data-f=otp] button').forEach(function(b){b.onclick=function(){var v=b.dataset.v;
b.parentNode.querySelectorAll('button').forEach(function(x){x.classList.toggle('on',x===b)});document.querySelectorAll('.otbl tbody tr').forEach(function(r){r.hidden=v&&r.dataset.mono!==v})}})})();</script>""")


# ---------------------------------------------------------------- counters
def gold15(ddir, champ, pos):
    """{oponente: (jogos, soma da diferenca de ouro aos 15 do ponto de vista do oponente)}"""
    agg = {}
    for p in champview.sample_paths(ddir):
        con = sqlite3.connect(p)
        try:
            q = """SELECT o.champion, fo.gold - fa.gold FROM participants a JOIN participants o
                   ON o.match_id=a.match_id AND o.team_id<>a.team_id AND o.position=a.position
                   JOIN frames fa ON fa.match_id=a.match_id AND fa.participant_id=a.participant_id AND fa.minute=15
                   JOIN frames fo ON fo.match_id=o.match_id AND fo.participant_id=o.participant_id AND fo.minute=15
                   WHERE a.champion=? AND a.position=?"""
            for opp, diff in con.execute(q, (champ, pos)):
                n, s = agg.get(opp, (0, 0))
                agg[opp] = (n + 1, s + (diff or 0))
        except sqlite3.Error:
            pass
        finally:
            con.close()
    return agg


_SV = {'sw': 'M14.5 3.5l6 0 0 6-9.5 9.5-2.5-2.5 2-2-3-3-2 2-2.5-2.5z', 'sh': 'M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z', 'tg': 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zm0 4a5 5 0 1 1 0 10 5 5 0 0 1 0-10zm0 3a2 2 0 1 0 0 4 2 2 0 0 0 0-4z'}


def _ico(c):
    return f"<span class='cnt-i {c}'><svg viewBox='0 0 24 24' width='16' height='16'><path d='{_SV[c]}'/></svg></span>"


def _col(title, sub, icon_cls, items, fmt, bar_cls):
    if not items:
        return (f"<div class='cnt'><div class='cnt-h'>{_ico(icon_cls)}<div><b>{e(title)}</b><small>{e(sub)}</small></div></div>"
                "<p class='n' style='padding:10px 0'>Ainda sem confrontos suficientes.</p></div>")
    mx = max(abs(x[2]) for x in items) or 1
    rows = ""
    for i, (opp, n, val, extra) in enumerate(items[:10], 1):
        width = 100 * abs(val) / mx if bar_cls == "gold" else min(100, max(4, (val - 30) / 40 * 100))
        rows += (f"<a class='cnt-r{' more' if i > 5 else ''}' href='/campeao/{e(icons.champ_id(opp))}'><span class='cnt-n'>{i}</span>{icons.champ(opp, 34)}"
                 f"<span class='cnt-m'><b>{e(opp)}</b><small>{n} partidas{extra}</small></span><em class='{bar_cls}'>{fmt(val)}</em>"
                 f"<span class='cnt-b'><i class='{bar_cls}' style='width:{width:.0f}%'></i></span></a>")
    more = "<button type='button' class='cnt-more'>Ver mais</button>" if len(items) > 5 else ""
    return (f"<div class='cnt'><div class='cnt-h'>{_ico(icon_cls)}<div><b>{e(title)}</b><small>{e(sub)}</small></div></div>"
            f"{rows}{more}</div>")


def counters(mu, g15, name, pos, min_n=20):
    ok = [(o, n, w) for o, n, w in mu if n >= min_n]
    tot_n = sum(m[1] for m in mu)
    avg = 100 * sum(m[2] for m in mu) / tot_n if tot_n else 50
    # do ponto de vista de quem escolhe CONTRA o campeao
    vs = [(o, n, 100 * (n - w) / n) for o, n, w in ok]
    sv = {o: (n - w + 10) / (n + 20) for o, n, w in ok}          # ordena pelo suavizado: pouco jogo nao lidera
    best = sorted(vs, key=lambda x: -sv[x[0]])
    worst = sorted(vs, key=lambda x: sv[x[0]])
    delta = lambda v: f" · {'+' if (v - (100 - avg)) >= 0 else ''}{v - (100 - avg):.1f} vs média"
    best_i = [(o, n, v, delta(v)) for o, n, v in best if v > 50]
    worst_i = [(o, n, v, delta(v)) for o, n, v in worst if v < 50]
    gl = sorted(((o, n, s / n, "") for o, (n, s) in g15.items() if n >= min_n and s > 0), key=lambda x: -x[2])
    role = ROLE_PT.get(pos, "")
    js = """<script>(function(){document.addEventListener('click',function(ev){var b=ev.target.closest('.cnt-more');if(!b)return;var c=b.closest('.cnt');
var on=c.classList.toggle('open');b.textContent=on?'Ver menos':'Ver mais'})})();</script>"""
    head = (f"<p class='cnt-sum'>Melhores e piores escolhas contra {e(name)} no {e(role)}, pela taxa de vitória e pela vantagem de ouro aos 15 minutos"
            + (f". {', '.join(x[0] for x in best_i[:3])} vencem {e(name)} com mais frequência" if best_i else "")
            + (f"; {', '.join(x[0] for x in gl[:3])} ganham a rota com mais ouro" if gl else "") + ".</p>")
    return (head + "<div class='cnts'>"
            + _col(f"Melhores escolhas contra {name}", f"Maior taxa de vitória contra {name}.", "sw", best_i, lambda v: f"{v:.1f}%", "win")
            + _col(f"Piores escolhas contra {name}", f"Menor taxa de vitória contra {name}.", "sh", worst_i, lambda v: f"{v:.1f}%", "loss")
            + _col(f"Quem ganha a rota de {name}", "Mais ouro que ele aos 15 minutos.", "tg", gl, lambda v: f"+{v:.0f}", "gold")
            + f"</div><p class='n'><span class='tag dado'>dado</span> {tot_n} partidas nas amostras do app; entra quem tem {min_n} jogos ou mais.</p>{js}")


# ---------------------------------------------------------------- JS / CSS
SORT_JS = """<script>(function(){if(window.__st)return;window.__st=1;document.addEventListener('click',function(ev){var th=ev.target.closest('table.st th[data-k]');if(!th)return;
var tb=th.closest('table'),i=[].indexOf.call(th.parentNode.children,th),num=th.dataset.k==='n',asc=!th.classList.contains('asc');
if(th.classList.contains('desc')||th.classList.contains('asc'))asc=th.classList.contains('desc');else asc=!num;
tb.querySelectorAll('th').forEach(function(x){x.classList.remove('asc','desc')});th.classList.add(asc?'asc':'desc');
var body=tb.tBodies[0],rows=[].slice.call(body.rows);rows.sort(function(a,b){var x=a.cells[i].dataset.v,y=b.cells[i].dataset.v;
if(num){x=+x;y=+y}var r=x<y?-1:x>y?1:0;return asc?r:-r});rows.forEach(function(r){body.appendChild(r)})})})();</script>"""

CSS = """
/* ===== statsui ===== */
.sx{display:inline-block;vertical-align:middle;border-radius:6px;background:#0b1622}.sx.ph{border:1px solid #1d2a3a}
.sx.rn,.sx.rk,.sx.rs{border-radius:50%;background:#0a121c}.sx.rk{box-shadow:0 0 0 1px rgba(200,170,110,.6)}
.hi{color:#3fd6a5 !important}.ok{color:#EEE6DB}.lo{color:#ff6b7a !important}
.k5{color:#ff9d3c !important}.k3{color:#4fb3ff !important}.k2{color:#3fd6a5 !important}.k1{color:#9aa4b8 !important}
.seg{display:inline-flex;border:1px solid var(--line-soft,#2a3546);border-radius:10px;overflow:hidden;background:rgba(9,17,28,.6)}
.seg button{all:unset;cursor:pointer;padding:8px 14px !important;font:600 13px var(--body) !important;color:#9aa4b8 !important;background:transparent !important;border:0 !important;border-right:1px solid var(--line-soft,#2a3546) !important;border-radius:0 !important;box-shadow:none !important}
.seg button:last-child{border-right:0 !important}.seg button.on{background:linear-gradient(180deg,rgba(200,170,110,.28),rgba(200,170,110,.12)) !important;color:#fff !important}
.seg button:hover{color:#fff !important}
.ctab:hover,.ctab:focus{border-top:0 !important;border-left:0 !important;border-right:0 !important;background:none !important}
.ctab:hover,.ctab:focus,.seg button:hover,.bx-core:hover,.bx-tb:hover,.cnt-more:hover{box-shadow:none !important;filter:none !important;transform:none !important}
.seg button::after,.seg button::before,.bx-core::after,.bx-core::before,.bx-tb::after,.bx-tb::before,.cnt-more::after,.cnt-more::before{display:none !important}
/* cabecalho das partidas */
.mhead{display:grid;grid-template-columns:1.2fr 1.4fr 1fr;gap:12px;margin:0 0 14px}
.mh-box{padding:14px 16px;border:1px solid var(--line-soft);border-radius:12px;background:linear-gradient(180deg,var(--panel-a),var(--panel-b))}
.mh-sum{display:flex;align-items:center;gap:16px}.mh-sum b{display:block;font:700 18px var(--body);color:#fff}.mh-sum small{display:block;color:#9aa4b8;font-size:12.5px}
.mh-sum span{display:block;font:700 16px var(--body);margin-top:6px}
.donut{width:86px;height:86px;flex:none}.dn-b{fill:none;stroke:#ff6b7a;stroke-width:4.5;opacity:.85}.dn-f{fill:none;stroke:#4fb3ff;stroke-width:4.5}
.donut text{fill:#fff;font:700 8px var(--body);text-anchor:middle}
.mh-l{display:block;color:#9aa4b8;font-size:12px;margin-bottom:6px}
.mh-c{display:flex;align-items:center;gap:10px;margin:5px 0}.mh-c .cic{border-radius:50%}.mh-c span{font-size:13px}.mh-c small{color:#9aa4b8}.mh-c em{font-style:normal;margin-left:8px;font-weight:600;font-size:12.5px}
.mh-rs{display:flex;align-items:flex-end;gap:12px;height:86px}.mh-r{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%;gap:4px}
.mh-r i{display:block;width:100%;max-width:22px;min-height:3px;border-radius:4px 4px 0 0;background:linear-gradient(180deg,#4fb3ff,#2a6fc0)}.mh-r small{font-size:10.5px;color:#9aa4b8}
.mfilt{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:0 0 12px}.mfilt select{width:auto;min-width:200px;padding:8px 12px}
.mday{display:flex;gap:14px;align-items:baseline;padding:14px 4px 6px;font-size:13px;color:#9aa4b8}.mday b{color:#EEE6DB;font-size:13.5px}.mday[hidden]{display:none}
.mlist{display:flex;flex-direction:column;gap:6px}
.mrow2{display:grid;grid-template-columns:118px 120px 128px minmax(124px,auto) 150px minmax(220px,1fr) 92px;gap:14px;align-items:center;padding:10px 12px 10px 16px;
border-radius:12px;position:relative;border:1px solid transparent;overflow:hidden}
.mrow2[hidden]{display:none}
.mrow2::before{content:'';position:absolute;left:0;top:0;bottom:0;width:5px}
.mrow2.v{background:linear-gradient(90deg,rgba(40,90,170,.32),rgba(20,40,80,.28));border-color:rgba(79,179,255,.22)}.mrow2.v::before{background:#4fb3ff}
.mrow2.d{background:linear-gradient(90deg,rgba(150,40,55,.32),rgba(70,20,30,.28));border-color:rgba(255,107,122,.22)}.mrow2.d::before{background:#ff6b7a}
.mrow2:hover{filter:brightness(1.12)}
.ml-q b{display:block;font:700 13px var(--body);color:#fff}.mrow2.v .ml-q b{color:#7cc6ff}.mrow2.d .ml-q b{color:#ff8f9b}
.ml-q small{display:block;color:#a9b2c4;font-size:11.5px}.ml-res{display:block;margin-top:6px;font:600 12.5px var(--body);color:#EEE6DB}
.ml-ch{display:grid;grid-template-columns:52px 24px 24px;gap:4px;align-items:center}
.ml-ci{position:relative;display:block;width:52px;height:52px}.ml-ci .cic{border-radius:12px}
.mlv{position:absolute;right:-4px;bottom:-4px;min-width:20px;height:20px;border-radius:10px;background:#010a13;border:1px solid rgba(200,170,110,.6);font:700 11px/18px var(--body);color:#fff;text-align:center}
.ml-ss,.ml-rr{display:flex;flex-direction:column;gap:4px;align-items:center}
.ml-k b{display:block;font:700 17px var(--body);color:#fff;letter-spacing:.02em}.ml-k b i{font-style:normal}.ml-k span{display:block;font:600 12.5px var(--body)}
.ml-k small{display:flex;align-items:center;gap:4px;color:#a9b2c4;font-size:11.5px;margin-top:4px}.ml-k small .cic{border-radius:50%}
.ml-it{display:grid;grid-template-columns:repeat(4,28px);gap:3px}.ml-it .sx{border-radius:5px}
.ml-st{display:flex;flex-direction:column;gap:3px}.ml-st b{font-weight:600;white-space:nowrap}.ml-st span{display:grid;grid-template-columns:76px auto;gap:6px;font:600 12.5px var(--body);color:#EEE6DB}.ml-st small{color:#a9b2c4;font-weight:500}.ml-st i{font-style:normal;color:#a9b2c4;font-weight:500}
.mppl{display:grid;grid-template-columns:1fr 1fr;gap:0 10px;min-width:0}.mppl>div{display:flex;flex-direction:column;gap:1px;min-width:0}
.mp{display:flex;align-items:center;gap:5px;font-size:11.5px;color:#a9b2c4;min-width:0}.mp em{font-style:normal;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mp .cic{border-radius:4px;flex:none}.mp.me em{color:#fff;font-weight:700}
.ml-act{display:flex;flex-direction:column;gap:6px}
.ml-act a{display:flex;align-items:center;justify-content:center;height:32px;border-radius:8px;font:600 12.5px var(--body);text-decoration:none;color:#EEE6DB;
background:rgba(1,10,19,.45);border:1px solid rgba(255,255,255,.14)}.ml-act a:hover{border-color:var(--gold);color:#fff}
.ml-act a+a{color:#7fe3ff;border-color:rgba(127,227,255,.35)}
@media (max-width:1250px){.mrow2{grid-template-columns:110px 120px 120px auto 1fr 92px}.mppl{display:none}}
@media (max-width:820px){.mhead{grid-template-columns:1fr}.mrow2{grid-template-columns:1fr 1fr;gap:10px}.ml-act{flex-direction:row;grid-column:1/-1}.ml-act a{flex:1}}
/* tabela ordenavel */
table.st{width:100%;border-collapse:collapse}table.st th{text-align:left;font:600 12px var(--body);color:#9aa4b8;padding:10px 10px;border-bottom:1px solid var(--line-soft);cursor:pointer;user-select:none;white-space:nowrap}
table.st th:hover{color:#fff}table.st th.asc::after{content:' ▲';font-size:9px;color:var(--gold)}table.st th.desc::after{content:' ▼';font-size:9px;color:var(--gold)}
table.st td{padding:9px 10px;border-bottom:1px solid rgba(255,255,255,.05);font:500 13.5px var(--body);color:#EEE6DB;vertical-align:middle}
table.st tbody tr:hover{background:rgba(200,170,110,.05)}table.st td small{display:block;color:#9aa4b8;font-size:11.5px}table.st td i{font-style:normal}
td.num{font-variant-numeric:tabular-nums}
.ct-c{display:flex;align-items:center;gap:10px;color:#fff;text-decoration:none}.ct-c .cic{border-radius:8px}.ct-c b{font-weight:700}
.ct-b{display:flex;align-items:center;gap:10px}.ct-b span{flex:1;max-width:120px;height:8px;border-radius:4px;background:rgba(255,255,255,.07);overflow:hidden}
.ct-b span i{display:block;height:100%;border-radius:4px;background:linear-gradient(90deg,#2a6fc0,#4fb3ff)}.ct-b.wr span i.hi{background:#3fd6a5}.ct-b.wr span i.ok{background:#8fa3c4}.ct-b.wr span i.lo{background:#ff6b7a}
.ct-b b{min-width:38px;font-variant-numeric:tabular-nums}
.ctab-w:not(.open) tr.xtra{display:none}
/* trilha de elo */
.rtrack{padding:16px 18px;border:1px solid var(--line-soft);border-radius:12px;background:linear-gradient(180deg,var(--panel-a),var(--panel-b));margin:0 0 16px}
.rt-h{display:flex;gap:12px;align-items:baseline;flex-wrap:wrap}.rt-h b{font:700 18px var(--body);color:#fff}.rt-h span{color:var(--gold);font-weight:700}.rt-h small{color:#9aa4b8;margin-left:auto}
.rt-line{position:relative;height:6px;border-radius:3px;background:rgba(255,255,255,.08);margin:18px 12px 0}.rt-line span{position:absolute;inset:0 auto 0 0;border-radius:3px;background:linear-gradient(90deg,#3fd6a5,#4fb3ff)}
.rt-ss{display:flex;justify-content:space-between;margin:-12px 0 0}.rt-s{display:flex;flex-direction:column;align-items:center;gap:6px;width:24px}
.rt-s i{width:18px;height:18px;border-radius:50%;background:#0b1622;border:2px solid #3a4658}.rt-s.done i{background:#3fd6a5;border-color:#3fd6a5}
.rt-s.cur i{background:#4fb3ff;border-color:#bfe3ff;box-shadow:0 0 12px rgba(79,179,255,.7)}.rt-s small{font:600 11.5px var(--body);color:#9aa4b8}.rt-s.cur small{color:#fff}
/* build */
.bx{display:grid;grid-template-columns:230px minmax(0,1fr);gap:12px;margin:6px 0 8px}
.bx-left,.bx-t,.bx-sk,.bx-items{border:1px solid var(--line-soft);border-radius:12px;background:linear-gradient(180deg,var(--panel-a),var(--panel-b));overflow:hidden}
.bx-left{padding-bottom:10px}.bx-left .n{padding:8px 12px 0;font-size:12px}
.bx-h{padding:10px 12px;font:600 13px var(--body);color:#fff;border-bottom:1px solid var(--line-soft)}
.bx-lh{display:grid;grid-template-columns:1fr 46px 50px;padding:6px 12px;font-size:11.5px;color:#9aa4b8}.bx-lh span:first-child{grid-column:2}
.bx-core{all:unset;cursor:pointer;display:grid !important;grid-template-columns:1fr 46px 50px;align-items:center;width:100%;box-sizing:border-box;padding:8px 12px !important;
border:0 !important;border-left:3px solid transparent !important;border-radius:0 !important;background:transparent !important;box-shadow:none !important;font:600 13px var(--body) !important;color:#EEE6DB !important}
.bx-core:hover{background:rgba(255,255,255,.04) !important}.bx-core.on{background:rgba(63,214,165,.10) !important;border-left-color:#3fd6a5 !important}
.bx-ci{display:flex;gap:4px;align-items:center}.bx-core span.num{text-align:center;font-size:12.5px}
.bx-main{min-width:0}.bx-pane[hidden]{display:none}
.bx-g{display:grid;grid-template-columns:minmax(0,1.25fr) minmax(0,1fr);gap:12px}.bx-side{display:flex;flex-direction:column;gap:12px}
table.bxt{width:100%;border-collapse:collapse}table.bxt th{text-align:left;font:600 12px var(--body);color:#9aa4b8;padding:9px 12px;border-bottom:1px solid var(--line-soft)}
table.bxt th:not(:first-child),table.bxt td.num{text-align:center;width:62px}
table.bxt td{vertical-align:middle;padding:8px 12px;border-bottom:1px solid rgba(255,255,255,.05);font:600 13px var(--body);color:#EEE6DB}table.bxt td .sx{margin-right:4px}
table.bxt tr:last-child td{border-bottom:0}table.bxt.mini{width:auto;margin-left:auto}table.bxt.mini td{border:0;padding:0 8px}
.bx-rp{display:flex;align-items:center;gap:5px}.bx-sep{width:1px;height:24px;background:var(--line-soft);margin:0 6px}
.bx-sk{margin:12px 0}.bx-skr{display:flex;align-items:center;gap:18px;flex-wrap:wrap;padding:10px 12px}
.bx-mx{display:flex;align-items:center;gap:8px}.bx-mx em{font-style:normal;color:var(--gold);font-weight:800}
.bx-ab{position:relative;display:inline-block}.bx-ab b{position:absolute;right:-4px;bottom:-4px;background:#010a13;border:1px solid var(--gold);border-radius:4px;font:700 10px var(--body);color:var(--gold);padding:0 3px}
.bx-seq{display:flex;gap:4px;flex:1;flex-wrap:wrap}.bx-seq i{width:26px;height:26px;display:flex;align-items:center;justify-content:center;border-radius:6px;font:700 12px var(--body);font-style:normal;background:#0b1622;border:1px solid #23324a;color:#cfd7e6}
.bx-seq i.k1{color:#3fd6a5;border-color:rgba(63,214,165,.5)}.bx-seq i.k2{color:#4fb3ff;border-color:rgba(79,179,255,.5)}.bx-seq i.k3{color:#ff9d3c;border-color:rgba(255,157,60,.5)}
.bx-seq i.k4{background:linear-gradient(180deg,#e2c792,#b8923f);color:#1a1405;border-color:#f0e6d2}
.bx-tbs{display:grid;grid-template-columns:repeat(4,1fr);border-bottom:1px solid var(--line-soft)}
.bx-tb{all:unset;cursor:pointer;text-align:center;padding:11px 0 !important;font:600 13.5px var(--body) !important;color:#9aa4b8 !important;background:transparent !important;border:0 !important;border-bottom:2px solid transparent !important;border-radius:0 !important;box-shadow:none !important}
.bx-tb.on{color:#fff !important;border-bottom-color:#3fd6a5 !important;background:rgba(63,214,165,.07) !important}.bx-tb:hover{color:#fff !important}
.bx-ib{display:flex;align-items:center;gap:6px}.bx-ib em{font-style:normal;color:#5d6a80}.bx-kp[hidden]{display:none}
@media (max-width:1000px){.bx,.bx-g{grid-template-columns:1fr}}
/* otp */
.otp-h{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:8px;flex-wrap:wrap}
.otp-n{display:flex;align-items:center;gap:10px}.otp-n .cic{border-radius:6px}.otp-n b{display:block;color:#fff}.otp-n small{display:inline;color:#9aa4b8}
.mono{font-style:normal;font:700 10.5px var(--body);padding:2px 8px;border-radius:999px;background:rgba(200,170,110,.18);color:var(--gold);border:1px solid rgba(200,170,110,.4)}
.otp-t{display:inline-flex;align-items:center;gap:6px}.otp-t b{color:#fff}.otbl tr[hidden]{display:none}
/* counters */
.cnt-sum{color:#D6CCC0;max-width:80ch;line-height:1.6;margin:0 0 14px}
.cnts{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
.cnt{padding:14px 16px 10px;border:1px solid var(--line-soft);border-radius:12px;background:linear-gradient(180deg,var(--panel-a),var(--panel-b))}
.cnt-h{display:flex;gap:12px;align-items:flex-start;margin-bottom:10px}.cnt-h b{display:block;font:700 14px var(--body);color:#fff}.cnt-h small{color:#9aa4b8;font-size:12px}
.cnt-i{flex:none;width:30px;height:30px;border-radius:8px;border:1px solid;display:flex;align-items:center;justify-content:center}.cnt-i path{fill:none;stroke:currentColor;stroke-width:1.8;stroke-linejoin:round}.cnt-i.sw{color:#c9a7ff}.cnt-i.sh{color:#ff8f9b}.cnt-i.tg{color:#f2c94c}.cnt-i.sw{border-color:rgba(167,139,250,.5);background:rgba(167,139,250,.12)}
.cnt-i.sh{border-color:rgba(255,107,122,.5);background:rgba(255,107,122,.12)}.cnt-i.tg{border-color:rgba(233,196,106,.5);background:rgba(233,196,106,.12)}
.cnt-r{display:grid;grid-template-columns:16px 34px minmax(0,1fr) auto;grid-template-rows:auto 6px;column-gap:10px;row-gap:5px;align-items:center;padding:8px 0;
border-top:1px solid rgba(255,255,255,.05);text-decoration:none;color:inherit}
.cnt-r:hover b{color:var(--gold)}.cnt-r .cic{grid-row:1/3;border-radius:8px}.cnt-n{grid-row:1/3;color:#6d7890;font-size:12px}
.cnt-m b{display:block;color:#fff;font-size:13.5px}.cnt-m small{color:#9aa4b8;font-size:11.5px}
.cnt-r em{font-style:normal;font:700 14px var(--body);font-variant-numeric:tabular-nums}.cnt-r em.win{color:#3fd6a5}.cnt-r em.loss{color:#ff6b7a}.cnt-r em.gold{color:#f2c94c}
.cnt-b{grid-column:3/5;height:5px;border-radius:3px;background:rgba(255,255,255,.07);overflow:hidden}.cnt-b i{display:block;height:100%;border-radius:3px}
.cnt-b i.win{background:#3fd6a5}.cnt-b i.loss{background:#ff6b7a}.cnt-b i.gold{background:#f2c94c}
.cnt-r.more{display:none}.cnt.open .cnt-r.more{display:grid}
.cnt-more{all:unset;cursor:pointer;display:block !important;width:100%;text-align:center;padding:8px 0 2px !important;color:#D6CCC0 !important;background:transparent !important;border:0 !important;box-shadow:none !important;font:600 12.5px var(--body) !important}
.cnt-more:hover{color:#fff}
@media (max-width:1000px){.cnts{grid-template-columns:1fr}}
"""


def rune_options(con, rows, dd, max_pages=4):
    """Bloco 'Opções de runas': as paginas mais usadas + qual runa os melhores usam contra cada tipo de oponente."""
    from . import builds
    try:
        info, champs = dd.rune_info(), dd.champions()
    except Exception:
        info, champs = {}, {}
    pages = builds.keystone_stats(rows)
    if not pages:
        return ""
    nm = lambda i: (info.get(i) or info.get(str(i)) or {}).get("name", str(i))

    def page_cell(page):
        prim, sub, sel = page
        return (f"<div class='ro-p'>{rune_img(sel[0], info, 34, 'rk')}<div><b>{e(nm(sel[0]))}</b>"
                f"<small>{e(nm(prim))} + {e(nm(sub))}</small></div><div class='ro-mini'>"
                + "".join(rune_img(i, info, 20) for i in sel[1:6]) + "</div></div>")
    total = sum(n for _, n, _ in pages)
    rows_html = "".join(f"<tr><td>{page_cell(p)}</td><td class='num'>{n}</td><td class='num'>{round(100 * n / total)}%</td>"
                        f"<td class='num {'win' if w / n >= .5 else 'loss'}'>{round(100 * w / n)}%</td></tr>" for p, n, w in pages[:max_pages])
    by, counts = builds.runes_by_opponent(con, rows, champs)
    vs = ""
    for key, label, _ in builds.OPP_CLASS:
        st = by.get(key)
        if not st or counts.get(key, 0) < 4:
            continue
        b = builds.best_page(st)
        if not b:
            continue
        p, n, w = b
        vs += (f"<tr><td><span class='ro-k'>Contra {e(label.lower())}</span></td><td>{page_cell(p)}</td>"
               f"<td class='num'>{n}/{counts[key]}</td><td class='num {'win' if w / n >= .5 else 'loss'}'>{round(100 * w / n)}%</td></tr>")
    out = ("<div class='ro'><div class='ro-b'><b class='gl'>Opções de runa (pela runa principal)</b><table class='ro-t'><thead><tr><th>Página</th><th>Jogos</th><th>Uso</th><th>Vitória</th></tr></thead>"
           f"<tbody>{rows_html}</tbody></table></div>")
    if vs:
        out += ("<div class='ro-b'><b class='gl'>Qual runa contra cada tipo de oponente</b><table class='ro-t'><thead><tr><th>Oponente de rota</th><th>Runa que mais vence</th><th>Jogos</th><th>Vitória</th></tr></thead>"
                f"<tbody>{vs}</tbody></table><p class='n'><span class='tag dado'>dado</span> pela classe do oponente de rota em cada partida (classes do Data Dragon); só entra com 4 jogos ou mais.</p></div>")
    return out + "</div>"


RO_CSS = """
.ro{display:grid;grid-template-columns:repeat(auto-fit,minmax(420px,1fr));gap:14px;margin-top:14px}
.ro-b{border:1px solid var(--line);border-radius:12px;padding:14px 16px;background:rgba(0,0,0,.12)}
.ro-t{width:100%;border-collapse:collapse;margin-top:8px}.ro-t th{text-align:left;font:500 12px var(--body);color:var(--steel);padding:6px 4px;border-bottom:1px solid var(--line)}
.ro-t td{padding:8px 4px;border-bottom:1px solid rgba(255,255,255,.04);vertical-align:middle}.ro-t .num{text-align:right;font:600 13px var(--body);white-space:nowrap}
.ro-t .win{color:var(--win)}.ro-t .loss{color:var(--loss)}
.ro-p{display:flex;align-items:center;gap:10px}.ro-p b{display:block;font:600 14px var(--body)}.ro-p small{color:var(--steel);font-size:12px}
.ro-mini{display:flex;gap:3px;margin-left:auto}.ro-k{font:600 13px var(--body);color:#c8aa6e;white-space:nowrap}
@media (max-width:700px){.ro-mini{display:none}}
"""
