"""Graficos que ajudam a subir: calendario de calor, sessoes, winrate movel, PDL por campeao, horario x dia,
voce contra o seu elo e os primeiros 15 minutos. Tudo das suas partidas guardadas; SVG puro com dica ao passar o mouse."""
import html
import math
import time
from collections import defaultdict

from . import report, icons

e = lambda x: html.escape("" if x is None else str(x))
WEEK = ["seg", "ter", "qua", "qui", "sex", "sáb", "dom"]
G, R_, GOLD = "#4FC08D", "#E5564E", "#F2B04A"
_TIER_CACHE = {}

CSS = """
.gfx{display:flex;flex-direction:column;gap:16px}
.gfx-f{display:flex;gap:6px;flex-wrap:wrap;align-items:center}.gfx-f a{padding:7px 14px;border-radius:999px;border:1px solid var(--rule);color:#D6CCC0;text-decoration:none;font:600 13px var(--body)}
.gfx-f a.on{background:var(--gold);color:#1a1405;border-color:var(--gold)}.gfx-f span{color:var(--mute);font-size:12px;margin:0 4px}
.gfx-g{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}@media (max-width:1000px){.gfx-g{grid-template-columns:1fr}}
.gc{position:relative;border:1px solid rgba(255,255,255,.07);border-radius:18px;padding:18px 20px 14px;overflow:hidden;
background:radial-gradient(600px 200px at 0 0,rgba(242,176,74,.07),transparent 70%),linear-gradient(180deg,rgba(32,24,23,.92),rgba(18,13,13,.96));
box-shadow:0 18px 40px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.04)}
.gc.gwide{grid-column:1/-1}
.gc h3{margin:0;font:700 17px var(--head);color:#fff;display:flex;align-items:center;gap:8px}.gc h3 i{width:8px;height:8px;border-radius:50%;background:var(--gold);box-shadow:0 0 12px var(--gold)}
.gc .sub{margin:4px 0 12px;color:#9A8F86;font-size:12.5px}.gc .ins{margin:10px 0 0;padding:10px 12px;border-radius:10px;background:rgba(242,176,74,.07);color:#F0E4CC;font-size:13px;border-left:3px solid var(--gold)}
.gc svg{width:100%;height:auto;display:block}.gc svg text{font-family:var(--body)}
.gc .hv{transition:opacity .15s}.gc .hv:hover{opacity:.75;cursor:default}
.gtip{position:fixed;pointer-events:none;background:#1E1716;border:1px solid rgba(255,255,255,.12);border-radius:10px;padding:7px 10px;font-size:12.5px;color:#F0E4CC;
box-shadow:0 10px 30px rgba(0,0,0,.5);z-index:50;display:none;max-width:280px}
.gempty{color:var(--mute);font-size:13px;padding:30px 0;text-align:center}
"""

JS = """<script>(function(){var t=document.createElement('div');t.className='gtip';document.body.appendChild(t);
document.addEventListener('pointermove',function(ev){var el=ev.target.closest('[data-tip]');if(!el){t.style.display='none';return}
t.innerHTML=el.getAttribute('data-tip');t.style.display='block';var x=ev.clientX+14,y=ev.clientY+14;if(x+290>innerWidth)x=ev.clientX-290;t.style.left=x+'px';t.style.top=y+'px'})})();</script>"""


def _wr(gs):
    return round(100 * sum(1 for g in gs if g["win"]) / len(gs)) if gs else None


def _card(title, sub, body, insight="", wide=False):
    return (f"<div class='gc{' gwide' if wide else ''}'><h3><i></i>{e(title)}</h3><p class='sub'>{e(sub)}</p>{body}"
            + (f"<p class='ins'>{insight}</p>" if insight else "") + "</div>")


def _defs():
    return (f"<defs><linearGradient id='gG' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#6BE0A6'/><stop offset='1' stop-color='{G}'/></linearGradient>"
            f"<linearGradient id='gR' x1='0' y1='1' x2='0' y2='0'><stop offset='0' stop-color='#FF7A70'/><stop offset='1' stop-color='{R_}'/></linearGradient>"
            f"<linearGradient id='gGh' x1='0' y1='0' x2='1' y2='0'><stop offset='0' stop-color='{G}'/><stop offset='1' stop-color='#6BE0A6'/></linearGradient>"
            f"<linearGradient id='gRh' x1='1' y1='0' x2='0' y2='0'><stop offset='0' stop-color='{R_}'/><stop offset='1' stop-color='#FF7A70'/></linearGradient>"
            f"<linearGradient id='gA' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='{GOLD}' stop-opacity='.35'/><stop offset='1' stop-color='{GOLD}' stop-opacity='0'/></linearGradient>"
            "<filter id='gw' x='-10%' y='-30%' width='120%' height='160%'><feGaussianBlur stdDeviation='2.5' result='b'/><feMerge><feMergeNode in='b'/><feMergeNode in='SourceGraphic'/></feMerge></filter></defs>")


def _day(ms):
    return time.strftime("%Y-%m-%d", time.localtime(ms / 1000 - 6 * 3600))


# 1) calendario de calor
def calendar(gs, lp):
    days = defaultdict(lambda: [0, 0, 0, False])     # pdl, v, d, tem_pdl
    for g in gs:
        d = days[_day(g["started_ms"])]
        d[1 if g["win"] else 2] += 1
        if g["match_id"] in lp:
            d[0] += lp[g["match_id"]][0]
            d[3] = True
    if not days:
        return ""
    today = time.time()
    weeks = 53
    start = today - (weeks * 7 - 1) * 86400
    st_wd = time.localtime(start).tm_wday
    start -= st_wd * 86400
    cells, x0, cs, gap = "", 34, 15, 3
    best = worst = None
    for i in range(weeks * 7 + st_wd + 1):
        t = start + i * 86400
        if t > today + 86400:
            break
        k = time.strftime("%Y-%m-%d", time.localtime(t))
        w, wd = divmod(i, 7)
        d = days.get(k)
        if d:
            val = d[0] if d[3] else (d[1] - d[2]) * 20
            a = min(1, abs(val) / 80)
            col = f"rgba(79,192,141,{0.25 + 0.75 * a:.2f})" if val > 0 else f"rgba(229,86,78,{0.25 + 0.75 * a:.2f})" if val < 0 else "#5a4d48"
            tip = f"<b>{time.strftime('%d/%m', time.localtime(t))}</b> · {d[1]}V {d[2]}D" + (f" · {val:+d} PDL" if d[3] else "")
            best = k if best is None or val > days[best][0] else best
        else:
            col, tip = "rgba(255,255,255,.04)", time.strftime('%d/%m', time.localtime(t)) + " · sem partidas"
        cells += f"<rect class='hv' x='{x0 + w * (cs + gap)}' y='{18 + wd * (cs + gap)}' width='{cs}' height='{cs}' rx='4' fill='{col}' data-tip='{e(tip)}'/>"
    lab = "".join(f"<text x='{x0 - 6}' y='{18 + i * (cs + gap) + 11}' font-size='10' fill='#7C716A' text-anchor='end'>{WEEK[i]}</text>" for i in (0, 2, 4, 6))
    mon, last_m = "", None
    for w in range(weeks + 1):
        lt = time.localtime(start + w * 7 * 86400)
        if lt.tm_mon != last_m and (w > 2 or lt.tm_mday <= 7):
            last_m = lt.tm_mon
            mon += f"<text x='{x0 + w * (cs + gap)}' y='10' font-size='10' fill='#9A8F86'>{['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'][lt.tm_mon - 1]}</text>"
    W = x0 + (weeks + 1) * (cs + gap)
    pos = sum(1 for d in days.values() if (d[0] if d[3] else d[1] - d[2]) > 0)
    neg = sum(1 for d in days.values() if (d[0] if d[3] else d[1] - d[2]) < 0)
    return _card("Calendário de calor", "Cada quadrado é um dia (o dia vira às 6h): verde fechou no lucro, vermelho no prejuízo.",
                 f"<svg viewBox='0 0 {W} {18 + 7 * (cs + gap)}'>{mon}{lab}{cells}</svg>",
                 f"{pos} dias no lucro e {neg} no prejuízo no último ano.", wide=True)


# 2) sessoes
def sessions(gs, lp):
    chron = sorted(gs, key=lambda g: g["started_ms"])
    ses = []
    for g in chron:
        if ses and g["started_ms"] - (ses[-1][-1]["started_ms"] + (ses[-1][-1]["duration_s"] or 0) * 1000) < 60 * 60000:
            ses[-1].append(g)
        else:
            ses.append([g])
    if len(ses) < 3:
        return ""
    val = lambda s: sum(lp[g["match_id"]][0] if g["match_id"] in lp else (20 if g["win"] else -20) for g in s)
    show = ses[-18:]
    W, H, base = 640, 230, 110
    mx = max(abs(val(s)) for s in show) or 1
    bw = (W - 60) / len(show)
    g_ = f"<line x1='30' x2='{W - 10}' y1='{base}' y2='{base}' stroke='rgba(255,255,255,.15)'/>"
    for i, s in enumerate(show):
        v = val(s)
        h = 85 * abs(v) / mx
        x = 40 + i * bw
        y = base - h if v >= 0 else base
        w_ = sum(1 for g in s if g["win"])
        tip = (f"<b>{time.strftime('%d/%m %Hh', time.localtime(s[0]['started_ms'] / 1000))}</b><br>{len(s)} partidas · {w_}V {len(s) - w_}D · "
               f"<b style=\"color:{'#6BE0A6' if v >= 0 else '#FF7A70'}\">{v:+d} PDL</b>")
        g_ += (f"<rect class='hv' x='{x:.1f}' y='{y:.1f}' width='{bw * 0.62:.1f}' height='{max(2, h):.1f}' rx='5' fill='url(#{'gG' if v >= 0 else 'gR'})' data-tip='{e(tip)}'/>"
               f"<text x='{x + bw * 0.31:.1f}' y='{(y - 6) if v >= 0 else (y + h + 14):.1f}' font-size='10.5' fill='#E8DCCB' text-anchor='middle'>{v:+d}</text>"
               f"<text x='{x + bw * 0.31:.1f}' y='{H - 8}' font-size='10' fill='#7C716A' text-anchor='middle'>{len(s)}j</text>")
    short = [val(s) for s in ses if len(s) <= 3]
    long_ = [val(s) for s in ses if len(s) >= 4]
    ins = ""
    if short and long_:
        a, b = sum(short) / len(short), sum(long_) / len(long_)
        ins = (f"Sessões de até 3 partidas: <b>{a:+.0f} PDL</b> em média. Sessões de 4 ou mais: <b>{b:+.0f} PDL</b>."
               + (" Parar cedo está valendo PDL para você." if a > b else " Você rende bem em sessões longas."))
    return _card("Sessões", "Cada barra é uma sessão de jogo (partidas com menos de 1 hora de intervalo): saldo de PDL e quantos jogos.",
                 f"<svg viewBox='0 0 {W} {H}'>{_defs()}{g_}</svg>", ins)


# 3) winrate movel
def rolling(gs, n=20):
    chron = sorted(gs, key=lambda g: g["started_ms"])
    if len(chron) < n + 5:
        return ""
    pts = []
    for i in range(n, len(chron) + 1):
        win = chron[i - n:i]
        pts.append((chron[i - 1]["started_ms"], 100 * sum(1 for g in win if g["win"]) / n))
    W, H, L, T, B = 640, 220, 34, 12, 26
    X = lambda i: L + (W - L - 10) * i / max(1, len(pts) - 1)
    Y = lambda v: T + (H - T - B) * (1 - (v - 20) / 60)
    line = " ".join(f"{X(i):.1f},{Y(min(80, max(20, v))):.1f}" for i, (_, v) in enumerate(pts))
    area = f"M{X(0):.1f},{H - B} L" + " L".join(f"{X(i):.1f},{Y(min(80, max(20, v))):.1f}" for i, (_, v) in enumerate(pts)) + f" L{X(len(pts) - 1):.1f},{H - B} Z"
    g_ = ""
    for v in (30, 40, 50, 60, 70):
        stroke = "rgba(242,176,74,.5)" if v == 50 else "rgba(255,255,255,.05)"
        dash = " stroke-dasharray='5 4'" if v == 50 else ""
        g_ += (f"<line x1='{L}' x2='{W - 10}' y1='{Y(v):.1f}' y2='{Y(v):.1f}' stroke='{stroke}'{dash}/>"
               f"<text x='{L - 6}' y='{Y(v) + 3:.1f}' font-size='10' fill='#7C716A' text-anchor='end'>{v}%</text>")
    dots = ""
    for i, (t, v) in enumerate(pts):
        tip = "<b>%.0f%%</b> nas 20 partidas até %s" % (v, time.strftime("%d/%m", time.localtime(t / 1000)))
        dots += f"<circle class='hv' cx='{X(i):.1f}' cy='{Y(min(80, max(20, v))):.1f}' r='6' fill='transparent' data-tip='{e(tip)}'/>"
    cur = pts[-1][1]
    peak = max(pts, key=lambda p: p[1])
    return _card("Winrate móvel (20 partidas)", "Sua fase real ao longo do tempo, sem o barulho de uma noite boa ou ruim.",
                 f"<svg viewBox='0 0 {W} {H}'>{_defs()}{g_}<path d='{area}' fill='url(#gA)'/><polyline points='{line}' fill='none' stroke='{GOLD}' stroke-width='2.6' filter='url(#gw)'/>"
                 f"<circle cx='{X(len(pts) - 1):.1f}' cy='{Y(min(80, max(20, cur))):.1f}' r='5' fill='{GOLD}' stroke='#150F0F' stroke-width='2'/>{dots}</svg>",
                 f"Agora: <b>{cur:.0f}%</b>. Melhor fase: {peak[1]:.0f}% (até {time.strftime('%d/%m', time.localtime(peak[0] / 1000))}).")


# 4) PDL por campeao
def champs(gs, lp, icon):
    by = defaultdict(list)
    for g in gs:
        by[g["champion"]].append(g)
    rows = []
    for c, l in by.items():
        v = sum(lp[g["match_id"]][0] if g["match_id"] in lp else (20 if g["win"] else -20) for g in l)
        rows.append((c, v, len(l), _wr(l)))
    rows = sorted([r for r in rows if r[2] >= 2], key=lambda r: -r[1])[:12]
    if not rows:
        return ""
    W, rh = 640, 30
    mx = max(abs(r[1]) for r in rows) or 1
    mid = 400
    g_ = f"<line x1='{mid}' x2='{mid}' y1='0' y2='{len(rows) * rh}' stroke='rgba(255,255,255,.15)'/>"
    for i, (c, v, n, wr) in enumerate(rows):
        y = i * rh + 6
        w = 190 * abs(v) / mx
        x = mid if v >= 0 else mid - w
        tip = f"<b>{e(c)}</b><br>{n} partidas · {wr}% de vitória · <b>{v:+d} PDL</b>"
        u_ = icons.champ_url(c)
        if u_:
            g_ += (f"<clipPath id='pc{i}'><circle cx='{12}' cy='{y + 9}' r='11'/></clipPath>"
                   f"<image href='{u_}' x='1' y='{y - 2}' width='22' height='22' clip-path='url(#pc{i})'/>"
                   f"<circle cx='12' cy='{y + 9}' r='11' fill='none' stroke='{'#7CCB98' if v >= 0 else '#EE8A8F'}' stroke-width='1.2'/>")
        g_ += (f"<text x='118' y='{y + 13}' font-size='12.5' fill='#E8DCCB' text-anchor='end'>{e(c)}</text>"
               f"<text x='126' y='{y + 13}' font-size='10.5' fill='#7C716A'>{n}j · {wr}%</text>"
               f"<rect class='hv' x='{x:.1f}' y='{y}' width='{max(3, w):.1f}' height='18' rx='5' fill='url(#{'gGh' if v >= 0 else 'gRh'})' data-tip='{e(tip)}'/>"
               f"<text x='{(x + w + 6) if v >= 0 else (x - 6):.1f}' y='{y + 13}' font-size='11.5' font-weight='700' fill='{'#6BE0A6' if v >= 0 else '#FF7A70'}' "
               f"text-anchor='{'start' if v >= 0 else 'end'}'>{v:+d}</text>")
    pos = [r for r in rows if r[1] > 0]
    neg = [r for r in rows if r[1] < 0]
    ins = ""
    if pos and neg:
        ins = f"<b>{e(pos[0][0])}</b> te deu {pos[0][1]:+d} PDL; os campeões no vermelho somam {sum(r[1] for r in neg):+d}."
    return _card("PDL por campeão", "Quanto cada campeão te deu ou tirou de PDL (2 partidas ou mais).",
                 f"<svg viewBox='0 0 {W} {len(rows) * rh + 8}'>{_defs()}{g_}</svg>", ins)


# 5) horario x dia da semana
def heat(gs):
    slots = [("manhã", 6, 12), ("tarde", 12, 18), ("noite", 18, 24), ("madrugada", 0, 6)]
    grid = defaultdict(list)
    for g in gs:
        lt = time.localtime(g["started_ms"] / 1000)
        s = next(i for i, (_, a, b) in enumerate(slots) if a <= lt.tm_hour < b)
        wd = lt.tm_wday if lt.tm_hour >= 6 else (lt.tm_wday - 1) % 7
        grid[(wd, s)].append(g)
    if not grid:
        return ""
    W, cw, ch, x0, y0 = 640, 140, 26, 60, 22
    g_ = "".join(f"<text x='{x0 + j * cw + cw / 2 - 4}' y='14' font-size='11' fill='#9A8F86' text-anchor='middle'>{n}</text>" for j, (n, _, _) in enumerate(slots))
    best = None
    for i, d in enumerate(WEEK):
        g_ += f"<text x='{x0 - 10}' y='{y0 + i * (ch + 4) + 17}' font-size='11.5' fill='#C9BDB0' text-anchor='end'>{d}</text>"
        for j, (n, _, _) in enumerate(slots):
            l = grid.get((i, j), [])
            if len(l) >= 3:
                wr = _wr(l)
                a = min(1, abs(wr - 50) / 20)
                col = f"rgba(79,192,141,{0.3 + 0.7 * a:.2f})" if wr >= 50 else f"rgba(229,86,78,{0.3 + 0.7 * a:.2f})"
                txt = f"{wr}%"
                if best is None or wr > best[0]:
                    best = (wr, d, n, len(l))
            else:
                col, txt, wr = "rgba(255,255,255,.035)", ("·" if not l else f"{len(l)}j"), None
            tip = f"<b>{d}, {n}</b><br>" + (f"{len(l)} partidas · {wr}% de vitória" if wr is not None else f"{len(l)} partida(s): pouca amostra")
            g_ += (f"<rect class='hv' x='{x0 + j * cw}' y='{y0 + i * (ch + 4)}' width='{cw - 8}' height='{ch}' rx='7' fill='{col}' data-tip='{e(tip)}'/>"
                   f"<text x='{x0 + j * cw + (cw - 8) / 2}' y='{y0 + i * (ch + 4) + 17}' font-size='11.5' font-weight='700' fill='#fff' text-anchor='middle' pointer-events='none'>{txt}</text>")
    return _card("Horário × dia da semana", "Winrate em cada horário de cada dia (3 partidas ou mais).",
                 f"<svg viewBox='0 0 {W} {y0 + 7 * (ch + 4)}'>{g_}</svg>",
                 f"Seu melhor horário: <b>{best[1]}, {best[2]}</b> ({best[0]}% em {best[3]} partidas)." if best else "")


# 6) voce contra o seu elo
def radar(gs, ref, ref_name):
    if not gs or not ref:
        return _card("Você contra o seu elo", "Compara seus números com a média de jogadores do seu elo.",
                     "<p class='gempty'>Ainda sem a amostra do seu elo. Abra <a href='/topo' style='color:var(--gold)'>Comparar</a> e baixe a amostra: o gráfico aparece aqui.</p>") if gs else ""
    M = [("Farm/min", "cs_per_min", True), ("Visão/min", "vision_per_min", True), ("Sem morrer cedo", "deaths_before_10", False),
         ("Part. em abates", "kp", True), ("Farm aos 10 vs oponente", "csdiff10", True), ("Ouro aos 15 vs oponente", "golddiff15", True)]
    avg = lambda l, k: (sum(g[k] for g in l if g.get(k) is not None) / max(1, sum(1 for g in l if g.get(k) is not None))) if any(g.get(k) is not None for g in l) else None
    vals = []
    for lab, k, hi in M:
        a, b = avg(gs, k), avg(ref, k)
        if a is None or b is None:
            continue
        if k in ("csdiff10", "golddiff15"):
            sc = 0.5 + max(-0.45, min(0.45, (a - b) / (40 if k == "csdiff10" else 1200)))
        elif hi:
            sc = 0.5 * a / b if b else 0.5
        else:
            sc = 0.5 * (b + 0.3) / (a + 0.3)
        vals.append((lab, max(0.08, min(1, sc)), a, b, k))
    if len(vals) < 3:
        return ""
    W, H, cx, cy, Rr = 640, 300, 320, 150, 110
    n = len(vals)
    P = lambda i, r: (cx + Rr * r * math.sin(2 * math.pi * i / n), cy - Rr * r * math.cos(2 * math.pi * i / n))
    g_ = ""
    for k in (0.25, 0.5, 0.75, 1):
        g_ += f"<polygon points='{' '.join(f'{x:.1f},{y:.1f}' for x, y in (P(i, k) for i in range(n)))}' fill='none' stroke='rgba(255,255,255,{0.18 if k == 0.5 else 0.06})'/>"
    for i in range(n):
        x, y = P(i, 1)
        g_ += f"<line x1='{cx}' y1='{cy}' x2='{x:.1f}' y2='{y:.1f}' stroke='rgba(255,255,255,.05)'/>"
    ref_pts = " ".join(f"{x:.1f},{y:.1f}" for x, y in (P(i, 0.5) for i in range(n)))
    me_pts = " ".join(f"{x:.1f},{y:.1f}" for x, y in (P(i, v[1]) for i, v in enumerate(vals)))
    g_ += f"<polygon points='{ref_pts}' fill='rgba(141,162,192,.12)' stroke='#8DA2C0' stroke-dasharray='4 4'/>"
    g_ += f"<polygon points='{me_pts}' fill='rgba(242,176,74,.25)' stroke='{GOLD}' stroke-width='2.4' filter='url(#gw)'/>"
    for i, (lab, sc, a, b, k) in enumerate(vals):
        x, y = P(i, sc)
        fmt = (lambda v: f"{v * 100:.0f}%") if k == "kp" else (lambda v: f"{v:+.0f}") if k in ("csdiff10", "golddiff15") else (lambda v: f"{v:.2f}" if k == "vision_per_min" else f"{v:.1f}")
        g_ += f"<circle class='hv' cx='{x:.1f}' cy='{y:.1f}' r='6' fill='{GOLD}' stroke='#150F0F' stroke-width='2' data-tip='{e(f'<b>{lab}</b><br>você: {fmt(a)} · {ref_name}: {fmt(b)}')}'/>"
        lx, ly = P(i, 1.22)
        g_ += f"<text x='{lx:.1f}' y='{ly + 4:.1f}' font-size='11.5' fill='{'#6BE0A6' if sc >= 0.5 else '#FF7A70'}' text-anchor='middle'>{e(lab)}</text>"
    worst = min(vals, key=lambda v: v[1])
    return _card(f"Você contra o {ref_name}", "Linha tracejada = média do elo. Fora dela, você está melhor; dentro, pior.",
                 f"<svg viewBox='0 0 {W} {H}'>{_defs()}{g_}</svg>",
                 f"Ponto mais fraco: <b>{e(worst[0].lower())}</b>.")


# 7) primeiros 15 minutos
def early(con, gs):
    win, loss = defaultdict(list), defaultdict(list)
    for g in gs[:80]:
        if not g.get("opp_id"):
            continue
        rows = con.execute(
            """SELECT a.minute, a.gold - b.gold FROM frames a JOIN frames b ON b.match_id=a.match_id AND b.minute=a.minute AND b.participant_id=?
               WHERE a.match_id=? AND a.participant_id=? AND a.minute<=15""", (g["opp_id"], g["match_id"], g["participant_id"])).fetchall()
        for m, d in rows:
            (win if g["win"] else loss)[m].append(d)
    if len(win) < 10 or len(loss) < 10:
        return ""
    W, H, L, T, B = 640, 240, 50, 14, 26
    mw = [sum(win[m]) / len(win[m]) for m in range(16) if win.get(m)]
    ml = [sum(loss[m]) / len(loss[m]) for m in range(16) if loss.get(m)]
    mx = max(max(abs(x) for x in mw + ml), 300)
    X = lambda m: L + (W - L - 12) * m / 15
    Y = lambda v: T + (H - T - B) * (1 - (v + mx) / (2 * mx))
    g_ = f"<line x1='{L}' x2='{W - 12}' y1='{Y(0):.1f}' y2='{Y(0):.1f}' stroke='rgba(255,255,255,.2)'/>"
    for v in (-mx / 2, mx / 2):
        g_ += f"<line x1='{L}' x2='{W - 12}' y1='{Y(v):.1f}' y2='{Y(v):.1f}' stroke='rgba(255,255,255,.05)'/><text x='{L - 6}' y='{Y(v) + 3:.1f}' font-size='10' fill='#7C716A' text-anchor='end'>{v:+.0f}</text>"
    for m in (0, 5, 10, 15):
        g_ += f"<text x='{X(m):.1f}' y='{H - 8}' font-size='10' fill='#7C716A' text-anchor='middle'>{m} min</text>"
    pw = " ".join(f"{X(m):.1f},{Y(v):.1f}" for m, v in enumerate(mw))
    pl = " ".join(f"{X(m):.1f},{Y(v):.1f}" for m, v in enumerate(ml))
    g_ += f"<polyline points='{pw}' fill='none' stroke='{G}' stroke-width='2.6' filter='url(#gw)'/><polyline points='{pl}' fill='none' stroke='{R_}' stroke-width='2.6' filter='url(#gw)'/>"
    for m, (a, b) in enumerate(zip(mw, ml)):
        g_ += (f"<rect class='hv' x='{X(m) - 9:.1f}' y='{T}' width='18' height='{H - T - B}' fill='transparent' "
               f"data-tip='{e(f'<b>{m} min</b><br>vitórias: {a:+.0f} de ouro · derrotas: {b:+.0f}')}'/>")
    split = next((m for m, b in enumerate(ml) if b <= -250), None)
    ins = (f"Nas derrotas, você já está <b>250 de ouro atrás aos {split} min</b>: é aí que a partida começa a escapar." if split
           else "Nas derrotas a diferença cresce devagar: o problema costuma vir depois da rota.")
    return _card("Primeiros 15 minutos", "Ouro contra o oponente de rota, minuto a minuto: média das vitórias (verde) e das derrotas (vermelho).",
                 f"<svg viewBox='0 0 {W} {H}'>{_defs()}{g_}</svg>", ins)


def page_html(con, puuid, ddir, icon, link, queue="solo", period="90"):
    from . import pages4, tiers
    now = time.time() * 1000
    cut = {"30": now - 30 * 86400000, "90": now - 90 * 86400000, "180": now - 180 * 86400000}.get(period, 0)
    rows = con.execute(
        f"""SELECT p.*, m.queue_id, m.duration_s, m.patch, m.started_ms FROM participants p JOIN matches m USING (match_id)
            WHERE p.puuid=? AND COALESCE(m.duration_s,0)>=300 AND m.started_ms>=? {'AND m.queue_id=420' if queue == 'solo' else ''}
            ORDER BY m.started_ms DESC""", (puuid, cut)).fetchall()
    gs = [dict(r) for r in rows]
    filt = ("<div class='gfx-f'>" + "".join(f"<a href='/graficos?fila={k}&periodo={period}' class='{'on' if queue == k else ''}'>{t}</a>" for k, t in (("solo", "Ranqueada solo"), ("todas", "Todas as filas")))
            + "<span>·</span>" + "".join(f"<a href='/graficos?fila={queue}&periodo={k}' class='{'on' if period == k else ''}'>{t}</a>"
                                         for k, t in (("30", "30 dias"), ("90", "90 dias"), ("180", "6 meses"), ("tudo", "Tudo"))) + "</div>")
    if not gs:
        return f"<style>{CSS}</style><div class='gfx'>{filt}<div class='empty'><b>Sem partidas neste filtro</b><span>Troque o período ou a fila.</span></div></div>"
    lp = pages4.lp_per_game(con, puuid)
    full = report._games_from_rows(con, rows[:80])
    tier = (dict(link).get("tier") if link else None) or "DIAMOND"
    key = (tier, "MIDDLE")
    pos = max({g.get("position") for g in gs if g.get("position")} or {"MIDDLE"}, key=lambda p: sum(1 for g in gs if g.get("position") == p))
    key = (tier, pos)
    hit = _TIER_CACHE.get(key)
    if not hit or time.time() - hit[0] > 1800:
        try:
            ref = tiers.games(ddir, tier, pos)
        except Exception:
            ref = []
        _TIER_CACHE[key] = (time.time(), ref)
    ref = _TIER_CACHE[key][1]
    from . import ranks
    ref_name = ranks.TIER_PT.get(tier, tier)
    cal_rows = [dict(r) for r in con.execute(
        f"""SELECT p.match_id, p.win, m.started_ms FROM participants p JOIN matches m USING (match_id)
            WHERE p.puuid=? AND COALESCE(m.duration_s,0)>=300 {'AND m.queue_id=420' if queue == 'solo' else ''} AND m.started_ms>=?""",
        (puuid, now - 372 * 86400000)).fetchall()]
    parts = [calendar(cal_rows, lp), sessions(gs, lp), champs(gs, lp, icon), rolling(gs), heat(gs), radar(full, ref, ref_name), early(con, full)]
    body = "".join(p for p in parts if p)
    return f"<style>{CSS}</style><div class='gfx'>{filt}<div class='gfx-g'>{body}</div></div>{JS}"
