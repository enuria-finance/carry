"""Visual Hextech: azul-marinho profundo, dourado e ciano, cantos retos com moldura dupla e titulos em Cinzel.

So troca a aparencia (vem por ultimo no CSS e sobrescreve cores, fontes, bordas e botoes); nenhuma tela muda de conteudo.
Fontes servidas pelo proprio app (/static/fonts), licenca SIL OFL.
"""

FONTS = "".join(
    f"@font-face{{font-family:'{fam}';src:url('/static/fonts/{file}') format('woff2');font-weight:{w};font-style:normal;font-display:swap}}"
    for fam, file, w in [("Cinzel", "cinzel-latin-600-normal.woff2", 600), ("Cinzel", "cinzel-latin-700-normal.woff2", 700),
                         ("Cinzel", "cinzel-latin-800-normal.woff2", 800), ("Inter Tight", "inter-tight-latin-400-normal.woff2", 400),
                         ("Inter Tight", "inter-tight-latin-500-normal.woff2", 500), ("Inter Tight", "inter-tight-latin-600-normal.woff2", 600),
                         ("Inter Tight", "inter-tight-latin-700-normal.woff2", 700)])

BOXES = (".card,.kpi,.hero,.banner,.mhero,.dhero,.dcard2,.drawer,.phero2,.maincard,.trend,.lv-card,.lv-top,.coach,.ccol,.gplan,.gp-card,"
         ".gp-mini,.arena,.sstat,.eloh,.empty,.urow,.tip,.lchip,.dmore,.thr,.vsc,.pk,.phero,.rankbox,.pchamp,.mst,.chal,.howto li,.m-streak,"
         ".cidea,.lv-step,.lv-now,.lv-pl,.gcard,.tile,.dcard,.mcard,.alert,.jobbar,.ovl,.step,.pcard,.met,.slot,.duel,.dbar,.modes,.mchk,"
         ".gstep,.secret,.audit div,.qrow,.lv-empty,.pchip,.chip,.badge,.pill,.m-k,.trend,.gp-strip>div,.strip .tile,.levers .card")

CSS = FONTS + """
/* ================= HEXTECH ================= */
:root{--bg:#010a13;--panel:#08131f;--panel2:#0c1a29;--ink:#f0e6d2;--mute:#a09b8c;--rule:#2c2a22;
--gold:#c8aa6e;--purple:#0ac8b9;--purple2:#cdfafa;--peach:#cdfafa;--btn:#1e2328;--btnfg:#f0e6d2;
--dado:#0ac8b9;--regra:#c8aa6e;--hip:#9fb6d6;--win:#0ac8b9;--loss:#e84057;
--head:"Cinzel","Times New Roman",serif;--body:"Inter Tight","Segoe UI",system-ui,sans-serif;--mono:"Inter Tight","Segoe UI",system-ui,sans-serif;
--hx-line:#463714;--hx-gold2:#f0e6d2;--hx-glow:rgba(200,170,110,.35)}
html{background:#010a13}
body{background:radial-gradient(1100px 700px at 78% -12%,#0f2440 0%,transparent 62%),radial-gradient(900px 600px at -10% 110%,rgba(10,200,185,.06),transparent 60%),linear-gradient(180deg,#010a13,#04101b 55%,#010a13);background-attachment:fixed}
"""+BOXES+"""{border-radius:2px !important}
.card,.kpi,.trend,.lv-card,.ccol,.gp-card,.dcard2,.drawer,.lchip,.urow,.pchamp,.mst,.thr,.vsc,.tile,.gcard,.dcard,.mcard,.sstat,.eloh,.coach,.gplan,.lv-top,.arena,.dmore,.rankbox{
border-color:var(--hx-line) !important;box-shadow:inset 0 0 0 3px rgba(1,10,19,.85),inset 0 0 0 4px rgba(200,170,110,.10)}
.card,.kpi,.trend,.lv-card,.gp-card,.dcard2,.pchamp,.mst{background:linear-gradient(180deg,rgba(30,35,40,.55),rgba(8,19,31,.92))}
.banner,.mhero,.dhero,.phero2,.maincard,.hero{border-color:#785a28 !important;box-shadow:inset 0 0 0 3px rgba(1,10,19,.7),inset 0 0 0 4px rgba(200,170,110,.16),0 20px 60px rgba(0,0,0,.45)}
.banner::before,.mhero::before,.dhero::after,.phero2::after{content:"";position:absolute;left:0;right:0;top:0;height:2px;z-index:3;pointer-events:none;
background:linear-gradient(90deg,transparent,#785a28 15%,#c8aa6e 40%,#f0e6d2 50%,#c8aa6e 60%,#785a28 85%,transparent)}
.dhero::before{display:none}
/* tipografia: titulos em Cinzel, rotulos sem caixa-alta forcada */
h1,.banner h1,.m-t,.dh-t,.pname b,.gp-head b,.big2{font-family:var(--head);letter-spacing:.01em}
h2{font:700 15px/1.3 var(--head);letter-spacing:.06em;text-transform:none;color:var(--gold)}
h2::before{background:var(--gold)}
.gl,b.gl{font-family:var(--head);letter-spacing:.06em;text-transform:none;color:var(--gold);font-size:14px}
.kl,.kpi small.kl,.trend small,.lv-card h3,.ccol h3{font-family:var(--body)}
.kv,.kpi b,.trend b,.gapn,.m-streak>b,.lv-clock b,.cscore,.dh-gap{font-family:var(--head);font-variant-numeric:lining-nums}
.tag{font-family:var(--body);letter-spacing:.06em}
.bn-k,.dh-k,.mission .k,.pname small{font-family:var(--head);letter-spacing:.14em}
/* menu lateral */
.rail{background:linear-gradient(180deg,rgba(1,10,19,.96),rgba(4,16,27,.9)) !important;border-right:1px solid var(--hx-line) !important}
.brand{font-family:var(--head);color:var(--hx-gold2);letter-spacing:.04em}
.rail a{font-family:var(--body);letter-spacing:.04em;text-transform:none;font-size:14px;font-weight:500;border-radius:2px}
.rail a:hover{background:rgba(200,170,110,.07);color:var(--hx-gold2)}
.rail a[aria-current=page]{background:linear-gradient(90deg,rgba(200,170,110,.20),rgba(200,170,110,.02));border-color:transparent;border-left:2px solid var(--gold);color:var(--hx-gold2)}
.who{color:var(--gold);font-family:var(--body);letter-spacing:.08em}
/* botoes no estilo do cliente */
button,.btn{background:linear-gradient(180deg,#1e2328,#10161c) !important;color:var(--hx-gold2) !important;border:1px solid var(--gold) !important;border-radius:2px !important;
font-family:var(--head) !important;font-weight:700;letter-spacing:.08em;box-shadow:inset 0 0 0 1px rgba(1,10,19,.9),0 0 0 rgba(0,0,0,0)}
button:hover,.btn:hover{border-color:var(--hx-gold2) !important;box-shadow:inset 0 0 0 1px rgba(1,10,19,.9),0 0 18px var(--hx-glow) !important;filter:none}
.btn.ghost,button.ghost{border-color:var(--hx-line) !important;color:var(--mute) !important}
.btn.alt{background:linear-gradient(180deg,rgba(10,200,185,.16),rgba(10,200,185,.04)) !important;border-color:#0ac8b9 !important;color:#cdfafa !important}
.btn.alt:hover{box-shadow:0 0 18px rgba(10,200,185,.35) !important}
.btn.gold,button.btn.gold{background:linear-gradient(180deg,#e2c792,#b8923f) !important;color:#1a1405 !important;border-color:#f0e6d2 !important}
button.danger{background:linear-gradient(180deg,#5a1a24,#2a0d12) !important;border-color:#e84057 !important;color:#ffd5db !important}
button.okb{background:linear-gradient(180deg,#0e3b3a,#08201f) !important;border-color:#0ac8b9 !important;color:#cdfafa !important}
.syncbtn{border-radius:2px !important}
.usermenu button{background:none !important;border:1px solid transparent !important;color:var(--mute) !important;font-family:var(--body) !important;letter-spacing:.04em}
.jb-x{background:none !important;border:0 !important;box-shadow:none !important}
/* campos */
input,select,textarea{border-radius:2px !important;border-color:var(--hx-line) !important;background:#010a13 !important;color:var(--ink) !important}
input:focus,select:focus,textarea:focus{border-color:var(--gold) !important;box-shadow:0 0 0 2px rgba(200,170,110,.18) !important;outline:0}
/* barras e graficos no ciano/dourado */
.pt2 i,.bar i,.rb .tr i,.dbar.me i,.lv-bar i{background:linear-gradient(90deg,#0397ab,#0ac8b9) !important}
.dbar.top i{background:linear-gradient(90deg,#785a28,#c8aa6e) !important}
.lv-bar{background:#be1e37 !important}
.wring .fg{stroke:var(--gold)}
.pt2{background:#0e1a26}.pt2 u{background:var(--hx-gold2)}
.modes a[aria-current]{background:linear-gradient(180deg,#e2c792,#b8923f);color:#1a1405;box-shadow:0 0 18px var(--hx-glow)}
.gstep.on{background:linear-gradient(180deg,#e2c792,#b8923f)}
.chip-st.ok{color:var(--win)}.syncbtn.busy{border-color:var(--purple) !important}
.tip{border-left-width:2px}
.empty{border-style:solid;border-color:var(--hx-line);background:linear-gradient(180deg,rgba(30,35,40,.35),rgba(8,19,31,.6))}
/* tela de entrar */
.auth{background:#010a13}.auth-box .brand{font-family:var(--head)}
.auth-side{background:linear-gradient(180deg,rgba(1,10,19,.92),rgba(4,16,27,.98));border-left:1px solid var(--hx-line)}
.lv-step b,.lv-pl,.lv-dm,.gp-mini b,.mchk,.lv-gv,.lv-k2 span,.pill,.dmeta .pill,.drawer .dt b,.cidea li,.lv-obj,.dl,.pb .pn{font-family:var(--body) !important}
.lg i[style*='8cc4ff']{background:#0ac8b9 !important}
.radar polygon.me,.radar .me{fill:rgba(10,200,185,.28);stroke:#0ac8b9}
.gly{width:1.15em;height:1.15em;vertical-align:-.2em;color:var(--gold);flex:none}
.empty .em{display:flex;justify-content:center}.empty .em .gly{width:38px;height:38px;filter:drop-shadow(0 0 12px rgba(200,170,110,.4))}
.lv-now i .gly,.gp-mini i .gly,.gp-h i .gly,.lv-obj i .gly,.drawer .di .gly{width:20px;height:20px}
.pcard .em .gly{width:30px;height:30px}
::selection{background:rgba(200,170,110,.35)}
"""
