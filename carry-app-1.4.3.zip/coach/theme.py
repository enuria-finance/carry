"""Tema 'hextech': banner com arte do campeao, brilhos, animacoes ao rolar a pagina.
Tudo em CSS/JS puro, sem internet (so as imagens oficiais do Data Dragon, que ja usamos)."""

KICKER = {
    "/": ("Painel", "Seu jogo, seus números, o que fazer agora"),
    "/diagnostico": ("Diagnóstico", "O que separa as suas vitórias das derrotas"),
    "/partidas": ("Partidas", "Cada jogo com pós-jogo e revisão"),
    "/graficos": ("Gráficos", "Sessões, PDL por campeão, horários, você contra o seu elo e os primeiros 15 minutos"),
    "/guia": ("Como usar", "O passo a passo de tudo: instalar, chaves, partida, overlay, voz e páginas"),
    "/hoje": ("Resumo do dia", "Quantas ganhou, quantas perdeu, o PDL e os erros do dia"),
    "/desempenho": ("Meu desempenho", "Elo, campeões, padrões e recordes: onde você ganha e onde perde PDL"),
    "/padroes": ("Padrões", "O que se repete nas suas decisões"),
    "/matchups": ("Matchups", "Contra quem você ganha e contra quem sofre"),
    "/topo": ("Comparar", "Você contra o seu próximo elo e contra os melhores"),
    "/habitos": ("Hábitos", "Quando você joga melhor e se cumpre suas metas"),
    "/selecao": ("Seleção de campeões", "Pick, ban, runas e feitiços antes da partida"),
    "/aovivo": ("Ao vivo", "Dicas durante a partida, só com o que você já vê"),
    "/sincronizar": ("Sincronizar", "Suas partidas e a amostra dos melhores"),
    "/campeoes": ("Campeões", "Guia de cada campeão: build, runas, confrontos e especialistas"),
    "/coach": ("Coach IA", "Pergunte sobre o seu jogo: a resposta vem das suas partidas"),
    "/jogo": ("Partida", "Seleção, plano de jogo e painel ao vivo numa tela só"),
    "/overlay": ("Editar overlay", "O que aparece por cima do jogo, onde e de que tamanho"),
    "/perfil": ("Minha conta", "Quem você é no Rift, sua conta do LoL e seus dados"),
    "/conta": ("Minha conta", "Dados, senha e privacidade"),
    "/vincular": ("Conta do LoL", "Vincule e verifique a sua conta da Riot"),
    "/admin": ("Administração", "Usuários, chave da Riot, fila e auditoria"),
    "/privacidade": ("Privacidade", "O que o app guarda e por quê"),
}


def kicker_for(path):
    if path in KICKER:
        return KICKER[path]
    for k, v in KICKER.items():
        if k != "/" and path.startswith(k):
            return v
    if path.startswith("/partida/"):
        return ("Pós-jogo", "O que decidiu esta partida")
    if path.startswith("/revisao/"):
        return ("Revisão", "Erros e acertos, lance a lance")
    return ("Carry", "")


def banner(title, path, splash_url):
    kick, sub = kicker_for(path)
    from . import bg
    art = bg.art("bn-art", splash_url)
    s = f"<p class='bn-sub'>{sub}</p>" if sub else ""
    return (f"<header class='banner'>{art}<div class='bn-fade'></div><div class='bn-in'>"
            f"<p class='bn-k'><i></i>{kick}</p><h1>{title}</h1>{s}</div><span class='bn-line'></span></header>")


CSS = """
#liveroot.noanim *,#liveroot.noanim *::before,#liveroot.noanim *::after{animation:none !important;transition:none !important}

/* ---------- banner ---------- */
.banner{position:relative;overflow:hidden;border:1px solid var(--rule);border-radius:16px;margin:0 0 26px;min-height:150px;
display:flex;align-items:flex-end;background:linear-gradient(135deg,#131a26,#0f141c)}
.bn-art{position:absolute;inset:0;background-size:cover;background-position:right 22%;opacity:.55;
-webkit-mask-image:linear-gradient(90deg,transparent 18%,#000 80%);mask-image:linear-gradient(90deg,transparent 18%,#000 80%);
animation:kb 22s ease-in-out infinite alternate}
@keyframes kb{from{transform:scale(1.02)}to{transform:scale(1.09) translateX(-1.5%)}}
.bn-fade{position:absolute;inset:0;background:linear-gradient(90deg,rgba(14,17,22,.96) 18%,rgba(14,17,22,.2) 70%),linear-gradient(0deg,rgba(14,17,22,.65),transparent 55%)}
.bn-in{position:relative;padding:26px 30px 22px}
.bn-k{display:flex;align-items:center;gap:9px;margin:0 0 6px;color:var(--gold);font:600 12px var(--mono);letter-spacing:.2em;text-transform:uppercase}
.bn-k i{width:9px;height:9px;background:var(--gold);transform:rotate(45deg);box-shadow:0 0 12px var(--gold)}
.banner h1{margin:0;font-size:clamp(30px,3.6vw,46px);text-shadow:0 2px 24px rgba(0,0,0,.6)}
.bn-sub{margin:6px 0 0;color:#b9c4d9;font-size:15px}
.bn-line{position:absolute;left:0;right:0;bottom:0;height:2px;background:linear-gradient(90deg,transparent,var(--gold),var(--purple),transparent);
background-size:200% 100%;animation:slide 6s linear infinite;opacity:.8}
@keyframes slide{to{background-position:-200% 0}}

/* ---------- cartoes hextech ---------- */
.card,.kpi,.hero,.champ,.mcard,.gcard,.dcard,.tile{position:relative;transition:transform .22s ease,box-shadow .22s ease,border-color .22s ease}
.card::before,.hero::before,.kpi::before{content:"";position:absolute;left:16px;right:16px;top:-1px;height:1px;
background:linear-gradient(90deg,transparent,var(--gold),transparent);opacity:.55;pointer-events:none}
.card:hover,.kpi:hover{border-color:#3a4458}
a.mcard:hover,.gcard:hover,.dcard:hover,a.tile:hover,.champ:hover{transform:translateY(-4px);border-color:var(--purple);
box-shadow:0 14px 34px rgba(0,0,0,.45),0 0 22px rgba(59,158,255,.22)}
.gcard.v{background:linear-gradient(90deg,rgba(94,224,192,.10),var(--panel) 38%)}
.gcard.d{background:linear-gradient(90deg,rgba(255,122,133,.10),var(--panel) 38%)}
.cic{transition:transform .25s ease,box-shadow .25s ease}
.gcard:hover .cic,.mcard:hover .cic,.champ:hover .cic{transform:scale(1.1)}
.ring-me{box-shadow:0 0 0 2px var(--gold),0 0 14px rgba(233,196,106,.45)}
.ring-foe{box-shadow:0 0 0 2px #E8817C,0 0 14px rgba(255,122,133,.35)}

/* titulos de secao */
h2{display:flex;align-items:center;gap:12px}
h2::before{content:"";flex:none;width:8px;height:8px;background:var(--gold);transform:rotate(45deg);box-shadow:0 0 10px rgba(233,196,106,.7)}
h2::after{content:"";flex:1;height:1px;background:linear-gradient(90deg,var(--rule),transparent)}

/* menu */
.rail a{position:relative;transition:background .2s,color .2s,transform .2s}
.rail a:hover{transform:translateX(3px)}
.rail a[aria-current=page]{box-shadow:inset 3px 0 0 var(--gold),0 0 18px rgba(59,158,255,.18)}
.brand{text-shadow:0 0 22px rgba(59,158,255,.5);letter-spacing:.02em}

/* botoes */
button,.btn{position:relative;overflow:hidden;transition:transform .15s,box-shadow .2s,filter .2s}
button:hover,.btn:hover{transform:translateY(-1px);box-shadow:0 8px 22px rgba(59,158,255,.35);filter:brightness(1.08)}
button::after,.btn::after{content:"";position:absolute;top:0;left:-70%;width:45%;height:100%;
background:linear-gradient(100deg,transparent,rgba(255,255,255,.28),transparent);transform:skewX(-20deg);transition:left .5s}
button:hover::after,.btn:hover::after{left:130%}
.syncbtn{animation:glow 3.2s ease-in-out infinite}
@keyframes glow{0%,100%{box-shadow:0 0 0 rgba(59,158,255,0)}50%{box-shadow:0 0 22px rgba(59,158,255,.45)}}

/* aparecer ao rolar + barras e aneis animados */
.js .rv{opacity:0;transform:translateY(18px);transition:opacity .6s ease,transform .6s cubic-bezier(.2,.7,.2,1)}
.js .rv.in{opacity:1;transform:none}
.js .pt2 i,.js .bar i,.js .pbar i{transform:scaleX(0);transform-origin:left}
.js .in .pt2 i,.js .in .bar i,.js .in .pbar i{transform:scaleX(1);transition:transform 1s cubic-bezier(.2,.7,.2,1) .25s}
.js .wring .fg{stroke-dashoffset:132;transition:stroke-dashoffset 1.1s cubic-bezier(.2,.7,.2,1) .2s}
.wring .fg{filter:drop-shadow(0 0 4px rgba(140,196,255,.6))}

/* componentes novos */
.vs-hero{display:flex;align-items:center;gap:26px;padding:22px 26px;border:1px solid var(--rule);border-radius:16px;
background:linear-gradient(100deg,rgba(255,122,133,.12),var(--panel) 45%,rgba(233,196,106,.08));margin-bottom:18px;flex-wrap:wrap}
.vs-hero .who2{display:flex;flex-direction:column;gap:2px}.vs-hero .who2 small{color:var(--mute);font:11.5px var(--mono);letter-spacing:.12em;text-transform:uppercase}
.vs-hero .who2 b{font:700 30px/1.1 var(--head)}
.vs-hero .stats{display:flex;gap:12px;margin-left:auto;flex-wrap:wrap}
.pill{display:inline-flex;align-items:center;gap:8px;padding:8px 14px;border:1px solid var(--rule);border-radius:999px;background:rgba(255,255,255,.03);font:600 13px var(--head)}
.pill small{color:var(--mute);font:11px var(--mono);letter-spacing:.08em;text-transform:uppercase}
.pill.warnp{border-color:rgba(233,196,106,.55);color:var(--gold);background:rgba(233,196,106,.08)}
.pill.okp{border-color:rgba(94,224,192,.5);color:var(--win)}.pill.badp{border-color:rgba(255,122,133,.5);color:var(--loss)}
.vsgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:14px;margin:6px 0 22px}
.vsc{display:flex;align-items:center;gap:16px;padding:16px 18px;border:1px solid var(--rule);border-radius:14px;background:var(--panel)}
.vsc div{flex:1;display:flex;flex-direction:column;gap:2px}.vsc small{color:var(--mute)}
.vsc.good{box-shadow:inset 3px 0 0 var(--win)}.vsc.bad{box-shadow:inset 3px 0 0 var(--loss)}
.duel{display:grid;grid-template-columns:minmax(150px,230px) 1fr 70px;gap:16px;align-items:center;padding:14px 0;border-top:1px solid var(--rule)}
.duel:first-of-type{border-top:0}
.duel .dl{font-weight:600}.duel .dl small{display:block;color:var(--mute);font:11px var(--mono);font-weight:400}
.dtrack{position:relative;height:36px;display:flex;flex-direction:column;justify-content:space-between}
.dbar{height:14px;border-radius:7px;background:rgba(255,255,255,.05);position:relative;overflow:hidden}
.dbar i{display:block;height:100%;border-radius:7px}
.dbar.me i{background:linear-gradient(90deg,#2478d6,#8cc4ff)}.dbar.top i{background:linear-gradient(90deg,#b8923f,#E9C46A)}
.dbar b{position:absolute;right:8px;top:-1px;font:600 11px/16px var(--mono);color:#fff;text-shadow:0 1px 3px #000}
.dd{font:700 15px var(--mono);text-align:right}.dd.up{color:var(--win)}.dd.dn{color:var(--loss)}.dd.eq{color:var(--mute)}
.lg{display:flex;gap:18px;margin:0 0 6px;font:12px var(--mono);color:var(--mute)}.lg i{display:inline-block;width:12px;height:12px;border-radius:3px;margin-right:6px;vertical-align:-1px}
.pgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}
.pcard{padding:18px;border:1px solid var(--rule);border-radius:14px;background:var(--panel);display:flex;flex-direction:column;gap:6px;align-items:center;text-align:center}
.pcard .em{font-size:30px;filter:drop-shadow(0 0 10px rgba(233,196,106,.5))}.pcard b{font:700 15px var(--head)}.pcard small{color:var(--mute)}
.pcard.best{border-color:rgba(94,224,192,.6);box-shadow:0 0 24px rgba(94,224,192,.14)}.pcard.dim{opacity:.6}
.metas{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px}
.meta{display:flex;align-items:center;gap:14px;padding:14px 16px;border:1px solid var(--rule);border-radius:12px;background:var(--panel)}
.meta .ck{flex:none;width:34px;height:34px;border-radius:50%;display:grid;place-items:center;font:700 16px var(--head)}
.meta.ok .ck{background:rgba(94,224,192,.15);color:var(--win);border:1px solid var(--win)}.meta.no .ck{background:rgba(255,122,133,.12);color:var(--loss);border:1px solid var(--loss)}
.meta div{display:flex;flex-direction:column}.meta small{color:var(--mute)}
.steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px;margin:6px 0 4px}
.step{padding:18px 20px;border:1px solid var(--rule);border-radius:14px;background:var(--panel);display:flex;flex-direction:column;gap:8px}
.step .stn{display:flex;align-items:center;gap:12px;font:700 16px var(--head)}
.step .stn span{flex:none;width:30px;height:30px;display:grid;place-items:center;border-radius:8px;background:rgba(233,196,106,.12);color:var(--gold);border:1px solid rgba(233,196,106,.5);font:700 14px var(--mono)}
.joblog{display:flex;flex-direction:column;gap:0;border-left:2px solid var(--rule);margin-left:8px}
.joblog li{list-style:none;position:relative;padding:5px 0 5px 20px;font:13px var(--mono);color:#b9c4d9}
.joblog li::before{content:"";position:absolute;left:-6px;top:11px;width:10px;height:10px;border-radius:50%;background:var(--rule);border:2px solid var(--panel)}
.joblog li:last-child::before{background:var(--purple);box-shadow:0 0 10px var(--purple)}
.joblog{padding:0;margin:10px 0 0 8px}
.keybox{display:flex;align-items:center;gap:14px;flex-wrap:wrap}.keybox .st{font:600 12px var(--mono);letter-spacing:.1em;text-transform:uppercase}
.empty{display:flex;flex-direction:column;align-items:center;gap:6px;padding:34px;border:1px dashed var(--rule);border-radius:14px;text-align:center;color:var(--mute)}
.empty .em{font-size:34px}
@media (max-width:860px){.duel{grid-template-columns:1fr}.vs-hero .stats{margin-left:0}}

/* radar animado */
.radar .shape{filter:drop-shadow(0 0 9px rgba(59,158,255,.75));transform-box:view-box;transform-origin:50% 48.5%;animation:breathe 4s ease-in-out 1.6s infinite}
@keyframes breathe{0%,100%{fill:rgba(59,158,255,.28)}50%{fill:rgba(59,158,255,.46)}}
.radar .dot{filter:drop-shadow(0 0 5px #8cc4ff);transform-box:fill-box;transform-origin:center;animation:dotp 2.4s ease-in-out infinite}
@keyframes dotp{0%,100%{transform:scale(1)}50%{transform:scale(1.7)}}
.radar .ring1{animation:march 2.2s linear infinite}@keyframes march{to{stroke-dashoffset:-16}}
.radar .spoke{stroke:#2c3445}
.radar:hover .shape{stroke:#fff;filter:drop-shadow(0 0 14px rgba(140,196,255,.95))}
.js .radar .shape{transform:scale(0);opacity:0}
.js .in .radar .shape{transform:scale(1);opacity:1;transition:transform 1.2s cubic-bezier(.2,.9,.3,1.15) .35s,opacity .5s .35s}
.js .radar .dot,.js .radar .rl,.js .radar .rv,.js .radar .ra{opacity:0}
.js .in .radar .dot,.js .in .radar .rl,.js .in .radar .rv,.js .in .radar .ra{opacity:1;transition:opacity .7s 1.1s}
.js .radar .ringg,.js .radar .ring1,.js .radar .spoke{opacity:0}
.js .in .radar .ringg,.js .in .radar .ring1,.js .in .radar .spoke{opacity:1;transition:opacity .8s .1s}

/* graficos: linhas se desenham, areas surgem, pontos saltam */
.js .spark polyline,.js .evo .ln,.js .gold .line{stroke-dasharray:1;stroke-dashoffset:1}
.js .in .spark polyline,.js .in .evo .ln,.js .in .gold .line{stroke-dashoffset:0;transition:stroke-dashoffset 1.7s cubic-bezier(.3,.6,.2,1) .3s}
.js .gold .fill{opacity:0}.js .in .gold .fill{opacity:1;transition:opacity 1.2s ease 1.1s}
.js .gold .ev,.js .evo .pt,.js .spark .last,.js .tl .death,.js .tl .obj{opacity:0;transform-box:fill-box;transform-origin:center;transform:scale(0)}
.js .in .gold .ev,.js .in .evo .pt,.js .in .spark .last,.js .in .tl .death,.js .in .tl .obj{opacity:1;transform:scale(1);transition:opacity .4s,transform .5s cubic-bezier(.3,1.6,.5,1)}
.spark .last{filter:drop-shadow(0 0 5px #8cc4ff);animation:dotp 2.4s ease-in-out 2s infinite}
.evo .ln,.gold .line,.spark polyline{filter:drop-shadow(0 0 5px rgba(59,158,255,.55))}
.evo .pt:hover,.gold .ev:hover{filter:drop-shadow(0 0 8px #fff);transform:scale(1.5)!important}
.card::after,.kpi::after,.hero::after,.thr::after,.vsc::after,.pcard::after,.met::after,.step::after,.phero::after{content:"";position:absolute;inset:0;border-radius:inherit;pointer-events:none;opacity:0;
transition:opacity .3s;background:radial-gradient(280px circle at var(--mx,50%) var(--my,50%),rgba(140,196,255,.13),transparent 65%)}
.card:hover::after,.kpi:hover::after,.hero:hover::after,.thr:hover::after,.vsc:hover::after,.pcard:hover::after,.met:hover::after,.step:hover::after,.phero:hover::after{opacity:1}
.met,.vsc,.pcard,.step,.thr{position:relative}
.pt2 i,.bar .bt i{box-shadow:0 0 10px rgba(59,158,255,.35)}
.pt2 i::after{content:"";position:absolute;inset:0;background:linear-gradient(100deg,transparent 30%,rgba(255,255,255,.35),transparent 70%);background-size:220% 100%;animation:shim 3s ease-in-out infinite}
.pt2 i{position:relative;overflow:hidden}@keyframes shim{0%{background-position:150% 0}100%{background-position:-60% 0}}
.dbar i{position:relative;overflow:hidden}.dbar i::after{content:"";position:absolute;inset:0;background:linear-gradient(100deg,transparent 30%,rgba(255,255,255,.3),transparent 70%);background-size:220% 100%;animation:shim 3.4s ease-in-out infinite}
.js .dbar i,.js .wk i{transform:scaleX(0);transform-origin:left}.js .wk i{transform:scaleY(0);transform-origin:bottom}
.js .in .dbar i{transform:scaleX(1);transition:transform 1s cubic-bezier(.2,.7,.2,1) .2s}.js .in .wk i,.js .rv.in .wk i{transform:scaleY(1);transition:transform .9s cubic-bezier(.2,.8,.2,1) .2s}
.js .hc{opacity:0;transform:scale(.6)}.js .in .hc{opacity:1;transform:scale(1);transition:opacity .5s,transform .5s cubic-bezier(.3,1.5,.5,1)}

/* faixa de tarefa (em todas as telas) */
.jobbar{display:flex;align-items:center;gap:14px;padding:12px 18px;margin:0 0 16px;border-radius:14px;border:1px solid var(--rule);background:var(--panel);position:relative;overflow:hidden}
.jobbar div{display:flex;flex-direction:column;min-width:0;flex:1}.jobbar b{font:700 14px var(--head)}.jobbar small{color:var(--mute);font:12.5px var(--mono);overflow-wrap:anywhere}
.jobbar.run{border-color:rgba(59,158,255,.55);box-shadow:0 0 24px rgba(59,158,255,.18)}
.spin{flex:none;width:20px;height:20px;border-radius:50%;border:3px solid rgba(140,196,255,.25);border-top-color:#8cc4ff;animation:spn .9s linear infinite}@keyframes spn{to{transform:rotate(360deg)}}
.jb-bar{position:absolute;left:0;right:0;bottom:0;height:3px;background:rgba(255,255,255,.05)}
.jb-bar i{position:absolute;top:0;bottom:0;width:35%;background:linear-gradient(90deg,transparent,#3b9eff,#8cc4ff,transparent);animation:ind 1.6s ease-in-out infinite}@keyframes ind{from{left:-35%}to{left:100%}}
.jobbar.done{border-color:rgba(94,224,192,.5)}.jobbar.err{border-color:rgba(255,122,133,.6);background:rgba(255,122,133,.07)}
.jb-i{flex:none;width:28px;height:28px;border-radius:50%;display:grid;place-items:center;font:700 14px var(--head)}
.jobbar.done .jb-i{background:rgba(94,224,192,.15);color:var(--win);border:1px solid var(--win)}.jobbar.err .jb-i{background:rgba(255,122,133,.15);color:var(--loss);border:1px solid var(--loss)}
.jb-x{flex:none;background:none;color:var(--mute);box-shadow:none;padding:4px 9px}.jb-x:hover{color:#fff;transform:none;box-shadow:none;filter:none}
.btn.gold{background:linear-gradient(135deg,#E9C46A,#b8923f);color:#1a1405}.btn.gold:hover{box-shadow:0 8px 22px rgba(233,196,106,.4)}
@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}.js .rv{opacity:1;transform:none}}
"""

JS = r"""<script>
(function(){document.documentElement.classList.add('js');
var sel='main .card,main .hero,main .kpi,main .champ,main .mcard,main .gcard,main .dcard,main .tile,main .vsc,main .pcard,main .meta,main .step,main .vs-hero,main .tip,main .sec,main h2,main .grid2>*,main .teams>*,main .levers>*,main .thr,main .phero,main .arena,main .sstat,main .pkrail,main .empty';
var els=[].slice.call(document.querySelectorAll(sel));
els.forEach(function(el){if(el.closest('.rv')||el.closest('.ppanel[hidden]'))return;el.classList.add('rv');
var sib=el.parentNode?[].indexOf.call(el.parentNode.children,el):0;el.style.transitionDelay=Math.min(sib,10)*55+'ms';});
/* linhas dos graficos se desenham */
document.querySelectorAll('.spark polyline,.evo .ln,.gold .line').forEach(function(l){l.setAttribute('pathLength','1')});
document.querySelectorAll('.tl .death,.tl .obj,.gold .ev,.evo .pt').forEach(function(c,i){c.style.transitionDelay=(0.9+Math.min(i,30)*0.05)+'s'});
/* numeros contam de 0 ate o valor */
function count(el){if(el.dataset.cnt)return;el.dataset.cnt=1;var t=el.textContent.trim();var m=t.match(/^([+\-−]?)(\d+(?:[.,]\d+)?)(.*)$/);if(!m)return;
var dec=(m[2].split(/[.,]/)[1]||'').length,sep=m[2].indexOf(',')>=0?',':'.',v=parseFloat(m[2].replace(',','.')),t0=null;
function step(ts){if(!t0)t0=ts;var k=Math.min(1,(ts-t0)/1000),e=1-Math.pow(1-k,3);var n=(v*e).toFixed(dec);if(sep===',')n=n.replace('.',',');el.textContent=m[1]+n+m[3];if(k<1)requestAnimationFrame(step)}
requestAnimationFrame(step)}
function show(el){el.classList.add('in');
el.querySelectorAll('.wring .fg').forEach(function(f){f.style.strokeDashoffset=f.getAttribute('stroke-dashoffset')});
el.querySelectorAll('.kv,.wring text,.big2 b').forEach(count);
if(el.classList.contains('kpi')){var k=el.querySelector('.kv');if(k)count(k)}}
if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting){show(x.target);io.unobserve(x.target)}})},{threshold:.08});
document.querySelectorAll('.rv').forEach(function(el){io.observe(el)});}
setTimeout(function(){document.querySelectorAll('.rv:not(.in)').forEach(show)},2500);
/* brilho que segue o mouse e inclinacao 3D leve */
var G='.card,.kpi,.hero,.thr,.vsc,.pcard,.met,.step,.phero';
document.addEventListener('mousemove',function(ev){var c=ev.target.closest&&ev.target.closest(G);if(c){var r=c.getBoundingClientRect();c.style.setProperty('--mx',(ev.clientX-r.left)+'px');c.style.setProperty('--my',(ev.clientY-r.top)+'px')}
var t=ev.target.closest&&ev.target.closest('.kpi,.champ,.pk,.pcard,.vsc,.mcard,.thr,.step,.dcard');
if(t){var b=t.getBoundingClientRect(),x=(ev.clientX-b.left)/b.width-.5,y=(ev.clientY-b.top)/b.height-.5;
t.style.transition='transform .08s';t.style.transform='perspective(700px) rotateY('+(x*7)+'deg) rotateX('+(-y*7)+'deg) translateY(-3px)'}});
document.addEventListener('mouseout',function(ev){var t=ev.target.closest&&ev.target.closest('.kpi,.champ,.pk,.pcard,.vsc,.mcard,.thr,.step,.dcard');
if(t&&!t.contains(ev.relatedTarget)){t.style.transition='';t.style.transform=''}});

/* tarefa em segundo plano: atualiza so a faixa de cima, sem recarregar a pagina */
function jbDismissed(){try{var fin=localStorage.getItem('jb');document.querySelectorAll('.jobbar[data-fin]').forEach(function(b){if(b.dataset.fin===fin)b.remove()})}catch(x){}}
jbDismissed();
var ja=document.getElementById('jobarea');
if(ja){var wasRun=ja.dataset.running==='1';
function pollJob(){fetch('/api/jobs',{cache:'no-store'}).then(function(r){return r.text()}).then(function(h){
var run=h.indexOf('jobbar run')>=0;if(h!==ja.__last){ja.__last=h;ja.innerHTML=h;jbDismissed()}
ja.dataset.running=run?'1':'0';if(wasRun&&!run){document.dispatchEvent(new Event('jobdone'))}wasRun=run;
setTimeout(pollJob,run?2000:12000)}).catch(function(){setTimeout(pollJob,15000)})}
setTimeout(pollJob,wasRun?2000:12000)}
/* telas ao vivo (Selecao, Ao vivo): troca so o miolo quando algo muda, sem piscar */
var lr=document.getElementById('liveroot');
if(lr){var ms=parseInt(lr.dataset.every||'5000',10);
var busy=0;
setInterval(function(){if(busy>Date.now()||document.hidden||(window.__hold||0)>Date.now())return;var ae=document.activeElement;if(ae&&lr.contains(ae)&&/INPUT|TEXTAREA|SELECT/.test(ae.tagName))return;
busy=Date.now()+15000;
fetch(location.href,{cache:'no-store'}).then(function(r){return r.text()}).finally(function(){busy=0}).then(function(t){
var d=new DOMParser().parseFromString(t,'text/html');var n=d.getElementById('liveroot');if(!n)return;
if(n.innerHTML===lr.__last)return;lr.__last=n.innerHTML;lr.classList.add('noanim');lr.innerHTML=n.innerHTML;lr.classList.add('in');lr.querySelectorAll('.rv').forEach(function(r){r.classList.add('in')});requestAnimationFrame(function(){requestAnimationFrame(function(){lr.classList.remove('noanim')})});
lr.querySelectorAll('.wring .fg').forEach(function(f){f.style.strokeDashoffset=f.getAttribute('stroke-dashoffset')});
document.dispatchEvent(new Event('liveswap'))}).catch(function(){})},ms)}
})();
</script>"""
