"""Resumo do dia: quantas ganhou e perdeu, PDL do comeco ao fim, a sequencia de partidas, sinais de tilt
e os maiores erros do dia comparados com a sua media."""
import html
import time
from collections import Counter

from . import desempenho, postmore, ranks, report

e = lambda x: html.escape("" if x is None else str(x))
DAY_START_H = 6          # o dia vira as 6h: a madrugada conta como o dia anterior
QUEUE = {420: "Solo", 440: "Flex", 400: "Normal", 430: "Normal", 490: "Rápida", 450: "ARAM", 1700: "Arena", 1900: "URF"}
FIX = {
    "d10": ("Morreu antes dos 10 minutos", "Nos primeiros 10 min, só troque quando o oponente gastar a habilidade principal e saiba onde está o caçador inimigo."),
    "jg": ("Morreu para o caçador inimigo", "Sentinela no rio a cada volta à base; recue quando o caçador some do mapa."),
    "deep": ("Morreu avançado no lado inimigo", "Só avance do outro lado do rio com visão e sabendo onde estão os inimigos sumidos."),
    "cs": ("Ficou atrás no farm aos 10", "Não deixe a onda morrer na torre enquanto troca; priorize o último golpe."),
    "vis": ("Visão baixa", "Sentinela de Controle em toda volta à base e amuleto sempre que estiver pronto."),
    "many": ("Morreu 8 vezes ou mais", "Depois de 2 mortes, jogue seguro até o próximo item ou objetivo."),
    "ahead": ("Morreu com vantagem", "Com vantagem, transforme em torre ou objetivo antes de procurar mais abates."),
}


def day_bounds(day=None):
    """(inicio_ms, fim_ms, 'AAAA-MM-DD') do dia pedido; sem dia: o dia atual (que comeca as 6h)."""
    now = time.time()
    if day:
        try:
            t = time.strptime(day, "%Y-%m-%d")
        except ValueError:
            day = None
    if not day:
        lt = time.localtime(now - DAY_START_H * 3600)
        day = time.strftime("%Y-%m-%d", lt)
        t = time.strptime(day, "%Y-%m-%d")
    start = time.mktime((t.tm_year, t.tm_mon, t.tm_mday, DAY_START_H, 0, 0, 0, 0, -1))
    return int(start * 1000), int((start + 86400) * 1000), day


def _shift(day, n):
    t = time.strptime(day, "%Y-%m-%d")
    return time.strftime("%Y-%m-%d", time.localtime(time.mktime((t.tm_year, t.tm_mon, t.tm_mday, 12, 0, 0, 0, 0, -1)) + n * 86400))


def _rows(con, puuid, a, b):
    return con.execute(
        """SELECT p.*, m.queue_id, m.duration_s, m.patch, m.started_ms FROM participants p JOIN matches m USING (match_id)
           WHERE p.puuid=? AND COALESCE(m.duration_s,0)>=300 AND m.started_ms>=? AND m.started_ms<? ORDER BY m.started_ms""",
        (puuid, a, b)).fetchall()


def _rank_txt(h):
    if not h:
        return "-"
    return f"{ranks.TIER_PT.get(h['tier'], h['tier'])} {h['division'] or ''} {h['lp']} PDL".replace("  ", " ")


def _avg(gs, f):
    v = [f(g) for g in gs]
    v = [x for x in v if x is not None]
    return sum(v) / len(v) if v else None


CSS = """
.dy{display:flex;flex-direction:column;gap:16px}
.dy-nav{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.dy-nav a{padding:7px 12px;border:1px solid var(--rule);border-radius:10px;color:#D6CCC0;text-decoration:none;font:600 13px var(--body)}
.dy-nav b{font:700 16px var(--head);color:#fff}
.dy-verdict{border-radius:14px;padding:14px 16px;border:1px solid var(--rule);background:var(--panel);color:#F0E4CC;font-size:14px;line-height:1.5}
.dy-verdict.bad{border-color:rgba(217,83,79,.5);background:rgba(217,83,79,.08)}.dy-verdict.good{border-color:rgba(107,191,138,.45);background:rgba(107,191,138,.07)}
.dy-verdict b{font:700 17px var(--head);display:block;margin-bottom:4px;color:#fff}
.dy-top{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px}
.dy-k{border:1px solid var(--rule);border-radius:14px;padding:12px 14px;background:var(--panel)}
.dy-k small{display:block;color:var(--mute);font:600 11px var(--head);text-transform:uppercase;letter-spacing:.06em}
.dy-k b{display:block;font:700 22px var(--head);color:#fff;margin:4px 0 2px}.dy-k span{color:#D6CCC0;font-size:12.5px}
.dy .w{color:#8FD4A8}.dy .l{color:#E8817C}
.dy-card{border:1px solid var(--rule);border-radius:14px;padding:14px 16px;background:var(--panel);overflow-x:auto}
.dy-card h2{margin:0 0 10px;font:700 18px var(--head);color:#fff}.dy-card h2 small{color:var(--mute);font:500 12px var(--body);margin-left:8px}
.dy-t{width:100%;border-collapse:collapse;font-size:13px;min-width:620px}.dy-t th{text-align:left;color:var(--mute);font:600 11px var(--head);text-transform:uppercase;padding:6px 8px;border-bottom:1px solid var(--rule)}
.dy-t td{padding:7px 8px;border-bottom:1px solid rgba(255,255,255,.04);color:#E8DCCB;vertical-align:middle}.dy-t td.c{display:flex;align-items:center;gap:8px;color:#fff;font-weight:600}
.dy-t tr.tilt td{background:rgba(217,83,79,.06)}.dy-t a{color:#D6CCC0}
.lpb{font:700 12.5px var(--mono,monospace)}.lpb.w{color:#8FD4A8}.lpb.l{color:#E8817C}
.dy-res{font:700 11px var(--head);padding:3px 8px;border-radius:6px}.dy-res.w{background:rgba(107,191,138,.16)}.dy-res.l{background:rgba(217,83,79,.15)}
.dy-mist{display:flex;flex-direction:column;gap:10px}.dy-mist>div{display:grid;grid-template-columns:70px minmax(0,1fr);gap:12px;align-items:start;border-bottom:1px solid rgba(255,255,255,.05);padding-bottom:10px}
.dy-mist>div b.n{font:700 22px var(--head);color:#E8817C}.dy-mist div p{margin:2px 0;color:#D6CCC0;font-size:13px}.dy-mist div h3{margin:0;font:700 15px var(--head);color:#fff}
.dy-cmp div{display:grid;grid-template-columns:minmax(0,1fr) 80px 80px;gap:8px;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.04);font-size:13px;color:#E8DCCB}
.dy-cmp div.h{color:var(--mute);font:600 11px var(--head);text-transform:uppercase}
.dy-note{color:var(--mute);font-size:12px;margin:6px 0 0}
"""


def page_html(con, puuid, champ_icon, day=None):
    a, b, day = day_bounds(day)
    today = day_bounds()[2]
    label = time.strftime("%d/%m/%Y", time.strptime(day, "%Y-%m-%d"))
    nav = (f"<div class='dy-nav'><a href='/hoje?d={_shift(day, -1)}'>← dia anterior</a><b>{'Hoje · ' if day == today else ''}{label}</b>"
           + (f"<a href='/hoje?d={_shift(day, 1)}'>próximo dia →</a>" if day < today else "") + "</div>")
    rows = _rows(con, puuid, a, b)
    if not rows:
        return (f"<style>{CSS}</style><div class='dy'>{nav}<div class='empty'><b>Nenhuma partida neste dia</b>"
                "<span>Se você jogou, sincronize as partidas (o app também busca sozinho depois de cada jogo).</span></div></div>")
    games = report._games_from_rows(con, rows)
    qmap = {r["match_id"]: r["queue_id"] for r in rows}
    for g in games:
        g["queue_id"] = qmap.get(g["match_id"])
    fx = desempenho.facts(con, games)
    solo = [g for g in games if g["queue_id"] == 420]
    from . import pages4
    lp_all = pages4.lp_per_game(con, puuid)
    lp = {g["match_id"]: lp_all[g["match_id"]][0] for g in solo if g["match_id"] in lp_all}
    w = sum(1 for g in games if g["win"])
    l = len(games) - w

    # PDL do dia (historico guardado)
    hist = ranks.history(con)
    before = [h for h in hist if h["at_ms"] <= a]
    inday = [h for h in hist if a < h["at_ms"] <= b]
    start = before[-1] if before else (inday[0] if inday else None)
    end = inday[-1] if inday else None
    low = min(inday, key=lambda h: h["v"]) if inday else None
    high = max(inday, key=lambda h: h["v"]) if inday else None
    lp_sum = sum(lp.values()) if lp else None
    pdl_delta = (end["v"] - start["v"]) if start and end else lp_sum

    # sessao e tilt
    streak = worst_l = best_w = 0
    kind = None
    after2 = []
    for i, g in enumerate(games):
        if i >= 2 and not games[i - 1]["win"] and not games[i - 2]["win"]:
            after2.append(g)
        if g["win"] == kind:
            streak += 1
        else:
            kind, streak = g["win"], 1
        if g["win"]:
            best_w = max(best_w, streak)
        else:
            worst_l = max(worst_l, streak)
    first_t = games[0]["started_ms"]
    last_end = games[-1]["started_ms"] + (games[-1]["duration_s"] or 0) * 1000
    hours = (last_end - first_t) / 3600000
    play_min = sum((g["duration_s"] or 0) for g in games) / 60
    gaps = [(games[i]["started_ms"] - (games[i - 1]["started_ms"] + (games[i - 1]["duration_s"] or 0) * 1000)) / 60000 for i in range(1, len(games))]
    no_break = sum(1 for x in gaps if x < 5)
    first3 = games[:3]
    rest = games[3:]

    tilt = l > w and (len(after2) >= 2 or worst_l >= 3)
    if tilt:
        vcls, vt = "bad", "Dia de tilt"
        msg = (f"Você perdeu {worst_l} seguidas e jogou {len(after2)} partida{'s' if len(after2) != 1 else ''} logo depois de 2 derrotas"
               + (f" (ganhou {sum(1 for g in after2 if g['win'])})" if after2 else "") + ". "
               "Regra para amanhã: perdeu 2 seguidas, para por hoje ou faz uma pausa de 30 minutos longe do PC.")
    elif w > l:
        vcls, vt = "good", "Dia positivo"
        msg = f"{w} vitórias e {l} derrotas. " + ("Bom momento para parar no lucro." if len(games) >= 5 else "Continue no mesmo ritmo, sem forçar.")
    else:
        vcls, vt = "", "Dia equilibrado"
        msg = f"{w} vitórias e {l} derrotas."
    if len(first3) == 3 and rest:
        msg += (f" Nas 3 primeiras você ganhou {sum(1 for g in first3 if g['win'])}; depois disso, "
                f"{sum(1 for g in rest if g['win'])} de {len(rest)}.")
    if not tilt and worst_l >= 3:
        msg += f" Teve uma sequência de {worst_l} derrotas: nesse ponto, a pausa salva PDL."
    if no_break >= 3:
        msg += f" Emendou {no_break} partidas sem pausa de 5 minutos."

    top = (f"<div class='dy-top'>"
           f"<div class='dy-k'><small>Partidas</small><b>{len(games)}</b><span><span class='w'>{w}V</span> <span class='l'>{l}D</span> · {round(100 * w / len(games))}%</span></div>"
           f"<div class='dy-k'><small>PDL no dia</small><b class='{'w' if (pdl_delta or 0) >= 0 else 'l'}'>{(f'{pdl_delta:+d}' if pdl_delta is not None else '-')}</b>"
           + (f"<span>{e(_rank_txt(start))} → {e(_rank_txt(end))}</span></div>" if start and end else "<span>sem elo guardado neste dia</span></div>")
           + (f"<div class='dy-k'><small>Pior e melhor ponto</small><b class='l'>{e(_rank_txt(low))}</b><span>melhor: {e(_rank_txt(high))}</span></div>" if low else "")
           + f"<div class='dy-k'><small>Sequências</small><b>{worst_l} derrota{'s' if worst_l != 1 else ''}</b><span>maior sequência de vitórias: {best_w}</span></div>"
           f"<div class='dy-k'><small>Tempo jogando</small><b>{int(play_min // 60)}h{int(play_min % 60):02d}</b><span>em {hours:.1f} h de sessão</span></div></div>")

    # partidas do dia
    trs = ""
    for i, g in enumerate(games):
        k, d_, a_ = g["kills"], g["deaths"], g["assists"]
        f = fx.get(g["match_id"]) or {}
        dl = lp.get(g["match_id"])
        flags = postmore.game_flags(con, g)
        g["_flags"] = flags
        t_ = time.strftime("%H:%M", time.localtime(g["started_ms"] / 1000))
        errs = ", ".join(FIX[x][0].lower() for x in ("d10", "jg", "deep", "ahead", "many", "cs", "vis") if x in flags)
        trs += (f"<tr class='{'tilt' if g in after2 else ''}'><td>{t_}</td><td class='c'>{champ_icon(g['champion'], 26)}{e(g['champion'])}</td>"
                f"<td><span class='dy-res {'w' if g['win'] else 'l'}'>{'Vitória' if g['win'] else 'Derrota'}</span></td>"
                f"<td>{k}/<span class='l'>{d_}</span>/{a_}</td><td>{g['cs']} <small>({(g.get('cs_per_min') or 0):.1f})</small></td>"
                f"<td>{e(g.get('opp_champion') or '-')}</td><td>{e(QUEUE.get(g['queue_id'], ''))}</td>"
                f"<td>{pages4.lp_badge(lp_all.get(g['match_id'])) if g['queue_id'] == 420 else ''}</td>"
                f"<td><small>{e(errs) or '-'}</small></td><td><a href='/partida/{e(g['match_id'])}'>abrir</a></td></tr>")
    table = (f"<div class='dy-card'><h2>Partidas do dia<small>em vermelho claro: jogadas logo depois de 2 derrotas</small></h2>"
             f"<table class='dy-t'><thead><tr><th>Hora</th><th>Campeão</th><th>Resultado</th><th>KDA</th><th>Farm</th><th>Contra</th><th>Fila</th><th>PDL</th><th>Erros</th><th></th></tr></thead>"
             f"<tbody>{trs}</tbody></table></div>")

    # maiores erros do dia
    cnt = Counter(x for g in games for x in g["_flags"])
    in_loss = Counter(x for g in games if not g["win"] for x in g["_flags"])
    mist = ""
    for k_, n in sorted(cnt.items(), key=lambda kv: (-in_loss[kv[0]], -kv[1]))[:4]:
        title, fix = FIX[k_]
        mist += (f"<div><b class='n'>{n}×</b><div><h3>{e(title)}</h3><p>Em {n} de {len(games)} partidas"
                 + (f" ({in_loss[k_]} delas derrotas)" if in_loss[k_] else "") + f".</p><p><b>Para amanhã:</b> {e(fix)}</p></div></div>")
    mist_html = (f"<div class='dy-card'><h2>Maiores erros do dia</h2><div class='dy-mist'>{mist}</div></div>" if mist
                 else "<div class='dy-card'><h2>Maiores erros do dia</h2><p class='dy-note'>Nenhum dos erros que o app procura apareceu (ou as partidas ainda estão sem linha do tempo).</p></div>")

    # hoje contra a sua media (30 dias antes)
    base_rows = con.execute(
        """SELECT p.*, m.duration_s, m.patch, m.started_ms FROM participants p JOIN matches m USING (match_id)
           WHERE p.puuid=? AND COALESCE(m.duration_s,0)>=300 AND m.started_ms<? AND m.started_ms>=? ORDER BY m.started_ms DESC LIMIT 60""",
        (puuid, a, a - 30 * 86400000)).fetchall()
    base = report._games_from_rows(con, base_rows) if base_rows else []
    cmp_ = ""
    if base:
        metrics = [("Mortes por partida", lambda g: g["deaths"], False, 1), ("Mortes antes dos 10", lambda g: g.get("deaths_before_10"), False, 1),
                   ("Farm por minuto", lambda g: g.get("cs_per_min"), True, 1), ("Farm contra o oponente aos 10", lambda g: g.get("csdiff10"), True, 0),
                   ("Participação em abates", lambda g: (g.get("kp") or 0) * 100 if g.get("kp") is not None else None, True, 0),
                   ("Visão por minuto", lambda g: g.get("vision_per_min"), True, 2)]
        for name, f, hi, nd in metrics:
            t, bv = _avg(games, f), _avg(base, f)
            if t is None or bv is None:
                continue
            good = (t >= bv) if hi else (t <= bv)
            cmp_ += f"<div><span>{e(name)}</span><span class='{'w' if good else 'l'}'>{t:.{nd}f}</span><span>{bv:.{nd}f}</span></div>"
    cmp_html = (f"<div class='dy-card'><h2>Hoje contra a sua média<small>últimos 30 dias, até 60 partidas</small></h2>"
                f"<div class='dy-cmp'><div class='h'><span></span><span>Hoje</span><span>Média</span></div>{cmp_}</div></div>") if cmp_ else ""

    # campeoes do dia
    by_c = {}
    for g in games:
        by_c.setdefault(g["champion"], []).append(g)
    champs = " · ".join(f"{e(c)} {sum(1 for g in gs if g['win'])}V {len(gs) - sum(1 for g in gs if g['win'])}D" for c, gs in sorted(by_c.items(), key=lambda x: -len(x[1])))

    return (f"<style>{CSS}</style><div class='dy'>{nav}<div class='dy-verdict {vcls}'><b>{vt}</b>{e(msg)}</div>{top}{table}"
            f"<div class='desempenho-grid' style='display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:16px'>{mist_html}{cmp_html}</div>"
            f"<p class='dy-note'>Campeões do dia: {champs}. O dia vira às {DAY_START_H}h (a madrugada conta no dia anterior). "
            "PDL do dia vem do elo que o app guarda a cada sincronização e depois de cada partida.</p></div>")
