"""Espiar os inimigos na tela de carregamento (API oficial da Riot): elo, winrate da temporada, maestria no campeao
(especialista ou primeira vez), sequencia de vitorias e quem esta de duo. Uma busca por partida, em segundo plano."""
import threading
import time

from . import ranks

_LOCK = threading.Lock()
CACHE = {}          # game_key -> {"state", "rows", "at", "spoken"}
TIER_SHORT = {"IRON": "Ferro", "BRONZE": "Bronze", "SILVER": "Prata", "GOLD": "Ouro", "PLATINUM": "Platina", "EMERALD": "Esmeralda",
              "DIAMOND": "Diamante", "MASTER": "Mestre", "GRANDMASTER": "Grão-Mestre", "CHALLENGER": "Desafiante"}


def _riot_id(p):
    gn, tl = p.get("riotIdGameName"), p.get("riotIdTagLine")
    if gn and tl:
        return gn, tl
    rid = p.get("riotId") or ""
    if "#" in rid:
        a, b = rid.split("#", 1)
        return a, b
    return None, None


def get(live_data):
    from . import spelltimers
    with _LOCK:
        return CACHE.get(spelltimers.game_key(live_data))


def ensure(key, region, live_data, ddir):
    """Comeca a busca uma vez por partida (so nos primeiros minutos)."""
    from . import live, spelltimers
    if not key or not live_data:
        return
    gt = (live_data.get("gameData") or {}).get("gameTime") or 0
    gk = spelltimers.game_key(live_data)
    with _LOCK:
        if gk in CACHE or gt > 420:
            return
        CACHE[gk] = {"state": "buscando", "rows": [], "at": time.time(), "spoken": False}
        for k in [k for k in CACHE if k != gk][:-3]:
            CACHE.pop(k, None)
    me = live._find_me(live_data)
    foes = spelltimers.enemies(live_data, me)
    _id = lambda p: p.get("riotId") or p.get("summonerName") or p.get("championName")
    allies = [p for p in live_data.get("allPlayers") or [] if me and p.get("team") == me.get("team") and p is not me and _id(p) != _id(me)]

    def go():
        from . import jobs
        from .ddragon import DataDragon
        try:
            client = jobs.client_for(key, region)
            try:
                import os
                champs = DataDragon(cache_dir=os.path.join(ddir or ".", "cache")).champions()
            except Exception:
                champs = {}
            rows, ids = [], {}
            for p in foes:
                from . import liveview
                cid = liveview.champ_id(p)
                row = {"champ": cid, "name": p.get("championName"), "pos": (p.get("position") or "").upper(), "riot": None}
                gn, tl = _riot_id(p)
                try:
                    pu = client.puuid_by_riot_id(gn, tl) if gn else None
                except Exception:
                    pu = None
                if pu:
                    row["riot"] = f"{gn}#{tl}"
                    try:
                        solo = next((x for x in client.league_by_puuid(pu) if x.get("queueType") == "RANKED_SOLO_5x5"), None)
                    except Exception:
                        solo = None
                    if solo:
                        w, l = solo.get("wins") or 0, solo.get("losses") or 0
                        row.update(tier=solo.get("tier"), div=solo.get("rank"), lp=solo.get("leaguePoints"), wins=w, losses=l,
                                   wr=round(100 * w / (w + l)) if w + l else None, hot=bool(solo.get("hotStreak")))
                    num = (champs.get(cid) or {}).get("key")
                    by_key = {v.get("key"): v.get("name") for v in champs.values()}
                    try:                    # uma chamada: maestria de todos os campeoes, em ordem
                        allm = client.mastery_all(pu) or []
                        m = next((x for x in allm if num and x.get("championId") == int(num)), {}) or {}
                        row.update(mpts=m.get("championPoints") or 0, mlvl=m.get("championLevel") or 0, mlast=m.get("lastPlayTime"))
                        top = [x.get("championId") for x in allm[:5]]
                        row["mrank"] = (top.index(int(num)) + 1) if num and int(num) in top else None
                        row["main"] = by_key.get(top[0]) if top else None
                    except Exception:
                        row.update(mpts=None, mlvl=0)
                    try:
                        mids = client.match_ids(pu, count=15, queue=420) or []
                        ids[pu] = set(mids)
                    except Exception:
                        mids = []
                    recent = []             # ultimas 4 ranqueadas: resultado, posicao e campeao
                    for mid in mids[:8]:          # 8 partidas: o suficiente para saber o main atual e o KDA
                        try:
                            info = (client.match(mid) or {}).get("info") or {}
                        except Exception:
                            continue
                        me_ = next((x for x in info.get("participants") or [] if x.get("puuid") == pu), None)
                        if me_ and (info.get("gameDuration") or 0) > 300:          # ignora remake
                            ch_ = me_.get("challenges") or {}
                            recent.append({"early": ch_.get("killsOnLanersEarlyJungleAsJungler"),
                                           "win": bool(me_.get("win")), "pos": (me_.get("teamPosition") or "").upper(),
                                           "champ": me_.get("championName"), "k": me_.get("kills") or 0,
                                           "d": me_.get("deaths") or 0, "a": me_.get("assists") or 0, "mid": mid,
                                           "at": info.get("gameEndTimestamp") or info.get("gameCreation") or 0})
                    row["recent"] = recent
                    row["puuid"] = pu
                rows.append(row)
            # lado em que o cacador inimigo comeca (ideia 13): posicao aos 2 min nas 3 ultimas partidas dele de selva
            try:
                jr = next((r for r in rows if r.get("pos") == "JUNGLE" and r.get("puuid")), None)
                if jr:
                    sides = []
                    for g_ in [g for g in jr.get("recent") or [] if g.get("pos") == "JUNGLE" and g.get("mid")][:3]:
                        tl = client.timeline(g_["mid"]) or {}
                        fr = ((tl.get("info") or {}).get("frames") or [])
                        pid_ = next((x.get("participantId") for x in (tl.get("info") or {}).get("participants") or [] if x.get("puuid") == jr["puuid"]), None)
                        if len(fr) > 2 and pid_:
                            pos_ = (fr[2].get("participantFrames") or {}).get(str(pid_), {}).get("position") or {}
                            if pos_:
                                sides.append("cima" if pos_.get("y", 0) > pos_.get("x", 0) else "baixo")
                    if len(sides) >= 2:
                        top_s = max(set(sides), key=sides.count)
                        jr["start"] = (top_s, sides.count(top_s), len(sides))
            except Exception:
                pass
            # aliados (ideias 17 e 19): sequencia, fora da posicao e experiencia do seu cacador
            arows = []
            for p in allies:
                try:
                    from . import liveview
                    gn, tl_ = _riot_id(p)
                    pu = client.puuid_by_riot_id(gn, tl_) if gn else None
                    if not pu:
                        continue
                    a = {"champ": liveview.champ_id(p), "name": p.get("championName"), "pos": (p.get("position") or "").upper(), "recent": []}
                    for mid in (client.match_ids(pu, count=5, queue=420) or [])[:4]:
                        info = (client.match(mid) or {}).get("info") or {}
                        me_ = next((x for x in info.get("participants") or [] if x.get("puuid") == pu), None)
                        if me_ and (info.get("gameDuration") or 0) > 300:
                            a["recent"].append({"win": bool(me_.get("win")), "pos": (me_.get("teamPosition") or "").upper(), "champ": me_.get("championName")})
                    arows.append(a)
                except Exception:
                    continue
            # duo: dois inimigos com 3+ partidas recentes juntos
            pus = [r.get("puuid") for r in rows]
            for i, a in enumerate(pus):
                for j, b in enumerate(pus):
                    if a and b and i < j and len(ids.get(a, set()) & ids.get(b, set())) >= 3:
                        rows[i]["duo"] = rows[j]["name"]
                        rows[j]["duo"] = rows[i]["name"]
            for r in rows:
                r["tags"] = tags(r)
            with _LOCK:
                CACHE[gk].update(state="pronto", rows=rows, allies=arows)
        except Exception as ex:
            with _LOCK:
                CACHE[gk].update(state="erro", err=str(ex)[:120])
    threading.Thread(target=go, daemon=True).start()


POS_PT = {"TOP": "topo", "JUNGLE": "selva", "MIDDLE": "meio", "BOTTOM": "atirador", "UTILITY": "suporte"}


def _streak(recent):
    """(+n) vitorias seguidas ou (-n) derrotas seguidas, contando da ultima partida."""
    if not recent:
        return 0
    first = recent[0]["win"]
    n = 0
    for g in recent:
        if g["win"] != first:
            break
        n += 1
    return n if first else -n


def _mil(pts):
    return f"{pts / 1e6:.1f} milhão".replace(".", ",").replace(",0 ", " ") if pts >= 1_000_000 else f"{pts // 1000} mil"


def tags(r):
    """Etiquetas curtas, da mais importante para a menos. O que pesa e o que ele anda jogando AGORA (ultimas ranqueadas),
    nao a maestria: 500 mil de maestria num campeao que ele nao joga ha meses nao diz nada."""
    out = []
    pts = r.get("mpts")
    rec = r.get("recent") or []
    nm = r.get("name")
    on = [g for g in rec if g.get("champ") and r.get("champ") and g["champ"].lower() == str(r["champ"]).lower()]
    if len(rec) >= 4:
        cnt = {}
        for g in rec:
            cnt[g["champ"]] = cnt.get(g["champ"], 0) + 1
        top_c, top_n = max(cnt.items(), key=lambda kv: kv[1])
        if on:
            k = sum(g["k"] + g["a"] for g in on) / max(1, sum(g["d"] for g in on))
            w = sum(1 for g in on if g["win"])
            txt = f"{len(on)} das últimas {len(rec)} de {nm} ({w}V {len(on) - w}D, KDA {k:.1f})".replace(".", ",")
            out.append(("perigo" if len(on) >= len(rec) / 2 or (len(on) >= 3 and w / len(on) >= .6) else "info",
                        ("main atual: " if len(on) >= len(rec) / 2 else "") + txt))
        elif top_n >= 3:
            out.append(("bom", f"não jogou de {nm} nas últimas {len(rec)}; anda jogando de {top_c} ({top_n} de {len(rec)})"))
    if pts is not None:
        if pts >= 800_000:
            out.append(("perigo" if on else "info", f"{_mil(pts)} de maestria"))
        elif pts < 10_000 and not on:
            out.append(("bom", "primeira vez ou quase nunca jogou com ele" if pts < 3000 else "pouca experiência com o campeão"))
    # quanto anda jogando
    if r.get("wins") is not None:
        tot = (r.get("wins") or 0) + (r.get("losses") or 0)
        sem = sum(1 for g in rec if g.get("at") and time.time() * 1000 - g["at"] < 7 * 86400000)
        if tot:
            out.append(("info", f"{tot} ranqueadas na temporada" + (f", {sem} nos últimos 7 dias" if sem else "")))
    known = [g["pos"] for g in rec if g.get("pos")]
    if r.get("pos") and len(known) >= 3 and r["pos"] not in known:
        usual = max(set(known), key=known.count)
        out.append(("bom", f"fora da posição, costuma jogar de {POS_PT.get(usual, usual.lower())}"))
    if r.get("pos") == "JUNGLE":          # estilo do jungler: ganka cedo ou farma
        jg = [g for g in rec if g.get("pos") == "JUNGLE" and g.get("early") is not None]
        if len(jg) >= 3:
            avg = sum(g["early"] for g in jg) / len(jg)
            cedo = sum(1 for g in jg if g["early"] >= 1)
            if avg >= 1.2 or cedo >= len(jg) - 0:
                out.insert(0, ("perigo", f"ganka cedo: abate em rota antes dos 10 min em {cedo} das últimas {len(jg)}"))
            elif avg < 0.4:
                out.insert(0, ("bom", f"quase não ganka cedo ({cedo} das últimas {len(jg)} com abate em rota antes dos 10 min)"))
    s = _streak(rec)
    if s >= 3 or (r.get("hot") and s >= 2):
        out.append(("perigo", f"ganhou as últimas {s} partidas"))
    elif r.get("hot"):
        out.append(("perigo", "em sequência de vitórias"))
    elif s <= -3:
        out.append(("bom", f"perdeu as últimas {-s} partidas"))
    elif rec:
        g = rec[0]
        out.append(("info", ("ganhou" if g["win"] else "perdeu") + f" a última partida ({g['k']}/{g['d']}/{g['a']})"))
    if r.get("wr") is not None and (r.get("wins", 0) + r.get("losses", 0)) >= 30:
        if r["wr"] >= 57:
            out.append(("perigo", f"{r['wr']}% de vitórias na temporada"))
        elif r["wr"] <= 46:
            out.append(("bom", f"só {r['wr']}% de vitórias na temporada"))
    if r.get("duo"):
        out.append(("info", f"duo com {r['duo']}"))
    if r.get("start"):
        sd, k, n = r["start"]
        out.insert(0, ("perigo", f"começa a selva pelo lado de {sd} ({k} das últimas {n})"))
    return out


def tiltable(rows):
    """Ideia 15: o inimigo mais tiltável (derrotas seguidas e muitas mortes nas ultimas)."""
    best = None
    for r in rows or []:
        rec = r.get("recent") or []
        s = _streak(rec)
        d = sum(g["d"] for g in rec[:3]) / max(1, len(rec[:3])) if rec else 0
        sc = -s * 2 + d / 3 if s < 0 else d / 6
        if s <= -2 and (best is None or sc > best[0]):
            best = (sc, r["name"], -s)
    return best and (best[1], best[2])


def allies_text(arows, my_pos=None):
    """Ideias 17 e 19: aliado em sequencia ruim, fora da posicao, e o seu cacador com pouca experiencia."""
    out = []
    for a in arows or []:
        rec = a.get("recent") or []
        if len(rec) < 3:
            continue
        s = _streak([{"win": g["win"]} for g in rec])
        known = [g["pos"] for g in rec if g.get("pos")]
        on = sum(1 for g in rec if (g.get("champ") or "").lower() == str(a.get("champ") or "").lower())
        if a.get("pos") and known and a["pos"] not in known:
            out.append(f"{a['name']} do seu time está fora da posição: ajude cedo.")
        elif s <= -3:
            out.append(f"{a['name']} do seu time perdeu as últimas {-s}: conversa positiva no chat ajuda.")
        if a.get("pos") == "JUNGLE" and on == 0 and my_pos != "JUNGLE":
            out.append(f"Seu caçador não jogou de {a['name']} nas últimas {len(rec)}: não conte com gank cedo.")
    return out[:3]


def rank_txt(r):
    if not r.get("tier"):
        return "sem elo"
    t = TIER_SHORT.get(r["tier"], r["tier"])
    return f"{t} {r.get('div') or ''} {r.get('lp') or 0} PDL".replace("  ", " ") if r["tier"] not in ("MASTER", "GRANDMASTER", "CHALLENGER") else f"{t} {r.get('lp') or 0} PDL"


def speech(rows, my_pos=None):
    """Uma frase com o que mais importa (o seu oponente de rota primeiro)."""
    if not rows:
        return None
    parts = []
    lane = next((r for r in rows if my_pos and r.get("pos") == my_pos), None)
    ordered = ([lane] if lane else []) + [r for r in rows if r is not lane]
    for r in ordered:
        tg = [t for k, t in r.get("tags") or [] if not t.startswith("duo com")]
        strong = [t for k, t in r.get("tags") or [] if k in ("perigo", "bom")]
        if r is lane and tg:
            parts.append(f"Seu oponente, {r['name']}: " + ", ".join(tg[:3]) + ".")
        elif strong and len(parts) < 4:
            parts.append(f"{r['name']}: " + ", ".join(strong[:2]) + ".")
    duo = next((r for r in rows if r.get("duo")), None)
    if duo and len(parts) < 5:
        parts.append(f"{duo['name']} e {duo['duo']} estão de duo.")
    tl = tiltable(rows)
    if tl and len(parts) < 5:
        parts.append(f"Mais tiltável: {tl[0]}, perdeu as últimas {tl[1]}. Pressione ele cedo.")
    return " ".join(parts[:5]) or None


def card_html(st, champ_icon, e):
    """Cartao para a Partida ao vivo."""
    if not st:
        return ""
    if st["state"] == "buscando":
        return "<div class='lv-card'><h3>Inimigos</h3><div class='lv-empty'>Buscando o elo e a maestria dos inimigos na Riot…</div></div>"
    if st["state"] == "erro":
        return f"<div class='lv-card'><h3>Inimigos</h3><div class='lv-empty'>Não deu para buscar agora ({e(st.get('err', ''))}).</div></div>"
    trs = ""
    for r in st["rows"]:
        tg = " ".join(f"<span class='sc-t {k}'>{e(t)}</span>" for k, t in r.get("tags") or [])
        trs += (f"<div class='sc-r'>{champ_icon(r['champ'], 30)}<div><b>{e(r['name'])}</b><small>{e(rank_txt(r))}"
                + (f" · {r['wr']}% ({r['wins'] + r['losses']} jogos)" if r.get("wr") is not None else "") + f"</small><div>{tg}</div></div></div>")
    css = ("<style>.sc-r{display:flex;gap:10px;align-items:flex-start;padding:7px 0;border-bottom:1px solid rgba(255,255,255,.05)}"
           ".sc-r b{color:#fff;font:700 14px var(--head)}.sc-r small{display:block;color:var(--mute);font-size:12px}"
           ".sc-t{display:inline-block;font:600 11px var(--body);padding:2px 7px;border-radius:999px;margin:4px 4px 0 0;background:#2C2120;color:#D6CCC0}"
           ".sc-t.perigo{background:rgba(217,83,79,.16);color:#E8817C}.sc-t.bom{background:rgba(107,191,138,.16);color:#8FD4A8}</style>")
    al = allies_text(st.get("allies"))
    extra = ("<div class='lv-card'><h3>Seu time</h3>" + "".join(f"<p class='n'>{e(t)}</p>" for t in al) + "</div>") if al else ""
    return f"{css}<div class='lv-card'><h3>Inimigos <small>elo, maestria e duo (API da Riot)</small></h3>{trs}</div>{extra}"
