"""Caçador inimigo visto (beta): olha o SEU minimapa na tela (o que voce ja ve) e avisa quando o icone do cacador inimigo aparece.

So Python puro (ctypes do Windows para copiar a regiao do minimapa, decodificador de PNG simples).
Como funciona: acha os aneis vermelhos dos icones inimigos no minimapa e compara o rosto dentro do anel com o icone oficial
de cada campeao inimigo (Data Dragon). E aproximado: skins e tamanhos de minimapa diferentes podem errar.
"""
import struct
import zlib

GRID = 6


# ---------------- PNG (8 bits, RGB/RGBA, sem entrelacamento: o formato dos icones do Data Dragon) ----------------
def png_decode(data):
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("não é PNG")
    pos, idat, w = 8, b"", 0
    while pos < len(data):
        ln, typ = struct.unpack(">I4s", data[pos:pos + 8])
        chunk = data[pos + 8:pos + 8 + ln]
        if typ == b"IHDR":
            w, h, depth, ctype, _, _, inter = struct.unpack(">IIBBBBB", chunk)
            if depth != 8 or ctype not in (2, 6) or inter:
                raise ValueError("PNG em formato não suportado")
            bpp = 3 if ctype == 2 else 4
        elif typ == b"IDAT":
            idat += chunk
        elif typ == b"IEND":
            break
        pos += 12 + ln
    raw = zlib.decompress(idat)
    stride = w * bpp
    out = bytearray(h * stride)
    prev = bytearray(stride)
    i = 0
    for y in range(h):
        f = raw[i]
        line = bytearray(raw[i + 1:i + 1 + stride])
        i += 1 + stride
        if f == 1:
            for x in range(bpp, stride):
                line[x] = (line[x] + line[x - bpp]) & 255
        elif f == 2:
            for x in range(stride):
                line[x] = (line[x] + prev[x]) & 255
        elif f == 3:
            for x in range(stride):
                a = line[x - bpp] if x >= bpp else 0
                line[x] = (line[x] + ((a + prev[x]) >> 1)) & 255
        elif f == 4:
            for x in range(stride):
                a = line[x - bpp] if x >= bpp else 0
                b = prev[x]
                c = prev[x - bpp] if x >= bpp else 0
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                pr = a if pa <= pb and pa <= pc else (b if pb <= pc else c)
                line[x] = (line[x] + pr) & 255
        out[y * stride:(y + 1) * stride] = line
        prev = line
    return w, h, bpp, bytes(out)


def signature_from_png(data):
    """Media de cor em GRID x GRID dentro de um circulo (o minimapa mostra o rosto em circulo)."""
    w, h, bpp, px = png_decode(data)
    # o icone do minimapa corta as bordas: usa o miolo (80%)
    m0, m1 = int(w * 0.12), int(w * 0.88)
    return _sig(lambda x, y: px[(y * w + x) * bpp:(y * w + x) * bpp + 3], m0, m0, m1 - m0)


def _sig(get, x0, y0, size):
    out = []
    cell = size / GRID
    r2 = (size / 2) ** 2
    cx = cy = size / 2
    for gy in range(GRID):
        for gx in range(GRID):
            acc = [0, 0, 0]
            n = 0
            for sy in range(3):
                for sx in range(3):
                    lx = (gx + (sx + 0.5) / 3) * cell
                    ly = (gy + (sy + 0.5) / 3) * cell
                    if (lx - cx) ** 2 + (ly - cy) ** 2 > r2:
                        continue
                    c = get(int(x0 + lx), int(y0 + ly))
                    acc[0] += c[0]
                    acc[1] += c[1]
                    acc[2] += c[2]
                    n += 1
            out.append(tuple(v / n for v in acc) if n else None)
    return out


def dist(a, b):
    tot, n = 0.0, 0
    for p, q in zip(a, b):
        if p is None or q is None:
            continue
        tot += abs(p[0] - q[0]) + abs(p[1] - q[1]) + abs(p[2] - q[2])
        n += 1
    return tot / n if n else 1e9


# ---------------- captura da tela (Windows, GDI) ----------------
def capture(x, y, w, h):
    """BGRA de uma regiao da tela. None fora do Windows."""
    import ctypes
    from ctypes import wintypes
    user32, gdi32 = ctypes.windll.user32, ctypes.windll.gdi32
    hdc = user32.GetDC(0)
    mdc = gdi32.CreateCompatibleDC(hdc)
    bmp = gdi32.CreateCompatibleBitmap(hdc, w, h)
    gdi32.SelectObject(mdc, bmp)
    gdi32.BitBlt(mdc, 0, 0, w, h, hdc, x, y, 0x00CC0020)

    class BIH(ctypes.Structure):
        _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG), ("biHeight", wintypes.LONG), ("biPlanes", wintypes.WORD),
                    ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD), ("biSizeImage", wintypes.DWORD),
                    ("biXPelsPerMeter", wintypes.LONG), ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD), ("biClrImportant", wintypes.DWORD)]
    bi = BIH(ctypes.sizeof(BIH), w, -h, 1, 32, 0, 0, 0, 0, 0, 0)
    buf = ctypes.create_string_buffer(w * h * 4)
    gdi32.GetDIBits(mdc, bmp, 0, h, buf, ctypes.byref(bi), 0)
    gdi32.DeleteObject(bmp)
    gdi32.DeleteDC(mdc)
    user32.ReleaseDC(0, hdc)
    return buf.raw


def _red(b, g, r):
    return r > 150 and g < 90 and b < 90 and r - g > 90


def find_enemy_icons(bgra, w, h):
    """Centros e raios dos aneis vermelhos (icones inimigos) no minimapa."""
    step = 2
    cell = max(4, w // 40)
    cells = {}
    for y in range(0, h, step):
        row = y * w * 4
        for x in range(0, w, step):
            i = row + x * 4
            if _red(bgra[i], bgra[i + 1], bgra[i + 2]):
                k = (x // cell, y // cell)
                c = cells.setdefault(k, [0, 0, 0, x, y, x, y])
                c[0] += 1
                c[3], c[4] = min(c[3], x), min(c[4], y)
                c[5], c[6] = max(c[5], x), max(c[6], y)
    # junta celulas vizinhas em grupos
    seen, blobs = set(), []
    for k in cells:
        if k in seen:
            continue
        stack, grp = [k], []
        seen.add(k)
        while stack:
            a = stack.pop()
            grp.append(a)
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    nb = (a[0] + dx, a[1] + dy)
                    if nb in cells and nb not in seen:
                        seen.add(nb)
                        stack.append(nb)
        n = sum(cells[g][0] for g in grp)
        x0 = min(cells[g][3] for g in grp)
        y0 = min(cells[g][4] for g in grp)
        x1 = max(cells[g][5] for g in grp)
        y1 = max(cells[g][6] for g in grp)
        bw, bh = x1 - x0, y1 - y0
        lo, hi = w * 0.045, w * 0.16
        if lo <= bw <= hi and lo <= bh <= hi and 0.6 < (bw + 1) / (bh + 1) < 1.6 and n >= 6:
            blobs.append(((x0 + x1) / 2, (y0 + y1) / 2, (bw + bh) / 4))
    return blobs


def identify(bgra, w, h, blobs, sigs):
    """Para cada anel, qual campeao inimigo (pela assinatura de cor). sigs: {id: assinatura}."""
    get = lambda x, y: (bgra[(y * w + x) * 4 + 2], bgra[(y * w + x) * 4 + 1], bgra[(y * w + x) * 4]) if 0 <= x < w and 0 <= y < h else (0, 0, 0)
    out = []
    for cx, cy, r in blobs:
        inner = r * 0.72
        s = _sig(get, cx - inner, cy - inner, inner * 2)
        ranked = sorted((dist(s, sg), cid) for cid, sg in sigs.items())
        if ranked:
            out.append((ranked[0][1], ranked[0][0], ranked[1][0] if len(ranked) > 1 else 1e9, cx / w, cy / h))
    return out


def where(nx, ny, team):
    """Regiao do minimapa em palavras. nx, ny de 0 a 1 (0,0 = canto de cima a esquerda). team: 'ORDER' (azul) ou 'CHAOS'."""
    x, y = nx * 14870, (1 - ny) * 14870
    from .review import zone
    z = zone(x, y)
    top = y > x
    if z == "selva":
        mine = (x + y < 14870) if team == "ORDER" else (x + y > 14870)
        return f"na {'sua' if mine else 'própria'} selva, lado de {'cima' if top else 'baixo'}"
    if z == "rio":
        return f"no rio de {'cima' if top else 'baixo'}"
    return {"rota de cima": "na rota do topo", "rota de baixo": "na rota de baixo", "rota do meio": "no meio",
            "base azul": "perto da base azul", "base vermelha": "perto da base vermelha"}.get(z, z)


def side(nx, ny):
    """'cima' (lado do topo) ou 'baixo' (lado do bot) do mapa."""
    x, y = nx * 14870, (1 - ny) * 14870
    return "cima" if y > x else "baixo"


def advice(pos, nx, ny):
    """O que fazer sabendo onde o cacador inimigo esta, pela SUA rota (frase curta, para a voz)."""
    sd = side(nx, ny)
    mine = {"TOP": "cima", "BOTTOM": "baixo", "UTILITY": "baixo"}.get(pos)
    if mine:
        return "Ele está do seu lado: recue e não estenda." if sd == mine else "Ele está longe de você: dá para trocar e empurrar."
    if pos == "MIDDLE":
        return f"Cuidado no rio de {sd}; o rio do outro lado está mais seguro."
    if pos == "JUNGLE":
        return f"Faça o lado de {'baixo' if sd == 'cima' else 'cima'} ou prepare contra-emboscada no lado de {sd}."
    return ""
