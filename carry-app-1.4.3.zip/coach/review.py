"""Revisao guiada: acha os momentos criticos da partida e guarda suas respostas.

Fluxo (do doc): o app mostra o momento, PERGUNTA o que voce via e ia fazer, e so
depois mostra o contexto que faltava. Nada aqui aconselha durante a partida.
"""
import json
import math
from collections import Counter

from . import db
from .tags import DADO, REGRA, HIPOTESE, tip

CAUSES = {
    "A": "Sem ult ou com habilidades em recarga",
    "B": "Sem visão do jungler inimigo",
    "C": "Luta que não precisava",
    "D": "Posicionamento ou farm arriscado",
    "E": "Erro de wave ou de recall",
}
TRAINING = {
    "A": "Prática 10 min: o combo completo do seu campeão e sair; antes de entrar, olhe a ultimate e as recargas.",
    "B": "Antes de empurrar a wave, pergunte 'onde está o jungler?'. Treino: 1 ward de rio a cada recall.",
    "C": "Antes de cada luta responda: qual o objetivo? Se não há, não entre. Treino: 5 jogos sem trocar sem motivo.",
    "D": "Farm longe da torre só com visão do lado do jungler. Treino: freeze perto da torre por 3 min na prática.",
    "E": "Empurre antes de rotacionar ou voltar. Treino: crash + recall com ouro para item, 3 vezes na prática.",
}
# As causas e os treinos sao regras gerais de jogo (a conferir no patch atual).

BIG_OBJECTIVES = {"DRAGON": "Dragão", "BARON_NASHOR": "Barao", "RIFTHERALD": "Arauto",
                  "HORDE": "Vastilarvas"}


def zone(x, y):
    """Regiao APROXIMADA do mapa. So para dar contexto; e hipotese, nao dado."""
    if x is None or y is None:
        return "desconhecida"
    if x < 4000 and y < 4000:
        return "base azul"
    if x > 10870 and y > 10870:
        return "base vermelha"
    if abs((x + y) - 14870) < 2400:
        return "rio"
    if abs(x - y) < 2300:
        return "rota do meio"
    if x < 5500 and y > 8000:
        return "rota de cima"
    if y < 5500 and x > 8000:
        return "rota de baixo"
    return "selva"


def _mmss(t_ms):
    s = int(t_ms // 1000)
    return f"{s // 60}:{s % 60:02d}"


def _dist(x1, y1, x2, y2):
    if None in (x1, y1, x2, y2):
        return None
    return int(math.hypot(x1 - x2, y1 - y2))


def _parts(con, mid):
    return {r["participant_id"]: dict(r) for r in
            con.execute("SELECT * FROM participants WHERE match_id=?", (mid,))}


def _frame(con, mid, pid, minute):
    return con.execute(
        "SELECT * FROM frames WHERE match_id=? AND participant_id=? AND minute=?",
        (mid, pid, minute)).fetchone()


def my_participant(con, puuid, mid):
    r = con.execute("SELECT * FROM participants WHERE match_id=? AND puuid=?", (mid, puuid)).fetchone()
    return dict(r) if r else None


def moments(con, puuid, mid):
    """Momentos criticos: cada morte sua e cada objetivo grande que o inimigo fez."""
    me = my_participant(con, puuid, mid)
    if not me:
        return []
    parts = _parts(con, mid)
    enemy_team = 200 if me["team_id"] == 100 else 100
    opp = next((p for p in parts.values()
                if p["team_id"] == enemy_team and p["position"] == me["position"]), None)
    enemy_jg = next((p for p in parts.values()
                     if p["team_id"] == enemy_team and p["position"] == "JUNGLE"), None)
    out = []
    objectives = con.execute(
        "SELECT t_ms, type, team_id, x, y, data FROM events WHERE match_id=? AND type IN "
        "('ELITE_MONSTER_KILL','BUILDING_KILL') ORDER BY t_ms", (mid,)).fetchall()

    kills = [dict(r) for r in con.execute("SELECT * FROM events WHERE match_id=? AND type='CHAMPION_KILL' "
                                          "AND pid=? ORDER BY t_ms", (mid, me["participant_id"]))]
    if not kills:   # bancos antigos: so a tabela de mortes (sem assistencias)
        kills = [{"t_ms": r["t_ms"], "x": r["x"], "y": r["y"], "data": json.dumps({"killer": r["killer_id"], "assists": []})}
                 for r in con.execute("SELECT * FROM deaths WHERE match_id=? AND victim_id=? ORDER BY t_ms", (mid, me["participant_id"]))]
    for ev in kills:
        t = ev["t_ms"]
        data = json.loads(ev["data"] or "{}")
        minute = t // 60000
        facts = [tip(DADO, f"Você morreu aos {_mmss(t)}.")]
        killer = parts.get(data.get("killer"))
        if killer:
            assists = len(data.get("assists") or [])
            role = killer["position"] or "?"
            facts.append(tip(DADO, f"Morto por {killer['champion']} ({role}) com {assists} assistência(s)."))
        elif data.get("killer") in (0, None):
            facts.append(tip(DADO, "Morto por torre, minion ou monstro."))
        fm, fo = _frame(con, mid, me["participant_id"], minute), (
            _frame(con, mid, opp["participant_id"], minute) if opp else None)
        if fm and fo:
            facts.append(tip(DADO, f"No frame do min {minute}: ouro {fm['gold'] - fo['gold']:+d} e "
                                   f"CS {fm['cs'] - fo['cs']:+d} contra {opp['champion']}; "
                                   f"nível {fm['level']} contra {fo['level']}."))
        if fm:
            if fm["level"] < 6:
                facts.append(tip(DADO, f"Você estava no nível {fm['level']}: ainda sem ult."))
            else:
                facts.append(tip(HIPOTESE, "Nível 6 ou mais: o app não vê recarga, então não sabe se a ult estava disponível."))
        if enemy_jg and ev["x"] is not None:
            fj = _frame(con, mid, enemy_jg["participant_id"], minute)
            if fj:
                d = _dist(ev["x"], ev["y"], fj["x"], fj["y"])
                if d is not None:
                    facts.append(tip(DADO, f"{enemy_jg['champion']} (jungle inimigo) estava a cerca de {d} "
                                           f"unidades de onde você morreu, no frame do min {minute} "
                                           "(a foto é de até 60 s antes)."))
        later = []
        for o in objectives:
            if t < o["t_ms"] <= t + 90000:
                d = json.loads(o["data"] or "{}")
                if o["type"] == "ELITE_MONSTER_KILL" and o["team_id"] == enemy_team:
                    later.append(BIG_OBJECTIVES.get(d.get("monsterType"), d.get("monsterType", "monstro")))
                elif o["type"] == "BUILDING_KILL" and o["team_id"] == me["team_id"]:
                    later.append("torre/estrutura sua")
        if later:
            facts.append(tip(DADO, "Em até 90 s depois o inimigo fez: " + ", ".join(later) + "."))
        facts.append(tip(HIPOTESE, f"Região aproximada do mapa: {zone(ev['x'], ev['y'])}."))
        out.append({"t_ms": t, "kind": "morte", "title": f"Morte aos {_mmss(t)}",
                    "facts": facts, "objective_after": bool(later),
                    "by_lane_opponent": bool(killer and opp and killer["participant_id"] == opp["participant_id"]),
                    "level": fm["level"] if fm else None, "minute": minute})

    for o in objectives:
        d = json.loads(o["data"] or "{}")
        if o["type"] == "ELITE_MONSTER_KILL" and o["team_id"] == enemy_team \
                and d.get("monsterType") in BIG_OBJECTIVES:
            name = BIG_OBJECTIVES[d["monsterType"]]
            minute = o["t_ms"] // 60000
            facts = [tip(DADO, f"O inimigo fez {name} aos {_mmss(o['t_ms'])}.")]
            fm = _frame(con, mid, me["participant_id"], minute)
            if fm and o["x"] is not None:
                dd = _dist(fm["x"], fm["y"], o["x"], o["y"])
                if dd is not None:
                    facts.append(tip(DADO, f"No frame do min {minute} você estava a cerca de {dd} "
                                           "unidades do objetivo."))
                    facts.append(tip(HIPOTESE, f"Sua região no frame: {zone(fm['x'], fm['y'])}."))
            out.append({"t_ms": o["t_ms"], "kind": "objetivo", "title": f"{name} do inimigo aos {_mmss(o['t_ms'])}",
                        "facts": facts, "objective_after": False, "by_lane_opponent": False,
                        "level": fm["level"] if fm else None, "minute": minute})
            if sum(1 for m in out if m["kind"] == "objetivo") >= 6:
                break
    out.sort(key=lambda m: m["t_ms"])
    return out


# ---- respostas ------------------------------------------------------------
def save_answer(con, mid, t_ms, kind, thought, cause, knew_jungler):
    from . import vod
    valid = set(CAUSES) | set(vod.GOOD) | set(vod.BAD) | {"Z"}
    con.execute("INSERT OR REPLACE INTO review_answers VALUES (?,?,?,?,?,?,?)",
                (mid, int(t_ms), kind, (thought or "").strip(), cause if cause in valid else "",
                 knew_jungler if knew_jungler in ("sim", "nao") else "", db.now_ms()))
    con.commit()


def answers(con, mid):
    return {(r["t_ms"], r["kind"]): dict(r) for r in
            con.execute("SELECT * FROM review_answers WHERE match_id=?", (mid,))}


def save_notes(con, mid, do_different, feeling):
    con.execute("INSERT OR REPLACE INTO match_notes VALUES (?,?,?,?)",
                (mid, (do_different or "").strip(), (feeling or "").strip(), db.now_ms()))
    con.commit()


def notes(con, mid):
    r = con.execute("SELECT * FROM match_notes WHERE match_id=?", (mid,)).fetchone()
    return dict(r) if r else None


def patterns(con, puuid, top=3):
    """Ate 3 padroes com base nas causas que VOCE marcou, e um treino para cada."""
    rows = con.execute(
        """SELECT a.cause, a.knew_jungler, a.kind FROM review_answers a
           JOIN participants p ON p.match_id=a.match_id AND p.puuid=?
           WHERE a.cause<>''""", (puuid,)).fetchall()
    from . import vod
    good = [r for r in rows if r["cause"] in vod.GOOD]
    rows = [r for r in rows if r["cause"] in vod.BAD]
    total = len(rows)
    if not total and not good:
        return {"total": 0, "items": []}
    c = Counter(r["cause"] for r in rows)
    items = []
    for cause, n in c.most_common(top):
        lb = vod.BAD[cause]
        items.append({"cause": cause, "label": lb, "count": n,
                      "tips": [tip(DADO, f"{n} de {total} erros que você classificou foram '{lb}'.", total)]
                      + ([tip(REGRA, TRAINING[cause])] if cause in TRAINING else [])})
    if good:
        cg = Counter(r["cause"] for r in good)
        best = ", ".join(f"{vod.GOOD[k].lower()} ({n})" for k, n in cg.most_common(3))
        items.append({"cause": "good", "label": "Seus acertos mais comuns", "count": len(good),
                      "tips": [tip(DADO, f"Você marcou {len(good)} acertos. Os mais comuns: {best}.", len(good))]})
    total = total or len(good)
    nao = sum(1 for r in rows if r["knew_jungler"] == "nao")
    answered = sum(1 for r in rows if r["knew_jungler"])
    extra = []
    if answered:
        extra.append(tip(DADO, f"Em {nao} de {answered} respostas você não sabia onde estava o jungler inimigo.", answered))
    return {"total": total, "items": items, "extra": extra}
