"""Ficha do confronto, falada no comeco da partida: seu historico contra o oponente, o confronto no alto elo,
o item inicial dos melhores contra ele e quando eles costumam conseguir o primeiro abate (e o que isso pede de voce)."""
import json
import statistics
import time
from collections import Counter

_DONE = {}


def _first_kill_minutes(con, rows, opp):
    """Minuto do primeiro abate no oponente de rota, nas partidas dos melhores contra ele (None quando nao matou antes dos 15)."""
    out = []
    for r in rows:
        mid, pid = r["match_id"], r["participant_id"]
        o = con.execute("""SELECT o.participant_id FROM participants me JOIN participants o ON o.match_id=me.match_id
                           AND o.team_id<>me.team_id AND o.position=me.position WHERE me.match_id=? AND me.participant_id=?""",
                        (mid, pid)).fetchone()
        if not o:
            continue
        t = None
        for ev in con.execute("SELECT t_ms, data FROM events WHERE match_id=? AND type='CHAMPION_KILL' AND pid=? AND t_ms<900000 ORDER BY t_ms",
                              (mid, o[0])):
            d = json.loads(ev[1] or "{}")
            if d.get("killer") == pid or pid in (d.get("assists") or []):
                t = ev[0] / 60000
                break
        out.append(t)
    return out


def build(con, puuid, mine, opp, pos, items=None):
    from . import builds, counters, report
    parts = []
    mg = [g for g in report.my_games(con, puuid, pos) if g["champion"] == mine and (g.get("opp_champion") or "") == opp]
    if mg:
        w = sum(1 for g in mg if g["win"])
        parts.append(f"Você: {w} vitória{'s' if w != 1 else ''} em {len(mg)} contra ele")
    mu = counters.matchup(con, mine, opp, pos)
    if mu:
        parts.append(f"no alto elo, {mu[1]}% em {mu[0]} jogos ({counters.verdict(mu[1])})")
    tip = ""
    try:
        rows = builds.top_rows(con, mine, pos)
        vs, why = builds.matchup_rows(con, rows, opp=opp)
        if why and why.startswith("contra"):
            st = Counter(builds.start_inventory(con, r["match_id"], r["participant_id"]) for r in vs)
            st.pop((), None)
            if st and items:
                best = st.most_common(1)[0][0]
                nm = [((items.get(str(i)) or {}).get("name")) for i in best]
                nm = [x for x in nm if x]
                if nm:
                    parts.append("os melhores começam com " + " e ".join(dict.fromkeys(nm)))
            dur = {}
            for r in vs:
                d_ = con.execute("SELECT duration_s FROM matches WHERE match_id=?", (r["match_id"],)).fetchone()
                if d_ and d_[0]:
                    b_ = "cedo" if d_[0] < 25 * 60 else ("tarde" if d_[0] >= 30 * 60 else None)
                    if b_:
                        v_ = dur.setdefault(b_, [0, 0])
                        v_[0] += 1
                        v_[1] += 1 if r.get("win") else 0
            if all(dur.get(b_, [0])[0] >= 10 for b_ in ("cedo", "tarde")):
                wc = round(100 * dur["cedo"][1] / dur["cedo"][0])
                wl = round(100 * dur["tarde"][1] / dur["tarde"][0])
                if wc - wl >= 8:
                    parts.append(f"o {mine} ganha {wc}% quando o jogo acaba antes dos 25 e {wl}% depois dos 30: feche o jogo cedo")
                elif wl - wc >= 8:
                    parts.append(f"o {mine} ganha {wl}% depois dos 30 e {wc}% antes dos 25: não precisa forçar, o fim de jogo é seu")
            fk = _first_kill_minutes(con, vs[:60], opp)
            got = [x for x in fk if x is not None]
            if len(fk) >= 8:
                share = round(100 * len(got) / len(fk))
                if got and share >= 40:
                    med = statistics.median(got)
                    parts.append(f"eles matam o {opp} antes dos 15 em {share}% das partidas, em média aos {med:.0f} minutos")
                    tip = ("O confronto se ganha cedo: procure troca nos níveis 2 e 3." if med < 5.5 else
                           "A janela é o nível 6: antes disso, farme e guarde a vida." if med < 9 else
                           "O abate vem com o primeiro item: farme e não force antes.")
                else:
                    parts.append(f"os melhores quase não matam o {opp} na rota ({share}% antes dos 15)")
                    tip = "Não é rota de abate: farme, empurre e ganhe pelo mapa com o seu jungler."
    except Exception:
        pass
    if not parts:
        return None
    return f"Ficha do confronto, {mine} contra {opp}. " + "; ".join(parts) + "." + (f" {tip}" if tip else "")


def note_get(con, mine, opp):
    try:
        con.execute("CREATE TABLE IF NOT EXISTS matchup_notes (champion TEXT, opp TEXT, note TEXT, updated_ms INTEGER, PRIMARY KEY (champion, opp))")
        r = con.execute("SELECT note FROM matchup_notes WHERE champion=? AND opp=?", (mine, opp)).fetchone()
        return (r[0] or "").strip() if r else ""
    except Exception:
        return ""


def note_save(con, mine, opp, note):
    con.execute("CREATE TABLE IF NOT EXISTS matchup_notes (champion TEXT, opp TEXT, note TEXT, updated_ms INTEGER, PRIMARY KEY (champion, opp))")
    con.execute("INSERT OR REPLACE INTO matchup_notes VALUES (?,?,?,?)", (mine, opp, (note or "").strip()[:300], int(time.time() * 1000)))
    con.commit()


def cues(con, puuid, live_data, me, foes, pos, gt, items=None):
    if not pos or pos == "JUNGLE":
        return []
    from . import liveview, modelo
    lp = next((p for p in foes if (p.get("position") or "").upper() == pos), None)
    if not lp:
        return []
    mine, opp = liveview.champ_id(me), liveview.champ_id(lp)
    gk = "|".join(sorted((p.get("championName") or "") for p in live_data.get("allPlayers") or []))
    st = _DONE.get(gk)
    if st is None:                   # monta em segundo plano (consulta a amostra do topo): nao trava o overlay
        st = _DONE[gk] = {"txt": "", "rw": "x", "note": ""}
        if len(_DONE) > 4:
            for k in list(_DONE)[:-4]:
                _DONE.pop(k, None)
        path = None
        try:
            path = con.execute("PRAGMA database_list").fetchone()[2]
        except Exception:
            pass

        def go():
            import sqlite3
            try:
                c2 = sqlite3.connect(path, timeout=10) if path else con
                c2.row_factory = sqlite3.Row
            except Exception:
                return
            try:
                st["note"] = note_get(c2, mine, opp)
            except Exception:
                pass
            try:
                st["txt"] = build(c2, puuid, mine, opp, pos, items) or ""
            except Exception:
                pass
            try:                     # lado do mapa
                from . import report
                gs_ = report.my_games(c2, puuid, "")
                side = 100 if me.get("team") == "ORDER" else 200
                sg = [g for g in gs_ if g.get("team_id") == side]
                og = [g for g in gs_ if g.get("team_id") and g.get("team_id") != side]
                if len(sg) >= 20 and len(og) >= 20:
                    a_ = round(100 * sum(1 for g in sg if g["win"]) / len(sg))
                    b_ = round(100 * sum(1 for g in og if g["win"]) / len(og))
                    if abs(a_ - b_) >= 5:
                        nm_ = "azul" if side == 100 else "vermelho"
                        st["side"] = f"Lado {nm_}: você tem {a_}% em {len(sg)} jogos, contra {b_}% do outro lado."
            except Exception:
                pass
            try:                     # ordem das habilidades (so para campeao que voce joga pouco)
                from . import builds, champview, report
                n_mine = sum(1 for g in report.my_games(c2, puuid, "") if g["champion"] == mine)
                if n_mine < 20:
                    so = champview.skill_order(c2, builds.top_rows(c2, mine, pos))
                    if so and so.get("first"):
                        st["skills"] = [champview.SLOT.get(x, "?") for x in so["first"]]
                        st["max"] = [champview.SLOT.get(x, "?") for x in so.get("max") or []]
            except Exception:
                pass
            try:
                st["rw"] = modelo.recall_window(c2, mine, pos, items, opp)
            except Exception:
                st["rw"] = None
        import threading
        threading.Thread(target=go, daemon=True).start()
        return []
    out = []
    if 12 <= gt <= 150:
        if st["txt"]:
            out.append({"k": f"ficha_{mine}_{opp}", "t": st["txt"]})
        if st.get("side"):
            out.append({"k": "ficha_lado", "t": st["side"]})
        if st["note"]:
            out.append({"k": f"ficha_nota_{mine}_{opp}", "t": f"Sua nota contra {lp.get('championName')}: {st['note']}"})
        try:            # pico de forca do oponente e amuleto/primeira sentinela (ideias 21 e 22)
            import os as _os
            from . import extras
            from .ddragon import DataDragon
            out.append({"k": "fichax_amuleto", "t": extras.trinket(pos)})
            raiz = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
            ch_ = DataDragon(cache_dir=_os.path.join(raiz, "cache")).champions()
            sp_ = extras.spike(ch_, opp)
            if sp_:
                out.append({"k": f"ficha_spike_{opp}", "t": f"Pico de força do {lp.get('championName')}: {sp_}. Respeite esse momento."})
        except Exception:
            pass
        try:
            from . import especialista
            et_ = especialista.ficha_text(mine, opp)
            if et_:
                out.append({"k": f"ficha_esp_{mine}_{opp}", "t": et_})
        except Exception:
            pass
    sk = st.get("skills")
    lv = int(me.get("level") or 1)
    if sk and lv <= 3:
        mx = st.get("max") or []
        tail = f" Depois, maximize {', '.join(mx[:2])} primeiro." if lv == 3 and mx else ""
        out.append({"k": f"ficha_skill_{lv}", "t": f"Nível {lv}: pegue o {sk[lv - 1]}.{tail}"})
    out += modelo.recall_cue(con, live_data, me, foes, pos, gt, items, mine, opp, st)
    return out
