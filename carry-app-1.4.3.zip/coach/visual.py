"""Visual novo ("cara de jogo"), por cima do tema que ja existe: mesmas paginas e informacoes, so muda a aparencia.
Fontes locais (static/fonts, licenca OFL): Barlow, Barlow Condensed e Chakra Petch."""

FONTS = "".join(
    f"@font-face{{font-family:'{fam}';src:url('/static/fonts/{f}') format('woff2');font-weight:{w};font-style:normal;font-display:swap}}"
    for fam, f, w in [("Barlow", "barlow-latin-400-normal.woff2", 400), ("Barlow", "barlow-latin-500-normal.woff2", 500),
                      ("Barlow", "barlow-latin-600-normal.woff2", 600), ("Barlow", "barlow-latin-700-normal.woff2", 700),
                      ("Barlow Condensed", "barlow-condensed-latin-600-normal.woff2", 600), ("Barlow Condensed", "barlow-condensed-latin-700-normal.woff2", 700),
                      ("Barlow Condensed", "barlow-condensed-latin-800-normal.woff2", 800),
                      ("Chakra Petch", "chakra-petch-latin-500-normal.woff2", 500), ("Chakra Petch", "chakra-petch-latin-600-normal.woff2", 600),
                      ("Chakra Petch", "chakra-petch-latin-700-normal.woff2", 700)])

CSS = FONTS + """
/* ===== visual novo: cara de jogo ===== */
:root{--night:#0B0A10;--raised:#13121B;--raised2:#1A1824;--line:#262335;--bone:#EEE8F2;--steel:#ABA3B8;--gold:#D9B45A;--emerald:#7CCB98;
--win:#7CCB98;--loss:#EE8A8F;--dado:#7CCB98;--regra:#D9B45A;--hip:#ABA3B8;--purple:#9C7BFF;--purple2:#B9A6FF;--peach:#F0D28A;
--bg:var(--night);--panel:var(--raised);--panel2:var(--raised2);--ink:var(--bone);--mute:var(--steel);--rule:var(--line);--line-hover:#3A3550;
--d:'Barlow Condensed','BSD','Arial Narrow',sans-serif;--title:'Barlow Condensed','BSD',sans-serif;--head:'Barlow','Hanken',system-ui,sans-serif;
--body:'Barlow','Hanken',system-ui,sans-serif;--mono:'Chakra Petch','Hanken',monospace;--r-card:3px;--r-btn:2px;--hx-line:var(--line)}
html,body{background:var(--night)}
body{background:radial-gradient(1200px 600px at 85% -10%,rgba(111,183,255,.07),transparent 60%),radial-gradient(900px 500px at 10% 110%,rgba(156,123,255,.05),transparent 60%),var(--night);
font-family:var(--body);letter-spacing:.005em}
body::before{opacity:.025}
h1,h2,h3{font-family:var(--d);letter-spacing:.01em}
h1{text-transform:uppercase}
h2{text-transform:uppercase;font-weight:700}
h2::before{background:var(--gold) !important}
h2::after{background:linear-gradient(90deg,rgba(217,180,90,.35),transparent) !important}
/* cantos retos e linhas finas */
:where(.card,.hp-panel,.hp-mission,.hp-quick a,.kpi,.cnt,.bx-left,.bx-t,.bx-sk,.bx-items,.mh-box,.rtrack,.otp,.side-me,.sg a,.subnav,.subnav a,.subnav2 a,
.btn,button,input,select,textarea,.chip,.pill,.tag,.dcard,.empty,.panel,.box,.tile,.pg-card,[class*="card"]){border-radius:3px !important}
.card,.hp-panel,.hp-mission,.kpi,.panel,.box{background:linear-gradient(180deg,rgba(255,255,255,.028),rgba(255,255,255,.008)) ,var(--raised) !important;border-color:var(--line) !important}
.card::after,.hp-mission::before,.hp-panel::before,.hp-quick a::before{background:linear-gradient(90deg,var(--gold),transparent 45%) !important;left:0 !important;right:0 !important}
:where(.ab2,.aian,.aiban,.alert,.arena,.bgprev,.bn-art,.btn,.bx-items,.bx-left,.bx-sk,.bx-t,.card,.cbox,.ccol,.chal,.champ,.chatf,.chatlog,.chc,.cidea,.cneed,.cnt,.coach,.combo,.cplan,.cq,.cr-ai,.cr-off,.cr-s,.cr-v,.csteps,.dcard,.dcard2,.dhero,.dmore,.drawer,.duel-h,.dy-card,.dy-k,.dy-verdict,.dz-alert,.dz-card,.dz-k,.eloh,.empty,.exr,.gc,.gcard,.gd-hero,.gd-sec,.gd-toc,.gp-card,.gp-mini,.gplan,.gs-big,.gtip,.hc,.hero,.hp-hero,.hp-mission,.hpn,.hst,.itrow,.jobbar,.kpi,.kv4,.lchip,.ll,.ln-card,.ln-m,.ln-ph,.lq,.lrow,.lv-card,.lv-empty,.lv-now,.lv-step,.lv-top,.m-streak,.maincard,.map,.mcard,.met,.meta,.mh-box,.mhero,.mi,.mk-r,.mlv,.mrow,.mrow2,.msg,.mst,.nh-ic,.nh-score,.nowh,.oe-box,.oe-hud,.oe-scr,.oe-sel,.oe-zoom,.otp,.ovl,.pcard,.pchamp,.pdl-tip,.phase,.phead,.phero,.phero2,.pico,.pk,.pl-i,.pl-r,.pmenu,.psum,.rankbox,.ro-b,.rtrack,.secret,.seg,.side-me,.slot,.sstat,.step,.sug,.syncbtn,.tabs,.thr,.tierx,.tile,.tip,.tl-c,.tline,.trend,.urow,.vm,.vsc){border-radius:3px !important}

/* ===== Inicio: heroi com a skin ===== */
.vh{position:relative;min-height:360px;display:flex;align-items:flex-end;justify-content:space-between;gap:24px;overflow:hidden;border:1px solid var(--line);background:#0B0A10;padding:0 28px 26px;margin-bottom:22px;border-radius:3px}
.vh .hp-art{position:absolute;right:0;top:0;bottom:0;width:66%;background-size:cover;background-position:50% 22%;opacity:0;transition:opacity .5s;
 -webkit-mask-image:linear-gradient(90deg,transparent,#000 42%);mask-image:linear-gradient(90deg,transparent,#000 42%)}
.vh .hp-art.on{opacity:1}
.vh::after{content:"";position:absolute;inset:0;background:linear-gradient(0deg,rgba(11,10,16,.85),transparent 45%);pointer-events:none}
.vh-in{position:relative;z-index:1;max-width:680px;display:flex;flex-direction:column;gap:12px;padding-top:28px}
.vh-k{font:700 12px 'Barlow Condensed',sans-serif;letter-spacing:.18em;text-transform:uppercase;color:var(--steel)}
.vh-rank{display:flex;align-items:baseline;gap:14px;flex-wrap:wrap}
.vh-tier{font:800 68px/1 'Barlow Condensed',sans-serif;text-transform:uppercase;color:#fff;text-shadow:0 2px 24px rgba(0,0,0,.6)}
.vh-lp{font:600 28px 'Chakra Petch',monospace;color:var(--gold)}
.vh-ladder{display:flex;align-items:flex-end;gap:4px;max-width:560px}
.vh-sg{flex:1;display:flex;flex-direction:column;gap:4px}.vh-sg .tr{display:block;height:8px;background:#3A3550}.vh-sg .tr i{display:block;height:8px;background:var(--gold)}
.vh-sg small{font:600 11px 'Chakra Petch',monospace;color:var(--steel)}
.vh-goal{font:700 13px 'Barlow Condensed',sans-serif;letter-spacing:.12em;text-transform:uppercase;color:var(--gold);padding:0 0 18px 8px}
.vh-big{margin:0;font-size:19px;color:var(--bone)}.vh-wr{font-size:14px;color:var(--steel)}.vh-wr b{color:var(--gold)}.vh-big b{font-family:'Chakra Petch',monospace}
.vh-stats{display:flex;gap:30px;flex-wrap:wrap;align-items:flex-end}
.vh-stats>div{display:flex;flex-direction:column}.vh-stats small{font-size:12px;color:var(--steel)}
.vh-stats b{font:600 30px/1.1 'Chakra Petch',monospace;color:var(--bone)}.vh-stats span{font-size:12px;color:var(--steel)}
.vh-stats b.up{color:var(--win)}.vh-stats b.dn{color:var(--loss)}
.vh-lpb{display:grid !important;grid-template-columns:auto auto;column-gap:10px;align-items:end}
.vh-lpb small{grid-column:1/-1}.vh-lpb svg{grid-row:2/4;grid-column:2;width:120px;height:34px}
.vh-sub{margin:4px 0 0;color:var(--steel);font-size:15px;max-width:60ch}.vh-sub b{color:var(--bone)}
.vh-pool{position:relative;z-index:1;display:flex;flex-direction:column;gap:6px;align-self:flex-end}
.vh-pool button{background:rgba(11,10,16,.78) !important;border:1px solid var(--line-hover) !important;border-radius:3px !important}
.vh-pool button[aria-pressed=true]{border-color:var(--gold) !important;box-shadow:0 0 18px -6px var(--gold)}
@media (prefers-reduced-motion:no-preference){.vh .hp-art.on{animation:vkb 26s ease-in-out infinite alternate}
 .vh-sg .tr i{background-image:linear-gradient(100deg,transparent 30%,rgba(255,240,200,.55) 50%,transparent 70%);background-size:220% 100%;animation:vsheen 3.2s ease-in-out infinite}
 @keyframes vsheen{from{background-position:120% 0}to{background-position:-120% 0}}}
@media (max-width:900px){.vh{flex-direction:column;align-items:stretch}.vh .hp-art{width:100%;opacity:.35}.vh-tier{font-size:46px}}

/* ===== v2: componentes do protótipo ===== */
:root{--panel-a:var(--raised);--panel-b:var(--raised);--line-soft:var(--line);--hx-line:var(--line);--hx-gold2:var(--bone);--btn:var(--bone);--btnfg:var(--night);--hx-glow:rgba(217,180,90,.12)}
body::before{display:none}
main{max-width:1320px}
/* blocos: moldura fina, fundo escuro liso, linha dourada no topo, título com losango */
.hpn,.card,.gc,.onb,.kbox,.maincard,.pcard,.rankbox,.eloh,.ln-hero,.dhero,.mhero,.phero2,.chatlog{background:linear-gradient(180deg,rgba(255,255,255,.025),rgba(255,255,255,.006)),#12111A !important;
 border:1px solid var(--line) !important;border-radius:3px !important;box-shadow:none !important;position:relative}
.hpn::before,.card::before,.gc::before,.onb::before{content:"" !important;position:absolute !important;left:-1px !important;right:-1px !important;top:-1px !important;height:1px !important;
 background:linear-gradient(90deg,var(--gold),transparent 42%) !important;border:0 !important;width:auto !important;transform:none !important;opacity:1 !important;display:block !important}
.hpn-h h3,.gc>h3,.card>h2,.card>h3,.card>b.gl,.onb h2{display:flex !important;align-items:center;gap:10px;font:700 22px/1.15 'Barlow Condensed',sans-serif !important;text-transform:uppercase;letter-spacing:.02em;color:var(--bone) !important}
.hpn-h h3::before,.gc>h3>i:first-child,.card>h2::before,.card>h3::before,.card>b.gl::before{content:"";display:inline-block;width:8px;height:8px;background:var(--gold) !important;transform:rotate(45deg);flex:none;border-radius:0 !important;box-shadow:none !important}
.gc>h3>i:first-child{margin:0 !important}
.hpn-h small,.gc>.sub,.card>.sub{color:var(--steel) !important;font-size:14px}
.hpn-a{color:var(--gold) !important;font-weight:600}
/* atalhos do início */
.hp-quick{gap:2px !important}
.hp-quick a{background:#12111A !important;border:1px solid var(--line) !important;border-radius:3px !important}
.hp-quick a:hover{border-color:#6B5A2C !important}
.hp-quick a svg,.hp-quick .ni{color:var(--gold)}
/* números (Seus números) */
.hp-nums{border-top:1px solid var(--line);border-bottom:1px solid var(--line)}
.hp-num b,.hp-num-t b{font:600 40px/1 'Chakra Petch',monospace !important;letter-spacing:0}
.hp-num small.up{color:var(--win) !important}.hp-num small.dn{color:var(--loss) !important}
/* partidas */
.hg-row{border-radius:0 !important;border-bottom:1px solid var(--line) !important}
.hg.w .hg-row{box-shadow:inset 4px 0 0 var(--win)}.hg.l .hg-row{box-shadow:inset 4px 0 0 var(--loss)}
/* botões e chips */
.btn,button.btn,a.btn{border-radius:2px !important;font-family:'Barlow Condensed',sans-serif !important;font-weight:700 !important;letter-spacing:.08em;text-transform:uppercase}
.btn.gold,a.btn.gold,button.btn.gold{background:var(--ac) !important;color:#fff !important;border-color:var(--ac) !important}
.btn.ghost,a.btn.ghost,button.btn.ghost{background:transparent !important;color:var(--gold) !important;border:1px solid var(--gold) !important}
.seg button,.seg a,.chip,.rolef,.sug,.modes a,.modes button{border-radius:2px !important;font-family:var(--body) !important}
.seg button[aria-pressed=true],.seg a[aria-current],.rolef.on,.modes .on,.chip.on{background:var(--gold) !important;color:#14110A !important;border-color:var(--gold) !important}
.hp-tabs{border-bottom:1px solid var(--line) !important;background:transparent !important;border-radius:0 !important;padding:0 !important}
.hp-tabs [role=tab]{border-radius:0 !important;background:transparent !important;border:0 !important;border-bottom:2px solid transparent !important;color:var(--steel) !important;font:600 14px var(--body) !important}
.hp-tabs [role=tab][aria-selected=true]{color:var(--bone) !important;border-bottom-color:var(--gold) !important}
/* tabelas */
table{font-variant-numeric:tabular-nums}
table th{font:700 12px 'Barlow Condensed',sans-serif !important;letter-spacing:.14em;text-transform:uppercase;color:var(--steel) !important}
table td{border-color:var(--line) !important}
/* tags dado / regra / hipótese */
.tag,.pill{border-radius:2px !important}
/* menu lateral */
.side-mini{display:block;height:3px;background:#262335;margin-top:5px;width:100%}.side-mini i{display:block;height:100%;background:linear-gradient(90deg,#6FB7FF,#9C7BFF)}
.side-me>div{min-width:0;flex:1}
.side-st{display:flex;flex-direction:column;gap:3px;padding:2px 14px 8px;font-size:12px;color:var(--steel)}
.side-st i{display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--steel);margin-right:7px;vertical-align:middle}.side-st i.ok{background:var(--win);box-shadow:0 0 6px var(--win)}
.side .logo svg{filter:drop-shadow(0 0 6px rgba(224,56,76,.55))}
.side-f{border-top:1px solid var(--line)}
/* faixa do título nas páginas */
.banner,.ph,.pagehead{border-radius:3px !important}
/* seleção de campeões e ao vivo */
.bx-left,.bx-t,.bx-sk,.bx-items,.mh-box{background:rgba(0,0,0,.22) !important;border:1px solid var(--line) !important;border-radius:3px !important}

/* Coach IA: painel com destaque e cores */
.cbox{background:linear-gradient(160deg,rgba(111,183,255,.07),rgba(18,17,26,.6) 45%),#12111A !important;border-radius:3px !important}
.cbox h3{font:700 13px 'Barlow Condensed',sans-serif !important;letter-spacing:.16em;text-transform:uppercase;color:var(--sky,#6FB7FF) !important}
.cbst>div{border-radius:2px !important;background:#1A1824;border:0 !important;border-left:3px solid var(--c,#D9B45A) !important;padding:9px 10px !important}
.cbst>div:nth-child(1){--c:#7CCB98}.cbst>div:nth-child(2){--c:#EE8A8F}.cbst>div:nth-child(3){--c:#D9B45A}.cbst>div:nth-child(4){--c:#6FB7FF}
.cbst b{font:600 26px/1.1 'Chakra Petch',monospace !important;color:var(--c) !important}
.cbox:first-child>p:last-child{border:1px solid #6A2E36;background:linear-gradient(90deg,rgba(224,56,76,.16),rgba(224,56,76,.03));padding:10px 12px;margin-top:10px !important;color:#FFD0D5}
.cbox:first-child>p:last-child b{color:#FFB3BB}
.sgg small{display:flex !important;align-items:center;gap:6px;font:700 11px 'Barlow Condensed',sans-serif !important;letter-spacing:.16em;text-transform:uppercase;color:var(--c) !important}
.sgg small::before{content:"";width:8px;height:8px;background:var(--c);transform:rotate(45deg)}
.sgg:nth-of-type(1){--c:#D9B45A}.sgg:nth-of-type(2){--c:#7CCB98}.sgg:nth-of-type(3){--c:#6FB7FF}.sgg:nth-of-type(4){--c:#9C7BFF}
.sug{border-radius:2px !important;border-left:2px solid var(--c) !important;background:#13121B !important;transition:background .2s,transform .2s}
.sug:hover{background:#1F1C2C !important;transform:translateX(3px)}
.msg.bot{border-left:3px solid #6FB7FF !important}
/* texto escuro em fundo dourado */
.on-gold,.on-gold *{color:#14110A !important}

/* pós-jogo com a arte */
.vph{position:relative;overflow:hidden;min-height:150px;align-items:flex-end !important}
.vph>*{position:relative;z-index:1}
.vph-art{position:absolute !important;z-index:0 !important;right:0;top:0;bottom:0;width:62%;background-size:cover;background-position:50% 22%;
 -webkit-mask-image:linear-gradient(90deg,transparent,#000 45%);mask-image:linear-gradient(90deg,transparent,#000 45%);opacity:.9}
.vph.l .vph-art{filter:grayscale(.55) brightness(.8)}
.vph .res{font:800 44px/1 'Barlow Condensed',sans-serif !important}
/* títulos de bloco em qualquer página */
main :is(div,section,article)[class]>h3:first-child{font-family:'Barlow Condensed',sans-serif !important;font-weight:700;font-size:20px !important;text-transform:uppercase;letter-spacing:.02em;display:flex;align-items:center;gap:9px}
main :is(div,section,article)[class]>h3:first-child::before{content:"";width:7px;height:7px;background:var(--gold);transform:rotate(45deg);flex:none}
main .cbox>h3:first-child::before{display:none}

/* ao vivo: arte da skin atrás do relógio */
.lv-top{position:relative;overflow:hidden;min-height:150px;background:linear-gradient(90deg,rgba(11,10,16,.95),rgba(11,10,16,.6) 55%,rgba(11,10,16,.35)),var(--lvart) 70% 22%/cover no-repeat,#0B0A10 !important;border-radius:3px !important}
.lv-clock b{font:600 56px/1 'Chakra Petch',monospace !important}
.lv-live{display:inline-flex;align-items:center;gap:6px;font:700 11px 'Barlow Condensed',sans-serif;letter-spacing:.16em;text-transform:uppercase;color:#FF8C9A}
.lv-live::before{content:"";width:8px;height:8px;border-radius:50%;background:#E0384C}
@media (prefers-reduced-motion:no-preference){.lv-live::before{animation:vpulse 1.6s ease-in-out infinite}@keyframes vpulse{0%,100%{box-shadow:0 0 0 0 rgba(224,56,76,.6)}50%{box-shadow:0 0 0 7px rgba(224,56,76,0)}}}
.lv-card{border-radius:3px !important}
/* números de placar */
.kpi b,.hp-kpi b,.big,.num,.n-big,.stat b,.hx-num,td.num,.sc,.score,.lp,.v-big{font-family:'Chakra Petch',var(--mono);font-variant-numeric:tabular-nums}
/* menu lateral */
.shell{grid-template-columns:256px minmax(0,1fr) !important}
.side{background:linear-gradient(180deg,#100E18,#0B0A10 60%) !important;border-image:linear-gradient(180deg,rgba(217,180,90,.45),rgba(217,180,90,.06) 60%,rgba(217,180,90,.2)) 1 !important}
.clogo b{font-family:'Barlow Condensed',var(--d) !important;font-weight:800 !important;letter-spacing:.16em !important}
.side-me{background:linear-gradient(135deg,rgba(111,183,255,.12),rgba(156,123,255,.06) 50%,transparent),var(--raised) !important;border-color:#2D3550 !important}
.side-me .pav{box-shadow:0 0 0 2px #0B0A10,0 0 0 4px var(--tc,#6FB7FF),0 0 16px -2px var(--tc,#6FB7FF);border-radius:50%}
.sg small{color:var(--steel) !important;font:700 11px 'Barlow Condensed',var(--body) !important;letter-spacing:.18em;text-transform:uppercase}
.sg small::before{background:var(--gold) !important}
.sg a{border-radius:0 !important;font:500 15px var(--body) !important}
.sg a[aria-current]{background:linear-gradient(90deg,rgba(217,180,90,.18),rgba(217,180,90,.02) 70%,transparent) !important}
.sg a[aria-current]::before{background:var(--gold) !important;left:0;top:0;bottom:0;width:2px}
.sg a[aria-current] .ni{color:var(--gold) !important}
/* abas */
.subnav{border-radius:0 !important;background:transparent !important;border:0 !important;border-bottom:1px solid var(--line) !important;padding:0 !important;gap:2px !important;backdrop-filter:none;margin-bottom:12px}
.subnav a{border-radius:0 !important;background:transparent !important;color:var(--steel) !important;font:600 14px var(--body) !important;padding:11px 13px !important;border-bottom:2px solid transparent;margin-bottom:-1px}
.subnav a:hover{color:var(--bone) !important}
.subnav a[aria-current]{color:var(--bone) !important;border-bottom-color:var(--gold)}
.subnav2{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 18px}
.subnav2 a{font:600 13px var(--body);color:var(--steel);text-decoration:none;padding:6px 12px;border:1px solid var(--line-hover);transition:all .2s}
.subnav2 a:hover{color:var(--bone);border-color:var(--steel)}
.subnav2 a[aria-current]{color:#14110A;background:var(--gold);border-color:var(--gold)}
/* faixa de título com a arte da skin */
.banner{min-height:200px !important;border-radius:0 !important;border-bottom:1px solid var(--line)}
.banner .bn-art{-webkit-mask-image:linear-gradient(90deg,transparent 18%,#000 62%);mask-image:linear-gradient(90deg,transparent 18%,#000 62%)}
.banner h1{font:800 54px/1 'Barlow Condensed',var(--d) !important;text-transform:uppercase;letter-spacing:.01em}
.bn-k{font:700 12px 'Barlow Condensed',var(--body) !important;letter-spacing:.18em;text-transform:uppercase;color:var(--gold) !important}
/* botões */
.btn,button.primary,.cta{letter-spacing:.06em}
/* efeitos */
@media (prefers-reduced-motion:no-preference){
  main>*{animation:vrise .55s cubic-bezier(.2,.8,.2,1) both}
  main>*:nth-child(2){animation-delay:.04s}main>*:nth-child(3){animation-delay:.08s}main>*:nth-child(4){animation-delay:.12s}main>*:nth-child(n+5){animation-delay:.16s}
  @keyframes vrise{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}
  .banner .bn-art,.hp-art.on,.chero .sp{animation:vkb 26s ease-in-out infinite alternate}
  @keyframes vkb{from{transform:scale(1)}to{transform:scale(1.06)}}
  .card,.hp-panel,.kpi,.hp-quick a,.dcard{transition:transform .2s,box-shadow .2s,border-color .2s}
  .hp-quick a:hover,.dcard:hover{transform:translateY(-2px);box-shadow:0 8px 22px -10px rgba(217,180,90,.45)}
}
"""

JS = """<script>(function(){function flat(root){if(!root||!root.querySelectorAll)return;root.querySelectorAll('div,section,article,details,a,button,li,form,nav,input,select,textarea,span,p,label,aside,header,ol,ul,table').forEach(function(e){
var r=parseFloat(getComputedStyle(e).borderTopLeftRadius);var cs=getComputedStyle(e),bg=cs.backgroundColor;if(/rgb\\((2[0-3]\\d), (1[7-9]\\d|20\\d), ([5-9]\\d|10\\d)\\)/.test(bg)||/^linear-gradient\\(.{0,40}rgb\\((2[0-3]\\d), (1[7-9]\\d|20\\d), ([5-9]\\d|10\\d)\\)/.test(cs.backgroundImage))e.classList.add('on-gold');if(r<6)return;var b=e.getBoundingClientRect();if(!b.width||Math.abs(b.width-b.height)<6)return;if(r>=Math.min(b.width,b.height)/2-1&&Math.min(b.width,b.height)<44)return;e.style.borderRadius='3px'})}
var mn=document.querySelector('main');flat(mn);var t=null;if(mn&&window.MutationObserver)new MutationObserver(function(){clearTimeout(t);t=setTimeout(function(){flat(mn)},120)}).observe(mn,{childList:true,subtree:true});})();</script>
<script>(function(){if(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches)return;
/* numeros contam ate o valor quando a pagina abre */
document.querySelectorAll('.vh-stats b,.cbst b').forEach(function(el){if(el.children.length)return;
var t=el.textContent.trim(),m=t.match(/^([+\\u2212-]?)(\\d+)(?:([.,])(\\d{1,2}))?(%|\\s*PDL)?$/);if(!m)return;
var dec=m[4]?m[4].length:0,val=parseFloat(m[2]+(m[4]?'.'+m[4]:'')),sep=m[3]||',',t0=performance.now();
(function f(n){var k=Math.min(1,(n-t0)/900),e=1-Math.pow(1-k,3),v=(val*e).toFixed(dec).replace('.',sep);el.textContent=m[1]+v+(m[5]||'');if(k<1)requestAnimationFrame(f);else el.textContent=t})(t0)});
})();</script>"""
