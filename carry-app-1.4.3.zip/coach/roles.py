"""Um modo por rota: o que o app cobra de cada funcao (voz no jogo e o cartao do inicio).

As metas e dicas sao regra geral do app; os numeros da pessoa vem das partidas dela (dado).
"""
import html

e = lambda s: html.escape("" if s is None else str(s), quote=True)

MODES = {
    "TOP": ("Modo topo", "Ondas e teleporte",
            ["Controle a onda: congele perto da sua torre quando estiver atrás.", "Teleporte: guarde para dragão e lutas do lado de baixo.",
             "Arauto e larvas ficam do seu lado: ajude o caçador quando a onda estiver empurrada."]),
    "JUNGLE": ("Modo caçador", "Rota de acampamentos, ganks e objetivos",
               ["A rota dos melhores com o seu campeão (início, lado aos 3 min, primeiro abate).", "Qual rota tem vantagem para gankar, pelo placar.",
                "Farm do caçador inimigo comparado com o seu aos 5 e 10 min."]),
    "MIDDLE": ("Modo meio", "Prioridade de onda e rotação",
               ["Empurre e ajude o caçador no rio (caranguejo, larvas, dragão).", "Oponente morto ou na base: rota livre para rotacionar.",
                "Recargas do oponente sempre na faixa do overlay."]),
    "BOTTOM": ("Modo atirador", "Farm, posição e picos de item",
               ["Farm comparado com a sua média e com o alvo da rota.", "Avisos dos picos: 2 itens completos é hora de procurar objetivo.",
                "Dragão: chegue com a onda empurrada e o suporte com visão."]),
    "UTILITY": ("Modo suporte", "Visão e roaming",
                ["Pontuação de visão comparada com o alvo do suporte.", "Lembrete de Sentinela de Controle a cada volta à base.",
                 "Atirador morto ou na base: hora de colocar visão ou rotacionar para o meio."]),
}
VISION_PER_MIN = {"TOP": 0.7, "JUNGLE": 1.0, "MIDDLE": 0.8, "BOTTOM": 0.7, "UTILITY": 2.2}


def card_html(position, games=None):
    m = MODES.get(position)
    if not m:
        return ""
    title, sub, items = m
    lis = "".join(f"<li>{e(x)}</li>" for x in items)
    extra = ""
    if games:
        vs = [g["vision_per_min"] for g in games[:20] if g.get("vision_per_min") is not None]
        if vs:
            avg = sum(vs) / len(vs)
            tgt = VISION_PER_MIN.get(position, 0.8)
            extra = (f"<p class='n'><span class='tag dado'>dado</span> Sua visão nos últimos {len(vs)} jogos: {avg:.2f} por minuto "
                     f"(alvo da rota, pela regra geral do app: {tgt:g}).</p>")
    return f"<p><b>{e(title)}</b> · {e(sub)}</p><ul class='n' style='margin:6px 0 0;padding-left:18px'>{lis}</ul>{extra}"


def live_cues(live_data, me, foes, pos, gt, items=None):
    """Voz por rota (so o placar, que todo mundo ve)."""
    al = []
    add = lambda k, t, v=None: al.append({"k": k, "t": t, **({"v": v} if v else {})})
    sc = me.get("scores") or {}
    mins = max(gt / 60, 1)
    allies = [p for p in (live_data.get("allPlayers") or []) if p.get("team") == me.get("team") and p is not me]
    if pos == "UTILITY":
        for m in (5, 10, 15, 20):
            if m * 60 <= gt < m * 60 + 30:
                ws = float(sc.get("wardScore") or 0)
                tgt = VISION_PER_MIN["UTILITY"] * m
                add(f"sup_vis_{m}", f"{m} minutos: visão {ws:.0f} (alvo do suporte perto de {tgt:.0f}).",
                    f"{m} minutos. Sua visão está {'boa' if ws >= tgt * 0.85 else 'baixa'}: {ws:.0f} de pontuação.")
        adc = next((p for p in allies if p.get("position") == "BOTTOM"), None)
        if adc and adc.get("isDead") and int(adc.get("respawnTimer") or 0) >= 10 and gt >= 240:
            d = int((adc.get("scores") or {}).get("deaths") or 0)
            add(f"sup_adcdead_{d}", f"{adc.get('championName')} morto por {int(adc.get('respawnTimer') or 0)}s: coloque visão no rio ou ajude o meio.")
        if me.get("isDead"):
            owned = {it.get("itemID") for it in me.get("items") or []}
            d = int(sc.get("deaths") or 0)
            from . import visao
            if 2055 not in owned and visao.needs(me, gt):
                add(f"sup_cw_{d}", "Na base: compre Sentinela de Controle.")
    elif pos == "TOP":
        ss = me.get("summonerSpells") or {}
        names = " ".join(((ss.get(k) or {}).get("displayName") or "") for k in ("summonerSpellOne", "summonerSpellTwo")).lower()
        if "teleport" in names or "teleporte" in names:
            ev = (live_data.get("events") or {}).get("Events") or []
            drag = [x for x in ev if x.get("EventName") == "DragonKill"]
            nxt = (drag[-1].get("EventTime") or 0) + 300 if drag else 300
            if 0 < nxt - gt <= 50 and gt >= 240:
                add(f"top_tp_{int(nxt)}", "Dragão em menos de 1 minuto: se o Teleporte estiver pronto, empurre a onda e esteja pronto para a luta.")
        pass                     # larvas e Arauto: o aviso de 1 minuto vem do macrocues (com o que fazer pela rota)
    elif pos == "MIDDLE":
        if 2 * 60 + 30 <= gt < 2 * 60 + 50:
            add("mid_scuttle", "Caranguejos aos 2:55: com a onda empurrada, ajude o seu caçador no rio.")
    elif pos == "BOTTOM":
        legend = 0
        for it in me.get("items") or []:
            info = (items or {}).get(str(it.get("itemID"))) or {}
            if ((info.get("gold") or {}).get("total") or 0) >= 2500 and "Boots" not in (info.get("tags") or []):
                legend += 1
        if legend >= 2:
            add("adc_2items", "Dois itens completos: seu pico. Procure objetivo com o time.")
        if legend >= 3:
            add("adc_3items", "Três itens completos: lute junto do time e mire no alvo mais próximo com segurança.")
    return al
