"""Conversa com o cliente do LoL aberto no seu PC (API local, so em 127.0.0.1).

ATENCAO: a Riot diz na documentacao que esta API (LCU) NAO tem suporte oficial
para apps de terceiros: pode mudar sem aviso, e ela pede que quem usa o LCU
junto da API oficial registre o app no Developer Portal citando os endpoints
usados (veja LEIAME_V2.md). Este modulo so le a selecao de campeoes e grava paginas de
runas / conjuntos de itens. As dicas durante a partida ficam em live.py, que usa a
API oficial Live Client Data (porta 2999).

Os caminhos abaixo vem do conhecimento publico da comunidade e NAO foram testados
por mim contra um cliente real: quem confirma e o seu PC.
"""
import base64
import json
import os
import ssl
import urllib.error
import urllib.request

LOCKFILE_CANDIDATES = [
    r"C:\Riot Games\League of Legends\lockfile",
    r"D:\Riot Games\League of Legends\lockfile",
    r"C:\Program Files\Riot Games\League of Legends\lockfile",
    r"C:\Program Files (x86)\Riot Games\League of Legends\lockfile",
]


class LCUError(Exception):
    pass


def _install_from_riot():
    """Pasta do LoL pelo arquivo de instalacao do Riot Client (funciona em qualquer disco)."""
    f = r"C:\ProgramData\Riot Games\Metadata\league_of_legends.live\league_of_legends.live.product_settings.yaml"
    try:
        with open(f, encoding="utf-8", errors="ignore") as fh:
            for line in fh:
                if "product_install_full_path" in line:
                    p = line.split(":", 1)[1].strip().strip('"').strip("'")
                    return os.path.join(p, "lockfile")
    except OSError:
        pass
    return None


def find_lockfile():
    env = os.environ.get("LOL_LOCKFILE")
    for path in ([env] if env else []) + [_install_from_riot()] + LOCKFILE_CANDIDATES:
        if path and os.path.exists(path):
            return path
    return None


def _from_process():
    """Porta e senha pela linha de comando do cliente aberto (quando o lockfile nao esta num lugar conhecido)."""
    if os.name != "nt":
        return None
    import re
    import subprocess
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command",
                              "(Get-CimInstance Win32_Process -Filter \"name='LeagueClientUx.exe'\").CommandLine"],
                             capture_output=True, text=True, timeout=10, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout
    except Exception:
        return None
    port = re.search(r"--app-port=(\d+)", out or "")
    tok = re.search(r"--remoting-auth-token=([\w-]+)", out or "")
    return (int(port.group(1)), tok.group(1)) if port and tok else None


def parse_lockfile(text):
    parts = text.strip().split(":")
    if len(parts) < 5:
        raise LCUError("Lockfile em formato inesperado.")
    return {"port": int(parts[2]), "password": parts[3], "protocol": parts[4]}


_SSL = []


def _ssl_ctx():
    if not _SSL:
        _SSL.append(ssl.create_default_context())
    return _SSL[0]


class LCU:
    def __init__(self, port, password, opener=None):
        self.port = port
        self.password = password
        self._opener = opener
        ctx = _ssl_ctx()
        # O cliente usa certificado proprio; so falamos com 127.0.0.1.
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        self._ctx = ctx

    _cache = {"at": 0.0, "pp": None, "miss_at": 0.0}

    @classmethod
    def discover(cls):
        """Acha o cliente. Guarda porta e senha por alguns segundos: a tela ao vivo pergunta varias vezes por segundo
        e procurar o processo pelo PowerShell demora."""
        import time
        c = cls._cache
        now = time.time()
        if c["pp"] and now - c["at"] < 20:
            return cls(*c["pp"])
        path = find_lockfile()
        if not path:
            if now - c["miss_at"] < 8:          # acabou de procurar e nao achou: nao roda o PowerShell de novo agora
                raise LCUError("O cliente do LoL não está aberto. Abra o LoL (a tela inicial do cliente) e tente de novo.")
            pr = _from_process()
            if pr:
                c.update(at=now, pp=(pr[0], pr[1]))
                return cls(pr[0], pr[1])
            c.update(miss_at=now, pp=None)
            raise LCUError("O cliente do LoL não está aberto. Abra o LoL (a tela inicial do cliente) e tente de novo.")
        try:
            with open(path, encoding="utf-8") as f:
                info = parse_lockfile(f.read())
        except OSError as e:
            raise LCUError(f"Não consegui ler o lockfile: {e}")
        c.update(at=now, pp=(info["port"], info["password"]))
        return cls(info["port"], info["password"])

    @classmethod
    def forget(cls):
        cls._cache.update(at=0.0, pp=None)

    def request(self, method, path, body=None):
        """Retorna (status, json_ou_None)."""
        if self._opener:
            return self._opener(method, path, body)
        url = f"https://127.0.0.1:{self.port}{path}"
        data = json.dumps(body).encode("utf-8") if body is not None else None
        req = urllib.request.Request(url, data=data, method=method)
        token = base64.b64encode(f"riot:{self.password}".encode()).decode()
        req.add_header("Authorization", f"Basic {token}")
        req.add_header("Accept", "application/json")
        if data is not None:
            req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, context=self._ctx, timeout=10) as r:
                raw = r.read().decode("utf-8")
                return r.status, (json.loads(raw) if raw else None)
        except urllib.error.HTTPError as e:
            try:
                return e.code, json.loads(e.read().decode("utf-8"))
            except Exception:
                return e.code, None
        except (urllib.error.URLError, OSError) as e:
            LCU.forget()            # cliente fechou ou reiniciou (porta nova): procura de novo na proxima
            raise LCUError(f"Sem conexão com o cliente: {e}")

    # -- leitura -----------------------------------------------------------
    def champ_select_session(self):
        status, data = self.request("GET", "/lol-champ-select/v1/session")
        return data if status == 200 else None

    def gameflow_phase(self):
        """None, Lobby, Matchmaking, ReadyCheck, ChampSelect, GameStart, InProgress, WaitingForStats, PreEndOfGame, EndOfGame..."""
        status, data = self.request("GET", "/lol-gameflow/v1/gameflow-phase")
        return data if status == 200 and isinstance(data, str) else None

    def recent_results(self, n=20):
        """Ultimas partidas direto do cliente (nao precisa da chave da Riot): [{"started_ms", "win", "champion_id", "queue"}].
        Ignora remake (menos de 5 min)."""
        status, data = self.request("GET", f"/lol-match-history/v1/products/lol/current-summoner/matches?begIndex=0&endIndex={int(n)}")
        out = []
        if status != 200 or not isinstance(data, dict):
            return out
        for g in ((data.get("games") or {}).get("games") or []):
            try:
                if (g.get("gameDuration") or 0) < 300 or g.get("gameMode") not in ("CLASSIC", None):
                    continue
                p = (g.get("participants") or [{}])[0]
                out.append({"started_ms": int(g.get("gameCreation") or 0), "win": bool((p.get("stats") or {}).get("win")),
                            "champion_id": p.get("championId"), "queue": g.get("queueId"), "match_id": str(g.get("gameId")),
                            "duration_s": int(g.get("gameDuration") or 0)})
            except Exception:
                continue
        out.sort(key=lambda r: -r["started_ms"])
        return out

    def ranked_solo(self):
        """Elo da solo/duo direto do cliente (sem a chave da Riot): {tier, division, lp, wins, losses} ou None."""
        status, data = self.request("GET", "/lol-ranked/v1/current-ranked-stats")
        if status != 200 or not isinstance(data, dict):
            return None
        q = (data.get("queueMap") or {}).get("RANKED_SOLO_5x5")
        if not q:
            q = next((x for x in data.get("queues") or [] if x.get("queueType") == "RANKED_SOLO_5x5"), None)
        if not q or not q.get("tier") or q.get("tier") in ("NONE", ""):
            return None
        return {"tier": q.get("tier"), "division": q.get("division"), "lp": q.get("leaguePoints"),
                "wins": q.get("wins"), "losses": q.get("losses")}

    def last_game_id(self):
        """Id da partida que acabou de terminar (tela de fim de jogo do cliente)."""
        status, data = self.request("GET", "/lol-end-of-game/v1/eog-stats-block")
        if status == 200 and isinstance(data, dict) and data.get("gameId"):
            return int(data["gameId"])
        status, data = self.request("GET", "/lol-gameflow/v1/session")
        if status == 200 and isinstance(data, dict):
            gid = (data.get("gameData") or {}).get("gameId")
            if gid:
                return int(gid)
        return None

    def current_summoner(self):
        status, data = self.request("GET", "/lol-summoner/v1/current-summoner")
        return data if status == 200 else None

    # -- runas ---------------------------------------------------------------
    def rune_pages(self):
        status, data = self.request("GET", "/lol-perks/v1/pages")
        return data if status == 200 and isinstance(data, list) else []

    def save_rune_page(self, page, prefix=("Carry", "LoL Coach")):
        """Troca a pagina antiga do app (mesmo prefixo) pela nova. Nunca apaga paginas suas."""
        for p in self.rune_pages():
            if str(p.get("name", "")).startswith(prefix) and p.get("isDeletable", True):
                self.request("DELETE", f"/lol-perks/v1/pages/{p['id']}")
        status, data = self.request("POST", "/lol-perks/v1/pages", page)
        if status not in (200, 201):
            raise LCUError(f"O cliente recusou a página de runas (HTTP {status}). "
                           "Libere uma página de runas no cliente e tente de novo.")
        return data

    # -- itens ---------------------------------------------------------------
    def save_item_set(self, summoner_id, item_set, prefix=("Carry", "LoL Coach")):
        path = f"/lol-item-sets/v1/item-sets/{summoner_id}/sets"
        status, data = self.request("GET", path)
        data = data if status == 200 and isinstance(data, dict) else {"accountId": summoner_id, "itemSets": []}
        sets = [s for s in data.get("itemSets", []) if not str(s.get("title", "")).startswith(prefix)]
        sets.append(item_set)
        data["itemSets"] = sets
        status, _ = self.request("PUT", path, data)
        if status not in (200, 201, 204):
            raise LCUError(f"O cliente recusou o conjunto de itens (HTTP {status}).")

    # -- replay --------------------------------------------------------------
    def watch_replay(self, game_id):
        """Baixa e abre o replay no cliente (so partidas recentes). Nao verificado."""
        body = {"componentType": "replay-button-match-history"}
        self.request("POST", f"/lol-replays/v1/rofls/{game_id}/download", body)
        status, _ = self.request("POST", f"/lol-replays/v1/rofls/{game_id}/watch", body)
        if status not in (200, 204):
            raise LCUError(f"O cliente não abriu o replay (HTTP {status}). Só partidas recentes ficam disponíveis.")


def enable_replay_api():
    """Liga a API oficial de replay do jogo (EnableReplayApi=1 no game.cfg) para o app pular direto para o momento da morte.
    So mexe nessa linha. Devolve True se ja estava ligada ou se ligou agora (vale a partir do proximo replay aberto)."""
    lf = find_lockfile()
    base = os.path.dirname(lf) if lf else None
    if not base:
        return False
    cfg = os.path.join(base, "Config", "game.cfg")
    try:
        with open(cfg, encoding="utf-8", errors="ignore") as fh:
            txt = fh.read()
    except OSError:
        return False
    import re as _re
    if _re.search(r"(?im)^\s*EnableReplayApi\s*=\s*1\s*$", txt):
        return True
    if _re.search(r"(?im)^\s*EnableReplayApi\s*=", txt):
        txt = _re.sub(r"(?im)^\s*EnableReplayApi\s*=.*$", "EnableReplayApi=1", txt)
    elif _re.search(r"(?im)^\[General\]\s*$", txt):
        txt = _re.sub(r"(?im)^\[General\]\s*$", "[General]\nEnableReplayApi=1", txt, count=1)
    else:
        txt = "[General]\nEnableReplayApi=1\n" + txt
    try:
        import shutil
        shutil.copy2(cfg, cfg + ".carry-backup")
        with open(cfg, "w", encoding="utf-8") as fh:
            fh.write(txt)
        return True
    except OSError:
        return False


def _game_cfg():
    lf = find_lockfile()
    return os.path.join(os.path.dirname(lf), "Config", "game.cfg") if lf else None


def set_window_mode(mode):
    """WindowMode do jogo (0 tela cheia, 1 janela, 2 sem bordas). Devolve o valor anterior (ou None se nao deu)."""
    import re as _re
    cfg = _game_cfg()
    if not cfg or not os.path.exists(cfg):
        return None
    with open(cfg, encoding="utf-8", errors="ignore") as fh:
        txt = fh.read()
    m = _re.search(r"(?im)^\s*WindowMode\s*=\s*(\d+)\s*$", txt)
    old = int(m.group(1)) if m else 0
    if m:
        txt = _re.sub(r"(?im)^\s*WindowMode\s*=.*$", f"WindowMode={int(mode)}", txt)
    elif _re.search(r"(?im)^\[General\]\s*$", txt):
        txt = _re.sub(r"(?im)^\[General\]\s*$", f"[General]\nWindowMode={int(mode)}", txt, count=1)
    else:
        return None
    with open(cfg, "w", encoding="utf-8") as fh:
        fh.write(txt)
    return old


def game_running():
    if os.name != "nt":
        return False
    import subprocess
    try:
        out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq League of Legends.exe", "/NH"], capture_output=True, text=True,
                             creationflags=0x08000000, timeout=10).stdout
        return "League of Legends.exe" in out
    except Exception:
        return False


RESTORE_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "cache", "replay_janela.txt")


def replay_windowed_start():
    """Antes de abrir o replay: deixa o jogo em janela e guarda o modo de antes para voltar depois."""
    old = set_window_mode(1)
    if old is not None and old != 1:
        os.makedirs(os.path.dirname(RESTORE_FILE), exist_ok=True)
        with open(RESTORE_FILE, "w") as fh:
            fh.write(str(old))
    return old


def replay_windowed_restore(wait=True):
    """Volta o modo de tela de antes, depois que o jogo (replay) fechar de verdade (o jogo grava o game.cfg ao sair)."""
    import time as _t
    if not os.path.exists(RESTORE_FILE):
        return False
    if wait:
        for _ in range(1800):            # ate 1 h de replay
            if not game_running():
                break
            _t.sleep(2)
        _t.sleep(3)
    elif game_running():
        return False
    try:
        old = int(open(RESTORE_FILE).read().strip())
        set_window_mode(old)
        os.remove(RESTORE_FILE)
        return True
    except Exception:
        return False
