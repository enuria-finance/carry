"""Pos-jogo: resumo, o que foi bem, as 3 decisoes que mais custaram e a pergunta final."""
from . import report, review
from .tags import DADO, REGRA, HIPOTESE, tip

VISION_GOAL = 0.9  # meta sugerida no plano de 30 dias; nao e padrao oficial


def latest_match_id(con, puuid):
    r = con.execute(
        """SELECT m.match_id FROM participants p JOIN matches m USING (match_id)
           JOIN match_source s USING (match_id)
           WHERE p.puuid=? AND s.source='me' AND COALESCE(m.duration_s,0) >= 300
           ORDER BY m.started_ms DESC LIMIT 1""", (puuid,)).fetchone()
    return r[0] if r else None


def _fmt(v, nd=1):
    return "-" if v is None else f"{v:.{nd}f}"


def _cost(m):
    """Ordenacao das mortes: mais cedo, com objetivo logo depois, pelo oponente de rota.
    E uma heuristica do app (hipotese): nao mede ouro perdido de verdade."""
    score = 3 if m["minute"] < 10 else 2 if m["minute"] < 15 else 1
    score += 2 if m["objective_after"] else 0
    score += 1 if m["by_lane_opponent"] else 0
    return score


def build(con, puuid, mid):
    games = report.my_games(con, puuid, "")
    g = next((x for x in games if x["match_id"] == mid), None)
    if not g:
        return None
    others = [x for x in games if x["match_id"] != mid]
    mean = report.summary(others) if others else None
    res = {"match_id": mid, "game": g, "summary": [], "well": [], "costly": [], "focus": None}

    res["summary"].append(tip(DADO, f"{g['champion']} contra {g['opp_champion'] or 'oponente desconhecido'}: "
                                    f"{'vitoria' if g['win'] else 'derrota'}, KDA {g['kills']}/{g['deaths']}/{g['assists']}, "
                                    f"{g['duration_s'] // 60} min, patch {g['patch']}."))
    line = (f"CS aos 10: {_fmt(g['cs10'], 0)} (dif. {_fmt(g['csdiff10'], 0)}); aos 15: {_fmt(g['cs15'], 0)} "
            f"(dif. {_fmt(g['csdiff15'], 0)}); ouro vs oponente aos 15: {_fmt(g['golddiff15'], 0)}.")
    res["summary"].append(tip(DADO, line))
    res["summary"].append(tip(DADO, f"Mortes antes dos 10: {_fmt(g['deaths_before_10'], 0)}; antes dos 15: "
                                    f"{_fmt(g['deaths_before_15'], 0)}; visão {_fmt(g['vision_per_min'], 2)}/min; "
                                    f"participação em abates {_fmt(g['kp'] * 100 if g['kp'] is not None else None, 0)}%."))
    if g["cs10"] is None:
        res["summary"].append(tip(HIPOTESE, "Sem timeline desta partida: CS por minuto e mortes por minuto não estão disponíveis."))

    # O que foi bem: so o que esta acima da SUA media (com n) ou da meta do plano.
    def better(key, label, higher=True, nd=1):
        if not mean:
            return
        avg, n = mean[key]
        v = g.get(key)
        if v is None or avg is None or n < 3:
            return
        if (v > avg) if higher else (v < avg):
            res["well"].append(tip(DADO, f"{label}: {_fmt(v, nd)} contra sua média de {_fmt(avg, nd)}.", n))

    better("cs10", "CS aos 10 min", True, 0)
    better("csdiff10", "Diferença de CS aos 10", True, 0)
    better("deaths_before_15", "Mortes antes dos 15", False, 0)
    better("vision_per_min", "Visão por minuto", True, 2)
    better("kp", "Participação em abates", True, 2)
    if g["vision_per_min"] is not None and g["vision_per_min"] >= VISION_GOAL:
        res["well"].append(tip(DADO, f"Visão {_fmt(g['vision_per_min'], 2)}/min, na meta de {VISION_GOAL} do plano (sugestão, não oficial)."))
    if not res["well"]:
        res["well"].append(tip(DADO, "Nenhuma medida ficou acima da sua média neste jogo.", len(others)))

    ms = [m for m in review.moments(con, puuid, mid) if m["kind"] == "morte"]
    ms.sort(key=lambda m: (-_cost(m), m["t_ms"]))
    for m in ms[:3]:
        res["costly"].append({"title": m["title"], "facts": m["facts"], "t_ms": m["t_ms"],
                              "rank_note": tip(HIPOTESE, "A ordem é uma heurística do app (mais cedo, objetivo logo depois, morto pelo oponente de rota); não mede ouro perdido.")})
    if not ms:
        res["costly"] = []

    f = con.execute("SELECT * FROM focus WHERE match_id=?", (mid,)).fetchone()
    if f:
        res["focus"] = tip(DADO, f"Foco do jogo: {f['text']} - resultado {f['value']:.2f}: "
                                 f"{'cumprido' if f['met'] else 'não cumprido'} (sem julgamento).")
    else:
        res["focus"] = tip(DADO, "Não havia foco definido para este jogo. Defina um na tela inicial antes do próximo.")
    res["map_plan"] = tip(HIPOTESE, "O plano de mapa contra a comp inimiga ainda não existe (V3); nada para comparar.")
    res["notes"] = review.notes(con, mid)
    return res
