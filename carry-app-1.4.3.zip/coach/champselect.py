"""Selecao de campeoes: ban, melhor pick, plano B e sinergia, com runas e itens do topo.

Funciona SO na selecao de campeoes (antes da partida). Cada linha vem marcada
como dado (seu historico ou a amostra do topo, com n), regra geral ou hipotese.
"""
from . import builds, profile, report
from .tags import DADO, REGRA, HIPOTESE, tip

MIN_MATCHUP = 5


def snapshot(session, champ_by_key, tags_by_name=None):
    """Resumo da sessao do cliente: meu campeao/posicao, times e bans."""
    if not session:
        return None
    me_cell = session.get("localPlayerCellId")

    def name(cid):
        return champ_by_key.get(cid) if cid else None

    def side(team):
        out = []
        for p in team or []:
            cid = p.get("championId") or p.get("championPickIntent")
            out.append({"cell": p.get("cellId"), "champion": name(cid),
                        "position": (p.get("assignedPosition") or "").upper(),
                        "spells": [s for s in (p.get("spell1Id"), p.get("spell2Id")) if s]})
        return out

    mine = side(session.get("myTeam"))
    skin = next((p.get("selectedSkinId") for p in session.get("myTeam") or [] if p.get("cellId") == me_cell), None)
    theirs = side(session.get("theirTeam"))
    me = next((p for p in mine if p["cell"] == me_cell), None)
    my_cells = {p["cell"] for p in mine}
    # bans: o formato antigo (bans.myTeamBans) vem vazio na ranqueada; o certo e olhar as acoes de ban
    my_bans, their_bans, my_turn, hovers, done = [], [], None, {}, set()
    for group in session.get("actions") or []:
        for a in group or []:
            cid = a.get("championId")
            if a.get("type") == "ban" and a.get("completed") and cid:
                ally = a.get("isAllyAction") if a.get("isAllyAction") is not None else a.get("actorCellId") in my_cells
                (my_bans if ally else their_bans).append(name(cid))
            if a.get("actorCellId") == me_cell and a.get("isInProgress"):
                my_turn = a.get("type")
            if a.get("type") == "ban" and not a.get("completed") and cid and a.get("actorCellId") == me_cell:
                hovers["ban"] = name(cid)
            if a.get("actorCellId") == me_cell and a.get("completed"):
                done.add(a.get("type"))
    bans = session.get("bans") or {}
    my_bans = my_bans or [name(c) for c in bans.get("myTeamBans", []) if c]
    their_bans = their_bans or [name(c) for c in bans.get("theirTeamBans", []) if c]
    return {"me": me, "my_team": mine, "enemy_team": theirs, "my_bans": [b for b in my_bans if b],
            "their_bans": [b for b in their_bans if b], "my_turn": my_turn, "hovers": hovers,
            "ban_done": "ban" in done, "locked": "pick" in done,
            "phase": (session.get("timer") or {}).get("phase"), "skin": skin}


def ban_suggestions(games, min_games=MIN_MATCHUP):
    """Oponentes de rota contra os quais o seu historico e pior (com n)."""
    rows = [r for r in report.by_key(games, "opp_champion", min_games=min_games)]
    rows.sort(key=lambda r: (r[3], -r[1]))
    return [tip(DADO, f"{n}: {w}V {k - w}D ({100 * wr:.0f}%) contra você {profile.lane_in()}.", k)
            for n, k, w, wr in rows[:3]]


def pick_vs(games, opponent, min_games=1):
    """Entre os seus campeoes, como voce foi contra esse oponente de rota."""
    sel = [g for g in games if (g["opp_champion"] or "").lower() == opponent.lower()]
    out = []
    for name, n, w, wr in report.by_key(sel, "champion"):
        out.append(tip(DADO, f"Com {name} contra {opponent}: {w}V {n - w}D ({100 * wr:.0f}%).", n))
    if not out:
        out.append(tip(DADO, f"Nenhum jogo seu contra {opponent} nos dados sincronizados (sem dados).", 0))
    return out


def plan_b(games, main=None, min_games=3):
    main = main or profile.champion()
    rows = [r for r in report.by_key(games, "champion", min_games=min_games) if r[0] != main]
    rows.sort(key=lambda r: (-r[3], -r[1]))
    return [tip(DADO, f"{n}: {w}V {k - w}D ({100 * wr:.0f}%).", k) for n, k, w, wr in rows[:2]] or \
           [tip(DADO, f"Sem outro campeão com 3 jogos ou mais {profile.lane_in()}; plano B indefinido.", 0)]


def synergy(snap, tags_by_name):
    """Alerta simples de sinergia. E hipotese: so olha as classes do Data Dragon."""
    if not snap or not tags_by_name:
        return []
    allies = [p["champion"] for p in snap["my_team"]
              if p["champion"] and p is not snap["me"]]
    if len(allies) < 2:
        return []
    tanks = [a for a in allies if "Tank" in tags_by_name.get(a, [])]
    if not tanks:
        return [tip(HIPOTESE, "Nenhum aliado revelado e da classe Tanque (classes do Data Dragon): o time pode ficar sem engage; "
                              "o seu campeão teria que abrir a luta ou jogar de pick.")]
    return [tip(DADO, "Aliados da classe Tanque: " + ", ".join(tanks) + ".")]


# ---- cartoes de campeao (estilo "Sua escolha") ---------------------------
IMG = "https://ddragon.leagueoflegends.com"  # imagens oficiais da Riot (Data Dragon)


def pool_get(con):
    con.execute("CREATE TABLE IF NOT EXISTS pool (champion TEXT PRIMARY KEY)")
    return [r[0] for r in con.execute("SELECT champion FROM pool ORDER BY rowid")]


def pool_change(con, champion, add, valid_names):
    """Adiciona/remove do pool. So aceita nomes que existem (Data Dragon ou seus jogos)."""
    pool_get(con)
    by_lower = {n.lower(): n for n in valid_names}
    name = by_lower.get((champion or "").strip().lower())
    if not name:
        return False
    if add:
        con.execute("INSERT OR IGNORE INTO pool(champion) VALUES (?)", (name,))
    else:
        con.execute("DELETE FROM pool WHERE champion=?", (name,))
    con.commit()
    return True


def _pct(w, n):
    return round(100 * w / n) if n else None


def champion_scores(games, name, enemy_mid, snap, tags_by_name):
    """Tres barras (0-100 ou None) com a origem: dado (seu historico) ou hipotese (classes)."""
    mine = [g for g in games if g["champion"] == name]
    n_all = len(mine)
    w_all = sum(1 for g in mine if g["win"])
    vs_n = vs_w = 0
    if enemy_mid:
        vs = [g for g in mine if (g["opp_champion"] or "").lower() == enemy_mid.lower()]
        vs_n, vs_w = len(vs), sum(1 for g in vs if g["win"])
    fit = None
    if snap and tags_by_name:
        mytags = tags_by_name.get(name, [])
        allies = [p["champion"] for p in snap["my_team"] if p["champion"] and p is not snap["me"]]
        foes = [p["champion"] for p in snap["enemy_team"] if p["champion"]]
        if allies or foes:
            fit = 50
            if any("Tank" in tags_by_name.get(a, []) for a in allies):
                fit += 15
            tanks = sum(1 for f in foes if "Tank" in tags_by_name.get(f, []))
            squishy = sum(1 for f in foes if set(tags_by_name.get(f, [])) & {"Mage", "Marksman", "Assassin"}
                          and "Tank" not in tags_by_name.get(f, []))
            if "Assassin" in mytags:
                fit += 5 * min(squishy, 3) - 8 * min(tanks, 2)
            fit = max(5, min(95, fit))
    return {"vs": (_pct(vs_w, vs_n), vs_n), "fit": (fit, 0 if fit is None else len(snap["my_team"]) if snap else 0),
            "hist": (_pct(w_all, n_all), n_all)}


def tier_of(scores):
    """Letra so quando ha amostra minima; senao '?'. Mistura as barras que existem."""
    vals = [v for v, _ in (scores["vs"], scores["hist"], scores["fit"]) if v is not None]
    n = scores["hist"][1]
    if not vals or n < 5:
        return "?", None
    avg = sum(vals) / len(vals)
    return ("S" if avg >= 65 else "A" if avg >= 55 else "B" if avg >= 45 else "C"), avg


def _bar(label, val, n, kind, e):
    mark = {"dado": "dado", "hip": "hipotese"}[kind]
    w = 0 if val is None else val
    txt = "sem dados" if val is None else f"{val}"
    extra = "" if (n is None or n == 0 or kind == "hip") else f" · {n} jogo(s)"
    return (f"<div class='bar {mark}' title='{e(label)}'><span class='bl'>{e(label)}</span>"
            f"<span class='bt'><i style='width:{w}%'></i></span><span class='bv'>{e(txt)}{e(extra)}</span></div>")


def _chips(games, name):
    rows = report.by_key([g for g in games if g["champion"] == name], "opp_champion", min_games=report.MIN_VEREDITO)
    strong = sorted([r for r in rows if report.suave(r[2], r[1]) >= 0.58], key=lambda r: -report.suave(r[2], r[1]))[:3]
    weak = sorted([r for r in rows if report.suave(r[2], r[1]) <= 0.42], key=lambda r: report.suave(r[2], r[1]))[:3]
    return strong, weak


def champ_card(games, name, scores, imgs, e, picked=False, rank=None):
    tier, _ = tier_of(scores)
    strong, weak = _chips(games, name)
    splash = f"{IMG}/cdn/img/champion/splash/{name}_0.jpg" if imgs else ""
    bg = f"style=\"background-image:linear-gradient(180deg,rgba(7,9,20,.25),#0d1224 78%),url('{e(splash)}')\"" if splash else ""
    chips = "".join(f"<span class='chip good'>{e(r[0])} · {r[2]}V {r[1] - r[2]}D</span>" for r in strong)
    chips_w = "".join(f"<span class='chip bad'>{e(r[0])} · {r[2]}V {r[1] - r[2]}D</span>" for r in weak)
    n = scores["hist"][1]
    note = ("amostra pequena (menos de 5 jogos): a letra é '?'" if tier == "?"
            else f"letra = média das barras disponíveis; base: {n} jogos seus")
    return (f"<div class='champ{' picked' if picked else ''}'><div class='art' {bg}>"
            f"<span class='tierb t{e(tier if tier != '?' else 'q')}'>{e(tier)}</span>"
            f"{'<span class=pickd>escolhido agora</span>' if picked else ''}"
            f"<b>{e(name)}</b></div>"
            + _bar("Contra " + profile.lane_enemy(), scores["vs"][0], scores["vs"][1], "dado", e)
            + _bar("Seu desempenho (winrate)", scores["hist"][0], scores["hist"][1], "dado", e)
            + _bar("Encaixe no time", scores["fit"][0], None, "hip", e)
            + (f"<div class='chips'><small>Forte contra</small>{chips}</div>" if chips else "")
            + (f"<div class='chips'><small>Fraco contra</small>{chips_w}</div>" if chips_w else "")
            + f"<p class='n'>{e(note)}. Barra de encaixe é hipótese (só classes do Data Dragon).</p></div>")


def team_strip(players, tags_by_name, imgs, e, version):
    out = ""
    for p in players:
        nm = p["champion"]
        pic = (f"<img src='{IMG}/cdn/{e(version)}/img/champion/{e(nm)}.png' alt='' width='44' height='44'>"
               if imgs and nm else "<span class='ph'>?</span>")
        out += (f"<div class='mate'>{pic}<span>{e(nm or 'escolhendo…')}"
                f"<small>{e(p['position'] or '')}</small></span></div>")
    return out


def ban_cards(games, pool, imgs, e, min_games=5):
    """Cartoes 'Ameaca ao seu pool': oponentes de rota que mais te venceram (seu historico, com n)."""
    opp = {}
    for g in games:
        if g["opp_champion"]:
            opp.setdefault(g["opp_champion"], []).append(g)
    rows = []
    for name, gs in opp.items():
        if len(gs) < min_games:
            continue
        w = sum(1 for x in gs if x["win"])
        rows.append((round(100 * (1 - report.suave(w, len(gs)))), name, gs))
    rows.sort(key=lambda r: (-r[0], -len(r[2])))
    out = ""
    for threat, name, gs in rows[:6]:
        splash = f"{IMG}/cdn/img/champion/splash/{name}_0.jpg" if imgs else ""
        bg = f"style=\"background-image:linear-gradient(180deg,rgba(7,9,20,.25),#0d1224 80%),url('{e(splash)}')\"" if splash else ""
        lines = ""
        mine = {}
        for g in gs:
            mine.setdefault(g["champion"], []).append(g)
        for ch, xs in sorted(mine.items(), key=lambda kv: -len(kv[1]))[:4]:
            wr = round(100 * sum(1 for x in xs if x["win"]) / len(xs))
            lines += _bar(f"com {ch}", wr, len(xs), "dado", e)
        out += (f"<div class='champ'><div class='art' {bg}><b>{e(name)}</b></div>"
                + _bar("Ameaça a você " + profile.lane_in(), threat, len(gs), "dado", e) + lines +
                f"<p class='n'>{len(gs)} jogo(s) seus contra ele. Poucos jogos = pode ser só amostra.</p></div>")
    if not out:
        return "<p class='n'>Ainda sem oponentes com 2 jogos ou mais contra você.</p>"
    return "<div class='champs'>" + out + "</div>"


def page_body(con, puuid, e, tips_html):
    """Corpo da pagina /selecao no navegador."""
    from . import lcu as lcu_mod
    from .ddragon import DataDragon
    games = report.my_games(con, puuid, profile.position())
    body = ("<div class='card'><b>Aviso</b><p>Esta tela é da seleção de campeões. As dicas da partida ficam em "
            "<a href='/aovivo'>Ao vivo</a>.</p></div>")
    snap = dd = None
    champs = {}
    version = None
    live_msg = ""
    try:
        dd = DataDragon(cache_dir="cache")
        champs = dd.champions()
        version = dd.version()
    except Exception:  # sem internet: segue sem imagens
        dd = None
    try:
        client = lcu_mod.LCU.discover()
    except lcu_mod.LCUError as ex:
        client = None
        live_msg = f"<div class='card warn'>{e(ex)} Mostrando só a pré-visualização com o seu histórico.</div>"
    if client:
        try:
            session = client.champ_select_session()
            snap = snapshot(session, dd.champion_by_key()) if dd else None
        except Exception as ex:  # cliente fechado, formato novo
            live_msg = f"<div class='card warn'>Não consegui ler a seleção: {e(ex)}</div>"
        if snap is None and not live_msg:
            live_msg = "<div class='card'>Você não está na seleção de campeões agora. Entre na fila, e quando a seleção abrir recarregue a página (F5).</div>"
    tags = {k: v["tags"] for k, v in champs.items()} if champs else {}
    imgs = bool(version)
    body += live_msg

    # times
    if snap:
        body += "<h2>Times</h2><div class='teams'><div><small class='n'>Seu time</small>"
        body += team_strip(snap["my_team"], tags, imgs, e, version) + "</div><div><small class='n'>Inimigos</small>"
        body += team_strip(snap["enemy_team"], tags, imgs, e, version) + "</div></div>"
    enemy_mid = None
    if snap:
        enemy_mid = next((p["champion"] for p in snap["enemy_team"] if p["position"] == profile.position() and p["champion"]), None)

    # cartoes do pool
    pool = pool_get(con)
    default_pool = False
    if not pool:
        by_n = report.by_key(games, "champion")
        pool = [r[0] for r in sorted(by_n, key=lambda r: -r[1])[:3]]
        default_pool = True
    mine = (snap["me"] or {}).get("champion") if snap else None
    names = list(pool)
    if mine and mine not in names:
        names.append(mine)
    cards = []
    for nm in names:
        sc = champion_scores(games, nm, enemy_mid, snap, tags)
        cards.append((tier_of(sc)[1] or -1, nm, sc))
    cards.sort(key=lambda t: (-t[0], t[1]))
    body += "<h2>Sua escolha" + (" · ao vivo" if snap else " · pré-visualização") + "</h2>"
    if default_pool:
        body += f"<p class='n'>Você ainda não montou o seu pool; mostrando seus 3 mais jogados {profile.lane_in()}.</p>"
    body += "<div class='champs'>" + "".join(champ_card(games, nm, sc, imgs, e, picked=(nm == mine)) for _, nm, sc in cards) + "</div>"
    if not cards:
        body += "<div class='card'>Sem partidas de mid sincronizadas ainda. Rode o sync (opção 2).</div>"

    # editor do pool
    valid = sorted(champs) if champs else sorted({g["champion"] for g in games})
    chips = "".join(
        f"<form method='post' action='/selecao/pool' class='pool-chip'><input type='hidden' name='champion' value='{e(n)}'>"
        f"<button name='op' value='remove' class='btn ghost' title='Tirar do pool'>{e(n)} ✕</button></form>"
        for n in (pool_get(con)))
    opts = "".join(f"<option value='{e(n)}'>" for n in valid)
    body += ("<h2>Meu pool</h2><div class='card'><p class='n'>As cartas acima mostram só estes campeões "
             "(mais o que você escolher na seleção).</p><div class='pool'>" + (chips or "<span class='n'>vazio</span>") + "</div>"
             "<form method='post' action='/selecao/pool' class='row'><input type='text' name='champion' list='champs' "
             "placeholder='Adicionar campeão (ex.: Zed)'><datalist id='champs'>" + opts + "</datalist>"
             "<button name='op' value='add'>Adicionar</button></form></div>")

    # cartoes de texto (mantidos)
    body += "<h2>Seu ban · pelo seu histórico</h2>" + ban_cards(games, pool, imgs, e)
    body += "<h2>Bans e plano B</h2>"
    body += f"<div class='card'><b>Plano B se o {profile.champion('seu principal')} for banido</b>" + tips_html(plan_b(games)) + "</div>"
    if snap:
        if enemy_mid:
            body += f"<div class='card'><b>Contra {e(enemy_mid)} (mid inimigo revelado)</b>" + tips_html(pick_vs(games, enemy_mid)) + "</div>"
        sy = synergy(snap, tags)
        if sy:
            body += "<div class='card'><b>Sinergia do time</b>" + tips_html(sy) + "</div>"
    cfg_champ = mine or (cards[0][1] if cards else None)
    if cfg_champ and dd:
        from . import configview
        body += f"<h2>Sua configuração · {e(cfg_champ)}</h2>" + configview.top_panel(con, cfg_champ, dd, e, tips_html)
    return body


def _builds_card(con, champion, dd, e, tips_html):
    rows = builds.top_rows(con, champion, profile.resolve_pos(None, champion))      # rota desta partida, nao a mais jogada
    out = f"<div class='card'><b>Runas e itens do topo no {e(champion)}</b>"
    if not rows:
        return out + tips_html([tip(DADO, "Sem partidas do topo para este campeão. Rode: python -m coach topo --champion " + champion, 0)]) + "</div>"
    names = dd.rune_names() if dd else {}
    stats = builds.rune_stats(rows)
    if stats:
        (prim, sub, sel), n, w = stats[0]
        out += tips_html([tip(DADO, f"Página mais usada: {names.get(sel[0], sel[0])} ({names.get(prim, prim)} + {names.get(sub, sub)}); "
                                    f"{w}V {n - w}D nessa página.", n)])
    items = dd.items() if dd else {}
    st = builds.item_stats(con, rows, items)
    nm = lambda i: (items.get(str(i)) or {}).get("name", str(i))
    if st["n"]:
        if st["order"] and st["order"][0]:
            out += tips_html([tip(DADO, "Primeiros itens (caminho dos melhores): " + " > ".join(nm(i) for i in builds.full_build(st)[:3]) + ".", st["n"])])
        if st["boots"]:
            out += tips_html([tip(DADO, f"Botas mais comuns: {nm(st['boots'][0][0])}.", st["n"])])
    out += ("<form method='post' action='/selecao/importar'><input type='hidden' name='champion' value='" + e(champion) + "'>"
            "<button name='what' value='runas'>Importar runas no cliente</button> "
            "<button name='what' value='itens'>Importar itens no cliente</button></form></div>")
    return out


def do_import(con, champion, what, lcu_client=None, dd=None, page=None):
    """Grava runas ou itens do topo no cliente. Devolve texto de resultado."""
    from .ddragon import DataDragon
    lcu_client = lcu_client or __import__("coach.lcu", fromlist=["LCU"]).LCU.discover()
    dd = dd or DataDragon(cache_dir="cache")
    rows = builds.top_rows(con, champion, profile.resolve_pos(None, champion))      # rota desta partida, nao a mais jogada
    if not rows:
        return "Sem partidas do topo para este campeão nesta rota; nada para importar."
    if what == "runas":
        try:      # pagina escolhida na tela (ex.: a de "contra tanques"): prim,sub,9 runas
            nums = [int(x) for x in (page or "").split(",") if x.strip()]
        except ValueError:
            nums = []
        if len(nums) == 11:
            lcu_client.save_rune_page(builds.rune_page(f"Carry {champion}", (nums[0], nums[1], nums[2:])))
            return f"Página 'Carry {champion}' (a que você escolheu) gravada no cliente."
        if len(rows) < builds.MIN_ROWS:
            return f"Só {len(rows)} partidas dos melhores com {champion} nesta rota: pouco para confiar numa página. Baixe mais amostra."
        stats = builds.keystone_stats(rows)          # a mesma escolha das runas automaticas
        if not stats:
            return "Nenhuma página de runas completa na amostra."
        (prim, sub, sel), n, w = stats[0]
        lcu_client.save_rune_page(builds.rune_page(f"Carry {champion}", (prim, sub, list(sel))))
        return f"Página 'Carry {champion}' gravada no cliente (amostra: {n} jogos)."
    if what == "itens":
        items = dd.items()
        st = builds.item_stats(con, rows, items)
        key = dd.champions()[champion]["key"]
        me = lcu_client.current_summoner() or {}
        lcu_client.save_item_set(me.get("summonerId") or me.get("accountId") or 0,
                                 builds.item_set(f"Carry {champion}", key, st, items, champion, profile.resolve_pos(None, champion)))
        return f"Conjunto de itens 'Carry {champion}' gravado no cliente (amostra: {st['n']} jogos)."
    return "Ação desconhecida."


# ---------------- runas sozinho (pedido: "monta e fala comigo igual ao app do anuncio") ----------------
_AUTO = {}        # campeao -> {"page": pagina gravada, "enemy": oponente usado, "at": quando}


def auto_runes(con, client, snap, dd, position, roles=None):
    """Com o campeao travado, grava no cliente a pagina dos melhores (a de contra o oponente, se houver amostra)
    e o conjunto de itens. Devolve a fala {"k","t","v"} ou None (nada novo). Nunca apaga paginas suas."""
    import time as _t
    from . import draft
    me = (snap or {}).get("me") or {}
    champ = me.get("champion")
    if not champ or not snap.get("locked"):
        return None
    roles = roles if roles is not None else draft.role_map(con)
    enemy, _g = draft.enemy_laner(snap, position, roles)
    prev = _AUTO.get((champ, position))
    if prev and _t.time() - prev["at"] > 900:
        prev = None
    if prev and prev["enemy"] == (enemy or prev["enemy"]):
        return None
    if position not in ("TOP", "JUNGLE", "MIDDLE", "BOTTOM", "UTILITY"):
        return None                          # sem rota definida nao monta nada
    rows = builds.top_rows(con, champ, position)          # so a rota desta partida
    if len(rows) < builds.MIN_ROWS:          # poucos jogos dos melhores com o campeao: nao mexe nas suas runas
        return None
    runes = builds.keystone_stats(rows)
    if not runes:
        return None
    page, vs = runes[0][0], None
    champs = dd.champions()
    if enemy:
        try:
            cls = builds.class_of((champs.get(enemy) or {}).get("tags"))
            by, counts = builds.runes_by_opponent(con, rows, champs)
            if cls and counts.get(cls, 0) >= 15:
                b = builds.best_page(by[cls])
                if b and b[0] != page:
                    page, vs = b[0], enemy
        except Exception:
            pass
    if prev and prev["page"] == page:
        _AUTO[(champ, position)] = dict(prev, enemy=enemy or prev["enemy"], at=_t.time())
        return None
    prim, sub, sel = page
    client.save_rune_page(builds.rune_page(f"Carry {champ}", (prim, sub, list(sel))))
    first = prev is None
    _AUTO.clear()
    _AUTO[(champ, position)] = {"page": page, "enemy": enemy, "at": _t.time()}
    if first:
        try:
            items = dd.items()
            st = builds.item_stats(con, rows, items)
            who = client.current_summoner() or {}
            client.save_item_set(who.get("summonerId") or who.get("accountId") or 0,
                                 builds.item_set(f"Carry {champ}", champs[champ]["key"], st, items, champ, position))
        except Exception:
            pass
    names = dd.rune_names()
    ks, pn, sn = names.get(sel[0], "?"), names.get(prim, "?"), names.get(sub, "?")
    cname = (champs.get(champ) or {}).get("name", champ)
    if vs:
        t = f"Montei suas runas contra {vs}: {ks}, {pn} com {sn}. É a página que mais vence nesse tipo de duelo entre os melhores."
        v = f"Montei suas runas contra {vs}: {ks}, com {sn} na secundária."
    else:
        t = f"Já montei sua página de runas: {ks}, {pn} com {sn}, a mais usada pelos melhores de {cname}. Os itens também estão na loja."
        v = f"Já montei sua página de runas: {ks}, com {sn} na secundária."
    return {"k": f"sel_runas_{champ}_{vs or ''}", "t": t, "v": v}
