"""Depois da partida: nota 0-100, mortes no minimapa, erros mais comuns e o resumo falado.

Os alvos por rota (farm, visao, participacao) sao regra geral do app, nao numero oficial da Riot.
"""
import html
import json

from . import review

e = lambda s: html.escape("" if s is None else str(s), quote=True)

# alvos por rota (regra geral): farm por minuto, visao por minuto, participacao em abates
TARGETS = {"TOP": (7.0, 0.7, 0.45), "JUNGLE": (6.0, 1.0, 0.6), "MIDDLE": (7.5, 0.8, 0.5),
           "BOTTOM": (8.0, 0.7, 0.5), "UTILITY": (1.5, 2.2, 0.6)}
WEIGHTS = {"UTILITY": (0.2, 0.05, 0.4, 0.35), "JUNGLE": (0.2, 0.2, 0.2, 0.4)}
DEFAULT_W = (0.3, 0.3, 0.1, 0.3)
MAP_MAX = 14870


def _c(v):
    return max(0, min(100, round(v)))


def score(g):
    """{'total', 'parts': [(rotulo, nota, detalhe)]} a partir das medidas da partida (dado) e dos alvos da rota (regra geral)."""
    pos = g.get("position") or "MIDDLE"
    t_cs, t_vis, t_kp = TARGETS.get(pos, TARGETS["MIDDLE"])
    w = WEIGHTS.get(pos, DEFAULT_W)
    parts = []
    gd = g.get("golddiff15") if g.get("golddiff15") is not None else g.get("golddiff10")
    if gd is not None:
        lane = _c(50 + gd / 30)
        parts.append(("Rota", lane, f"{'+' if gd >= 0 else ''}{gd} de ouro contra o oponente aos {15 if g.get('golddiff15') is not None else 10} min"))
    elif g.get("csdiff10") is not None:
        lane = _c(50 + g["csdiff10"] * 2)
        parts.append(("Rota", lane, f"{g['csdiff10']:+d} de farm aos 10 min"))
    else:
        lane = None
    cspm = g.get("cs_per_min")
    farm = _c(100 * ((cspm / t_cs) - 0.4) / 0.6) if cspm is not None else None
    if farm is not None:
        parts.append(("Farm", farm, f"{cspm:.1f} por minuto (alvo da rota: {t_cs:g})"))
    vpm = g.get("vision_per_min")
    vis = _c(100 * vpm / (t_vis * 1.15)) if vpm is not None else None
    if vis is not None:
        parts.append(("Visão", vis, f"{vpm:.2f} por minuto (alvo: {t_vis:g})"))
    kp = g.get("kp")
    d = g.get("deaths") or 0
    fight = _c(65 * min(1, (kp or 0) / t_kp) + 35 * max(0, 1 - d / 9)) if kp is not None else _c(100 * max(0, 1 - d / 9))
    parts.append(("Lutas", fight, (f"{round(100 * kp)}% de participação, " if kp is not None else "") + f"{d} mortes"))
    vals = [(lane, w[0]), (farm, w[1]), (vis, w[2]), (fight, w[3])]
    tw = sum(wt for v, wt in vals if v is not None)
    total = _c(sum(v * wt for v, wt in vals if v is not None) / tw) if tw else None
    return {"total": total, "parts": parts}


def grade(total):
    if total is None:
        return "–", "n"
    return ("S", "g") if total >= 80 else ("A", "g") if total >= 65 else ("B", "n") if total >= 50 else ("C", "r") if total >= 35 else ("D", "r")


def score_html(sc):
    t = sc["total"]
    gr, cls = grade(t)
    rows = "".join(f"<div class='gs-r'><span>{e(lb)}</span><div class='gs-b'><i class='{'g' if v >= 60 else 'n' if v >= 40 else 'r'}' style='width:{v}%'></i></div>"
                   f"<b>{v}</b><small>{e(det)}</small></div>" for lb, v, det in sc["parts"])
    return (f"<div class='card gscore'><div class='gs-top'><div class='gs-big {cls}'><b>{t if t is not None else '–'}</b><small>nota {gr}</small></div>"
            f"<div><b class='gl'>Nota da partida</b><p class='n'>De 0 a 100 pela sua rota: rota, farm, visão e lutas. "
            f"<span class='tag regra'>regra geral</span> os alvos por rota são do app, não da Riot.</p></div></div>{rows}</div>")


SCORE_CSS = """
.gscore .gs-top{display:flex;gap:16px;align-items:center;margin-bottom:10px}
.gs-big{min-width:92px;height:92px;border-radius:20px;display:flex;flex-direction:column;align-items:center;justify-content:center;border:2px solid var(--rule);background:#150F0F}
.gs-big b{font:800 40px var(--d,var(--head));line-height:1;color:#fff}.gs-big small{font:700 11px var(--mono);letter-spacing:.12em;color:var(--mute);text-transform:uppercase}
.gs-big.g{border-color:#6BBF8A}.gs-big.g b{color:#8FD4A8}.gs-big.r{border-color:#D9534F}.gs-big.r b{color:#E8817C}
.gs-r{display:grid;grid-template-columns:70px minmax(80px,1fr) 34px minmax(0,1.4fr);gap:10px;align-items:center;padding:5px 0;font-size:13px}
.gs-r span{font:700 13px var(--head);color:#fff}.gs-r b{font:700 14px var(--head);color:#fff;text-align:right}.gs-r small{color:var(--mute)}
.gs-b{height:8px;border-radius:99px;background:#261C1B;overflow:hidden}.gs-b i{display:block;height:100%;border-radius:99px}
.gs-b i.g{background:#6BBF8A}.gs-b i.n{background:#E9C46A}.gs-b i.r{background:#D9534F}
.gchip{display:inline-flex;align-items:center;justify-content:center;min-width:34px;padding:2px 7px;border-radius:8px;font:800 12px var(--head);background:#261C1B;color:#D6CCC0}
.gchip.g{background:rgba(107,191,138,.16);color:#8FD4A8}.gchip.r{background:rgba(217,83,79,.14);color:#E8817C}
.dmap{display:grid;grid-template-columns:minmax(0,420px) minmax(0,1fr);gap:16px;align-items:start}
.dmap .mm{position:relative;aspect-ratio:1;border-radius:14px;overflow:hidden;background-size:cover;border:1px solid var(--rule)}
.dmap .mm i{position:absolute;transform:translate(-50%,-50%);width:24px;height:24px;border-radius:50%;background:#C1121F;color:#fff;font:800 12px var(--head);font-style:normal;
display:flex;align-items:center;justify-content:center;box-shadow:0 0 0 3px rgba(0,0,0,.55),0 0 14px rgba(255,77,77,.7)}
.dmap .mm i.early{background:#ff9a5a;box-shadow:0 0 0 3px rgba(0,0,0,.55),0 0 14px rgba(255,154,90,.7)}
.dmap ol{margin:0;padding:0;list-style:none;display:flex;flex-direction:column;gap:8px}
.dmap li{display:grid;grid-template-columns:30px minmax(0,1fr);gap:10px;align-items:start;padding:8px 10px;border:1px solid var(--rule);border-radius:12px;background:rgba(16,11,11,.4)}
.dmap li>b{width:26px;height:26px;border-radius:50%;background:#C1121F;color:#fff;display:flex;align-items:center;justify-content:center;font:800 12px var(--head)}
.dmap li.early>b{background:#ff9a5a}.dmap li p{margin:0;font-size:13px;color:#D6CCC0}.dmap li p strong{color:#fff}
.dmap li .rp{margin-top:6px}
@media (max-width:1000px){.dmap{grid-template-columns:1fr}}
.mist{display:flex;flex-direction:column;gap:12px}
.mi{text-align:left;border:1px solid var(--rule);border-radius:14px;padding:14px 16px;background:var(--panel);display:grid;grid-template-columns:64px minmax(0,1fr) 200px;gap:16px;align-items:center}
.mi .pct{font:800 30px var(--d,var(--head));color:#E8817C;text-align:center}.mi .pct small{display:block;font:600 11px var(--body);color:var(--mute)}
.mi h3{margin:0 0 4px;font:700 16px var(--head);color:#fff}.mi p{margin:2px 0;font-size:13px;color:#D6CCC0}
.mi .wr{font-size:12.5px;color:var(--mute)}.mi .wr b.w{color:#8FD4A8}.mi .wr b.l{color:#E8817C}
.mi .bar{height:8px;border-radius:99px;background:#261C1B;overflow:hidden;margin-top:6px}.mi .bar i{display:block;height:100%;background:#D9534F}
@media (max-width:900px){.mi{grid-template-columns:1fr}}
"""


def death_list(con, mid, my_pid, my_team, position):
    """Suas mortes com posicao, minuto, quem matou e a regiao do mapa."""
    parts = {r["participant_id"]: dict(r) for r in con.execute("SELECT * FROM participants WHERE match_id=?", (mid,))}
    out = []
    for r in con.execute("SELECT t_ms, killer_id, x, y FROM deaths WHERE match_id=? AND victim_id=? ORDER BY t_ms", (mid, my_pid)):
        k = parts.get(r["killer_id"])
        out.append({"t": r["t_ms"], "x": r["x"], "y": r["y"], "killer": k["champion"] if k else None,
                    "killer_pos": k["position"] if k else None, "zone": review.zone(r["x"], r["y"]),
                    "enemy_half": _enemy_half(r["x"], r["y"], my_team)})
    return out


def _enemy_half(x, y, team):
    if x is None or y is None:
        return False
    s = x + y
    return s > 16800 if team == 100 else s < 12900


def deaths_map_html(con, mid, my_pid, my_team, position, map_img, can_replay=True):
    ds = death_list(con, mid, my_pid, my_team, position)
    if not ds:
        return "<p class='n'>Nenhuma morte nesta partida (ou sem timeline).</p>"
    dots, rows = [], []
    for i, d in enumerate(ds, 1):
        mm = f"{d['t'] // 60000}:{(d['t'] // 1000) % 60:02d}"
        early = " early" if d["t"] < 600000 else ""
        if d["x"] is not None:
            dots.append(f"<i class='{early.strip()}' style='left:{100 * d['x'] / MAP_MAX:.1f}%;top:{100 - 100 * d['y'] / MAP_MAX:.1f}%' title='{e(mm)}'>{i}</i>")
        who = f"por {e(d['killer'])}" + (f" ({e(LANE.get(d['killer_pos'], d['killer_pos']))})" if d["killer_pos"] else "") if d["killer"] else "por torre, minion ou monstro"
        flags = []
        if d["t"] < 600000:
            flags.append("antes dos 10 min")
        if d["killer_pos"] == "JUNGLE" and position != "JUNGLE":
            flags.append("pelo caçador")
        if d["enemy_half"]:
            flags.append("no lado inimigo do mapa")
        rp = (f"<form method='post' action='/partida/{e(mid)}/replay' class='rp'><input type='hidden' name='t' value='{d['t']}'>"
              f"<button class='btn' style='padding:4px 10px;font-size:12px'>Ver no replay ({mm})</button></form>") if can_replay else ""
        rows.append(f"<li class='{early.strip()}'><b>{i}</b><div><p><strong>{e(mm)}</strong> · {who} · {e(d['zone'])}</p>"
                    + (f"<p class='n'>{e(', '.join(flags))}</p>" if flags else "") + rp + "</div></li>")
    return (f"<div class='dmap'><div class='mm' style=\"background-image:url('{map_img}')\">{''.join(dots)}</div><ol>{''.join(rows)}</ol></div>"
            "<p class='n'><span class='tag dado'>dado</span> laranja = antes dos 10 min. A região é aproximada (hipótese).</p>")


LANE = {"TOP": "topo", "JUNGLE": "selva", "MIDDLE": "meio", "BOTTOM": "atirador", "UTILITY": "suporte"}


def _wr(gs):
    return round(100 * sum(1 for g in gs if g["win"]) / len(gs)) if gs else None


def game_flags(con, g):
    """Erros de uma partida (as mesmas regras de common_mistakes)."""
    flags = set()
    if (g.get("deaths_before_10") or 0) >= 1:
        flags.add("d10")
    if g.get("csdiff10") is not None and g["csdiff10"] <= -10 and g.get("position") != "UTILITY":
        flags.add("cs")
    if g.get("vision_per_min") is not None and g["vision_per_min"] < TARGETS.get(g.get("position"), TARGETS["MIDDLE"])[1] * 0.6:
        flags.add("vis")
    if (g.get("deaths") or 0) >= 8:
        flags.add("many")
    try:
        pid, team = g["participant_id"], g["team_id"]
        try:            # mortes marcadas como "azar" na pagina da partida nao contam como erro
            azar = {r[0] for r in con.execute("SELECT t_ms FROM death_tags WHERE match_id=? AND tag='azar'", (g["match_id"],))}
        except Exception:
            azar = set()
        for d in death_list(con, g["match_id"], pid, team, g.get("position")):
            if d["t"] in azar:
                continue
            if d["killer_pos"] == "JUNGLE" and g.get("position") != "JUNGLE" and d["t"] < 900000:
                flags.add("jg")
            if d["enemy_half"] and d["t"] < 1200000:
                flags.add("deep")
        ahead = con.execute(
            """SELECT COUNT(*) FROM deaths d JOIN frames f ON f.match_id=d.match_id AND f.participant_id=d.victim_id AND f.minute=d.t_ms/60000
               JOIN frames o ON o.match_id=d.match_id AND o.participant_id=? AND o.minute=d.t_ms/60000
               WHERE d.match_id=? AND d.victim_id=? AND f.gold - o.gold >= 700""", (g.get("opp_id") or -1, g["match_id"], pid)).fetchone()[0]
        if ahead:
            flags.add("ahead")
    except Exception:
        pass
    return flags


def common_mistakes(con, puuid, games):
    """Erros que mais se repetem nas suas partidas (dado) e quanto cada um pesa na vitoria."""
    if not games:
        return []
    pos_main = max({g.get("position") for g in games}, key=lambda p: sum(1 for g in games if g.get("position") == p))
    t_cs, t_vis, _ = TARGETS.get(pos_main, TARGETS["MIDDLE"])
    per = {g["match_id"]: game_flags(con, g) for g in games}
    INFO = {
        "d10": ("Morrer antes dos 10 minutos", "Perder a rota cedo dá ouro e tempo para o oponente.", "Nos primeiros 10 min, só troque quando o oponente gastar a habilidade principal e saiba onde está o jungler inimigo."),
        "jg": ("Morrer para o jungler inimigo", "Ganks que pegam você antes dos 15 min.", "Coloque sentinela no rio a cada volta à base e jogue para trás quando o jungler inimigo some do mapa."),
        "deep": ("Morrer avançado no lado inimigo", "Mortes do outro lado do rio, longe da sua torre.", "Só avance no lado inimigo com visão e sabendo onde estão os inimigos que sumiram do mapa."),
        "cs": ("Ficar atrás no farm aos 10", "10 ou mais de farm a menos que o oponente.", "Pratique o último golpe e não deixe a onda morrer na torre enquanto você troca."),
        "vis": ("Visão baixa", f"Pontuação de visão bem abaixo do alvo da rota ({t_vis:g} por minuto).", "Compre Sentinela de Controle em toda volta à base e use o amuleto sempre que estiver pronto."),
        "many": ("Morrer 8 vezes ou mais", "Partidas com muitas mortes.", "Depois de 2 mortes, jogue seguro até o próximo item ou objetivo."),
        "ahead": ("Morrer com vantagem", "Mortes quando você estava 700+ de ouro à frente do oponente.", "Com vantagem, transforme em torre ou objetivo antes de procurar mais abates."),
    }
    out = []
    n = len(games)
    for k, (title, desc, fix) in INFO.items():
        withg = [g for g in games if k in per.get(g["match_id"], ())]
        if len(withg) < 2:
            continue
        without = [g for g in games if k not in per.get(g["match_id"], ())]
        out.append({"k": k, "title": title, "desc": desc, "fix": fix, "count": len(withg), "n": n,
                    "pct": round(100 * len(withg) / n), "wr_with": _wr(withg), "wr_without": _wr(without),
                    "impact": ((_wr(without) or 0) - (_wr(withg) or 0)) if without else 0})
    out = [x for x in out if x["impact"] > 0] or out
    out.sort(key=lambda x: -(x["pct"] * max(1, x["impact"] + 10)))
    return out


def mistakes_html(items, n):
    if not items:
        return "<div class='empty'><b>Sem padrões de erro ainda</b><span>Precisa de mais partidas com linha do tempo (sincronize).</span></div>"
    out = f"<p class='n'>Nas suas últimas {n} partidas. Ordem: o que mais acontece e mais pesa na vitória.</p><div class='mist'>"
    for it in items:
        wr = ""
        if it["wr_with"] is not None and it["wr_without"] is not None:
            wr = (f"<p class='wr'>Quando acontece, você vence <b class='l'>{it['wr_with']}%</b>; quando não acontece, <b class='w'>{it['wr_without']}%</b>.</p>")
        out += (f"<div class='mi'><div class='pct'>{it['pct']}%<small>{it['count']} de {it['n']} jogos</small></div>"
                f"<div><h3>{e(it['title'])}</h3><p>{e(it['desc'])}</p>{wr}</div>"
                f"<div><span class='tag regra'>regra geral</span><p>{e(it['fix'])}</p></div></div>")
    return out + "</div>"


def spoken_summary(snap):
    """Resumo falado no fim da partida, a partir do ultimo retrato do placar (so dado publico do jogo)."""
    if not snap:
        return None
    k, d, a = snap.get("k", 0), snap.get("d", 0), snap.get("a", 0)
    cs, mins = snap.get("cs", 0), max(1.0, snap.get("gt", 0) / 60)
    res = snap.get("result")
    head = "Vitória!" if res == "Win" else "Derrota." if res == "Lose" else "Fim de partida."
    parts = [f"{head} Você fez {k}, {d}, {a}", f"{cs} de farm, {cs / mins:.1f} por minuto"]
    if snap.get("avg_cspm"):
        diff = cs / mins - snap["avg_cspm"]
        parts[-1] += f", {'acima' if diff >= 0 else 'abaixo'} da sua média de {snap['avg_cspm']:.1f}"
    d10 = snap.get("d10", 0)
    if d10 >= 2:
        focus = f"Para a próxima: foram {d10} mortes antes dos 10 minutos, segure mais o começo."
    elif snap.get("ward", 0) < mins * 0.5:
        focus = "Para a próxima: coloque mais sentinelas, a visão ficou baixa."
    elif snap.get("avg_cspm") and cs / mins < snap["avg_cspm"] - 1:
        focus = "Para a próxima: cuide do farm, ficou abaixo do seu normal."
    elif d >= 8:
        focus = "Para a próxima: depois de duas mortes, jogue seguro até o próximo item."
    else:
        focus = "Bom jogo. Abra o pós-jogo no app para ver onde dá para melhorar."
    return ". ".join(parts) + ". " + focus
