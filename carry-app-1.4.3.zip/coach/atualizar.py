"""Atualizacao automatica do Carry.

O site publica versao.json (versao, endereco do pacote .zip, sha256 e notas). O app confere fora de partida, mostra
"Atualizacao disponivel" e, quando a pessoa clica, baixa o pacote, confere o sha256, guarda uma copia da versao atual
e troca SO os arquivos do app (coach/*.py, coach/static, o lancador e o icone). Dados, chaves e configuracoes nunca
sao tocados. Depois o vigia de arquivos do app reinicia sozinho (e nunca no meio de uma partida).
"""
import hashlib
import io
import json
import os
import shutil
import threading
import time
import urllib.request
import zipfile

URL = os.environ.get("CARRY_UPDATE_URL", "https://enuria-finance.github.io/carry/versao.json")
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PERMITIDOS = ("coach/", "LoL Coach.pyw", "carry.ico", "VERSAO.txt", "NOVIDADES.json", "Carry.exe")
STATE = {"checked": 0, "info": None, "err": None, "busy": False, "msg": None}
_LOCK = threading.Lock()


def atual():
    try:
        with open(os.path.join(RAIZ, "VERSAO.txt"), encoding="utf-8") as fh:
            return fh.read().strip() or "0.0.0"
    except OSError:
        return "0.0.0"


def _v(s):
    out = []
    for p in str(s or "0").split("."):
        try:
            out.append(int("".join(ch for ch in p if ch.isdigit()) or 0))
        except ValueError:
            out.append(0)
    return tuple(out + [0] * (3 - len(out)))


def checar(force=False):
    """Busca versao.json (no maximo 1x por hora). Devolve o dict da versao nova ou None."""
    with _LOCK:
        if not force and time.time() - STATE["checked"] < 3600:
            return STATE["info"]
        STATE["checked"] = time.time()
    try:
        req = urllib.request.Request(URL + f"?t={int(time.time())}", headers={"User-Agent": "Carry-app"})
        with urllib.request.urlopen(req, timeout=8) as r:
            info = json.loads(r.read().decode("utf-8"))
        nova = info if _v(info.get("versao")) > _v(atual()) and info.get("zip") and info.get("sha256") else None
        STATE.update(info=nova, err=None)
        return nova
    except Exception as ex:
        STATE.update(err=str(ex)[:120])
        return STATE["info"]


def checar_em_fundo():
    threading.Thread(target=checar, daemon=True).start()


def _seguro(nome):
    n = nome.replace("\\", "/")
    if n.startswith("/") or ".." in n.split("/"):
        return False
    return n.startswith(PERMITIDOS[0]) or n in PERMITIDOS[1:]


def aplicar(info=None, log=print):
    """Baixa, confere e instala. Devolve (ok, mensagem)."""
    info = info or STATE.get("info") or checar(force=True)
    if not info:
        return False, "Você já está na versão mais nova."
    with _LOCK:
        if STATE["busy"]:
            return False, "A atualização já está em andamento."
        STATE["busy"] = True
    try:
        log(f"Baixando a versão {info['versao']}…")
        req = urllib.request.Request(info["zip"], headers={"User-Agent": "Carry-app"})
        with urllib.request.urlopen(req, timeout=120) as r:
            data = r.read()
        if hashlib.sha256(data).hexdigest().lower() != str(info["sha256"]).lower():
            return False, "O arquivo baixado não confere (sha256). Nada foi trocado: tente de novo mais tarde."
        z = zipfile.ZipFile(io.BytesIO(data))
        nomes = [n for n in z.namelist() if not n.endswith("/")]
        if not nomes or not all(_seguro(n) for n in nomes):
            return False, "O pacote tem arquivos fora do esperado. Nada foi trocado."
        bk = os.path.join(RAIZ, "cache", f"backup_{atual()}")
        shutil.rmtree(bk, ignore_errors=True)
        os.makedirs(bk, exist_ok=True)
        if os.path.isdir(os.path.join(RAIZ, "coach")):
            shutil.copytree(os.path.join(RAIZ, "coach"), os.path.join(bk, "coach"),
                            ignore=shutil.ignore_patterns("__pycache__"))
        for f in PERMITIDOS[1:]:
            if os.path.exists(os.path.join(RAIZ, f)):
                shutil.copy2(os.path.join(RAIZ, f), bk)
        log("Instalando…")
        # o lancador e o icone primeiro; os .py do app por ultimo (o vigia reinicia quando eles mudam)
        for n in sorted(nomes, key=lambda x: (x.startswith("coach/") and x.endswith(".py"), x)):
            dest = os.path.join(RAIZ, *n.split("/"))
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            tmp = dest + ".novo"
            with z.open(n) as src, open(tmp, "wb") as out:
                shutil.copyfileobj(src, out)
            os.replace(tmp, dest)
        STATE.update(info=None, msg=f"Atualizado para a versão {info['versao']}. O app reinicia sozinho em alguns segundos.")
        return True, STATE["msg"]
    except Exception as ex:
        return False, f"Não deu para atualizar agora ({str(ex)[:100]}). Nada foi perdido."
    finally:
        STATE["busy"] = False


def banner_html(e):
    """Faixa no topo das paginas quando tem versao nova."""
    info = STATE.get("info")
    if not info:
        return ""
    notas = "".join(f"<li>{e(n)}</li>" for n in (info.get("notas") or [])[:5])
    return ("<div class='updbar' style='display:flex;gap:12px;align-items:center;flex-wrap:wrap;border:1px solid rgba(233,196,106,.45);"
            "background:rgba(233,196,106,.08);border-radius:12px;padding:10px 14px;margin:0 0 14px'>"
            f"<b>Atualização disponível: versão {e(info.get('versao'))}</b>"
            + (f"<details style='flex:1'><summary class='n' style='cursor:pointer'>O que mudou</summary><ul>{notas}</ul></details>" if notas else "<span style='flex:1'></span>")
            + "<form method='post' action='/atualizar'><button class='btn gold' style='width:auto'>Atualizar agora</button></form></div>")


VISTA = os.path.join(RAIZ, "cache", "novidades_vista.txt")


def novidades_html(e):
    """Uma vez depois de cada versao nova: o que mudou (de NOVIDADES.json, que vem no pacote)."""
    v = atual()
    try:
        if open(VISTA).read().strip() == v:
            return ""
    except OSError:
        pass
    try:
        with open(os.path.join(RAIZ, "NOVIDADES.json"), encoding="utf-8") as fh:
            d = json.load(fh)
    except Exception:
        return ""
    if str(d.get("versao")) != v or not d.get("notas"):
        return ""
    itens = "".join(f"<li>{e(n)}</li>" for n in d["notas"][:12])
    return ("<div class='card verdict' style='margin-bottom:14px'><b class='gl'>Novidades da versão " + e(v) + "</b>"
            f"<ul style='margin:8px 0'>{itens}</ul><form method='post' action='/novidades/ok'><button class='btn' style='width:auto'>Entendi</button></form></div>")


def novidades_ok():
    try:
        os.makedirs(os.path.dirname(VISTA), exist_ok=True)
        with open(VISTA, "w") as fh:
            fh.write(atual())
    except OSError:
        pass
