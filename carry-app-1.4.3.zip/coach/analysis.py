"""Analise da partida pela IA: le os fatos do pos-jogo (mortes com minuto e quem matou, farm, ouro, visao, objetivos)
e escreve o "#1 foco da proxima partida" e a "nota do coach". Guarda no banco do usuario (uma vez por partida)."""
import html
import json
import re
import time
import urllib.error
import urllib.request

from . import postgame, review

API = "https://api.anthropic.com/v1/messages"
e = lambda x: html.escape("" if x is None else str(x))

SYSTEM = """Você é o melhor coach de League of Legends do mundo, do nível de quem treina times campeões mundiais, revisando o VOD de uma partida solo de um aluno que quer subir de elo.
Seu estilo: direto, específico e acionável. Você cita minutos, campeões e números. Explica a CAUSA (por que aconteceu, o que o jogador provavelmente não viu ou não pensou),
não só o sintoma. Distingue erro de decisão (macro) de erro de execução (micro). Reconhece acertos de verdade. Prioriza o que mais faz subir de elo.
Regras: use SÓ os fatos enviados (vieram da linha do tempo oficial da Riot: uma foto de posição por minuto, abates, objetivos, sentinelas). Quando deduzir algo que os fatos não mostram, diga "provavelmente".
Nunca invente minutos, campeões ou eventos. Português do Brasil, sem emojis."""

PROMPT = """Fatos da partida:
{facts}

Responda APENAS com um JSON válido neste formato:
{{
 "veredito": "1 frase forte: por que a partida terminou assim",
 "resumo": "2-3 frases: a história da partida",
 "fase_rotas": "1 parágrafo: como foi a rota contra o oponente, o que decidiu, o que um jogador de elo alto faria",
 "meio_e_fim": "1 parágrafo: lutas, objetivos, conversão de vantagem ou virada, posicionamento no mapa",
 "erros": [{{"minuto": "m:ss", "titulo": "nome curto do erro", "o_que_aconteceu": "causa provável", "o_certo": "o que fazer no lugar, concreto"}}],
 "acertos": [{{"minuto": "m:ss", "titulo": "nome curto", "por_que": "por que foi bom e como repetir"}}],
 "treino": ["3 exercícios concretos para as próximas partidas"],
 "foco": "1 frase: a única coisa para a próxima partida",
 "nota": ["mesmo conteúdo do resumo em 1-2 parágrafos (compatibilidade)"],
 "bom": ["títulos dos acertos"],
 "melhorar": ["títulos dos erros"]
}}
Traga de 3 a 4 erros (os que mais custaram) e 2 a 3 acertos."""


def _ensure(con):
    con.execute("CREATE TABLE IF NOT EXISTS match_ai (match_id TEXT PRIMARY KEY, data TEXT, created_ms INTEGER)")


def get(con, mid):
    _ensure(con)
    r = con.execute("SELECT data FROM match_ai WHERE match_id=?", (mid,)).fetchone()
    return json.loads(r[0]) if r else None


def facts(con, puuid, mid):
    try:
        from . import coachreport
        R = coachreport.build(con, puuid, mid)
        if R:
            txt = coachreport.dossier_text(R)
            ans = review.answers(con, mid)
            said = [f"- Aos {int(t // 60000)}:{int(t // 1000 % 60):02d} o jogador disse: {a['thought']}" for (t, _k), a in sorted(ans.items()) if a.get("thought")]
            if said:
                txt += "\nO que o próprio jogador escreveu na revisão:\n" + "\n".join(said)
            return txt
    except Exception:
        pass
    pg = postgame.build(con, puuid, mid)
    if not pg:
        return None
    lines = [t["text"] for t in pg["summary"]]
    lines += ["Foi bem: " + t["text"] for t in pg["well"]]
    for m in review.moments(con, puuid, mid):
        mm = int(m["t_ms"] // 60000)
        ss = int(m["t_ms"] // 1000 % 60)
        lines.append(f"Momento {mm}:{ss:02d} ({m['kind']}): {m['title']} — " + " ".join(f["text"] for f in m["facts"]))
    if pg.get("focus"):
        lines.append("Meta do jogo: " + pg["focus"]["text"])
    return "\n".join(f"- {l}" for l in lines)


def generate(con, puuid, mid, key, model):
    f = facts(con, puuid, mid)
    if not f:
        raise RuntimeError("Partida não encontrada.")
    from . import ai
    body = {"model": model, "max_tokens": 3000, "system": SYSTEM, "messages": [{"role": "user", "content": PROMPT.format(facts=f)}]}
    try:
        res = ai.post(key, body, 180)
    except urllib.error.HTTPError as ex:
        detail = ex.read().decode("utf-8", "replace").lower()
        if "credit" in detail or "saldo" in detail:
            raise RuntimeError("A conta da Anthropic está sem crédito: compre em platform.claude.com, em Settings > Billing.")
        raise RuntimeError(f"Serviço de IA respondeu {ex.code}.")
    text = "".join(b.get("text", "") for b in res.get("content") or [] if b.get("type") == "text")
    m = re.search(r"\{.*\}", text, re.S)
    data = json.loads(m.group(0)) if m else None
    if not isinstance(data, dict) or not data.get("foco"):
        raise RuntimeError("A IA respondeu fora do formato; tente de novo.")
    _ensure(con)
    con.execute("INSERT OR REPLACE INTO match_ai VALUES (?,?,?)", (mid, json.dumps(data, ensure_ascii=False), int(time.time() * 1000)))
    con.commit()
    return data


def full_html(data):
    """Analise completa (formato novo)."""
    li = lambda xs: "".join(f"<li>{e(x)}</li>" for x in (xs or []))
    out = f"<div class='cr-ai'><h3>Análise do Coach IA</h3><p><b>{e(data.get('veredito'))}</b></p><p>{e(data.get('resumo'))}</p>"
    if data.get("fase_rotas"):
        out += f"<h4>Fase de rotas</h4><p>{e(data['fase_rotas'])}</p>"
    if data.get("meio_e_fim"):
        out += f"<h4>Meio e fim de jogo</h4><p>{e(data['meio_e_fim'])}</p>"
    if data.get("erros"):
        out += "<h4>Os erros que mais custaram</h4>" + "".join(
            f"<div class='er'><b>{e(x.get('minuto'))} · {e(x.get('titulo'))}</b><p>{e(x.get('o_que_aconteceu'))}</p><p><b>O certo:</b> {e(x.get('o_certo'))}</p></div>" for x in data["erros"])
    if data.get("acertos"):
        out += "<h4>O que você fez bem</h4>" + "".join(
            f"<div class='ok'><b>{e(x.get('minuto'))} · {e(x.get('titulo'))}</b><p>{e(x.get('por_que'))}</p></div>" for x in data["acertos"])
    if data.get("treino"):
        out += f"<h4>Treino para as próximas partidas</h4><ol>{li(data['treino'])}</ol>"
    if data.get("foco"):
        out += f"<h4>Foco da próxima partida</h4><p><b>{e(data['foco'])}</b></p>"
    return out + "<p class='n'><span class='tag hipotese'>análise por IA</span> feita com a linha do tempo oficial da partida e as suas respostas. Confira no replay.</p></div>"


def block(data, state, mid):
    if data and data.get("veredito"):
        return full_html(data)
    if data:
        nota = "".join(f"<p>{e(p)}</p>" for p in (data.get("nota") or []))
        li = lambda xs: "".join(f"<li>{e(x)}</li>" for x in (xs or []))
        return (f"<section class='aian'><div class='aian-f'><span class='aian-i'>#1</span><div><small>Foco para a próxima partida</small>"
                f"<p>{e(data.get('foco'))}</p></div></div><div class='aian-n'><b class='gl'>Nota do coach</b>{nota}</div>"
                f"<div class='grid2'><div><b class='gl'>Foi bem</b><ul class='tipl good'>{li(data.get('bom'))}</ul></div>"
                f"<div><b class='gl'>Ajustar</b><ul class='tipl bad'>{li(data.get('melhorar'))}</ul></div></div>"
                "<p class='n'><span class='tag hipotese'>análise por IA</span> feita com os dados desta partida. Confira no replay.</p></section>")
    if state == "gerando":
        return "<div class='aiban'><span class='spin'></span>O coach está analisando a partida… a página atualiza sozinha.</div>"
    if state == "sem_chave":
        return ""
    return (f"<form method='post' action='/partida/{e(mid)}/analisar' class='aian-cta'><div><b>Analisar esta partida com o Coach IA</b>"
            "<span>Foco para a próxima partida e uma nota do coach sobre o que aconteceu, com os minutos de cada lance.</span></div>"
            "<button class='btn gold'>Analisar partida</button></form>")


CSS = """
.aian{border:1px solid rgba(200,170,110,.45);padding:20px 22px;margin:0 0 18px;background:radial-gradient(120% 140% at 0% 0%,rgba(200,170,110,.10),transparent 50%),var(--panel)}
.aian-f{display:grid;grid-template-columns:auto minmax(0,1fr);gap:14px;align-items:start;padding:0 0 14px;border-bottom:1px solid var(--rule)}
.aian-i{width:44px;height:44px;display:flex;align-items:center;justify-content:center;font:800 16px var(--head);color:#1a1405;background:linear-gradient(180deg,#e2c792,#b8923f)}
.aian-f small{color:var(--gold);font:600 13px var(--head)}.aian-f p{margin:4px 0 0;font:600 17px/1.5 var(--body);color:#fff}
.aian-n{padding:12px 0 6px 14px;margin:12px 0;border-left:2px solid var(--gold)}.aian-n p{margin:8px 0;color:#DDD3C7;line-height:1.65}
.aian-cta{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;padding:16px 18px;margin:0 0 18px;border:1px dashed rgba(200,170,110,.5);background:rgba(200,170,110,.04)}
.aian-cta b{display:block;font:700 16px var(--head);color:#fff}.aian-cta span{color:var(--mute);font-size:13.5px}
"""
