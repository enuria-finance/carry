"""Modo iniciante: um questionario define o nivel da pessoa, aulas curtas do basico e uma voz "professora" na partida
que explica cada passo (comprar, subir habilidade, voltar a base, farm, visao, objetivos). Tudo regra geral do jogo.
"""
import html
import json

e = lambda s: html.escape("" if s is None else str(s), quote=True)

QUESTIONS = [
    ("tempo", "Há quanto tempo você joga League of Legends?",
     ["Nunca joguei ou comecei agora", "Menos de 1 mês", "De 1 a 6 meses", "De 6 meses a 2 anos", "Mais de 2 anos"]),
    ("elo", "Qual o seu elo na ranqueada?", ["Ainda não jogo ranqueada", "Ferro ou Bronze", "Prata ou Ouro", "Platina ou Esmeralda", "Diamante ou mais"]),
    ("farm", "Você sabe o que é dar o último golpe (farm)?",
     ["Não sei o que é", "Já ouvi falar", "Sei, mas erro bastante", "Sei e faço bem", "Faço bem e controlo a onda (congelar, empurrar)"]),
    ("base", "Quando você volta à base?",
     ["Só quando morro", "Quando a vida está baixa", "Quando tenho ouro para um item", "Com ouro e com a onda empurrada", "Planejo para não perder ondas nem objetivos"]),
    ("visao", "O que você faz com sentinelas?",
     ["Não sei o que são", "Quase não uso", "Uso o amuleto às vezes", "Uso sempre e compro de controle", "Coloco visão pensando no objetivo seguinte"]),
    ("mapa", "Com que frequência você olha o minimapa?", ["Quase nunca", "Quando lembro", "Às vezes", "A cada poucos segundos", "Sempre, e aviso o time"]),
    ("obj", "O que dá mais vantagem para o time?",
     ["Não sei", "Abates", "Torres", "Dragão, Arauto, larvas e Barão", "Depende do tempo da partida e do placar"]),
    ("rota", "Você sabe qual é o trabalho da sua rota?", ["Não sei quais são as rotas", "Sei as rotas, não o trabalho", "Mais ou menos", "Sei bem", "Sei e me adapto à partida"]),
]
LEVELS = [(0, "iniciante", "Iniciante", "Comece pelo básico: a voz da partida vai explicar cada passo."),
          (9, "basico", "Básico", "Você já sabe jogar: agora é farm, visão e voltar à base na hora certa."),
          (17, "intermediario", "Intermediário", "Foque em onda, mapa e objetivos. As aulas de macro são as suas."),
          (25, "avancado", "Avançado", "O básico está feito: use a revisão das partidas e o diagnóstico para os detalhes.")]

LESSONS = [
    ("objetivo", "O objetivo do jogo", "iniciante",
     "Duas equipes de 5. Ganha quem destruir o Nexus inimigo, a construção grande na base deles. Para chegar lá, é preciso derrubar torres e inibidores no caminho.",
     ["Abates ajudam, mas quem ganha é quem derruba estruturas", "Cada rota tem 3 torres antes do inibidor", "Jogar junto do time vale mais que jogar sozinho"],
     "Na próxima partida, conte quantas torres o seu time derrubou."),
    ("rotas", "As rotas e o trabalho de cada uma", "iniciante",
     "O mapa tem 3 rotas (topo, meio e baixo) e a selva entre elas. Topo: duelo. Meio: rota curta e central. Baixo: atirador e suporte juntos. Selva: anda pelo mapa e ajuda as rotas.",
     ["Escolha uma rota e fique nela até os 14 min", "Veja a página Rotas do app para o trabalho de cada uma"],
     "Jogue 3 partidas na mesma rota para aprender o ritmo dela."),
    ("farm", "Farm: o último golpe", "iniciante",
     "Os minions dão ouro só para quem dá o golpe final neles. Ouro compra itens, e itens deixam você forte. Farm é a principal fonte de ouro.",
     ["Ataque o minion quando a vida dele estiver quase no fim", "Meta para começar: 35 de farm aos 5 min e 60 aos 10", "Farm perdido é ouro perdido"],
     "Ferramenta de prática: 10 minutos só de último golpe, sem usar habilidades."),
    ("habilidades", "Habilidades e níveis", "iniciante",
     "Cada campeão tem 4 habilidades (Q, W, E e R). A cada nível você ganha um ponto para melhorar uma delas. A ultimate (R) libera no nível 6, e melhora no 11 e no 16.",
     ["Para usar o ponto: segure Ctrl e aperte a tecla da habilidade", "Em geral: maximize primeiro a habilidade principal do seu campeão", "Nível 6 muda o jogo: cuidado com a ultimate do oponente"],
     "Abra a página do seu campeão no app e veja a ordem de habilidades dos melhores."),
    ("loja", "Loja e itens", "iniciante",
     "A loja só funciona na base (tecla P). Comece com o item inicial e uma poção. Volte à base para gastar o ouro em componentes e depois no item completo.",
     ["Siga a build do app (aparece no overlay com o próximo item)", "Não guarde ouro: ouro no bolso não ajuda na luta", "Botas cedo ajudam a fugir e a perseguir"],
     "Na próxima partida, compre no máximo 1 minuto depois de chegar na base."),
    ("base", "Quando voltar à base", "basico",
     "Aperte B para voltar à base (8 segundos parado). A melhor hora: com ouro para um item e a onda empurrada para a torre inimiga, assim você perde pouco farm.",
     ["Vida baixa e nenhum lugar seguro: volte", "Não volte com a onda batendo na sua torre", "Volte antes de objetivos para comprar e voltar com vida cheia"],
     "Em cada volta à base, confira se a onda estava empurrada."),
    ("visao", "Visão e sentinelas", "basico",
     "O mato e a névoa escondem os inimigos. Sentinelas (tecla 4) mostram uma área do mapa por um tempo. Sentinela de Controle revela e desativa as do inimigo.",
     ["Coloque visão no rio para ver o caçador inimigo chegando", "Compre 1 Sentinela de Controle a cada volta à base", "Visão antes de objetivos ganha lutas"],
     "Meta: usar o amuleto toda vez que ele carregar."),
    ("mapa", "Olhar o minimapa", "basico",
     "O minimapa mostra onde estão os inimigos que alguém do seu time vê. Se o oponente sumiu da rota, ele pode estar indo atacar você ou outra rota.",
     ["Olhe o minimapa a cada 5 segundos", "Inimigo sumiu: recue para perto da torre", "Avise o time com sinal (Alt + clique)"],
     "Treino: toda vez que um minion morrer, olhe o minimapa."),
    ("objetivos", "Objetivos: dragão, larvas, Arauto e Barão", "intermediario",
     "Monstros grandes dão bônus para o time inteiro. Dragão (rio de baixo, a partir dos 5 min) dá bônus permanente. Larvas do Vazio (8 min) e Arauto (15 min) ajudam a derrubar torres. Barão (20 min) é o mais forte.",
     ["Chegue antes no rio com o time", "Não lute por objetivo com menos jogadores", "Se o inimigo pega um, pegue outro do outro lado do mapa"],
     "Na próxima partida, acompanhe o tempo do dragão no overlay e esteja perto 30 s antes."),
    ("onda", "Controle de onda", "intermediario",
     "As ondas de minions empurram para um lado ou outro. Empurrar deixa você livre para ajudar o time; congelar perto da sua torre deixa o inimigo vulnerável a ganks.",
     ["Empurre antes de voltar à base ou de ajudar o rio", "Congele quando estiver atrás ou com o caçador inimigo por perto", "Onda grande indo para a torre inimiga é hora boa de agir"],
     "Na prática, empurre uma onda inteira e conte quanto tempo você fica livre."),
    ("lutas", "Lutas em equipe", "intermediario",
     "Nas lutas, cada um tem um papel: a linha de frente segura, quem causa dano bate de trás, o suporte protege ou engaja. Morrer primeiro quase sempre perde a luta.",
     ["Conte os inimigos antes de entrar", "Atirador e mago: bata no alvo mais próximo com segurança", "Depois de ganhar uma luta, pegue um objetivo"],
     "Revise a sua última partida no app: em quantas lutas você foi o primeiro a morrer?"),
]


def score(answers):
    return sum(int(answers.get(k, 0)) for k, _, _ in QUESTIONS)


def level_of(total):
    lv = LEVELS[0]
    for th, key, nm, txt in LEVELS:
        if total >= th:
            lv = (th, key, nm, txt)
    return lv


def quiz_html():
    qs = ""
    for i, (k, q, opts) in enumerate(QUESTIONS, 1):
        qs += (f"<fieldset class='lq'><legend><span>{i}</span>{e(q)}</legend><div class='lq-o'>"
               + "".join(f"<label><input type='radio' name='{k}' value='{j}' required><span>{e(o)}</span></label>" for j, o in enumerate(opts))
               + "</div></fieldset>")
    return ("<section class='lh'><small>Antes de começar</small><div class='lh-t'>Qual é o seu nível no LoL?</div>"
            "<p class='lead'>8 perguntas rápidas. Com a resposta, o app escolhe as aulas certas e liga a voz que ensina durante a partida, se você for iniciante.</p></section>"
            f"<form method='post' action='/iniciante/nivel' class='lq-f'>{qs}<button class='btn gold'>Ver o meu nível</button></form>")


def page_html(level_key, total, done, voice_on):
    lv = next((l for l in LEVELS if l[1] == level_key), LEVELS[0])
    order = ["iniciante", "basico", "intermediario", "avancado"]
    mine = order.index(lv[1])
    cards = ""
    n_done = 0
    for k, title, lvl, text, points, practice in LESSONS:
        is_done = k in done
        n_done += is_done
        rec = order.index(lvl) >= mine and order.index(lvl) <= mine + 1
        cards += (f"<article class='ll{' done' if is_done else ''}{' rec' if rec and not is_done else ''}' id='a-{k}'>"
                  f"<header><span class='ll-lv'>{e(dict((l[1], l[2]) for l in LEVELS)[lvl])}</span>{'<span class=ll-rec>recomendada para você</span>' if rec and not is_done else ''}"
                  f"<h3>{e(title)}</h3></header><p>{e(text)}</p><ul>" + "".join(f"<li>{e(p)}</li>" for p in points) + "</ul>"
                  f"<p class='ll-pr'><b>Para praticar:</b> {e(practice)}</p>"
                  f"<form method='post' action='/iniciante/aula'><input type='hidden' name='k' value='{k}'><input type='hidden' name='v' value='{'0' if is_done else '1'}'>"
                  f"<button class='btn{' ghost' if is_done else ''}'>{'Feita (desmarcar)' if is_done else 'Marcar como feita'}</button></form></article>")
    pct = round(100 * n_done / len(LESSONS))
    head = (f"<section class='lh'><small>Seu nível</small><div class='lh-t'>{e(lv[2])}</div><p class='lead'>{e(lv[3])}</p>"
            f"<div class='lh-bar'><i style='width:{pct}%'></i></div><p class='n'>{n_done} de {len(LESSONS)} aulas feitas · pontuação do questionário: {total} de {len(QUESTIONS) * 4}</p>"
            "<div class='row' style='gap:10px;flex-wrap:wrap'>"
            f"<form method='post' action='/iniciante/voz'><input type='hidden' name='v' value='{'0' if voice_on else '1'}'>"
            f"<button class='btn {'gold' if not voice_on else ''}'>{'Desligar a voz professora' if voice_on else 'Ligar a voz professora na partida'}</button></form>"
            "<form method='post' action='/iniciante/refazer'><button class='btn ghost'>Refazer o questionário</button></form></div>"
            f"<p class='n'>{'A voz professora está ligada: na partida ela explica cada passo (comprar, subir habilidade, voltar à base, farm, visão, objetivos).' if voice_on else 'Com a voz professora ligada, o app explica cada passo durante a partida.'}</p></section>")
    return head + "<h2>Aulas</h2><div class='ll-grid'>" + cards + "</div>"


def live_cues(live_data, me, gt):
    """Voz professora: explica o que fazer agora, passo a passo (para quem marcou que e iniciante)."""
    al = []
    add = lambda k, t: al.append({"k": k, "t": t})
    act = live_data.get("activePlayer") or {}
    lvl = int(act.get("level") or me.get("level") or 1)
    gold = int(act.get("currentGold") or 0)
    stats = act.get("championStats") or {}
    sc = me.get("scores") or {}
    deaths = int(sc.get("deaths") or 0)
    if 3 <= gt < 70:
        add("nv_start", "Começou! Abra a loja com a tecla P, compre o item inicial e uma poção, e vá para a sua rota.")
    ab = act.get("abilities") or {}
    used = sum(int((ab.get(k) or {}).get("abilityLevel") or 0) for k in ("Q", "W", "E", "R"))
    if ab and lvl > used and gt > 20:
        add(f"nv_skill_{lvl}", "Você tem um ponto de habilidade sobrando: segure Ctrl e aperte Q, W, E ou R para melhorar uma habilidade.")
    if lvl >= 6:
        add("nv_r6", "Nível 6: a sua ultimate, a habilidade R, está liberada. Ela é a mais forte: use nas lutas e nas chances de abate.")
    if 58 <= gt < 90:
        add("nv_farm", "Os minions chegaram. Dê o último golpe, o ataque que mata o minion, para ganhar ouro.")
    if 115 <= gt < 145:
        add("nv_ward", "Dica de visão: aperte a tecla 4 para colocar uma sentinela no mato do rio. O caçador inimigo já pode aparecer a partir dos 2 minutos.")
    if 300 <= gt < 330:
        cs = int(sc.get("creepScore") or 0)
        add("nv_cs5", f"5 minutos: você tem {cs} de farm. Uma boa meta para começar é 35." + (" Muito bem!" if cs >= 35 else " Foque no último golpe."))
    if 270 <= gt < 290:
        add("nv_drag", "O dragão nasce aos 5 minutos no rio de baixo. Ele dá um bônus para o time inteiro.")
    if 120 <= gt < 600 and int(gt) % 90 < 12:
        add(f"nv_map_{int(gt // 90)}", "Olhe o minimapa no canto da tela. Se um inimigo sumiu, ele pode estar vindo atrás de você.")
    if not me.get("isDead") and gold >= 1100 and gt > 150:
        add(f"nv_gold_{deaths}_{gold // 1000}", f"Você tem {gold} de ouro. Quando a onda estiver longe da sua torre, aperte B para voltar à base e comprar.")
    hp, mhp = float(stats.get("currentHealth") or 0), float(stats.get("maxHealth") or 0)
    if mhp and hp / mhp < 0.3 and not me.get("isDead") and gt > 90:
        add(f"nv_hp_{int(gt // 45)}", "Vida baixa. Recue para perto da sua torre ou aperte B para voltar à base.")
    if me.get("isDead"):
        add(f"nv_dead_{deaths}", "Você morreu. Enquanto espera, abra a loja com P e compre o que der. Antes de avançar de novo, olhe o minimapa.")
    if 8 * 60 - 20 <= gt < 8 * 60:
        add("nv_grubs", "As Larvas do Vazio nascem aos 8 minutos no rio de cima. Elas ajudam o time a derrubar torres.")
    if 14 * 60 <= gt < 14 * 60 + 25:
        add("nv_14", "Acabou a fase de rotas. Agora o time se junta para pegar objetivos: ande com o time.")
    if 19 * 60 + 30 <= gt < 19 * 60 + 55:
        add("nv_baron", "O Barão nasce aos 20 minutos no rio de cima. É o objetivo mais forte: lute por ele com o time inteiro.")
    if gt >= 25 * 60 and int(gt) % 240 < 15:
        add(f"nv_late_{int(gt // 240)}", "Fim de jogo: não ande sozinho. Morrer agora demora muito para voltar e pode custar o Barão.")
    return al


CSS = """
.lh{padding:28px 30px;border-radius:22px;margin:0 0 20px;border:1px solid var(--rule);
background:radial-gradient(80% 150% at 100% 0%,color-mix(in srgb,var(--gold) 18%,transparent),transparent 55%),var(--panel)}
.lh small{font:700 11px var(--mono);letter-spacing:.2em;text-transform:uppercase;color:var(--mute)}
.lh-t{margin:6px 0;font:800 58px/.95 var(--d);color:var(--bone,#fff)}.lh .lead{font-size:17px;color:#DDD3C7;max-width:760px}
.lh-bar{height:8px;border-radius:99px;background:#261C1B;overflow:hidden;margin:14px 0 6px;max-width:520px}.lh-bar i{display:block;height:100%;background:linear-gradient(90deg,var(--gold),#6BBF8A)}
.lq-f{display:flex;flex-direction:column;gap:14px;max-width:900px}
.lq{border:1px solid var(--rule);border-radius:16px;padding:16px 18px;background:var(--panel);margin:0}
.lq legend{display:flex;align-items:center;gap:10px;font:700 16px var(--head);color:#fff;padding:0 6px}
.lq legend span{width:28px;height:28px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;background:var(--gold);color:#1a1405;font:800 13px var(--head)}
.lq-o{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:8px;margin-top:10px}
.lq-o label{display:block;cursor:pointer}.lq-o input{position:absolute;opacity:0}
.lq-o span{display:block;padding:10px 12px;border-radius:12px;border:1px solid var(--rule);background:rgba(16,11,11,.45);color:#DDD3C7;font-size:14px;transition:all .15s}
.lq-o input:checked+span{border-color:var(--gold);background:color-mix(in srgb,var(--gold) 14%,transparent);color:#fff;font-weight:600}
.lq-o label:hover span{border-color:color-mix(in srgb,var(--gold) 60%,var(--rule))}
.ll-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.ll{border:1px solid var(--rule);border-radius:18px;padding:18px 20px;background:var(--panel);position:relative}
.ll.rec{border-color:color-mix(in srgb,var(--gold) 55%,var(--rule));box-shadow:0 0 0 1px color-mix(in srgb,var(--gold) 20%,transparent)}
.ll.done{opacity:.6}.ll.done h3:after{content:" ✓";color:#6BBF8A}
.ll header{display:flex;flex-wrap:wrap;gap:8px;align-items:center}.ll h3{flex-basis:100%;margin:6px 0 4px;font:700 19px var(--head);color:#fff}
.ll-lv,.ll-rec{font:700 11px var(--head);padding:3px 9px;border-radius:999px;background:#2C2120;color:#D6CCC0}.ll-rec{background:color-mix(in srgb,var(--gold) 18%,transparent);color:var(--gold)}
.ll p{color:#DDD3C7;font-size:14.5px;line-height:1.6}.ll ul{margin:0 0 8px;padding-left:18px}.ll li{color:#D6CCC0;font-size:14px;margin:4px 0}
.ll-pr{border-left:3px solid #6BBF8A;padding-left:10px}.ll form{margin-top:8px}.ll .btn{width:auto !important}
@media (max-width:1000px){.ll-grid{grid-template-columns:1fr}}
"""
