"""Modo cacador: como os melhores jogam a selva com cada campeao (inicio, lado aos 3 min, ritmo de farm, primeiro abate e primeiro objetivo).

Tudo vem das partidas dos melhores guardadas pelo app (linha do tempo oficial da Riot, uma foto por minuto): e dado, com n.
A leitura de "lado" e "camp" a partir da posicao do minuto e aproximada (hipotese).
"""
import html
import json
import statistics
import time
from collections import Counter

e = lambda s: html.escape("" if s is None else str(s), quote=True)
MAPW = 14870
# acampamentos do lado azul (coordenadas do mapa); o lado vermelho e o espelho
CAMPS = {"Azul": (3800, 7900), "Gromp": (2200, 8400), "Lobos": (3800, 6500), "Aves": (7000, 5400), "Vermelho": (7800, 4000), "Krugs": (8400, 2700)}
_CACHE = {}


def _norm(x, y, team):
    if x is None or y is None:
        return None, None
    return (x, y) if team == 100 else (MAPW - x, MAPW - y)


def _near_camp(x, y):
    best, bd = None, 1e9
    for k, (cx, cy) in CAMPS.items():
        d = (x - cx) ** 2 + (y - cy) ** 2
        if d < bd:
            best, bd = k, d
    return best, bd ** 0.5


def _where(x, y):
    """Leitura aproximada da posicao (ja no ponto de vista do lado azul)."""
    if x is None:
        return None
    if x < 2600 and y < 2600:
        return "base"
    if abs(x + y - MAPW) < 1700:
        return "rio de cima" if y > x else "rio de baixo"
    if x > MAPW / 2 + 800 and y > MAPW / 2 + 800:
        return "selva inimiga"
    if x < 3200 and y > 9500 or y > 12500:
        return "rota de cima"
    if y < 3200 and x > 9500 or x > 12500:
        return "rota de baixo"
    if abs(x - y) < 1500 and 4000 < x < 11000:
        return "rota do meio"
    return "seu lado de cima (Azul)" if y > x else "seu lado de baixo (Vermelho)"


def summary_cached(champion):
    hit = _CACHE.get(champion)
    return hit[1] if hit else None


def summary(con, champion):
    """Resumo dos melhores com o campeao na selva. Cache de 30 min."""
    key = champion
    hit = _CACHE.get(key)
    if hit and time.time() - hit[0] < 1800:
        return hit[1]
    rows = con.execute(
        """SELECT p.match_id, p.participant_id, p.team_id, p.win FROM participants p JOIN match_source s USING (match_id)
           JOIN matches m USING (match_id) WHERE s.source='top' AND p.position='JUNGLE' AND p.champion=? AND m.has_timeline=1""",
        (champion,)).fetchall()
    general = False
    if len(rows) < 10:
        rows = con.execute(
            """SELECT p.match_id, p.participant_id, p.team_id, p.win FROM participants p JOIN match_source s USING (match_id)
               JOIN matches m USING (match_id) WHERE s.source='top' AND p.position='JUNGLE' AND m.has_timeline=1 LIMIT 300""").fetchall()
        general = True
    if not rows:
        _CACHE[key] = (time.time(), None)
        return None
    start, at3, cs3, cs4, lv4, gank_min, gank_where, first_obj = Counter(), Counter(), [], [], [], [], Counter(), Counter()
    for r in rows:
        mid, pid, team = r["match_id"], r["participant_id"], r["team_id"]
        fr = {f["minute"]: f for f in con.execute("SELECT minute, cs, x, y, level FROM frames WHERE match_id=? AND participant_id=? AND minute<=5",
                                                 (mid, pid))}
        if 1 in fr:
            x, y = _norm(fr[1]["x"], fr[1]["y"], team)
            if x is not None:
                da = (x - CAMPS["Azul"][0]) ** 2 + (y - CAMPS["Azul"][1]) ** 2
                dr = (x - CAMPS["Vermelho"][0]) ** 2 + (y - CAMPS["Vermelho"][1]) ** 2
                start["Azul" if da < dr else "Vermelho"] += 1
        if 3 in fr:
            x, y = _norm(fr[3]["x"], fr[3]["y"], team)
            w = _where(x, y)
            if w:
                at3[w] += 1
            cs3.append(fr[3]["cs"])
        if 4 in fr:
            cs4.append(fr[4]["cs"])
            lv4.append(fr[4]["level"])
        # primeiro abate com participacao do cacador (matou ou deu assistencia)
        for ev in con.execute("SELECT t_ms, x, y, data FROM events WHERE match_id=? AND type='CHAMPION_KILL' ORDER BY t_ms", (mid,)):
            d = json.loads(ev["data"] or "{}")
            if d.get("killer") == pid or pid in (d.get("assists") or []):
                gank_min.append(ev["t_ms"] / 60000)
                x, y = _norm(ev["x"], ev["y"], team)
                w = _where(x, y)
                if w:
                    gank_where[w.replace("seu lado de cima (Azul)", "selva").replace("seu lado de baixo (Vermelho)", "selva")] += 1
                break
        fo = con.execute("""SELECT data FROM events WHERE match_id=? AND type='ELITE_MONSTER_KILL' AND team_id=? ORDER BY t_ms LIMIT 1""",
                         (mid, team)).fetchone()
        if fo:
            mt = json.loads(fo["data"] or "{}").get("monsterType")
            first_obj[{"HORDE": "Larvas do Vazio", "DRAGON": "Dragão", "RIFTHERALD": "Arauto", "BARON_NASHOR": "Barão", "ATAKHAN": "Atakhan"}.get(mt, mt)] += 1
    n = len(rows)
    med = lambda v: statistics.median(v) if v else None
    out = {"n": n, "general": general, "champion": champion, "start": start.most_common(), "at3": at3.most_common(4),
           "cs3": med(cs3), "cs4": med(cs4), "lv4": med(lv4), "gank_min": med(gank_min), "gank_where": gank_where.most_common(3),
           "first_obj": first_obj.most_common(3), "wr": round(100 * sum(r["win"] for r in rows) / n)}
    _CACHE[key] = (time.time(), out)
    return out


def _em(w):
    return ("na " if w.startswith(("rota", "selva", "base")) else "no ") + w


def _pct(lst, n):
    return ", ".join(f"{k} {round(100 * v / n)}%" for k, v in lst)


def mmss(m):
    s = int(round(m * 60))
    return f"{s // 60}:{s % 60:02d}"


def spoken_route(sm, name):
    if not sm or not sm["start"]:
        return None
    s0 = sm["start"][0]
    txt = f"Selva com {name}: os melhores começam no {s0[0]} ({round(100 * s0[1] / sm['n'])}%)"
    if sm["at3"]:
        txt += f"; aos 3 minutos estão mais {_em(sm['at3'][0][0])}"
    if sm["gank_min"]:
        txt += f"; primeiro abate por volta de {mmss(sm['gank_min'])}"
        if sm["gank_where"]:
            txt += f", mais {_em(sm['gank_where'][0][0])}"
    if sm["first_obj"]:
        txt += f"; primeiro objetivo: {sm['first_obj'][0][0]}"
    return txt + "."


def page_html(sm, name, my_jg_games=None):
    if not sm:
        return ("<div class='empty'><b>Sem amostra de selva ainda</b><span>Em Sincronizar, baixe a amostra dos melhores com esse campeão.</span></div>")
    n = sm["n"]
    src = (f"{n} partidas dos melhores com {e(name)} na selva" if not sm["general"]
           else f"poucas partidas com {e(name)}: mostrando {n} partidas de todos os caçadores (hipótese para esse campeão)")
    def kv(lbl, val, sub):
        return f"<div class='kv4'><small>{e(lbl)}</small><b>{val}</b><span>{e(sub)}</span></div>"
    out = f"<p class='n'><span class='tag dado'>dado</span> {src}. Vitória da amostra: {sm['wr']}%.</p><div class='duel-g'>"
    out += kv("Começam no", e(sm["start"][0][0]) if sm["start"] else "–", _pct(sm["start"], n))
    out += kv("Farm aos 3 min", f"{sm['cs3']:.0f}" if sm["cs3"] is not None else "–", "mediana (ritmo da primeira volta)")
    out += kv("Farm aos 4 min", f"{sm['cs4']:.0f}" if sm["cs4"] is not None else "–", f"nível {sm['lv4']:.0f} aos 4 min" if sm["lv4"] else "")
    out += "</div><div class='duel-g' style='margin-top:14px'>"
    out += kv("Onde estão aos 3 min", e(sm["at3"][0][0]) if sm["at3"] else "–", _pct(sm["at3"], n))
    out += kv("Primeiro abate", mmss(sm["gank_min"]) if sm["gank_min"] else "–", ("mais: " + _pct(sm["gank_where"], n)) if sm["gank_where"] else "")
    out += kv("Primeiro objetivo", e(sm["first_obj"][0][0]) if sm["first_obj"] else "–", _pct(sm["first_obj"], n))
    out += "</div>"
    if my_jg_games:
        cs4 = [g for g in my_jg_games if g.get("cs4") is not None]
        if cs4 and sm["cs4"]:
            mine = statistics.median([g["cs4"] for g in cs4])
            diff = mine - sm["cs4"]
            out += (f"<div class='card' style='margin-top:14px'><b class='gl'>Você contra os melhores</b><p>Seu farm aos 4 min com {e(name)}: <b>{mine:.0f}</b> "
                    f"({'+' if diff >= 0 else ''}{diff:.0f} contra a mediana dos melhores). "
                    + ("Sua primeira volta está no ritmo." if diff >= -2 else "Sua primeira volta está mais lenta: treine a rota de acampamentos na prática.") + "</p></div>")
    out += ("<div class='card' style='margin-top:14px'><b class='gl'>Regras gerais da selva</b>"
            "<p class='n'><span class='tag regra'>regra geral</span> Comece do lado oposto de onde quer chegar aos 3 min (para ganhar ou pegar o caranguejo). "
            "Ganke a rota que tem nível 2 ou 3 antes do oponente ou com a onda indo para a sua torre. "
            "Larvas aos 8 min e dragão: chegue com a rota do lado com prioridade (onda empurrada). Olhe o placar: o caçador inimigo com farm alto está farmando, não gankando.</p></div>")
    return out


def live_cues(con, live_data, me, foes, pos, gt, my_cid):
    """Voz no jogo para quem joga de selva: rota dos melhores, caranguejo, rotas com vantagem e o farm do cacador inimigo (so placar)."""
    from . import liveview
    al = []
    add = lambda k, t, v=None: al.append({"k": k, "t": t, **({"v": v} if v else {})})
    if pos != "JUNGLE":
        return al
    if 10 <= gt < 45:          # acampamentos nascem aos 0:55 (2026): a rota vem antes
        sm = summary(con, my_cid)
        txt = spoken_route(sm, me.get("championName") or my_cid)
        if txt:
            add("jg_route", txt)
    if 158 <= gt < 172:
        add("jg_scuttle", f"Caranguejos nascem em {175 - int(gt)} segundos.")
    allies = [p for p in (live_data.get("allPlayers") or []) if p.get("team") == me.get("team") and p is not me]
    by_pos = {p.get("position"): p for p in foes}
    if 150 <= gt < 900 and int(gt) % 120 < 25:
        best, worst = None, None
        for a in allies:
            o = by_pos.get(a.get("position"))
            if not o or a.get("position") in ("JUNGLE", "", None):
                continue
            ka, ko = (a.get("scores") or {}), (o.get("scores") or {})
            adv = (int(a.get("level") or 0) - int(o.get("level") or 0)) * 2 + int(ka.get("kills") or 0) - int(ko.get("kills") or 0) \
                + int(ko.get("deaths") or 0) - int(ka.get("deaths") or 0)
            if best is None or adv > best[0]:
                best = (adv, a, o)
            if worst is None or adv < worst[0]:
                worst = (adv, a, o)
        LN = {"TOP": "topo", "MIDDLE": "meio", "BOTTOM": "rota de baixo", "UTILITY": "rota de baixo"}
        if best and best[0] >= 2:
            add(f"jg_best_{int(gt // 120)}", f"Rota com vantagem para gankar: {LN.get(best[1].get('position'), 'rota')} "
                f"({best[1].get('championName')} nível {best[1].get('level')} contra {best[2].get('championName')} nível {best[2].get('level')}).")
        if worst and worst[0] <= -3:
            add(f"jg_worst_{int(gt // 120)}", f"Rota em perigo: {LN.get(worst[1].get('position'), 'rota')}. "
                f"{worst[2].get('championName')} está forte; evite lutar lá sem visão.")
    ej = by_pos.get("JUNGLE")
    if ej:
        for m in (5, 10):
            if m * 60 <= gt < m * 60 + 30:
                ecs = int((ej.get("scores") or {}).get("creepScore") or 0)
                mcs = int((me.get("scores") or {}).get("creepScore") or 0)
                add(f"jg_farm_{m}", f"{m} minutos: você {mcs} de farm, o caçador inimigo {ecs}."
                    + (" Ele está farmando mais: procure invadir ou pegar objetivo do outro lado." if ecs >= mcs + 8 else ""))
    return al
