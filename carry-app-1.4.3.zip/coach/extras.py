"""Lote grande das 100 ideias: selecao, carregamento, partida, pos-jogo, evolucao, rotina e produto.
Tudo com dados que o app ja tem (suas partidas, a amostra do alto elo, Data Dragon e a partida ao vivo).
Cada funcao devolve frases prontas ou HTML; nada aqui chama a Riot (o que precisa da Riot fica no scout)."""
import html
import json
import os
import time
from collections import Counter, defaultdict

e = lambda x: html.escape("" if x is None else str(x))

# ---------------- classes e tempo de força (hipótese pelas classes do Data Dragon) ----------------
EARLY = {"Assassin": 1.0, "Fighter": 0.6, "Tank": 0.2, "Support": 0.2, "Mage": 0.0, "Marksman": -0.8}
ENGAGE = {"Leona", "Nautilus", "Alistar", "Rell", "Amumu", "Malphite", "Sejuani", "Zac", "Ornn", "JarvanIV", "Vi", "Rakan", "Thresh",
          "Blitzcrank", "Galio", "Maokai", "Rammus", "Gragas", "Wukong", "MonkeyKing", "Hecarim", "Diana", "Sion", "Skarner", "Poppy",
          "Nunu", "Kennen", "Lissandra", "Ashe", "Varus", "Annie", "Orianna", "Camille", "Pyke", "Leblanc"}
BOT_DUO = {("Draven", "Leona"), ("Draven", "Nautilus"), ("Samira", "Nautilus"), ("Samira", "Rell"), ("Kalista", "Thresh"), ("Kalista", "Renata"),
           ("Lucian", "Nami"), ("Lucian", "Braum"), ("Xayah", "Rakan"), ("Caitlyn", "Lux"), ("Caitlyn", "Morgana"), ("Jhin", "Zyra"),
           ("Ezreal", "Karma"), ("Kaisa", "Nautilus"), ("Kaisa", "Rell"), ("Tristana", "Leona"), ("Twitch", "Lulu"), ("Zeri", "Yuumi"),
           ("Jinx", "Thresh"), ("Varus", "Alistar"), ("Ashe", "Leona"), ("Senna", "Tahm Kench"), ("Nilah", "Taric")}


def _tags(champs, c):
    return (champs.get(c) or {}).get("tags") or []


def _name(champs, c):
    return (champs.get(c) or {}).get("name") or c


def comp_read(champs, team):
    """(cedo, frente, engajamento, dano fisico/magico) de uma lista de ids."""
    team = [c for c in team if c]
    early = sum(max((EARLY.get(t, 0) for t in _tags(champs, c)), default=0) for c in team)
    front = [c for c in team if "Tank" in _tags(champs, c) or ("Fighter" in _tags(champs, c) and "Assassin" not in _tags(champs, c))]
    eng = [c for c in team if c in ENGAGE]
    ad = sum(1 for c in team if (champs.get(c) or {}).get("info", {}).get("attack", 0) > (champs.get(c) or {}).get("info", {}).get("magic", 0))
    return {"early": early, "front": front, "engage": eng, "ad": ad, "ap": len(team) - ad, "n": len(team)}


def win_condition(champs, mine, theirs):
    """Ideia 1 e 2: condicao de vitoria dos dois times e quem e forte cedo/no fim."""
    a, b = comp_read(champs, mine), comp_read(champs, theirs)
    if a["n"] < 4 or b["n"] < 4:
        return None
    def cond(r):
        if len(r["engage"]) >= 2:
            return "lutar 5 contra 5 abrindo a luta com " + ", ".join(_name(champs, c) for c in r["engage"][:2])
        if r["early"] >= 2.5:
            return "ganhar cedo: pressionar rotas e objetivos antes dos 20 minutos"
        if not r["front"]:
            return "pegar alvos soltos e cercar (pick), sem luta de frente"
        return "chegar no fim com itens e lutar perto de objetivo"
    tempo = ("O seu time é mais forte cedo e o deles cresce no fim: acelere." if a["early"] - b["early"] >= 1.2 else
             "O time deles é mais forte cedo e o seu cresce no fim: segure os primeiros 20 minutos." if b["early"] - a["early"] >= 1.2 else
             "Os dois times têm força parecida no tempo.")
    ca, cb = cond(a), cond(b)
    if ca == cb:
        return f"Os dois times querem o mesmo: {ca}. Quem chegar antes no objetivo, com visão, leva. {tempo}"
    return f"Para o seu time ganhar: {ca}. O time deles quer {cb}. {tempo}"


def no_front(champs, mine, pool, position):
    """Ideia 4: time sem linha de frente ou sem engajamento, com pick do seu pool que resolve."""
    r = comp_read(champs, mine)
    if r["n"] < 3 or (r["front"] and r["engage"]):
        return None
    falta = "linha de frente" if not r["front"] else "quem abra a luta"
    fix = [c for c in pool if c not in mine and (("Tank" in _tags(champs, c) or "Fighter" in _tags(champs, c)) if not r["front"] else c in ENGAGE)]
    return f"Seu time está sem {falta}. Do seu pool, {_name(champs, fix[0])} resolve." if fix else None


def pool_vs_comp(con, pool, enemies, position, min_n=60):
    """Ideia 5: pick do seu pool que mais ganha contra a composicao inteira (amostra do alto elo)."""
    enemies = [c for c in enemies if c]
    if len(enemies) < 3 or not pool:
        return None
    best = []
    for c in pool[:6]:
        w = n = 0
        for en in enemies:
            r = con.execute("""SELECT SUM(me.win), COUNT(*) FROM participants me JOIN participants o ON o.match_id=me.match_id AND o.team_id<>me.team_id
                               JOIN match_source s ON s.match_id=me.match_id
                               WHERE s.source='top' AND me.champion=? AND o.champion=? AND me.position=?""", (c, en, position)).fetchone()
            if r and r[1]:
                w += r[0] or 0
                n += r[1]
        if n >= min_n:
            best.append(((w + 20) / (n + 40), c, round(100 * w / n), n))
    if not best:
        return None
    best.sort(reverse=True)
    s_, c, wr, n = best[0]
    if s_ < 0.51:                    # ninguem do pool ganha de verdade desse time: nao fala nada
        return None
    return c, wr, n


def revealed(con, mine, position, enemy_laner_known):
    """Ideia 7: voce travou antes do oponente: os counters que ele pode pegar."""
    if enemy_laner_known or not mine:
        return None
    from . import counters
    cl = counters.counters_of(con, mine, position, limit=3)
    return cl or None


def bot_duo(champs, enemy_team):
    """Ideia 10: dupla de baixo perigosa no time inimigo."""
    bot = next((p["champion"] for p in enemy_team if (p.get("position") or "").upper() == "BOTTOM" and p.get("champion")), None)
    sup = next((p["champion"] for p in enemy_team if (p.get("position") or "").upper() == "UTILITY" and p.get("champion")), None)
    if not bot or not sup:
        ids = [p["champion"] for p in enemy_team if p.get("champion")]
        for a, b in BOT_DUO:
            if a in ids and b in ids:
                bot, sup = a, b
                break
        else:
            return None
    if (bot, sup) in BOT_DUO or (sup in ENGAGE and bot in ("Draven", "Samira", "Kaisa", "Tristana", "Kalista", "Lucian", "Nilah")):
        return f"Dupla de baixo perigosa: {_name(champs, bot)} com {_name(champs, sup)}. Nível 2 e 3 deles matam: respeite o primeiro empurrão."
    return None


def team_summary(champs, enemies):
    """Ideia 11: em 10 segundos, a ameaca e o alvo do time deles."""
    enemies = [c for c in enemies if c]
    if len(enemies) < 5:
        return None
    threat = next((c for c in enemies if "Assassin" in _tags(champs, c)), None) or \
        next((c for c in enemies if "Marksman" in _tags(champs, c)), None) or enemies[0]
    alvo = next((c for c in enemies if c != threat and ("Marksman" in _tags(champs, c) or "Mage" in _tags(champs, c))
                 and "Tank" not in _tags(champs, c)), None)
    r = comp_read(champs, enemies)
    dano = "quase só físico" if r["ad"] >= 4 else "quase só mágico" if r["ap"] >= 4 else "misto"
    return (f"Time deles: a ameaça é {_name(champs, threat)}" + (f", o alvo é {_name(champs, alvo)}" if alvo else "")
            + f"; dano {dano}.")


def unused_spell(con, puuid, mine, position=None):
    """Ideia 12: feitico que os melhores usam com o campeao NA ROTA e voce nunca usou (sem rota, nada: Golpear no mid nao)."""
    if position not in ("TOP", "JUNGLE", "MIDDLE", "BOTTOM", "UTILITY"):
        return None
    try:
        rows = con.execute("""SELECT x.spells FROM participants p JOIN participant_extra x USING (match_id, participant_id)
                              JOIN match_source s USING (match_id) WHERE s.source='top' AND p.champion=? AND p.position=?""",
                           (mine, position)).fetchall()
        if len(rows) < 20:
            return None
        top = Counter()
        for (sp,) in rows:
            for x in json.loads(sp or "[]"):
                top[x] += 1
        mine_rows = con.execute("""SELECT x.spells FROM participants p JOIN participant_extra x USING (match_id, participant_id)
                                   WHERE p.puuid=? AND p.champion=? AND p.position=?""", (puuid, mine, position)).fetchall()
        used = set()
        for (sp,) in mine_rows:
            used |= set(json.loads(sp or "[]"))
        if len(mine_rows) < 5 or not top:
            return None
        n = len(rows)
        for sid, k in top.most_common(3):
            if sid not in used and k / max(1, n) >= .35:
                return sid, round(100 * k / n)
    except Exception:
        return None
    return None


SPELL_PT = {1: "Purificar", 3: "Exaustão", 4: "Flash", 6: "Fantasma", 7: "Curar", 11: "Golpear", 12: "Teleporte", 14: "Incendiar", 21: "Barreira"}


_SEL = {}


def select_extra(con, puuid, snap, champs, position, pool):
    """Com cache: a selecao e consultada a cada poucos segundos e as contas leem a amostra do alto elo."""
    key = (puuid, position, tuple(pool or ()), (snap.get("me") or {}).get("champion"), bool(snap.get("locked")),
           tuple(p.get("champion") for p in snap.get("my_team") or []), tuple((p.get("champion"), p.get("position")) for p in snap.get("enemy_team") or []))
    if key in _SEL:
        return _SEL[key]
    out = _select_extra(con, puuid, snap, champs, position, pool)
    if len(_SEL) > 40:
        _SEL.clear()
    _SEL[key] = out
    return out


def _select_extra(con, puuid, snap, champs, position, pool):
    """Falas extras da selecao (ideias 1, 2, 4, 5, 7, 10, 11, 12). [(chave, texto, curto)]"""
    out = []
    me = snap.get("me") or {}
    mine_c = me.get("champion")
    allies = [p.get("champion") for p in snap.get("my_team") or [] if p.get("champion")]
    foes = [p.get("champion") for p in snap.get("enemy_team") or [] if p.get("champion")]
    try:
        if not mine_c:
            pv = pool_vs_comp(con, pool, foes, position)
            if pv:
                out.append((f"selx_pvc_{pv[0]}", f"Do seu pool, o que mais ganha contra esse time inteiro no alto elo: {_name(champs, pv[0])}, {pv[1]}% em {pv[2]} jogos.",
                            f"Melhor do seu pool contra esse time: {_name(champs, pv[0])}."))
            nf = no_front(champs, allies, pool, position)
            if nf:
                out.append(("selx_front", nf, None))
        else:
            from . import draft
            en, _ = draft.enemy_laner(snap, position, draft.role_map(con))
            rv = revealed(con, mine_c, position, en) if snap.get("locked") else None     # so depois de travar de verdade (passar o mouse nao conta)
            if rv:
                out.append((f"selx_rev_{mine_c}", f"Você lockou antes do seu oponente. Cuidado com counter: "
                            + ", ".join(f"{_name(champs, c)} ({wr}%)" for c, wr, n in rv) + ".", None))
            us = unused_spell(con, puuid, mine_c, position)
            if us:
                out.append((f"selx_spell_{mine_c}", f"Os melhores de {_name(champs, mine_c)} levam {SPELL_PT.get(us[0], 'outro feitiço')} em {us[1]}% das partidas e você nunca usou.", None))
        bd = bot_duo(champs, snap.get("enemy_team") or [])
        if bd:
            out.append(("sel_duo_bot", bd, None))
        if len(foes) >= 5:
            ts = team_summary(champs, foes)
            if ts:
                out.append(("sel_resumo", ts, None))
            wc = win_condition(champs, allies, foes)
            if wc:
                out.append(("selx_wincon", wc, None))
    except Exception:
        pass
    return out


# ---------------- carregamento ----------------
SPIKE = {"Assassin": "nível 6 e o primeiro item", "Fighter": "nível 6 e o primeiro item", "Mage": "nível 6 e dois itens",
         "Marksman": "dois itens (por volta dos 20 minutos)", "Tank": "nível 6 e o primeiro item de defesa", "Support": "nível 2 e 6"}


def spike(champs, c):
    """Ideia 22: pico de força do oponente."""
    t = _tags(champs, c)
    return SPIKE.get(t[0]) if t else None


def trinket(position):
    """Ideia 21: amuleto e primeira sentinela."""
    p = (position or "").upper()
    if p == "UTILITY":
        return "Comece com o Amuleto de Sentinela. Primeira sentinela no arbusto do rio da rota de baixo aos 1:30, antes do nível 2."
    if p == "JUNGLE":
        return "Comece com o Amuleto de Sentinela e troque pela Lente depois do primeiro abate do Arauto."
    return "Comece com o Amuleto de Sentinela. Primeira sentinela no rio do seu lado aos 2:45, quando chega o primeiro gank."


# ---------------- partida ----------------
def gold_for_item(live_data, me, gt, next_cost):
    """Ideia 32: ouro para item completo no meio da luta."""
    gold = int(((live_data.get("activePlayer") or {}).get("currentGold")) or 0)
    if next_cost and gold >= next_cost and gt >= 360:
        return f"Você já tem ouro para o item completo ({gold}). Saindo da luta, volte para a base."
    return None


# ---------------- pos-jogo ----------------
def _frames(con, mid):
    out = defaultdict(dict)
    for pid, mn, gold, x, y in con.execute("SELECT participant_id, minute, gold, x, y FROM frames WHERE match_id=?", (mid,)):
        out[pid][mn] = (gold or 0, x, y)
    return out


def phase_grades(con, mid, my_pid, my_team):
    """Ideia 48: nota da fase de rotas, do meio e do fim (pelo ouro do time)."""
    fr = _frames(con, mid)
    teams = dict(con.execute("SELECT participant_id, team_id FROM participants WHERE match_id=?", (mid,)).fetchall())
    def diff(mn):
        a = sum(fr[p].get(mn, (0, 0, 0))[0] for p, t in teams.items() if t == my_team)
        b = sum(fr[p].get(mn, (0, 0, 0))[0] for p, t in teams.items() if t != my_team)
        return a - b
    mx = max((m for p in fr for m in fr[p]), default=0)
    if mx < 15:
        return None
    lane = diff(14)
    mid_ = diff(min(25, mx)) - lane
    end = diff(mx) - diff(min(25, mx)) if mx > 25 else None
    nota = lambda d: max(0, min(100, 50 + d / 80))
    return [("Fase de rotas (até 14)", lane, nota(lane)), ("Meio (14 a 25)", mid_, nota(mid_))] + ([("Fim (25+)", end, nota(end))] if end is not None else [])


def phase_html(pg):
    if not pg:
        return ""
    rows = "".join(f"<div class='xp-row'><span>{e(n)}</span><div class='xp-bar'><i style='width:{v:.0f}%;background:{'#7CCB98' if d >= 0 else '#EE8A8F'}'></i></div>"
                   f"<b>{v:.0f}</b><small>{'+' if d >= 0 else '−'}{abs(d) / 1000:.1f}k de ouro do time</small></div>" for n, d, v in pg)
    return f"<div class='card'><h3>Nota por fase</h3><p class='sub'>Pelo ouro do seu time contra o deles em cada fase.</p>{rows}</div>"


def dead_time(con, mid, my_pid, my_cpm=None):
    """Ideia 51: tempo morto total e o ouro que custou (respawn aproximado pelo minuto)."""
    ts = [r[0] for r in con.execute("SELECT t_ms FROM deaths WHERE match_id=? AND victim_id=?", (mid, my_pid)).fetchall()]
    if not ts:
        return None
    resp = lambda m: 6 + min(m, 40) * 1.1                  # aproximacao do tempo de renascer por minuto de jogo
    secs = sum(resp(t / 60000) for t in ts)
    gpm = 380 if my_cpm is None else 200 + my_cpm * 21
    return int(secs), int(secs / 60 * gpm)


def _has_col(con, tb, col):
    try:
        return col in [r[1] for r in con.execute(f"PRAGMA table_info({tb})")]
    except Exception:
        return False


def build_vs_top(con, mid, my_pid, champion, position, items_data):
    """Ideia 50: sua build contra a dos melhores no mesmo campeao, item por item."""
    from . import builds
    mine = [i for t, i in builds._purchases(con, mid, my_pid) if builds.is_complete(items_data, i)]
    seen = []
    for i in mine:
        if i not in seen:
            seen.append(i)
    rows = builds.top_rows(con, champion, position)
    if len(rows) < builds.MIN_ROWS or not seen:
        return None
    st = builds.item_stats(con, rows, items_data)
    top = builds.clean_build(st, items_data, champion, position)["order"][:4]
    return seen[:4], top[:4]


def build_vs_html(bv, items_data, icon):
    if not bv:
        return ""
    mine, top = bv
    def row(lbl, ids):
        return f"<div class='xb-row'><span>{e(lbl)}</span>" + "".join(
            f"<span class='xb-i{' ok' if i in top else ''}' title='{e((items_data.get(str(i)) or {}).get('name'))}'>{icon(i)}</span>" for i in ids) + "</div>"
    same = len(set(mine[:3]) & set(top[:3]))
    return (f"<div class='card'><h3>Sua build contra a dos melhores</h3><p class='sub'>{same} dos 3 primeiros itens iguais aos dos melhores com o mesmo campeão.</p>"
            + row("Você", mine) + row("Os melhores", top) + "</div>")


def where_at_objectives(con, mid, my_pid, my_team):
    """Ideia 52: onde voce estava em cada objetivo grande."""
    out = []
    try:
        evs = con.execute("SELECT t_ms, team_id, x, y, data FROM events WHERE match_id=? AND type='ELITE_MONSTER_KILL' ORDER BY t_ms", (mid,)).fetchall()
    except Exception:
        return out
    fr = _frames(con, mid)
    from . import vod
    for t, team, ex, ey, d in evs:
        d = json.loads(d or "{}")
        mn = int(round(t / 60000))
        f = fr.get(my_pid, {}).get(mn) or fr.get(my_pid, {}).get(int(t // 60000))
        if not f or f[1] is None or ex is None:
            continue
        dist = ((f[1] - ex) ** 2 + (f[2] - ey) ** 2) ** .5
        nome = {"DRAGON": "Dragão", "BARON_NASHOR": "Barão", "RIFTHERALD": "Arauto", "HORDE": "Larvas", "ATAKHAN": "Atakhan"}.get(d.get("monsterType"), "Objetivo")
        ours = (team or d.get("killerTeamId")) == my_team
        out.append((t, nome, ours, dist < 3500, vod.zona(f[1], f[2])))
    return out


def where_html(rows):
    if not rows:
        return ""
    li = "".join(f"<li><b>{int(t // 60000)}:{int(t % 60000 // 1000):02d}</b> {e(n)} {'nosso' if o else 'deles'} · "
                 + ("<span class='win'>você estava perto</span>" if near else f"<span class='loss'>você estava longe ({e(z)})</span>") + "</li>"
                 for t, n, o, near, z in rows)
    return f"<div class='card'><h3>Onde você estava nos objetivos</h3><p class='sub'>Pela foto de cada minuto da Riot.</p><ul class='xl'>{li}</ul></div>"


def vision_by_phase(con, mid, my_pid, champion, position):
    """Ideia 54: sentinelas por fase contra a media dos melhores."""
    def phases(m, p):
        c = [0, 0, 0]
        for (t,) in con.execute("SELECT t_ms FROM wards WHERE match_id=? AND participant_id=? AND COALESCE(ward_type,'')<>'UNDEFINED'", (m, p)):
            c[0 if t < 840000 else 1 if t < 1500000 else 2] += 1
        return c
    mine = phases(mid, my_pid)
    from . import builds
    rows = builds.top_rows(con, champion, position)[:40]
    if len(rows) < 8:
        return mine, None
    tot = [0, 0, 0]
    for r in rows:
        for i, v in enumerate(phases(r["match_id"], r["participant_id"])):
            tot[i] += v
    return mine, [round(v / len(rows), 1) for v in tot]


def vision_html(v):
    if not v:
        return ""
    mine, top = v
    lab = ["Até 14 min", "14 a 25", "25+"]
    rows = "".join(f"<tr><td>{lab[i]}</td><td>{mine[i]}</td><td>{top[i] if top else '—'}</td></tr>" for i in range(3))
    return (f"<div class='card'><h3>Visão por fase</h3><p class='sub'>Sentinelas colocadas, você contra a média dos melhores com o mesmo campeão.</p>"
            f"<table><thead><tr><th>Fase</th><th>Você</th><th>Os melhores</th></tr></thead><tbody>{rows}</tbody></table></div>")


def similar_match(con, puuid, mid, champion, opp):
    """Ideia 58: uma partida antiga sua no mesmo confronto."""
    r = con.execute("""SELECT me.match_id, me.win, me.kills, me.deaths, me.assists FROM participants me
                       JOIN participants o ON o.match_id=me.match_id AND o.team_id<>me.team_id AND o.position=me.position
                       JOIN matches m ON m.match_id=me.match_id
                       WHERE me.puuid=? AND me.champion=? AND o.champion=? AND me.match_id<>? ORDER BY m.started_ms DESC LIMIT 1""",
                    (puuid, champion, opp, mid)).fetchone()
    return r


def ensure_tables(con):
    con.execute("CREATE TABLE IF NOT EXISTS death_tags (match_id TEXT, t_ms INTEGER, tag TEXT, PRIMARY KEY (match_id, t_ms))")
    con.execute("CREATE TABLE IF NOT EXISTS mood (at_ms INTEGER PRIMARY KEY, kind TEXT, value TEXT, match_id TEXT)")
    con.commit()


def mark_death(con, mid, t_ms, tag):
    """Ideia 59: marcar uma morte como 'azar' (sai das contas de erro)."""
    ensure_tables(con)
    con.execute("INSERT OR REPLACE INTO death_tags VALUES (?,?,?)", (mid, int(t_ms), tag))
    con.commit()


def death_tags(con, mid):
    ensure_tables(con)
    return dict(con.execute("SELECT t_ms, tag FROM death_tags WHERE match_id=?", (mid,)).fetchall())


PRINT_CSS = ("@media print{.side,.subnav,.subnav2,.topbar,#jobarea,.btn,button,form,.updbar,.tour{display:none !important}"
             "body,main{background:#fff !important;color:#000 !important}main{max-width:none !important;padding:0 !important}"
             ".card,.hpn,.gc{break-inside:avoid;background:#fff !important;color:#000 !important;border-color:#ccc !important}"
             "*{color:#000 !important;box-shadow:none !important}}")


def pdf_button():
    """Ideia 60: exportar a revisao em PDF (pelo 'Salvar como PDF' do Windows)."""
    return ("<button type='button' class='btn ghost' onclick='window.print()' style='width:auto'>Salvar a revisão em PDF</button>"
            f"<style>{PRINT_CSS}</style>")


# ---------------- evolucao ----------------
def best_games(games, n=5):
    """Ideia 68: as suas melhores partidas para assistir (pela nota do app)."""
    from . import postmore
    sc = []
    for g in games[:150]:
        try:
            s = postmore.score(g)
            sc.append((s.get("total") if isinstance(s, dict) else s, g))
        except Exception:
            pass
    sc = [x for x in sc if x[0] is not None]
    sc.sort(key=lambda x: -x[0])
    return sc[:n]


def best_html(bg):
    if not bg:
        return ""
    li = "".join(f"<li><a href='/partida/{e(g['match_id'])}'><b>{e(g['champion'])}</b> contra {e(g.get('opp_champion') or '?')} · "
                 f"{g['kills']}/{g['deaths']}/{g['assists']} · nota <b>{int(s)}</b></a></li>" for s, g in bg)
    return f"<div class='card'><h3>Seus melhores jogos</h3><p class='sub'>Assista estes: é o seu jogo quando dá certo.</p><ol class='xl'>{li}</ol></div>"


TYPE_PT = {"Assassin": "assassinos", "Mage": "magos", "Fighter": "lutadores", "Tank": "tanques", "Marksman": "atiradores", "Support": "suportes"}


def by_opp_type(games, champs):
    """Ideia 74: winrate por tipo de oponente de rota."""
    by = defaultdict(lambda: [0, 0])
    for g in games:
        t = _tags(champs, g.get("opp_champion"))
        if t:
            by[t[0]][0] += 1 if g["win"] else 0
            by[t[0]][1] += 1
    return sorted(((TYPE_PT.get(k, k), round(100 * w / n), n) for k, (w, n) in by.items() if n >= 8), key=lambda x: -x[1])


_JGT = {}


def by_ally_jungler_type(con, puuid):
    """Ideia 73: winrate por tipo de jungler aliado (ganka cedo x farma), pelos dados da Riot de cada partida."""
    n_ = con.execute("SELECT COUNT(*) FROM participants WHERE puuid=?", (puuid,)).fetchone()[0]
    hit = _JGT.get(puuid)
    if hit and hit[0] == n_:
        return hit[1]
    res = _by_ally_jungler_type(con, puuid)
    _JGT[puuid] = (n_, res)
    return res


def _by_ally_jungler_type(con, puuid):
    from . import db
    w = defaultdict(lambda: [0, 0])
    for mid, win, team in con.execute("SELECT match_id, win, team_id FROM participants WHERE puuid=? ORDER BY match_id DESC LIMIT 120", (puuid,)):
        try:
            raw = db.load_raw(con, mid, "match")
            info = (raw or {}).get("info") or {}
            jg = next((p for p in info.get("participants") or [] if p.get("teamId") == team and p.get("teamPosition") == "JUNGLE"), None)
            if not jg:
                continue
            early = (jg.get("challenges") or {}).get("killsOnLanersEarlyJungleAsJungler")
            if early is None:
                continue
            k = "ganka cedo" if early >= 1 else "farma"
            w[k][0] += 1 if win else 0
            w[k][1] += 1
        except Exception:
            continue
    return {k: (round(100 * a / b), b) for k, (a, b) in w.items() if b >= 5}


def types_html(opp, jgt):
    if not opp and not jgt:
        return ""
    a = "".join(f"<li>Contra {e(t)}: <b class='{'win' if wr >= 50 else 'loss'}'>{wr}%</b> <small>({n} jogos)</small></li>" for t, wr, n in opp)
    b = "".join(f"<li>Caçador aliado que {e(k)}: <b class='{'win' if v[0] >= 50 else 'loss'}'>{v[0]}%</b> <small>({v[1]} jogos)</small></li>" for k, v in jgt.items())
    return (f"<div class='card'><h3>Contra quem e com quem você ganha</h3><p class='sub'>Pelo tipo do oponente de rota e pelo estilo do seu caçador.</p>"
            f"<ul class='xl'>{a}{b}</ul></div>")


LESSONS = {
    "d10": ("Não morrer antes dos 10", ["Antes de cada troca, olhe o minimapa: onde está o caçador deles?", "Com a onda do lado deles, você está exposto: recue até a metade da rota.",
            "Troque só quando o oponente gastar a habilidade principal.", "Exercício: 3 partidas com a meta de no máximo 1 morte antes dos 10."]),
    "cs": ("Farm aos 10", ["Último golpe vale mais que troca enquanto o oponente tem as habilidades prontas.", "Use a habilidade nos minions que o ataque básico não alcança.",
           "Volte para a base com a onda empurrada para não perder minions.", "Exercício: modo de treino, 5 minutos, só ataque básico."]),
    "vis": ("Visão", ["Compre Sentinela de Controle em toda volta.", "Amuleto no rio aos 2:45 e antes de cada objetivo.",
            "Depois dos 14, troque para a Lente se for suporte ou caçador.", "Exercício: 3 partidas com pelo menos 1 sentinela de controle por volta."]),
    "deep": ("Morrer avançado", ["Depois dos 15, só passe do rio com o time ou com visão.", "Se 2 inimigos sumiram, recue.", "Empurre a onda do lado só quando souber onde está o caçador deles."]),
}


def lesson_html(top_key):
    """Ideia 64: mini-aula de 3 minutos sobre o seu maior buraco."""
    l = LESSONS.get(top_key) or LESSONS["d10"]
    li = "".join(f"<li>{e(x)}</li>" for x in l[1])
    return f"<div class='card'><h3>Mini-aula · {e(l[0])}</h3><p class='sub'>3 minutos de leitura, feita para o seu erro que mais pesa.</p><ol class='xl'>{li}</ol></div>"


def weekly_letter(gs_week, gs_prev, name):
    """Ideia 62: carta do coach da semana (texto montado com os seus números; a IA reescreve se tiver chave)."""
    if not gs_week:
        return None
    wr = lambda g: round(100 * sum(1 for x in g if x["win"]) / len(g)) if g else None
    d10 = lambda g: (sum(x.get("deaths_before_10") or 0 for x in g) / len(g)) if g else None
    a, b = wr(gs_week), wr(gs_prev)
    txt = [f"{name}, esta semana foram {len(gs_week)} partidas com {a}% de vitória" + (f" (a passada: {b}%)." if b is not None else ".")]
    da, db_ = d10(gs_week), d10(gs_prev)
    if da is not None and db_ is not None:
        f1 = lambda x: f"{x:.1f}".replace(".", ",")
        if abs(da - db_) < 0.15:
            txt.append(f"As mortes antes dos 10 ficaram iguais: {f1(da)} por partida.")
        else:
            txt.append(("As mortes antes dos 10 caíram" if da < db_ else "As mortes antes dos 10 subiram") + f": {f1(da)} contra {f1(db_)} na semana passada.")
    best = Counter(g["champion"] for g in gs_week if g["win"]).most_common(1)
    if best:
        txt.append(f"O campeão que mais te deu vitória foi {best[0][0]}.")
    txt.append("Foco da próxima semana: o seu erro principal no Diagnóstico, uma partida de cada vez.")
    return " ".join(txt)


# ---------------- rotina ----------------
MOODS = [("bem", "Bem"), ("cansado", "Cansado ou com sono"), ("fome", "Com fome"), ("irritado", "Irritado")]


def mood_save(con, kind, value, mid=None):
    ensure_tables(con)
    con.execute("INSERT OR REPLACE INTO mood VALUES (?,?,?,?)", (int(time.time() * 1000), kind, value, mid))
    con.commit()


def mood_stats(con, puuid):
    """Ideia 76: winrate por estado antes da fila (liga o check a proxima partida jogada)."""
    ensure_tables(con)
    chk = con.execute("SELECT at_ms, value FROM mood WHERE kind='antes' ORDER BY at_ms").fetchall()
    if not chk:
        return {}
    games = con.execute("""SELECT m.started_ms, p.win FROM participants p JOIN matches m USING (match_id) WHERE p.puuid=? ORDER BY m.started_ms""",
                        (puuid,)).fetchall()
    out = defaultdict(lambda: [0, 0])
    for at, v in chk:
        g = next((w for s, w in games if s and at <= s <= at + 3 * 3600 * 1000), None)
        if g is not None:
            out[v][0] += 1 if g else 0
            out[v][1] += 1
    return {k: (round(100 * a / b), b) for k, (a, b) in out.items()}


def mood_html(con, puuid, csrf):
    st = mood_stats(con, puuid)
    btn = "".join(f"<button name='v' value='{k}' class='btn ghost' style='width:auto'>{e(t)}"
                  + (f" <small>({st[k][0]}% em {st[k][1]})</small>" if k in st else "") + "</button>" for k, t in MOODS)
    return (f"<div class='card'><h3>Como você está antes da fila?</h3><p class='sub'>10 segundos. Com o tempo o app mostra quanto você ganha em cada estado.</p>"
            f"<form method='post' action='/humor' class='row' style='flex-wrap:wrap;gap:8px'><input type='hidden' name='k' value='antes'>"
            f"{btn}</form></div>")


def feel_html(mid, csrf):
    """Ideia 81: registro de sentimento depois da partida (1 clique)."""
    opts = [("tilt", "Tiltei"), ("normal", "Normal"), ("focado", "Focado")]
    btn = "".join(f"<button name='v' value='{k}' class='btn ghost' style='width:auto'>{t}</button>" for k, t in opts)
    return (f"<form method='post' action='/humor' class='row' style='gap:8px;flex-wrap:wrap;margin:8px 0'><span class='n'>Como você jogou esta?</span>"
            f"<input type='hidden' name='k' value='depois'><input type='hidden' name='mid' value='{e(mid)}'>{btn}</form>")


def session_minutes(con, puuid):
    """Minutos desde o comeco da sessao atual (partidas com menos de 1 h de intervalo)."""
    rows = con.execute("""SELECT m.started_ms, COALESCE(m.duration_s,0) FROM participants p JOIN matches m USING (match_id)
                          WHERE p.puuid=? ORDER BY m.started_ms DESC LIMIT 15""", (puuid,)).fetchall()
    if not rows:
        return 0
    now = time.time() * 1000
    if now - (rows[0][0] + rows[0][1] * 1000) > 3600 * 1000:
        return 0
    start = rows[0][0]
    for i in range(1, len(rows)):
        if start - (rows[i][0] + rows[i][1] * 1000) > 3600 * 1000:
            break
        start = rows[i][0]
    return int((now - start) / 60000)


def routine_cues(con, puuid, today, so_uma=False):
    """Ideias 77, 78, 79 e 80 no saguao. today: o resumo de pregame.today. [(chave, texto)]"""
    out = []
    mins = session_minutes(con, puuid)
    if mins >= 120:
        out.append((f"lobby_pausa2h_{mins // 120}", f"Você está jogando há {mins // 60} horas seguidas. Pausa de 10 minutos: água, levante, olhe longe da tela."))
    w, n, lim = today.get("w", 0), today.get("n", 0), today.get("limit") or 3
    if 2 <= n < lim and w == n:
        out.append((f"lobby_boa_{n}", f"{w} vitórias seguidas hoje. Sequência boa, mas o limite do dia continua {lim}: pare no limite mesmo ganhando."))
    if so_uma and n >= 1:
        out.append((f"lobby_souma_{n}", "Modo só uma: você combinou jogar uma partida hoje. Fecha o jogo e volta amanhã."))
    return out


# ---------------- produto ----------------
def status_checks(ddir):
    """Ideia 93: status dos servicos que o app usa."""
    import urllib.request
    out = []
    for nome, url in (("Data Dragon (imagens e dados do jogo)", "https://ddragon.leagueoflegends.com/api/versions.json"),
                      ("Riot (partidas e elo)", "https://br1.api.riotgames.com/lol/status/v4/platform-data"),
                      ("Google Gemini (IA e voz)", "https://generativelanguage.googleapis.com/"),
                      ("ElevenLabs (voz)", "https://api.elevenlabs.io/")):
        t0 = time.time()
        try:
            urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "Carry-app"}), timeout=6)
            ok = True
        except Exception as ex:
            ok = getattr(ex, "code", None) in (401, 403, 404)       # respondeu: o servico esta no ar
        out.append((nome, ok, int((time.time() - t0) * 1000)))
    return out


def status_html(rows):
    li = "".join(f"<li><b class='{'win' if ok else 'loss'}'>{'no ar' if ok else 'fora do ar'}</b> · {e(n)} <small>({ms} ms)</small></li>" for n, ok, ms in rows)
    return f"<div class='card'><h3>Status dos serviços</h3><p class='sub'>Se algo não funciona, veja aqui se é do Carry ou de fora.</p><ul class='xl'>{li}</ul></div>"


CSS = """.xp-row{display:grid;grid-template-columns:170px 1fr 44px minmax(120px,auto);gap:12px;align-items:center;margin:6px 0}
.xp-bar{height:8px;background:#262335}.xp-bar i{display:block;height:100%}.xp-row b{font-family:'Chakra Petch',monospace}.xp-row small{color:var(--steel)}
.xb-row{display:flex;align-items:center;gap:8px;margin:6px 0}.xb-row>span:first-child{width:110px;color:var(--steel)}
.xb-i img{width:34px;height:34px;border:1px solid #3A3550;display:block}.xb-i.ok img{border-color:#7CCB98}
.xl{margin:6px 0 0;padding-left:20px}.xl li{margin:4px 0}.xl a{text-decoration:none;color:inherit}.xl a:hover{color:var(--gold)}"""


# ---------------- carregamento com o scout ----------------
def history_vs(con, my_puuid, rows):
    """Ideia 16: o seu historico contra esses jogadores (partidas que estao na sua base)."""
    out = []
    for r in rows or []:
        pu = r.get("puuid")
        if not pu:
            continue
        q = con.execute("""SELECT me.win, o.team_id<>me.team_id FROM participants me JOIN participants o ON o.match_id=me.match_id AND o.puuid=?
                           WHERE me.puuid=?""", (pu, my_puuid)).fetchall()
        vs = [w for w, foe in q if foe]
        if vs:
            w = sum(1 for x in vs if x)
            out.append(f"Você já enfrentou {r['name']} {len(vs)} vez{'es' if len(vs) > 1 else ''}: {w} vitória{'s' if w != 1 else ''} e {len(vs) - w} derrota{'s' if len(vs) - w != 1 else ''}.")
    return out[:2]


def jungle_side_cue(rows, my_pos, gt):
    """Ideia 24: pelo lado em que o cacador deles comeca, de onde vem o primeiro gank."""
    jr = next((r for r in rows or [] if r.get("start")), None)
    if not jr or not (60 <= gt <= 200):
        return None
    sd = jr["start"][0]
    fim = "baixo" if sd == "cima" else "cima"
    alvo = {"cima": ("TOP",), "baixo": ("BOTTOM", "UTILITY")}[fim]
    perto = (my_pos or "").upper() in alvo
    return (f"O caçador deles, {jr['name']}, costuma começar por {sd}: a primeira volta termina por {fim} por volta dos 3:15."
            + (" Esse lado é o seu: sentinela no rio e cuidado aos 3 minutos." if perto else " O meio deve ver ele cruzar o rio por volta dos 3:30." if (my_pos or "").upper() == "MIDDLE" else ""))


# ---------------- overlay ----------------
_URG = ("cuidado", "recue", "caçador deles", "caçador inimigo", "barão", "ancião", "inibidor", "peguem", "não lute", "a menos",
        "jogue para trás", "volte", "sumiu", "perto de você", "contra 1", "luta ")


def urgent_text(t):
    """Ideia 91: frase urgente (usa a segunda voz, se escolhida)."""
    t = (t or "").lower()
    return any(w in t for w in _URG)


PROFILES = {
    "ranqueada": ("Ranqueada (completo)", {"voz_essencial": 1, "a_det": 1, "a_select": 1, "a_role": 1, "a_mytips": 1, "panel": 1, "balao": 1}),
    "foco": ("Foco (só o essencial)", {"voz_essencial": 1, "a_det": 0, "a_role": 0, "a_mytips": 0, "a_farm": 0, "a_habit": 0, "a_events": 0, "panel": 0, "plan": 0, "lanes": 0}),
    "treino": ("Treino (fala tudo)", {"voz_essencial": 0, "a_det": 1, "a_role": 1, "a_mytips": 1, "a_farm": 1, "a_habit": 1, "a_events": 1, "panel": 1, "plan": 1, "lanes": 1}),
}


def profiles_html(cur):
    """Ideia 90: perfis de aviso trocados com um clique."""
    btn = "".join(f"<button name='p' value='{k}' class='btn {'gold' if k == cur else 'ghost'}' style='width:auto'>{e(n)}</button>"
                  for k, (n, _) in PROFILES.items())
    return (f"<div class='card'><h3>Perfis de aviso</h3><p class='sub'>Troque tudo com um clique. Você ainda pode ajustar cada item abaixo.</p>"
            f"<form method='post' action='/overlay/perfil' class='row' style='gap:8px;flex-wrap:wrap'>{btn}</form></div>")


# ---------------- patch (ideias 71 e 72) ----------------
def _pk(p):
    try:
        return tuple(int(x) for x in str(p).split(".")[:2])
    except ValueError:
        return (0, 0)


def patch_shift(con, champion, min_n=25):
    """Winrate do campeao no alto elo no patch novo contra o anterior: (patch_novo, wr_novo, n_novo, patch_velho, wr_velho, n_velho)."""
    by = defaultdict(lambda: [0, 0])
    for patch, win in con.execute("""SELECT m.patch, p.win FROM participants p JOIN matches m USING (match_id) JOIN match_source s USING (match_id)
                                     WHERE s.source='top' AND p.champion=?""", (champion,)):
        k = ".".join(str(patch or "").split(".")[:2])
        if k:
            by[k][0] += 1 if win else 0
            by[k][1] += 1
    ps = sorted(by, key=_pk, reverse=True)
    if len(ps) < 2:
        return None
    a, b = ps[0], ps[1]
    if by[a][1] < min_n or by[b][1] < min_n:
        return None
    return a, round(100 * by[a][0] / by[a][1]), by[a][1], b, round(100 * by[b][0] / by[b][1]), by[b][1]


def patch_html(con, mains, items_data, icon, position):
    cards = []
    for c in mains[:3]:
        sh = patch_shift(con, c)
        txt = ""
        if sh:
            d = sh[1] - sh[4]
            tag = ("<b class='win'>subiu</b>" if d >= 2 else "<b class='loss'>caiu</b>" if d <= -2 else "ficou igual")
            txt = (f"<p>No alto elo, o {e(c)} {tag}: {sh[4]}% no patch {e(sh[3])} ({sh[5]} jogos) e {sh[1]}% no {e(sh[0])} ({sh[2]} jogos)."
                   + (" Mudança grande: leia as notas do patch antes de jogar." if abs(d) >= 3 else "") + "</p>")
        try:
            from . import builds
            rows = builds.top_rows(con, c, position)
            st = builds.item_stats(con, rows, items_data) if len(rows) >= builds.MIN_ROWS else None
        except Exception:
            st = None
        its = ""
        if st and st["order"] and st["order"][0]:
            ids = builds.full_build(st)[:3]
            its = "<div class='xb-row'><span>Build do patch</span>" + "".join(f"<span class='xb-i'>{icon(i)}</span>" for i in ids) + "</div>"
        if txt or its:
            cards.append(f"<div class='card'><h3>{e(c)} no patch novo</h3>{txt}{its}<p class='sub'>Amostra do alto elo guardada no app.</p></div>")
    return "".join(cards)


def souma_html(on):
    """Ideia 80: modo so uma partida hoje."""
    return (f"<div class='card'><h3>Modo só uma</h3><p class='sub'>{'Ligado hoje: depois desta partida o coach avisa para parar.' if on else 'Para os dias em que você quer jogar uma partida e parar.'}</p>"
            f"<form method='post' action='/souma'><button class='btn {'ghost' if on else 'gold'}' style='width:auto'>{'Desligar' if on else 'Hoje só uma'}</button></form></div>")
