"""Abre o Carry na janela dele (duplo clique). Use --fundo para nao abrir a janela (--aguardar: espera o app antigo fechar).

Se o app ja estiver rodando, so abre o navegador na tela dele.
"""
import os
import socket
import sys
import webbrowser

AQUI = os.path.dirname(os.path.abspath(__file__))
os.chdir(AQUI)
sys.path.insert(0, AQUI)
PORTA = 8765


def em_uso():
    with socket.socket() as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", PORTA)) == 0


if __name__ == "__main__":
    if "--abertura" in sys.argv:      # tela de abertura (processo separado): confere atualizacao e espera a janela abrir
        from coach import abertura
        abertura.run(rapida="--rapida" in sys.argv)
        sys.exit(0)
    fundo = "--fundo" in sys.argv
    if "--guia" in sys.argv:          # primeira vez (vindo do instalador): abre direto no passo a passo
        os.environ["CARRY_OPEN_PATH"] = "/guia"
    if "--aguardar" in sys.argv:  # vindo do botao Reiniciar: espera o app antigo fechar
        import time
        for _ in range(30):
            if not em_uso():
                break
            time.sleep(0.5)
        if em_uso():  # o antigo travou: encerra pelo numero do processo que ele mesmo anotou
            try:
                pid = int(open(os.path.join(AQUI, "coach.pid")).read().strip())
                if pid != os.getpid():
                    import subprocess
                    subprocess.run(["taskkill", "/PID", str(pid), "/F"], capture_output=True, creationflags=0x08000000)
            except Exception:
                pass
            for _ in range(20):
                if not em_uso():
                    break
                time.sleep(0.5)
    if em_uso():
        if not fundo:
            try:                      # o app ja roda em segundo plano: mostra a abertura rapida antes da janela
                import subprocess
                exe = sys.executable.replace("python.exe", "pythonw.exe") if sys.executable.lower().endswith("python.exe") else sys.executable
                subprocess.Popen([exe, os.path.abspath(__file__), "--abertura", "--rapida"], cwd=AQUI,
                                 creationflags=0x08000000 if os.name == "nt" else 0)
                import time
                time.sleep(1.2)
            except Exception:
                pass
            url = f"http://127.0.0.1:{PORTA}" + (os.environ.get("CARRY_OPEN_PATH") or "/launcher")
            try:
                from coach import janela          # janela propria do Carry (cai no navegador se nao der)
                janela.abrir(url)
            except Exception:
                webbrowser.open(url)
        sys.exit(0)
    if not fundo and "--sem-abertura" not in sys.argv:
        try:
            import subprocess
            exe = sys.executable.replace("python.exe", "pythonw.exe") if sys.executable.lower().endswith("python.exe") else sys.executable
            subprocess.Popen([exe, os.path.abspath(__file__), "--abertura"], cwd=AQUI, creationflags=0x08000000 if os.name == "nt" else 0)
            from coach import abertura
            abertura.esperar_ok()
        except Exception:
            pass
    # sem console: manda a saida para um arquivo de log
    log = open(os.path.join(AQUI, "coach.log"), "a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stderr = log
    from coach.__main__ import main
    main(["app", "--port", str(PORTA)] + (["--no-browser"] if fundo else []))
